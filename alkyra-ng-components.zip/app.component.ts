import { AppInfoService } from '@alkyra/infrastructure-services/app-info.service';
import { RabbitMqInitializerService } from '@alkyra/infrastructure-services/rabbitmq-initializer.service';
import { ScreenService } from '@alkyra/infrastructure-services/screen.service';
import { TenantService } from '@alkyra/infrastructure-services/tenant.service';
import { AppLayoutComponent } from '@alkyra/layouts/app-layout/app-layout.component';
import { ScreenLockStore } from '@alkyra/screen-lock/+store/screen-lock.store';
import { ScreenLockComponent } from '@alkyra/screen-lock/screen-lock.component';
import { UserStore } from '@alkyra/user/user.store';
import { Component, HostBinding, inject, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, NavigationStart, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { OAuthService } from 'angular-oauth2-oidc';
import { filter } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  standalone: true,
  imports: [AppLayoutComponent, ScreenLockComponent],
})
export class AppComponent implements OnInit {
  @HostBinding('class') get getClass() {
    const sizeClassName = Object.keys(this.screen.sizes)
      .filter((cl) => this.screen.sizes[cl])
      .join(' ');
    return `${sizeClassName} app`;
  }

  private readonly authService: OAuthService = inject(OAuthService);
  private readonly screen: ScreenService = inject(ScreenService);
  public appInfo: AppInfoService = inject(AppInfoService);
  private readonly _router = inject(Router);
  private readonly _screenLockStore = inject(ScreenLockStore);
  private readonly translate: TranslateService = inject(TranslateService);
  private readonly _userStore = inject(UserStore);
  private readonly rabbitmqInitializer = inject(RabbitMqInitializerService);
  private readonly tenantService = inject(TenantService);

  constructor() {
    this._router.events
      .pipe(filter((event) => event instanceof NavigationStart || event instanceof NavigationEnd))
      .subscribe((event) => {
        if (event instanceof NavigationStart) {
          this._screenLockStore.lockScreen();
        } else if (event instanceof NavigationEnd) {
          const currentRoute = this.getCurrentRoute(this._router.routerState.root);
          const autoUnlock = currentRoute.snapshot.data['autoUnlock'] ?? true;

          this._screenLockStore.setAutoUnlock(autoUnlock);

          if (autoUnlock) {
            this._screenLockStore.unlockScreen();
          }
        }
      });
  }

  ngOnInit() {
    const storedLang = this._userStore.language();
    if (storedLang) {
      this.translate.use(storedLang);
    } else {
      const browserLang = this.translate.getBrowserLang();
      const defaultLang = browserLang?.match(/en|es/) ? browserLang : 'en';
      this.translate.use(defaultLang);
      this._userStore.setLanguage(defaultLang);
    }

    // Initialize RabbitMQ if user is already logged in (e.g., after page refresh)
    if (this.loggedIn()) {
      this.tenantService.refreshTenantId();
      this.rabbitmqInitializer.initializeAfterAuth().subscribe();
    }

    // Subscribe to OAuth events for both initial login and token refresh
    this.authService.events
      .pipe(filter((e) => e.type === 'token_received' || e.type === 'token_refreshed'))
      .subscribe(() => {
        this.tenantService.refreshTenantId();
        this.rabbitmqInitializer.initializeAfterAuth().subscribe();
      });
  }

  private getCurrentRoute(route: ActivatedRoute): ActivatedRoute {
    while (route.firstChild) {
      route = route.firstChild;
    }
    return route;
  }

  loggedIn() {
    return this.authService.hasValidAccessToken();
  }
}
