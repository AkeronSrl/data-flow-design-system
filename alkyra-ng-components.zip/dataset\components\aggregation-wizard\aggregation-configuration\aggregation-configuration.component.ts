import { TiaraSectionPanelComponent } from '@akeron-ng/tiara-ng/tiara-section-panel';
import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { AggregationColumn, AggregationFunction } from '@alkyra/dataset/models/dataset-aggregation.model';
import { DatasetColumn } from '@alkyra/dataset/models/dataset-column.model';
import { DatasetService } from '@alkyra/dataset/services/dataset.service';
import { DatasetColumnFormulaService } from '@alkyra/dataset/services/dataset-column-formula.service';
import {
  ExpressionEditorConfig,
  ExpressionValidationState,
} from '@alkyra/ui/smart-expression-editor/models/expression-editor.model';
import { SmartExpressionEditorComponent } from '@alkyra/ui/smart-expression-editor/smart-expression-editor.component';
import { ValidationResult } from '@alkyra/validation/models/validation-result.model';
import { ChangeDetectionStrategy, Component, computed, inject, OnDestroy, OnInit, Signal, signal } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { SelectionChangedEvent } from 'devextreme/ui/select_box';
import { ValueChangedEvent } from 'devextreme/ui/text_box';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxFormModule } from 'devextreme-angular/ui/form';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { lastValueFrom } from 'rxjs';

import { WizardAggregationStore } from '../+store/wizard-aggregation.store';

@Component({
  selector: 'alk-aggregation-configuration',
  templateUrl: './aggregation-configuration.component.html',
  styleUrls: ['./aggregation-configuration.component.scss'],
  standalone: true,
  imports: [
    TiaraSuiteWizardStepComponent,
    TiaraSectionPanelComponent,
    TranslatePipe,
    DxSelectBoxModule,
    DxButtonModule,
    DxTextBoxModule,
    DxFormModule,
    SmartExpressionEditorComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AggregationConfigurationComponent extends WizardStep implements OnInit, OnDestroy {
  private readonly _wizardJoinStore = inject(WizardAggregationStore);
  private readonly _datasetService = inject(DatasetService);
  private readonly datasetColumns = signal<DatasetColumn[]>([]);
  private readonly _transformationService = inject(DatasetColumnFormulaService);

  groupBySelects = signal<(DatasetColumn | undefined)[]>([]);
  aggregationColumns = signal<AggregationColumn[]>([
    <AggregationColumn>{
      alias: '',
      column: {},
      functionType: AggregationFunction.SUM,
    },
  ]);

  aggregationFunctions = [
    { value: AggregationFunction.SUM, label: 'SUM' },
    { value: AggregationFunction.MIN, label: 'MIN' },
    { value: AggregationFunction.MAX, label: 'MAX' },
    { value: AggregationFunction.MEAN, label: 'MEAN' },
    { value: AggregationFunction.MEDIAN, label: 'MEDIAN' },
    { value: AggregationFunction.COUNT, label: 'COUNT' },
    { value: AggregationFunction.N_UNIQUE, label: 'COUNT DISTINCT' },
    { value: AggregationFunction.FIRST, label: 'FIRST' },
    { value: AggregationFunction.LAST, label: 'LAST' },
    { value: AggregationFunction.STD, label: 'STD' },
    { value: AggregationFunction.VAR, label: 'VAR' },
    { value: AggregationFunction.LIST, label: 'LIST' },
    { value: AggregationFunction.QUANTILE_25, label: 'QUANTILE 25' },
    { value: AggregationFunction.QUANTILE_75, label: 'QUANTILE 75' },
  ];

  formulaHaving = signal<string>('');
  formulaValida = signal<boolean>(true);
  formulaValidationState = signal<ExpressionValidationState>('none');
  formulaValidationMessage = signal<string>('');
  private formulaValidationDebounceTimer: ReturnType<typeof setTimeout> | null = null;
  private formulaValidationRequestId = 0;
  havingEditorConfig = computed<ExpressionEditorConfig>(() => ({
    dialect: 'formula',
    columns: this.getHavingValidationColumns(),
    warnOnUnknownFunctions: true,
    maxSuggestions: 15,
  }));

  ngOnInit(): void {
    this._datasetService
      .getDatasetColumns(this._wizardJoinStore.sourceDataset()!.id)
      .subscribe((columns: DatasetColumn[]) => {
        this.datasetColumns.set(columns);
      });
    if (this._wizardJoinStore.aggregationColumns().length > 0) {
      const selected: DatasetColumn[] = [];
      this._wizardJoinStore
        .aggregationColumns()
        .filter((column: AggregationColumn) => column.functionType === AggregationFunction.GROUP_BY)
        .forEach((col) => {
          if (col.column) {
            selected.push(col.column);
          }
        });
      this.groupBySelects.set(selected);
      this.aggregationColumns.set(
        this._wizardJoinStore
          .aggregationColumns()
          .filter((column: AggregationColumn) => column.functionType !== AggregationFunction.GROUP_BY),
      );
    }
    this.formulaHaving.set(this._wizardJoinStore.formulaHaving());
  }

  groupBySelectionChanged(event: SelectionChangedEvent, index: number): void {
    const selectedValue = event.selectedItem;
    this.groupBySelects.update((selects) => {
      if (selectedValue === null || selectedValue === undefined) {
        selects.splice(index, 1);
      } else {
        selects[index] = this.datasetColumns().filter((c) => c.displayName === selectedValue)[0];
      }
      return [...selects];
    });
    this.validateFormulaHaving();
  }

  onFormulaChanged(newValue: string): void {
    this.formulaHaving.update(() => newValue ?? '');
    this.formulaValidationRequestId++;
    this.formulaValida.set(true);
    this.formulaValidationState.set('none');
    this.formulaValidationMessage.set('');
    this.scheduleFormulaValidation();
  }

  onFormulaFocusOut(): void {
    this.validateFormulaHaving();
  }

  aggregationColumnChanged(event: SelectionChangedEvent, index: number): void {
    const selectedValue: string = event.selectedItem;
    const datasetColumn = this.datasetColumns().filter((c) => c.displayName === selectedValue)[0];
    this.aggregationColumns.update((columns: AggregationColumn[]) => {
      columns[index].column = datasetColumn;
      return [...columns];
    });
    console.log('datasetColumn', datasetColumn);
    console.log('selectedValue', selectedValue);
    console.log('aggregationColumnChanged', this.aggregationColumns());
  }

  aggregationFunctionChanged(event: SelectionChangedEvent, index: number): void {
    const selectedValue = event.selectedItem.value;
    this.aggregationColumns.update((columns: AggregationColumn[]) => {
      columns[index].functionType = selectedValue;
      return [...columns];
    });
  }

  aggregationAliasChanged(event: ValueChangedEvent, index: number): void {
    const selectedValue = event.value;
    this.aggregationColumns.update((columns: AggregationColumn[]) => {
      columns[index].alias = selectedValue;
      return [...columns];
    });
    this.scheduleFormulaValidation();
  }

  addGroupBySelect(): void {
    this.groupBySelects.update((selects) => {
      selects.push(undefined);
      return [...selects];
    });
  }

  addAggregationColumn(): void {
    this.aggregationColumns.update((columns) => {
      columns.push(<AggregationColumn>{
        alias: '',
        column: undefined,
        functionType: AggregationFunction.SUM,
      });
      return [...columns];
    });
  }

  deleteAggregationColumn(index: number): void {
    this.aggregationColumns.update((columns) => {
      columns.splice(index, 1);
      return [...columns];
    });
  }

  availableGroupByColumns(index: number): string[] {
    return this.availableSelectBoxOptions(
      this.groupBySelects().map((c) => c?.displayName),
      index,
      this.datasetColumns(),
    );
  }

  availableAggregationColumns(index: number): string[] {
    const selectedColumns = this.aggregationColumns().map((col) => col.column?.displayName);
    return this.availableSelectBoxOptions(selectedColumns, index, this.datasetColumns());
  }

  canAddGroupByColumn(): boolean {
    return this.canAddSelectBox(this.groupBySelects(), this.datasetColumns());
  }

  canAddAggregationColumn(): boolean {
    const aggregationColumns = this.aggregationColumns().map((col) => col.column);
    return this.canAddSelectBox(aggregationColumns, this.datasetColumns());
  }

  canAddSelectBox = (selectedValues: (DatasetColumn | undefined)[], columns: DatasetColumn[]): boolean => {
    const allFilled = !selectedValues.some((v) => v == null || v === undefined);
    const notAllSelected = selectedValues.length < columns.length;
    return allFilled && notAllSelected;
  };

  availableSelectBoxOptions = (
    selectedValues: (string | undefined)[],
    currentValueIndex: number,
    originalColumns: DatasetColumn[],
  ): string[] => {
    return originalColumns
      .filter(
        (column) =>
          column.displayName === selectedValues[currentValueIndex] ||
          !selectedValues.includes(column.displayName || column.name),
      )
      .map((col) => col.displayName || col.name);
  };

  override canGoforward: Signal<boolean> = computed((): boolean => {
    const groupByColumns = this.groupBySelects();
    const aggregationColumns = this.aggregationColumns();
    const groupByValid = groupByColumns.every((value: DatasetColumn | undefined) => value !== undefined);
    const aggregationValid = aggregationColumns.every(
      (col: AggregationColumn) => col.column !== undefined && col.alias !== '',
    );
    return (
      groupByColumns.length > 0 &&
      aggregationColumns.length > 0 &&
      groupByValid &&
      aggregationValid &&
      this.formulaValida()
    );
  });

  validateFormulaHaving(): void {
    const currentRequestId = ++this.formulaValidationRequestId;
    const formula = this.formulaHaving();
    if (formula === '') {
      this.formulaValida.set(true); // No formula means no validation needed
      this.formulaValidationState.set('none');
      this.formulaValidationMessage.set('');
    } else {
      this._transformationService
        .validateFormula({
          expression: formula,
          columns: this.getHavingValidationColumns(),
        })
        .subscribe({
          next: (result: ValidationResult) => {
            if (currentRequestId !== this.formulaValidationRequestId) {
              return;
            }
            if (result.status === 'error') {
              this.formulaValida.set(false);
              this.formulaValidationState.set('invalid');
              this.formulaValidationMessage.set(result.message ?? '');
            } else {
              this.formulaValida.set(true);
              this.formulaValidationState.set('valid');
              this.formulaValidationMessage.set('');
            }
          },
          error: () => {
            if (currentRequestId !== this.formulaValidationRequestId) {
              return;
            }
            this.formulaValida.set(true);
            this.formulaValidationState.set('none');
            this.formulaValidationMessage.set('');
          },
        });
    }
  }

  validateAsync = (params: any): Promise<{ isValid: boolean; message?: string }> => {
    const expression = `${params?.value ?? ''}`.trim();
    if (!expression) {
      this.formulaValida.set(true);
      this.formulaValidationState.set('none');
      this.formulaValidationMessage.set('');
      return Promise.resolve({ isValid: true });
    }

    return lastValueFrom(
      this._transformationService.validateFormula({
        expression,
        columns: this.getHavingValidationColumns(),
      }),
    )
      .then((res: any) => {
        if (res.status !== 'error') {
          this.formulaValida.set(true);
          this.formulaValidationState.set('valid');
          this.formulaValidationMessage.set('');
          return { isValid: true };
        } else {
          this.formulaValida.set(false);
          this.formulaValidationState.set('invalid');
          this.formulaValidationMessage.set(res.message ?? '');
          return {
            isValid: false,
            message: res.message,
          };
        }
      })
      .catch((error) => {
        const errorMessage = String(error ?? '');
        this.formulaValida.set(false);
        this.formulaValidationState.set('invalid');
        this.formulaValidationMessage.set(errorMessage);
        return {
          isValid: false,
          message: error,
        };
      });
  };

  ngOnDestroy(): void {
    if (this.formulaValidationDebounceTimer) {
      clearTimeout(this.formulaValidationDebounceTimer);
      this.formulaValidationDebounceTimer = null;
    }
  }

  private scheduleFormulaValidation(): void {
    if (this.formulaValidationDebounceTimer) {
      clearTimeout(this.formulaValidationDebounceTimer);
    }
    this.formulaValidationDebounceTimer = setTimeout(() => {
      this.validateFormulaHaving();
    }, 300);
  }

  private getHavingValidationColumns(): string[] {
    const columns: string[] = [];
    const unique = new Set<string>();
    const add = (value?: string) => {
      const normalized = value?.trim();
      if (!normalized || unique.has(normalized)) {
        return;
      }
      unique.add(normalized);
      columns.push(normalized);
    };

    this.groupBySelects().forEach((column) => {
      add(column?.displayName ?? column?.name);
    });
    this.aggregationColumns().forEach((column) => {
      add(column.alias);
    });

    return columns;
  }

  override onForward(): void {
    const aggregationColumns: AggregationColumn[] = [];
    this.groupBySelects().forEach((column: DatasetColumn | undefined) => {
      if (column) {
        aggregationColumns.push({
          column: column,
          alias: column.displayName || column.name,
          functionType: AggregationFunction.GROUP_BY,
        });
      }
    });
    this.aggregationColumns().forEach((col: AggregationColumn) => {
      if (col.column && col.alias) {
        aggregationColumns.push(col);
      }
    });
    this._wizardJoinStore.setAggregationColumns(aggregationColumns);
    this._wizardJoinStore.setFormulaHaving(this.formulaHaving());
  }
}
