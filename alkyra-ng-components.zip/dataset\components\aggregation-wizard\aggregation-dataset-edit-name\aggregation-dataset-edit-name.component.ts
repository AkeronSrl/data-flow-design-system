import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { ChangeDetectionStrategy, Component, computed, inject, OnInit, Signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { ValueChangedEvent as TextAreaValueChangedEvent } from 'devextreme/ui/text_area';
import { ValueChangedEvent as TextBoxValueChangedEvent } from 'devextreme/ui/text_box';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';

import { WizardAggregationStore } from '../+store/wizard-aggregation.store';

@Component({
  selector: 'alk-aggregation-dataset-edit-name',
  templateUrl: './aggregation-dataset-edit-name.component.html',
  styleUrls: ['./aggregation-dataset-edit-name.component.scss'],
  standalone: true,
  imports: [TiaraSuiteWizardStepComponent, DxTextBoxModule, DxTextAreaModule, TranslatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AggregationDatasetEditNameComponent extends WizardStep implements OnInit {
  name: string = '';
  description: string = '';
  private readonly _translateService: TranslateService = inject(TranslateService);
  _wizardAggregationStore = inject(WizardAggregationStore);

  ngOnInit(): void {
    const sourceName = this._wizardAggregationStore.sourceDataset()!.name;
    const gropBy = this._translateService.instant('group.by');
    this._wizardAggregationStore.setName(`${gropBy} - ${sourceName}`);
  }

  onNameChange(value: TextBoxValueChangedEvent) {
    this._wizardAggregationStore.setName(value.value);
  }

  onDescriptionChange(value: TextAreaValueChangedEvent) {
    this._wizardAggregationStore.setDescription(value.value);
  }

  override canGoforward: Signal<boolean> = computed(() => {
    return this._wizardAggregationStore.name().length > 0;
  });
}
