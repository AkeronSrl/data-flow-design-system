import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { CustomStore } from 'devextreme-angular/common/data';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { lastValueFrom } from 'rxjs';

import { DatasetAggregation } from '../../../models/dataset-aggregation.model';
import { DatasetService } from '../../../services/dataset.service';
import { WizardAggregationStore } from '../+store/wizard-aggregation.store';

@Component({
  selector: 'alk-aggregation-preview',
  templateUrl: './aggregation-preview.component.html',
  styleUrls: ['./aggregation-preview.component.scss'],
  standalone: true,
  imports: [TiaraSuiteWizardStepComponent, DxDataGridModule, TranslatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AggregationPreviewComponent extends WizardStep {
  readonly _wizardAggregationStore = inject(WizardAggregationStore);

  private readonly _datasetService = inject(DatasetService);

  datasetAggregation = {
    datasetSourceId: this._wizardAggregationStore.sourceDataset()?.id,
    aggregationColumns: this._wizardAggregationStore.aggregationColumns(),
    formulaHaving: this._wizardAggregationStore.formulaHaving(),
  } as DatasetAggregation;

  dataSource: CustomStore = new CustomStore({
    load: () => {
      return lastValueFrom(this._datasetService.getAggregationPreview(this.datasetAggregation));
    },
  });
}
