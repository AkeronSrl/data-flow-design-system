import { TiaraSuiteWizardComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { Dataset } from '@alkyra/dataset/models/dataset.model';
import { DatasetAggregationCreate } from '@alkyra/dataset/models/dataset-aggregation.model';
import { DatasetColumn } from '@alkyra/dataset/models/dataset-column.model';
import { DatasetAggregationService } from '@alkyra/dataset/services/dataset-aggregation.service';
import { Id } from '@alkyra/shared-models/id.model';
import { ChangeDetectionStrategy, Component, inject, input, OnInit, output } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';

import { WizardAggregationStore } from './+store/wizard-aggregation.store';
import { AggregationConfigurationComponent } from './aggregation-configuration/aggregation-configuration.component';
import { AggregationDatasetEditNameComponent } from './aggregation-dataset-edit-name/aggregation-dataset-edit-name.component';
import { AggregationPreviewComponent } from './aggregation-preview/aggregation-preview.component';

@Component({
  selector: 'alk-aggregation-wizard',
  templateUrl: './aggregation-wizard.component.html',
  styleUrls: ['./aggregation-wizard.component.scss'],
  standalone: true,
  imports: [
    TiaraSuiteWizardComponent,
    TranslatePipe,
    AggregationConfigurationComponent,
    AggregationPreviewComponent,
    AggregationDatasetEditNameComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [WizardAggregationStore],
})
export class AggregationWizardComponent implements OnInit {
  private readonly _wizardAggregationStore = inject(WizardAggregationStore);
  private readonly _datasetAggregationService = inject(DatasetAggregationService);

  pipelineId = input<string | null>();
  sourceDataset = input<Dataset | null>();
  onSave = output<Id>();
  onClose = output<void>();

  ngOnInit(): void {
    this._wizardAggregationStore.setPipelineId(this.pipelineId());
    this._wizardAggregationStore.setSourceDataset(this.sourceDataset());
  }

  complete() {
    const selectedColumns: DatasetColumn[] = [];
    this._wizardAggregationStore
      .aggregationColumns()
      .map((col) => col.column)
      .forEach((col) => {
        if (col) {
          selectedColumns.push(col);
        }
      });
    const datasetAggregationCreate: DatasetAggregationCreate = <DatasetAggregationCreate>{
      pipelineId: this._wizardAggregationStore.pipelineId()!,
      name: this._wizardAggregationStore.name(),
      columns: selectedColumns,
      datasetSourceId: this._wizardAggregationStore.sourceDataset()!.id,
      aggregationColumns: this._wizardAggregationStore.aggregationColumns(),
      formulaHaving: this._wizardAggregationStore.formulaHaving(),
    };
    this._datasetAggregationService.addAggregationDataset(datasetAggregationCreate).subscribe((id: Id) => {
      this.onSave.emit(id);
    });
  }

  close() {
    this.onClose.emit();
  }
}
