import { Dataset, DatasetMetadataUpdate } from '@alkyra/dataset/models/dataset.model';
import { Component, effect, input, output, signal, ViewChild } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { ValueChangedEvent as TextAreaValueChangedEvent } from 'devextreme/ui/text_area';
import { ValueChangedEvent as TextBoxValueChangedEvent } from 'devextreme/ui/text_box';
import { ValidationCallbackData } from 'devextreme-angular/common';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxPopupModule } from 'devextreme-angular/ui/popup';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxValidationGroupComponent, DxValidationGroupModule } from 'devextreme-angular/ui/validation-group';
import { DxValidatorModule } from 'devextreme-angular/ui/validator';

@Component({
  selector: 'alk-dataset-edit-popup',
  standalone: true,
  imports: [
    DxButtonModule,
    DxPopupModule,
    DxTextBoxModule,
    DxTextAreaModule,
    DxValidatorModule,
    DxValidationGroupModule,
    TranslateModule,
  ],
  templateUrl: './dataset-edit-popup.component.html',
  styleUrl: './dataset-edit-popup.component.scss',
})
export class DatasetEditPopupComponent {
  @ViewChild('metadataGroup', { static: false }) validationGroup: DxValidationGroupComponent | undefined;

  visible = input.required<boolean>();
  dataset = input.required<Dataset | null>();

  saved = output<DatasetMetadataUpdate>();
  closed = output<void>();

  form = signal<DatasetMetadataUpdate>({
    name: '',
    description: '',
  });

  constructor() {
    effect(() => {
      const isVisible = this.visible();
      const dataset = this.dataset();
      if (!isVisible || !dataset) {
        return;
      }
      this.form.set({
        name: dataset.name ?? '',
        description: dataset.description ?? '',
      });
    });
  }

  onNameChange(value: TextBoxValueChangedEvent): void {
    this.form.update((state) => ({
      ...state,
      name: value.value ?? '',
    }));
  }

  onDescriptionChange(value: TextAreaValueChangedEvent): void {
    this.form.update((state) => ({
      ...state,
      description: value.value ?? '',
    }));
  }

  save(): void {
    if (!this.validationGroup?.instance?.validate().isValid) {
      return;
    }

    const current = this.form();
    const name = current.name.trim();
    if (!name) {
      return;
    }

    this.saved.emit({
      name,
      description: (current.description ?? '').trim(),
    });
  }

  close(): void {
    this.closed.emit();
  }

  validateEmptyField = (e: ValidationCallbackData) => {
    return e.value && e.value.trim() !== '';
  };
}
