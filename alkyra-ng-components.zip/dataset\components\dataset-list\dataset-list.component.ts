import { TiaraAccordionComponent } from '@akeron-ng/tiara-ng';
import { TiaraSuiteListMenuComponent, TiaraSuiteMenuGroup } from '@akeron-ng/tiara-ng-suite/tiara-list-menu';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { Dataset } from '@alkyra/dataset/models/dataset.model';
import { DatasetAggregationRelation } from '@alkyra/dataset/models/dataset-aggregation.model';
import { DatasetColumn, DatasetColumnType } from '@alkyra/dataset/models/dataset-column.model';
import { DatasetConnector } from '@alkyra/dataset/models/dataset-connector.model';
import { DatasetJoinRelation } from '@alkyra/dataset/models/dataset-join.model';
import { DatasetSubsetRelation } from '@alkyra/dataset/models/dataset-subset.model';
import { DatasetUnionRelation } from '@alkyra/dataset/models/dataset-union.model';
import { Component, EventEmitter, Input, inject, OnChanges, Output, SimpleChanges } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { confirm } from 'devextreme/ui/dialog';
import { DxButtonModule } from 'devextreme-angular/ui/button';

import { PipelineStore } from '../../../pages/pipeline/+store/pipeline.store';
import {
  computePipelineDatasetBadgeLabelMap,
  computePipelineDatasetRoleMap,
  PipelineDatasetBadgeLabelKey,
  PipelineDatasetRole,
} from '../../../pages/pipeline/utils/pipeline-dataset-role.utils';

type DatasetTransformationKind = 'rename' | 'filter' | 'formula';

interface DatasetTransformationRow {
  id: string;
  kind: DatasetTransformationKind;
  label: string;
}

interface DatasetTransformationGroups {
  renamedColumns: DatasetTransformationRow[];
  filters: DatasetTransformationRow[];
  addedFormulas: DatasetTransformationRow[];
}

type DatasetWithRuntimeFilterExpression = Dataset & { filterExpression?: string | null };

@Component({
  selector: 'alk-pipeline-dataset-list',
  standalone: true,
  imports: [DxButtonModule, TiaraAccordionComponent, TiaraSuiteListMenuComponent, TranslatePipe],
  templateUrl: './dataset-list.component.html',
  styleUrl: './dataset-list.component.scss',
})
export class DatasetListComponent implements OnChanges {
  private static readonly DATASET_ACTION_RENAME = 1;
  private static readonly DATASET_ACTION_DELETE = 2;
  private static readonly ROLE_INPUT_KEYS = [
    'datasets',
    'joinRelations',
    'unionRelations',
    'aggregationRelations',
    'subsetRelations',
  ] as const;

  _store = inject(PipelineStore);
  private readonly _translateService: TranslateService = inject(TranslateService);

  @Input() datasets: Dataset[] = [];
  @Input() joinRelations: DatasetJoinRelation[] = [];
  @Input() unionRelations: DatasetUnionRelation[] = [];
  @Input() aggregationRelations: DatasetAggregationRelation[] = [];
  @Input() subsetRelations: DatasetSubsetRelation[] = [];

  @Output() onDeleteDataset: EventEmitter<Dataset> = new EventEmitter<Dataset>();
  @Output() onEditExport: EventEmitter<DatasetConnector> = new EventEmitter<DatasetConnector>();
  @Output() onDeleteExport: EventEmitter<DatasetConnector> = new EventEmitter<DatasetConnector>();
  @Output() onEditDataset: EventEmitter<Dataset> = new EventEmitter<Dataset>();
  private datasetRoleMap = new Map<string, PipelineDatasetRole>();
  private datasetBadgeLabelMap = new Map<string, PipelineDatasetBadgeLabelKey>();

  ngOnChanges(changes: SimpleChanges): void {
    if (!this.hasRoleInputChanges(changes)) {
      return;
    }

    this.datasetRoleMap = computePipelineDatasetRoleMap(
      this.datasets,
      this.joinRelations,
      this.unionRelations,
      this.aggregationRelations,
      this.subsetRelations,
    );
    this.datasetBadgeLabelMap = computePipelineDatasetBadgeLabelMap(
      this.datasets,
      this.joinRelations,
      this.unionRelations,
      this.aggregationRelations,
      this.subsetRelations,
    );
  }

  isSource(dataset: Dataset): boolean {
    return this.datasetRoleMap.get(dataset.id) === 'source';
  }

  isJoin(dataset: Dataset): boolean {
    return this.datasetRoleMap.get(dataset.id) === 'join';
  }

  isDerived(dataset: Dataset): boolean {
    return this.datasetRoleMap.get(dataset.id) === 'derived';
  }

  readonly datasetActionGroups: TiaraSuiteMenuGroup[] = [
    {
      items: [
        {
          id: DatasetListComponent.DATASET_ACTION_RENAME,
          name: this._translateService.instant('actions.rename'),
          tiaraIcon: 'edit',
        },
        {
          id: DatasetListComponent.DATASET_ACTION_DELETE,
          name: this._translateService.instant('actions.delete'),
          tiaraIcon: 'trash',
        },
      ],
    },
  ];

  getDerivedBadgeLabelKey(dataset: Dataset): PipelineDatasetBadgeLabelKey {
    return this.datasetBadgeLabelMap.get(dataset.id) ?? 'pipeline.flow.operation.transformation';
  }

  isSelected(dataset: Dataset): boolean {
    return this._store.focusedDataset()?.id === dataset.id;
  }

  toggleSelection(e: any): void {
    this._store.setFocusedStep(e);
  }

  deleteDataset(dataset: Dataset): void {
    const result = confirm(this._translateService.instant('dataset.delete.confirmation'), '');
    result.then((dialogResult) => {
      if (dialogResult && this.onDeleteDataset) {
        this.onDeleteDataset.emit(dataset);
      }
    });
  }

  getTransformationGroups(dataset: Dataset): DatasetTransformationGroups {
    const groups: DatasetTransformationGroups = {
      renamedColumns: [],
      filters: [],
      addedFormulas: [],
    };

    const groupedColumns = [...(dataset.columns ?? [])]
      .sort((first, second) => this.getColumnUpdatedAt(second) - this.getColumnUpdatedAt(first))
      .reduce((accumulator, column, index) => {
        if (column.type === DatasetColumnType.FORMULA) {
          accumulator.addedFormulas.push({
            id: `${column.id ?? column.name}-formula-${index}`,
            kind: 'formula',
            label: column.displayName ?? column.name,
          });
          return accumulator;
        }

        const alias = this.resolveRenamedAlias(column);
        if (!alias) {
          return accumulator;
        }

        accumulator.renamedColumns.push({
          id: `${column.id ?? column.name}-renamed-${index}`,
          kind: 'rename',
          label: `${column.name} \u2192 ${alias}`,
        });
        return accumulator;
      }, groups);

    return this.appendRuntimeFilterTransformation(dataset, groupedColumns);
  }

  getTransformationCount(groups: DatasetTransformationGroups): number {
    return groups.renamedColumns.length + groups.filters.length + groups.addedFormulas.length;
  }

  getExportConnectors(dataset: Dataset): DatasetConnector[] {
    return dataset.exportDatasetConnectors ?? [];
  }

  private appendRuntimeFilterTransformation(
    dataset: Dataset,
    groups: DatasetTransformationGroups,
  ): DatasetTransformationGroups {
    const filterExpression = this.resolveFilterExpression(dataset);
    if (!filterExpression) {
      return groups;
    }

    return {
      ...groups,
      filters: [{ id: `${dataset.id}-filter-expression`, kind: 'filter', label: filterExpression }],
    };
  }

  isEditableExport(connector: DatasetConnector): boolean {
    return [
      ConnectorType.S3_BUCKET,
      ConnectorType.AZURE_BLOB,
      ConnectorType.DATABASE,
      ConnectorType.REST_API,
      ConnectorType.BUSINESS_CENTRAL,
    ].includes(connector.connector.connectorType);
  }

  getExportLabel(connector: DatasetConnector): string {
    return `${this._translateService.instant('dataset.export')}: ${connector.connector.description} - ${connector.connectorEntity}`;
  }

  editExport(connector: DatasetConnector): void {
    this.onEditExport.emit(connector);
  }

  deleteExport(connector: DatasetConnector, e?: any): void {
    e?.event?.stopPropagation?.();
    const result = confirm(this._translateService.instant('dataset.export.delete.confirmation'), '');
    result.then((dialogResult) => {
      if (dialogResult && this.onDeleteExport) {
        this.onDeleteExport.emit(connector);
      }
    });
  }

  editDataset(dataset: Dataset, e?: any): void {
    e?.event?.stopPropagation?.();
    this.onEditDataset.emit(dataset);
  }

  private hasRoleInputChanges(changes: SimpleChanges): boolean {
    return DatasetListComponent.ROLE_INPUT_KEYS.some((inputKey) => !!changes[inputKey]);
  }

  getDatasetActionsButtonId(dataset: Dataset): string {
    return `dataset-actions-${this.toSafeDomId(dataset.id)}`;
  }

  onDatasetMenuItemSelected(dataset: Dataset, actionId: number): void {
    if (actionId === DatasetListComponent.DATASET_ACTION_RENAME) {
      this.editDataset(dataset);
      return;
    }

    if (actionId === DatasetListComponent.DATASET_ACTION_DELETE) {
      this.deleteDataset(dataset);
    }
  }

  private toSafeDomId(value: string): string {
    return value.replace(/[^a-zA-Z0-9_-]/g, '-');
  }

  private getColumnUpdatedAt(column: DatasetColumn): number {
    const timestamps = column as DatasetColumn & {
      updated_at?: string;
      updatedAt?: string;
      lastModifiedDate?: string;
      modifiedDate?: string;
    };
    const candidate =
      timestamps.updated_at ?? timestamps.updatedAt ?? timestamps.lastModifiedDate ?? timestamps.modifiedDate;

    const parsed = candidate ? Date.parse(candidate) : Number.NaN;
    return Number.isNaN(parsed) ? 0 : parsed;
  }

  private resolveRenamedAlias(column: DatasetColumn): string | null {
    if (column.type !== DatasetColumnType.SIMPLE) {
      return null;
    }
    const alias = column.alias?.trim();
    if (!alias || alias === column.name) {
      return null;
    }
    return alias;
  }

  private resolveFilterExpression(dataset: Dataset): string | null {
    const runtimeDataset = dataset as DatasetWithRuntimeFilterExpression;
    const filterExpression = runtimeDataset.filterExpression?.trim();
    return filterExpression ? filterExpression : null;
  }
}
