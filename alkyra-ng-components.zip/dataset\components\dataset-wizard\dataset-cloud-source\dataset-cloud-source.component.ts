import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { TiaraSectionPanelComponent } from '@akeron-ng/tiara-ng/tiara-section-panel';
import { TiaraSuiteTreeNode, TiaraSuiteTreeSelectionEvent } from '@akeron-ng/tiara-ng-suite/tiara-tree-view';
import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { S3BucketConnector } from '@alkyra/amazon-s3-connector/models/s3-bucket-connector.model';
import { S3BucketConnectorService } from '@alkyra/amazon-s3-connector/services/s3-bucket-connector.service';
import { AzureBlobConnector } from '@alkyra/azure-blob-connector/models/azure-blob-connector.model';
import { AzureBlobConnectorService } from '@alkyra/azure-blob-connector/services/azure-blob-connector.service';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { CsvConnectorService } from '@alkyra/csv-connector/services/csv-connector.service';
import { buildSupportedCloudFileTreeNodes } from '@alkyra/dataset/components/dataset-wizard/dataset-cloud-source/cloud-supported-tree.utils';
import { CloudFileRequest } from '@alkyra/dataset/components/dataset-wizard/models/cloud-file-request.model';
import { ExcelConnectorService } from '@alkyra/excel-connector/services/excel-connector.service';
import { FileExplorerItem } from '@alkyra/file-explorer/models/file-explorer-item.model';
import { ScreenLockStore } from '@alkyra/screen-lock/+store/screen-lock.store';
import { FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { mapCloudTreeNodesToSchemaDiscoveryNodes } from '@alkyra/ui/schema-discovery/mappers/cloud-file-schema-discovery.mapper';
import { SchemaDiscoverySelectionEvent } from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject, OnInit, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { CustomStore } from 'devextreme/common/data';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxCheckBoxModule } from 'devextreme-angular/ui/check-box';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { catchError, finalize, forkJoin, lastValueFrom, Observable, of, switchMap, tap } from 'rxjs';

import { DatasetWizardStore } from '../+store/dataset-wizard.store';
import { DatasetColumnSelectorComponent } from '../dataset-column-selector/dataset-column-selector.component';
import { DatasetFlowContext } from '../flow-steps/dataset-flow-context.model';
import { CloudProvider } from '../models/cloud-provider.model';
import {
  DatasetConnectionContextComponent,
  DatasetConnectionContextItem,
} from '../shared/dataset-connection-context/dataset-connection-context.component';
import { DatasetResourceSelectionLayoutComponent } from '../shared/dataset-resource-selection-layout/dataset-resource-selection-layout.component';
import { CloudSelectableFile, listSupportedCloudFiles, resolveCloudFileType } from './cloud-file-tree.utils';

type CloudStorageConnector = AzureBlobConnector | S3BucketConnector;

type CloudConnectionListItem = {
  connectorType: CloudProvider;
  description: string;
  iconAlt: string;
  iconSrc: string;
  id: string;
  title: string;
};

function isS3BucketConnector(connector: CloudStorageConnector): connector is S3BucketConnector {
  return connector.type === ConnectorType.S3_BUCKET || connector.connectorType === ConnectorType.S3_BUCKET;
}

@Component({
  selector: 'alk-dataset-cloud-source',
  standalone: true,
  imports: [
    CommonModule,
    TiaraSuiteWizardStepComponent,
    TranslatePipe,
    TiaraCircularIllustrationComponent,
    TiaraSectionPanelComponent,
    SchemaDiscoveryComponent,
    DatasetConnectionContextComponent,
    DatasetResourceSelectionLayoutComponent,
    DxButtonModule,
    DxCheckBoxModule,
    DxDataGridModule,
    DxSelectBoxModule,
    DxTextBoxModule,
  ],
  templateUrl: './dataset-cloud-source.component.html',
  styleUrl: './dataset-cloud-source.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DatasetCloudSourceComponent extends FlowWizardStep<DatasetFlowContext> implements OnInit {
  static readonly stepId = 'dataset-cloud-source';
  static readonly candidates: readonly FlowWizardStepClass<DatasetFlowContext>[] = [DatasetColumnSelectorComponent];
  private static readonly FILE_TYPE_PARAM = 'fileType';
  private static readonly HAS_HEADER_PARAM = 'hasHeader';
  private static readonly INFER_COLUMN_TYPES_PARAM = 'inferColumnTypes';
  private static readonly SEPARATOR_PARAM = 'separator';
  private static readonly QUOTE_CHAR_PARAM = 'quoteChar';
  private static readonly SHEET_PARAM = 'sheetName';

  private readonly _azureBlobConnectorService = inject(AzureBlobConnectorService);
  private readonly _s3BucketConnectorService = inject(S3BucketConnectorService);
  private readonly _csvConnectorService = inject(CsvConnectorService);
  private readonly _excelConnectorService = inject(ExcelConnectorService);
  private readonly _screenLockStore = inject(ScreenLockStore);
  private readonly _translateService = inject(TranslateService);
  readonly _datasetWizardStore = inject(DatasetWizardStore);

  readonly connectionItems = signal<CloudConnectionListItem[]>([]);
  readonly isTreeLoading = signal(false);
  readonly rawTreeItems = signal<FileExplorerItem[]>([]);
  readonly selectedConnector = signal<CloudStorageConnector | null>(null);
  readonly visibleFileTreeNodes = computed<TiaraSuiteTreeNode<FileExplorerItem, FileExplorerItem>[]>(() =>
    buildSupportedCloudFileTreeNodes(this.rawTreeItems(), {
      groupSelectable: false,
      itemSelectable: true,
    }),
  );
  readonly schemaFileTreeNodes = computed(() => mapCloudTreeNodesToSchemaDiscoveryNodes(this.visibleFileTreeNodes()));
  readonly hasVisibleFiles = computed(() => this.visibleFileTreeNodes().length > 0);

  // CSV/Excel params
  readonly isCsv = computed(() => this._datasetWizardStore.connectorType() === ConnectorType.CSV);
  readonly isExcel = computed(() => this._datasetWizardStore.connectorType() === ConnectorType.EXCEL);
  readonly hasHeader = signal(true);
  readonly inferColumnTypes = signal(true);
  readonly separator = signal(',');
  readonly quoteChar = signal('"');
  readonly selectedSheet = signal<string | null>(null);
  readonly sheets = signal<string[]>([]);
  readonly isCloudPreviewExecuted = signal(false);
  readonly previewData = signal<CustomStore>(new CustomStore({ load: () => lastValueFrom(of([])) }));
  readonly cloudPreviewDisabled = computed(() => {
    if (!this._datasetWizardStore.connectorEntity()?.trim()) {
      return true;
    }

    if (this.isCsv()) {
      return !this.separator()?.trim();
    }

    if (this.isExcel()) {
      return !this.selectedSheet();
    }

    return true;
  });

  override canGoforward = computed(() => {
    const hasConnector = !!this._datasetWizardStore.idConnector()?.trim();
    const hasFile = !!this._datasetWizardStore.connectorEntity()?.trim();
    const type = this._datasetWizardStore.connectorType();
    if (!hasConnector || !hasFile || !type) {
      return false;
    }

    if (type === ConnectorType.CSV) {
      return !!this.separator()?.trim();
    }

    if (type === ConnectorType.EXCEL) {
      return !!this.selectedSheet();
    }

    return true;
  });

  ngOnInit(): void {
    forkJoin({
      azure: this._azureBlobConnectorService.findAll().pipe(catchError(() => of([]))),
      s3: this._s3BucketConnectorService.findAll().pipe(catchError(() => of([]))),
    }).subscribe(({ azure, s3 }) => {
      const connectionItems = [...this.mapAzureConnections(azure ?? []), ...this.mapS3Connections(s3 ?? [])];
      this.connectionItems.set(connectionItems);

      const storedConnectorId = this._datasetWizardStore.idConnector()?.trim();
      if (!storedConnectorId) {
        return;
      }

      const storedConnection = connectionItems.find((item) => item.id === storedConnectorId);
      if (storedConnection) {
        this.loadConnection(storedConnection, false);
      }
    });
  }

  onConnectorSelected(event: any): void {
    const connection = event.addedItems?.[0] as CloudConnectionListItem | undefined;
    if (!connection) {
      this.clearConnectionSelection();
      return;
    }

    this.loadConnection(connection, true);
  }

  toConnectionContextItems(items: CloudConnectionListItem[]): DatasetConnectionContextItem<CloudConnectionListItem>[] {
    return items.map((item) => ({
      id: item.id,
      title: item.title,
      subtitle: item.description,
      typeLabel: this.resolveCloudProviderLabel(item.connectorType),
      iconSrc: item.iconSrc,
      iconAlt: item.iconAlt,
      raw: item,
    }));
  }

  onConnectionContextSelected(item: DatasetConnectionContextItem<CloudConnectionListItem>): void {
    if (!item.raw || item.id === this._datasetWizardStore.idConnector()) {
      return;
    }

    this.loadConnection(item.raw, true);
  }

  onSchemaFileSelected(event: SchemaDiscoverySelectionEvent): void {
    const selectedItem = this.toCloudSelectableFile(event.node.data as FileExplorerItem);
    if (!selectedItem) {
      return;
    }

    this.applyFileSelection(selectedItem);
  }

  onTreeFileSelected(selection: TiaraSuiteTreeSelectionEvent | null): void {
    if (!selection || selection.kind !== 'item') {
      return;
    }

    const selectedItem = this.toCloudSelectableFile(selection.value as FileExplorerItem);
    if (!selectedItem) {
      return;
    }

    this.applyFileSelection(selectedItem);
  }

  override onForward(): void {
    const selectedFile = listSupportedCloudFiles(this.rawTreeItems()).find(
      (file) => file.path === this._datasetWizardStore.connectorEntity(),
    );
    if (selectedFile) {
      this.applyFileSelection(selectedFile);
    }
  }

  override onBackward(): void {
    this._datasetWizardStore.resetSourceConfiguration();
    this._datasetWizardStore.setSourceFamily('CLOUD');
  }

  // CSV param handlers
  onHasHeaderChanged(event: boolean | { value?: boolean }): void {
    const val = typeof event === 'boolean' ? event : !!event?.value;
    this.hasHeader.set(val);
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: DatasetCloudSourceComponent.HAS_HEADER_PARAM,
      valoreBooleano: val,
    });
    this.resetPreview();
  }

  onSeparatorChanged(event: string | { value?: string }): void {
    const val = typeof event === 'string' ? event : (event?.value ?? '');
    this.separator.set(val);
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: DatasetCloudSourceComponent.SEPARATOR_PARAM,
      valoreStringa: val,
    });
    this.resetPreview();
  }

  onQuoteCharChanged(event: string | { value?: string }): void {
    const val = typeof event === 'string' ? event : (event?.value ?? '');
    this.quoteChar.set(val);
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: DatasetCloudSourceComponent.QUOTE_CHAR_PARAM,
      valoreStringa: val,
    });
    this.resetPreview();
  }

  onInferColumnTypesChanged(event: boolean | { value?: boolean }): void {
    const val = typeof event === 'boolean' ? event : !!event?.value;
    this.inferColumnTypes.set(val);
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: DatasetCloudSourceComponent.INFER_COLUMN_TYPES_PARAM,
      valoreBooleano: val,
    });
    this.resetPreview();
  }

  // Excel param handlers
  changeSheet(sheet: string | null): void {
    this.selectedSheet.set(sheet);
    if (sheet) {
      this._datasetWizardStore.addDatasetConnectorParam({
        codParametro: DatasetCloudSourceComponent.SHEET_PARAM,
        valoreStringa: sheet,
      });
    } else {
      this._datasetWizardStore.removeConnecotorParam(DatasetCloudSourceComponent.SHEET_PARAM);
    }

    this.resetPreview();
  }

  // Preview
  showPreview(): void {
    if (this.isCsv()) {
      this.showCsvPreview();
    } else if (this.isExcel()) {
      this.showExcelPreview();
    }
  }

  private showCsvPreview(): void {
    const request = this.buildCsvCloudRequest();
    if (!request) {
      this.resetPreview();
      return;
    }

    this.executePreviewRequest(() => this._csvConnectorService.cloudCsvPreview(request));
  }

  private showExcelPreview(): void {
    const request = this.buildExcelCloudRequest(this.selectedSheet());
    if (!request) {
      this.resetPreview();
      return;
    }

    this.executePreviewRequest(() => this._excelConnectorService.cloudExcelPreview(request));
  }

  private executePreviewRequest(loader: () => Observable<any[]>): void {
    this.previewData.set(new CustomStore({ load: () => lastValueFrom(loader()) }));
    this.isCloudPreviewExecuted.set(true);
  }

  private resetPreview(): void {
    this.previewData.set(new CustomStore({ load: () => lastValueFrom(of([])) }));
    this.isCloudPreviewExecuted.set(false);
  }

  private buildCsvCloudRequest(): CloudFileRequest | null {
    const connectorId = this._datasetWizardStore.idConnector()?.trim();
    const filePath = this._datasetWizardStore.connectorEntity()?.trim();
    const separator = this.separator().trim();
    if (!connectorId) {
      return null;
    }
    if (!filePath) {
      return null;
    }
    if (!separator) {
      return null;
    }

    return {
      connectorId,
      filePath,
      fileType: ConnectorType.CSV,
      hasHeader: this.hasHeader(),
      inferColumnTypes: this.inferColumnTypes(),
      separator,
      quoteChar: this.quoteChar().trim() || null,
    };
  }

  private buildExcelCloudRequest(sheetName: string | null): CloudFileRequest | null {
    const connectorId = this._datasetWizardStore.idConnector()?.trim();
    const filePath = this._datasetWizardStore.connectorEntity()?.trim();
    if (!connectorId || !filePath) {
      return null;
    }

    return {
      connectorId,
      filePath,
      fileType: ConnectorType.EXCEL,
      hasHeader: this.hasHeader(),
      sheetName,
    };
  }

  private loadCloudSheets(): void {
    const request = this.buildExcelCloudRequest(this.selectedSheet());
    if (!request) {
      this.sheets.set([]);
      return;
    }

    this._excelConnectorService.cloudSheets(request).subscribe((sheets) => {
      this.sheets.set(sheets);
      if (!sheets.length) {
        this.changeSheet(null);
        return;
      }

      if (this.selectedSheet() && sheets.includes(this.selectedSheet()!)) {
        return;
      }

      this.changeSheet(sheets[0]);
    });
  }

  private initCsvDefaults(): void {
    const params = this._datasetWizardStore.datasetConnectorParams();
    const hasHeader =
      params.find((p) => p.codParametro === DatasetCloudSourceComponent.HAS_HEADER_PARAM)?.valoreBooleano ?? true;
    const separator =
      params.find((p) => p.codParametro === DatasetCloudSourceComponent.SEPARATOR_PARAM)?.valoreStringa?.trim() || ',';
    const quoteChar =
      params.find((p) => p.codParametro === DatasetCloudSourceComponent.QUOTE_CHAR_PARAM)?.valoreStringa ?? '"';
    const inferColumnTypes =
      params.find((p) => p.codParametro === DatasetCloudSourceComponent.INFER_COLUMN_TYPES_PARAM)?.valoreBooleano ??
      true;

    this.hasHeader.set(hasHeader);
    this.separator.set(separator);
    this.quoteChar.set(quoteChar);
    this.inferColumnTypes.set(inferColumnTypes);

    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: DatasetCloudSourceComponent.HAS_HEADER_PARAM,
      valoreBooleano: hasHeader,
    });
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: DatasetCloudSourceComponent.SEPARATOR_PARAM,
      valoreStringa: separator,
    });
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: DatasetCloudSourceComponent.QUOTE_CHAR_PARAM,
      valoreStringa: quoteChar,
    });
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: DatasetCloudSourceComponent.INFER_COLUMN_TYPES_PARAM,
      valoreBooleano: inferColumnTypes,
    });
  }

  private loadConnection(connection: CloudConnectionListItem, clearFileSelection: boolean): void {
    this._datasetWizardStore.setIdConnector(connection.id);
    this._datasetWizardStore.setCloudProvider(connection.connectorType);
    if (clearFileSelection) {
      this.clearSelectedFile();
    }
    this.rawTreeItems.set([]);
    this.isTreeLoading.set(true);
    this._screenLockStore.lockScreen();

    this.getConnectorDetails(connection)
      .pipe(
        tap((connector) => {
          this.selectedConnector.set(connector);
          this._datasetWizardStore.setConnector(connector);
        }),
        switchMap((connector) => this.getConnectionPreview(connector)),
        finalize(() => {
          this.isTreeLoading.set(false);
          this._screenLockStore.unlockScreen();
        }),
      )
      .subscribe({
        next: (items) => {
          this.rawTreeItems.set(items ?? []);
          if (!clearFileSelection) {
            this.syncStoredFileSelection();
          }
        },
        error: () => {
          this.selectedConnector.set(null);
          this._datasetWizardStore.setConnector(null);
          this.rawTreeItems.set([]);
          if (clearFileSelection) {
            this.clearSelectedFile();
          }
        },
      });
  }

  private syncStoredFileSelection(): void {
    const selectedPath = this._datasetWizardStore.connectorEntity()?.trim();
    if (!selectedPath) {
      return;
    }

    const selectedFile = listSupportedCloudFiles(this.rawTreeItems()).find((file) => file.path === selectedPath);
    if (!selectedFile) {
      this.clearSelectedFile();
      return;
    }

    this.applyFileSelection(selectedFile);
  }

  private applyFileSelection(file: CloudSelectableFile): void {
    this._datasetWizardStore.setConnectorEntity(file.path);
    this._datasetWizardStore.setConnectorType(file.fileType);
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: DatasetCloudSourceComponent.FILE_TYPE_PARAM,
      valoreStringa: file.fileType,
    });
    this.resetPreview();

    if (file.fileType === ConnectorType.CSV) {
      this.initCsvDefaults();
    } else if (file.fileType === ConnectorType.EXCEL) {
      const storedSheet =
        this._datasetWizardStore
          .datasetConnectorParams()
          .find((p) => p.codParametro === DatasetCloudSourceComponent.SHEET_PARAM)?.valoreStringa ?? null;
      this.selectedSheet.set(storedSheet);
      this.sheets.set([]);
      this.loadCloudSheets();
    }
  }

  private clearConnectionSelection(): void {
    this.selectedConnector.set(null);
    this._datasetWizardStore.setIdConnector('');
    this._datasetWizardStore.setConnector(null);
    this._datasetWizardStore.setCloudProvider(null);
    this.rawTreeItems.set([]);
    this.clearSelectedFile();
  }

  private clearSelectedFile(): void {
    this._datasetWizardStore.setConnectorEntity('');
    this._datasetWizardStore.setConnectorType(null);
    this._datasetWizardStore.removeConnecotorParam(DatasetCloudSourceComponent.FILE_TYPE_PARAM);
    this._datasetWizardStore.removeConnecotorParam(DatasetCloudSourceComponent.HAS_HEADER_PARAM);
    this._datasetWizardStore.removeConnecotorParam(DatasetCloudSourceComponent.INFER_COLUMN_TYPES_PARAM);
    this._datasetWizardStore.removeConnecotorParam(DatasetCloudSourceComponent.SEPARATOR_PARAM);
    this._datasetWizardStore.removeConnecotorParam(DatasetCloudSourceComponent.QUOTE_CHAR_PARAM);
    this._datasetWizardStore.removeConnecotorParam(DatasetCloudSourceComponent.SHEET_PARAM);
    this.sheets.set([]);
    this.selectedSheet.set(null);
    this.resetPreview();
  }

  private resolveCloudProviderLabel(provider: CloudProvider): string {
    return provider === ConnectorType.S3_BUCKET
      ? this._translateService.instant('datasource.amazon.s3')
      : this._translateService.instant('datasource.azure.blob');
  }

  private getConnectorDetails(connection: CloudConnectionListItem): Observable<CloudStorageConnector> {
    return connection.connectorType === ConnectorType.S3_BUCKET
      ? this._s3BucketConnectorService.findConnector(connection.id)
      : this._azureBlobConnectorService.findConnector(connection.id);
  }

  private getConnectionPreview(connector: CloudStorageConnector): Observable<FileExplorerItem[]> {
    return isS3BucketConnector(connector)
      ? this._s3BucketConnectorService.connectionPreview(connector)
      : this._azureBlobConnectorService.connectionPreview(connector);
  }

  private mapAzureConnections(connectors: AzureBlobConnector[]): CloudConnectionListItem[] {
    const providerLabel = this._translateService.instant('datasource.azure.blob');
    return connectors
      .filter((connector): connector is AzureBlobConnector & { id: string } => !!connector.id?.trim())
      .map((connector) => ({
        connectorType: ConnectorType.AZURE_BLOB,
        description: this.buildConnectionDescription(providerLabel, connector.description),
        iconAlt: providerLabel,
        iconSrc: 'assets/cloud-icon/azure.png',
        id: connector.id,
        title: connector.containerName,
      }));
  }

  private mapS3Connections(connectors: S3BucketConnector[]): CloudConnectionListItem[] {
    const providerLabel = this._translateService.instant('datasource.amazon.s3');
    return connectors
      .filter((connector): connector is S3BucketConnector & { id: string } => !!connector.id?.trim())
      .map((connector) => ({
        connectorType: ConnectorType.S3_BUCKET,
        description: this.buildConnectionDescription(providerLabel, connector.description),
        iconAlt: providerLabel,
        iconSrc: 'assets/cloud-icon/s3.png',
        id: connector.id,
        title: connector.bucketName,
      }));
  }

  private buildConnectionDescription(providerLabel: string, description: string | undefined): string {
    const trimmedDescription = description?.trim();
    return trimmedDescription ? `${providerLabel} - ${trimmedDescription}` : providerLabel;
  }

  private toCloudSelectableFile(item: FileExplorerItem): CloudSelectableFile | null {
    const fileType = resolveCloudFileType(item.path);
    if (!fileType) {
      return null;
    }

    return {
      fileType,
      name: item.name,
      path: item.path,
    };
  }
}
