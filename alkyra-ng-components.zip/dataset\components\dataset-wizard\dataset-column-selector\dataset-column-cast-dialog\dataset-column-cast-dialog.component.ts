import { TiaraSuiteWizardStepperComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { ColumnCastConfig } from '@alkyra/connector/models/column-cast-config.model';
import { ConnectorMetadataPreviewColumn } from '@alkyra/connector/models/connector-metadata-preview-column.model';
import { DatasetColumnRenameImpactItem } from '@alkyra/dataset/models/dataset-column-rename-impact.model';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxPopupModule } from 'devextreme-angular/ui/popup';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxTooltipModule } from 'devextreme-angular/ui/tooltip';

import {
  buildColumnCastConfig,
  CastEditorState,
  CastValidationResult,
  createCastEditorState,
  getCastTypeOptions,
  isCastEditorParamRequired,
  isCastEditorStepValid,
  normalizeCastTypeOption,
  resolveDefaultCastFormat,
} from '../dataset-column-selector.models';

let formatHelpTooltipIdSequence = 0;

@Component({
  selector: 'alk-dataset-column-cast-dialog',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    DxPopupModule,
    DxTextBoxModule,
    DxSelectBoxModule,
    DxButtonModule,
    DxLoadIndicatorModule,
    DxTooltipModule,
    TiaraSuiteWizardStepperComponent,
  ],
  templateUrl: './dataset-column-cast-dialog.component.html',
  styleUrls: ['./dataset-column-cast-dialog.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DatasetColumnCastDialogComponent {
  private readonly _translateService = inject(TranslateService);

  readonly formatHelpTooltipTargetId = `dataset-column-cast-format-help-${++formatHelpTooltipIdSequence}`;

  visible = input.required<boolean>();
  column = input<ConnectorMetadataPreviewColumn | null>(null);
  validationResult = input<CastValidationResult | null>(null);
  validationLoading = input(false);
  usageImpacts = input<DatasetColumnRenameImpactItem[]>([]);

  validateRequested = output<ColumnCastConfig>();
  saved = output<ColumnCastConfig | null>();
  closed = output<void>();

  readonly supportedCastTypes = getCastTypeOptions();
  readonly editor = signal<CastEditorState | null>(null);
  readonly currentStep = signal(1);
  readonly awaitingValidation = signal(false);
  readonly lastValidatedCast = signal<ColumnCastConfig | null>(null);
  readonly requires = computed(() => {
    const editor = this.editor();
    return editor
      ? isCastEditorParamRequired(editor)
      : {
          format: false,
          trueValue: false,
          falseValue: false,
        };
  });
  readonly canContinueFromTypeStep = computed(() => {
    const editor = this.editor();
    return !!editor && isCastEditorStepValid(editor) && !this.hasUsageImpacts();
  });
  readonly canContinueFromValidateStep = computed(() => this.validationResult()?.valid ?? false);
  readonly hasUsageImpacts = computed(() => this.usageImpacts().length > 0);
  readonly isRemoval = computed(() => {
    const editor = this.editor();
    const column = this.column();
    if (!editor || !column) {
      return false;
    }
    return buildColumnCastConfig(editor, column.type) === null;
  });

  constructor() {
    effect(() => {
      const column = this.column();
      if (!this.visible() || !column) {
        this.editor.set(null);
        this.currentStep.set(1);
        this.awaitingValidation.set(false);
        this.lastValidatedCast.set(null);
        return;
      }
      this.editor.set(createCastEditorState(column));
      this.currentStep.set(1);
      this.awaitingValidation.set(false);
      this.lastValidatedCast.set(null);
    });

    effect(() => {
      if (this.validationLoading() || !this.awaitingValidation()) {
        return;
      }
      const result = this.validationResult();
      if (!result) {
        return;
      }
      this.awaitingValidation.set(false);
      this.currentStep.set(2);
    });
  }

  onTargetTypeChanged(value: string | null | undefined): void {
    if (this.hasUsageImpacts()) {
      return;
    }
    this.patchEditor({ targetType: value ?? 'String' });
  }

  updateFormat(value: string | null | undefined): void {
    if (this.hasUsageImpacts()) {
      return;
    }
    this.patchEditor({ format: value ?? '' });
  }

  updateTrueValue(value: string | null | undefined): void {
    if (this.hasUsageImpacts()) {
      return;
    }
    this.patchEditor({ trueValue: value ?? '' });
  }

  updateFalseValue(value: string | null | undefined): void {
    if (this.hasUsageImpacts()) {
      return;
    }
    this.patchEditor({ falseValue: value ?? '' });
  }

  next(): void {
    const editor = this.editor();
    const column = this.column();
    if (!editor || !column) {
      return;
    }

    if (this.currentStep() === 1) {
      const cast = this.buildCastConfig(editor, column.type);
      if (!cast) {
        this.lastValidatedCast.set(null);
        this.currentStep.set(3);
        return;
      }
      this.awaitingValidation.set(true);
      this.validateRequested.emit(cast);
      return;
    }

    if (this.currentStep() === 2 && this.canContinueFromValidateStep()) {
      this.lastValidatedCast.set(this.buildCastConfig(editor, column.type));
      this.currentStep.set(3);
    }
  }

  back(): void {
    if (this.currentStep() <= 1) {
      return;
    }
    this.currentStep.update((step) => step - 1);
  }

  apply(): void {
    const editor = this.editor();
    const column = this.column();
    if (!editor || !column) {
      return;
    }
    this.saved.emit(this.buildCastConfig(editor, column.type));
  }

  close(): void {
    this.closed.emit();
  }

  getDialogTitle(): string {
    const column = this.column();
    const baseTitle = this._translateService.instant('dataset.column.cast.dialogTitle');
    const columnLabel = column?.alias?.trim() || column?.columnName;
    return columnLabel ? `${baseTitle} - ${columnLabel}` : baseTitle;
  }

  getStepTitle(): string {
    switch (this.currentStep()) {
      case 2:
        return this._translateService.instant('dataset.column.cast.step.validate.title');
      case 3:
        return this._translateService.instant('dataset.column.cast.step.apply.title');
      case 1:
      default:
        return this._translateService.instant('dataset.column.cast.step.type.title');
    }
  }

  getSourceTypeLabel(): string {
    return normalizeCastTypeOption(this.editor()?.originalType);
  }

  getCurrentTypeLabel(): string {
    return normalizeCastTypeOption(this.editor()?.currentType);
  }

  getTargetTypeLabel(): string {
    return this.editor()?.targetType ?? 'String';
  }

  getTypeChipClass(type: string): string {
    switch (normalizeCastTypeOption(type)) {
      case 'Int':
      case 'Float':
        return 'number';
      case 'Boolean':
        return 'boolean';
      case 'Date':
        return 'date';
      case 'Datetime':
        return 'datetime';
      case 'String':
      default:
        return 'string';
    }
  }

  getUsageImpactsLabel(): string {
    return this._translateService.instant('dataset.column.cast.usedInFormulas.title', {
      count: this.usageImpacts().length,
    });
  }

  private patchEditor(patch: Partial<CastEditorState>): void {
    const editor = this.editor();
    if (!editor) {
      return;
    }
    this.awaitingValidation.set(false);
    if (this.currentStep() > 1) {
      this.currentStep.set(1);
    }
    this.editor.set({
      ...editor,
      ...patch,
    });
  }

  private buildCastConfig(editor: CastEditorState, fallbackSourceType: string): ColumnCastConfig | null {
    const language = this._translateService.currentLang || this._translateService.defaultLang || 'en';
    const defaultFormat = resolveDefaultCastFormat(
      language,
      editor.originalType || fallbackSourceType,
      editor.targetType,
    );
    return buildColumnCastConfig(editor, fallbackSourceType, defaultFormat);
  }
}
