import { ConnectorMetadataPreviewColumn } from '@alkyra/connector/models/connector-metadata-preview-column.model';
import { DataGridColumnTypeMapperService } from '@alkyra/datagrid-column-type-mapper/services/data-grid-column-type-mapper.service';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { ReorderEvent } from 'devextreme/ui/sortable';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxCheckBoxModule } from 'devextreme-angular/ui/check-box';
import { DxListModule } from 'devextreme-angular/ui/list';
import { DxPopupModule } from 'devextreme-angular/ui/popup';

import {
  buildChooserDraft,
  ColumnChooserApplyEvent,
  ColumnSelectionItem,
  resolveColumnTypeMeta,
} from '../dataset-column-selector.models';

@Component({
  selector: 'alk-dataset-column-chooser-dialog',
  standalone: true,
  imports: [CommonModule, TranslatePipe, DxPopupModule, DxButtonModule, DxCheckBoxModule, DxListModule],
  templateUrl: './dataset-column-chooser-dialog.component.html',
  styleUrls: ['./dataset-column-chooser-dialog.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DatasetColumnChooserDialogComponent {
  private readonly dataGridColumnTypeMapper = inject(DataGridColumnTypeMapperService);

  visible = input.required<boolean>();
  selectedColumns = input.required<ConnectorMetadataPreviewColumn[]>();
  removedColumns = input.required<ConnectorMetadataPreviewColumn[]>();
  columnId = input<(column: ConnectorMetadataPreviewColumn) => string>((column) => column.columnName);
  columnDisplayName = input<(column: ConnectorMetadataPreviewColumn) => string | null | undefined>(() => null);

  applied = output<ColumnChooserApplyEvent>();
  closed = output<void>();

  readonly draft = signal<ColumnSelectionItem[]>([]);
  readonly chooserSelectedCount = computed(() => this.draft().filter((item) => item.selected).length);
  readonly onChooserReorder = (event: ReorderEvent): void => {
    this.draft.update((draft) => {
      const items = [...draft];
      const [moved] = items.splice(event.fromIndex, 1);
      if (!moved) {
        return draft;
      }
      items.splice(event.toIndex, 0, moved);
      return items.map((item, index) => ({ ...item, order: index + 1 }));
    });
  };

  constructor() {
    effect(() => {
      if (!this.visible()) {
        return;
      }
      this.draft.set(
        buildChooserDraft(this.selectedColumns(), this.removedColumns(), {
          getId: this.columnId(),
          getDisplayName: (column) => this.columnDisplayName()(column) ?? undefined,
        }),
      );
    });
  }

  onSelectionChanged(item: ColumnSelectionItem, selected: boolean): void {
    this.draft.update((draft) => draft.map((entry) => (entry.id === item.id ? { ...entry, selected } : entry)));
  }

  apply(): void {
    const draft = [...this.draft()];
    this.applied.emit({
      selectedColumns: draft
        .filter((item) => item.selected)
        .sort((left, right) => left.order - right.order)
        .map((item) => item.column),
      removedColumns: draft.filter((item) => !item.selected).map((item) => item.column),
    });
  }

  close(): void {
    this.closed.emit();
  }

  getColumnTypeMetaByType(type: string) {
    return resolveColumnTypeMeta(type, (value) => this.dataGridColumnTypeMapper.mapType(value));
  }
}
