import { TiaraSuiteListMenuComponent, TiaraSuiteMenuGroup } from '@akeron-ng/tiara-ng-suite/tiara-list-menu';
import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { ColumnCastConfig } from '@alkyra/connector/models/column-cast-config.model';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { ConnectorMetadataColumn } from '@alkyra/connector/models/connector-metadata-column.model';
import { ConnectorMetadataPreviewColumn } from '@alkyra/connector/models/connector-metadata-preview-column.model';
import { CsvConnector } from '@alkyra/csv-connector/models/csv-connector.model';
import { CsvConnectorService } from '@alkyra/csv-connector/services/csv-connector.service';
import { DatabaseConnectorService } from '@alkyra/database-connector/services/database-connector.service';
import { DataGridColumnTypeMapperService } from '@alkyra/datagrid-column-type-mapper/services/data-grid-column-type-mapper.service';
import { CloudFileRequest } from '@alkyra/dataset/components/dataset-wizard/models/cloud-file-request.model';
import {
  buildExtractColumnsValidationSignature,
  isMetadataColumnIdentifierValid,
  resolveColumnSuggestedAlias,
  resolveExtractColumnValidationIssues,
  resolveValidationSuggestedAlias,
} from '@alkyra/dataset/components/shared/extract-columns-validation.utils';
import {
  ExtractColumnsInvalidColumn,
  ExtractColumnsValidationIssueCode,
  ExtractColumnsValidationResponse,
} from '@alkyra/dataset/models/extract-columns-validation.model';
import { DatasetConnectorService } from '@alkyra/dataset/services/dataset-connector.service';
import {
  resolveSalesforceSavedQueryId,
  resolveSalesforceSourceType,
  SALESFORCE_SOURCE_TYPE_SAVED_QUERY,
} from '@alkyra/dataset/utils/salesforce-source-config.util';
import { ExcelConnector } from '@alkyra/excel-connector/models/excel-connector.model';
import { ExcelConnectorService } from '@alkyra/excel-connector/services/excel-connector.service';
import {
  HubSpotDiscoverySnapshot,
  HubSpotSearchFilterGroup,
  HubSpotSearchFiltersPayload,
} from '@alkyra/hubspot-connector/models/hubspot-connector.model';
import { HubSpotConnectorService } from '@alkyra/hubspot-connector/services/hubspot-connector.service';
import { JsonConnectorService } from '@alkyra/json-connector/services/json-connector.service';
import { PipelineType } from '@alkyra/pipeline/models/pipeline.model';
import { SalesforceConnectorService } from '@alkyra/salesforce-connector/services/salesforce-connector.service';
import { FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, inject, OnInit, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { CustomStore } from 'devextreme/common/data';
import { alert } from 'devextreme/ui/dialog';
import notify from 'devextreme/ui/notify';
import { SelectionChangedEvent } from 'devextreme/ui/select_box';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxListModule } from 'devextreme-angular/ui/list';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxPopupModule } from 'devextreme-angular/ui/popup';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxTooltipModule } from 'devextreme-angular/ui/tooltip';
import { catchError, finalize, forkJoin, lastValueFrom, map, Observable, of, switchMap, take } from 'rxjs';

import { normalizeDatasetColumnAlias, resolveDatasetColumnOutputName } from '../../shared/dataset-column-alias.utils';
import { ApiStepStore } from '../+store/api-step.store';
import { DatasetWizardStore } from '../+store/dataset-wizard.store';
import { RestApiStepStore } from '../+store/rest-api-step.store';
import { SqsStepStore } from '../+store/sqs-step.store';
import { DatasetNamingComponent } from '../dataset-edit-name/dataset-edit-name.component';
import { DatasetFlowContext } from '../flow-steps/dataset-flow-context.model';
import { DatasetColumnCastDialogComponent } from './dataset-column-cast-dialog/dataset-column-cast-dialog.component';
import { DatasetColumnChooserDialogComponent } from './dataset-column-chooser-dialog/dataset-column-chooser-dialog.component';
import {
  buildCastValidationResult,
  buildDatasetColumnActionGroups,
  CastValidationResult,
  ColumnChooserApplyEvent,
  ColumnListItem,
  ColumnTypeMeta,
  DATASET_COLUMN_ACTION_CAST,
  DATASET_COLUMN_ACTION_DELETE,
  DATASET_COLUMN_ACTION_RENAME,
  getColumnTitle,
  getEffectiveColumnType,
  hasCast,
  PreviewGridColumn,
  resolveColumnTypeMeta,
} from './dataset-column-selector.models';
import {
  loadDatasetColumnSelectorPreviewRows,
  normalizeDatasetColumnSelectorPreviewRows,
} from './dataset-column-selector-preview.resolver';

interface PreviewLoadOptions {
  bootstrap?: boolean;
  suppressDuplicateAlert?: boolean;
}

type PreviewLoadResult =
  | {
      kind: 'invalid';
      response: ExtractColumnsValidationResponse;
      validationSignature: string;
    }
  | {
      kind: 'success';
      response: ExtractColumnsValidationResponse;
      validationSignature: string;
      rows: any[];
    };

@Component({
  selector: 'alk-dataset-column-selector',
  templateUrl: './dataset-column-selector.component.html',
  styleUrls: ['./dataset-column-selector.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    TiaraSuiteWizardStepComponent,
    TranslatePipe,
    DxListModule,
    DxDataGridModule,
    DxLoadIndicatorModule,
    DxTextBoxModule,
    DxButtonModule,
    DxSelectBoxModule,
    DxScrollViewModule,
    DxTextAreaModule,
    DxTooltipModule,
    DxPopupModule,
    DatasetColumnCastDialogComponent,
    DatasetColumnChooserDialogComponent,
    TiaraSuiteListMenuComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DatasetColumnSelectorComponent extends FlowWizardStep<DatasetFlowContext> implements OnInit {
  static readonly stepId = 'dataset-columns';
  static readonly candidates: readonly FlowWizardStepClass<DatasetFlowContext>[] = [DatasetNamingComponent];
  private static readonly HAS_HEADER_PARAM = 'hasHeader';
  private static readonly INFER_COLUMN_TYPES_PARAM = 'inferColumnTypes';
  private static readonly SHEET_PARAM = 'sheetName';
  private static readonly SEPARATOR_PARAM = 'separator';
  private static readonly QUOTE_CHAR_PARAM = 'quoteChar';
  private static readonly DATA_PATH_PARAM = 'dataPath';
  private static readonly HUBSPOT_SEARCH_FILTERS_PARAM = 'hubSpotSearchFilters';
  private static readonly HUBSPOT_DISCOVERY_SNAPSHOT_PARAM = 'hubSpotDiscoverySnapshot';
  private lastColumnsLoadKey: string | null = null;

  readonly _datasetWizardStore = inject(DatasetWizardStore);
  readonly _translateService = inject(TranslateService);
  private readonly _dataGridColumnTypeMapper = inject(DataGridColumnTypeMapperService);
  private readonly _datasetConnectorService = inject(DatasetConnectorService);

  csvConnectorService = inject(CsvConnectorService);
  excelConnectorService = inject(ExcelConnectorService);
  databaseConnectorService = inject(DatabaseConnectorService);
  jsonConnectorService = inject(JsonConnectorService);
  salesforceConnectorService = inject(SalesforceConnectorService);
  hubSpotConnectorService = inject(HubSpotConnectorService);
  readonly sqsStore = inject(SqsStepStore);
  readonly apiStepStore = inject(ApiStepStore);
  readonly restApiStepStore = inject(RestApiStepStore);

  columns_to_add = signal<ColumnListItem[]>([]);

  columns_removed = signal<ConnectorMetadataPreviewColumn[]>([]);
  duplicateColumnsInList = signal<ConnectorMetadataPreviewColumn[]>([]);
  columnsValidationLoading = signal<boolean>(false);
  stepBootstrapLoading = signal<boolean>(false);
  renameDialogVisible = signal(false);
  chooserDialogVisible = signal(false);
  castDialogVisible = signal(false);
  castValidationLoading = signal(false);
  castValidationResult = signal<CastValidationResult | null>(null);
  editingColumnName = signal<string | null>(null);
  castEditingColumnName = signal<string | null>(null);
  previewRows = signal<any[]>([]);
  renameAlias = signal('');
  readonly columnActionGroups: TiaraSuiteMenuGroup[] = buildDatasetColumnActionGroups((key) =>
    this._translateService.instant(key),
  );

  columnsSelected = computed((): ConnectorMetadataPreviewColumn[] => {
    return this.columns_to_add()
      .filter((c) => c.column !== undefined)
      .map((c, index) => ({
        ...c.column!,
        order: index + 1,
      }));
  });

  readonly previewGridColumns = computed((): PreviewGridColumn[] => {
    return this.columnsSelected().map((column) => ({
      dataField: column.columnName,
      caption: column.alias?.trim() || column.columnName,
      dataType: this.getColumnTypeMeta(column).dataType,
      column,
    }));
  });
  readonly selectedColumnsCount = computed(() => this.columnsSelected().length);
  readonly totalColumnsCount = computed(
    () => this.columns_to_add().filter((item) => item.column).length + this.columns_removed().length,
  );
  readonly currentValidationIssues = computed(() => {
    const issuesByColumnName = new Map<string, ExtractColumnsValidationIssueCode[]>();
    const selectedColumns = this.columnsSelected();
    selectedColumns.forEach((column) => {
      const issues = resolveExtractColumnValidationIssues(
        column,
        selectedColumns,
        this._datasetWizardStore.invalidColumns(),
      );
      if (issues.length > 0) {
        issuesByColumnName.set(column.columnName, issues);
      }
    });
    return issuesByColumnName;
  });
  readonly previewLoading = computed(() => this.stepBootstrapLoading() || this.columnsValidationLoading());

  /** Track if preview was run after custom query change (for DATABASE connectors) */
  previewValidated = signal<boolean>(false);
  readonly isApiPipeline = computed(() => this.apiStepStore.selectedPipeline()?.pipelineType === PipelineType.API);
  readonly hasApiSample = computed(() => !!this.apiStepStore.jsonSample());

  constructor() {
    super();
    effect(() => {
      const connectorType = this._datasetWizardStore.connectorType();
      const schema = this.isRestLikeConnector(connectorType)
        ? this.resolveRestApiSchema()
        : this.apiStepStore.jsonSchemaRaw();
      if (connectorType === 'HOOK_API') {
        return;
      }
      if (this.shouldLoadSchemaColumns(connectorType, schema)) {
        this.loadColumns();
      }
    });
  }

  ngOnInit(): void {
    const connectorType = this._datasetWizardStore.connectorType();
    if (connectorType === 'HOOK_API') {
      this.bindLockedHookApiPath();
    } else if (connectorType === 'JSON' && this.isApiPipeline()) {
      this.apiStepStore.loadApiConfig();
    }

    this.loadColumns();
  }

  loadColumns() {
    const loadKey = this.buildColumnsLoadKey();
    if (loadKey && loadKey === this.lastColumnsLoadKey) {
      return;
    }

    this.lastColumnsLoadKey = loadKey;
    const columns$ = this.resolveColumnsLoader();
    if (!columns$) {
      this.stepBootstrapLoading.set(false);
      this.resetColumnsSelection();
      return;
    }

    this.stepBootstrapLoading.set(true);
    this.clearPreview();
    this.applyLoadedColumns(columns$);
  }

  private buildColumnsLoadKey(): string {
    return JSON.stringify({
      connectorType: this._datasetWizardStore.connectorType(),
      connectorId: this._datasetWizardStore.idConnector(),
      connectorEntity: this._datasetWizardStore.connectorEntity(),
      datasetConnectorParams: this._datasetWizardStore.datasetConnectorParams(),
      apiSchema: this.apiStepStore.jsonSchemaRaw(),
      restPreviewSchema: this.restApiStepStore.previewJsonSchema(),
      restResponseSchema: this.restApiStepStore.responseJsonSchema(),
      restDataPath: this.restApiStepStore.dataPath(),
    });
  }

  private shouldLoadSchemaColumns(
    connectorType: string | null | undefined,
    schema: string | null | undefined,
  ): boolean {
    return this.isSchemaConnector(connectorType) && this.hasText(schema);
  }

  private isSchemaConnector(connectorType: string | null | undefined): boolean {
    return connectorType === 'HOOK_API' || connectorType === 'JSON' || this.isRestLikeConnector(connectorType);
  }

  private hasText(value: string | null | undefined): boolean {
    return !!value?.trim();
  }

  private isRestLikeConnector(connectorType: string | null | undefined): boolean {
    return connectorType === ConnectorType.REST_API || connectorType === ConnectorType.BUSINESS_CENTRAL;
  }

  private resolveRestApiSchema(): string {
    return this.restApiStepStore.previewJsonSchema() ?? this.restApiStepStore.responseJsonSchema() ?? '';
  }

  private shouldApplyRestApiDataPath(): boolean {
    return !this.hasText(this.restApiStepStore.previewJsonSchema());
  }

  private resolveColumnsLoader(): Observable<ConnectorMetadataColumn[]> | null {
    const loaders: Partial<Record<string, () => Observable<ConnectorMetadataColumn[]>>> = {
      CSV: () => this.loadCsvColumns(),
      EXCEL: () => this.loadExcelColumns(),
      DATABASE: () => this.loadDatabaseColumns(),
      AMAZON_SQS: () => this.loadAmazonSqsColumns(),
      HOOK_API: () => this.loadApiSchemaColumns(true),
      REST_API: () => this.loadRestApiSchemaColumns(),
      BUSINESS_CENTRAL: () => this.loadRestApiSchemaColumns(),
      JSON: () => this.loadApiSchemaColumns(false),
      SALESFORCE: () => this.loadSalesforceColumns(),
      HUBSPOT: () => this.loadHubSpotColumns(),
    };
    return loaders[this._datasetWizardStore.connectorType() ?? '']?.() ?? null;
  }

  private resetColumnsSelection(): void {
    this.columns_to_add.set([]);
    this.duplicateColumnsInList.set([]);
    this.previewValidated.set(false);
    this._datasetWizardStore.clearColumnsValidationState();
  }

  private applyLoadedColumns(columns$: Observable<ConnectorMetadataColumn[]>): void {
    columns$.pipe(take(1)).subscribe({
      next: (cols) => {
        this.columns_to_add.set(this.toPreviewColumns(cols));
        this.previewValidated.set(false);
        this._datasetWizardStore.clearColumnsValidationState();
        this.validateSelectedColumns();
        this.showPreview({ bootstrap: true, suppressDuplicateAlert: true });
      },
      error: (error) => {
        this.resetColumnsSelection();
        this.clearPreview();
        this.notify(this.resolveErrorMessage(error, 'dataset.source.edit.preview.error'), 'error', 5000);
        this.stepBootstrapLoading.set(false);
      },
    });
  }

  private toPreviewColumns(cols: ConnectorMetadataColumn[]): ColumnListItem[] {
    return cols.map((c) => ({
      column: this.applySuggestedAlias(this.toPreviewColumn(c)),
    }));
  }

  private toPreviewColumn(column: ConnectorMetadataColumn): ConnectorMetadataPreviewColumn {
    const salesforceValidation = this.resolveSalesforceValidationMetadata(column.columnName);
    return {
      columnName: column.columnName,
      type: column.dataType,
      length: column.length,
      precision: column.precision,
      identifierValid: column.identifierValid ?? salesforceValidation?.identifierValid,
      suggestedAlias: column.suggestedAlias ?? salesforceValidation?.suggestedAlias,
    };
  }

  private loadCsvColumns(): Observable<ConnectorMetadataColumn[]> {
    if (this.isCloudMode()) {
      const request = this.buildCloudRequest(ConnectorType.CSV);
      return request ? this.csvConnectorService.cloudColumns(request) : of([]);
    }

    return this.csvConnectorService.columns(
      this._datasetWizardStore.connector() as CsvConnector,
      this.getInferColumnTypesParam(),
    );
  }

  private loadExcelColumns(): Observable<ConnectorMetadataColumn[]> {
    if (this.isCloudMode()) {
      const request = this.buildCloudRequest(ConnectorType.EXCEL);
      return request ? this.excelConnectorService.cloudColumns(request) : of([]);
    }

    const connector = this._datasetWizardStore.connector() as ExcelConnector;
    return this.excelConnectorService.columns(
      connector,
      this.getDatasetParamString(DatasetColumnSelectorComponent.SHEET_PARAM) ?? '',
      this.getDatasetParamBoolean(DatasetColumnSelectorComponent.HAS_HEADER_PARAM, true),
    );
  }

  private loadDatabaseColumns(): Observable<ConnectorMetadataColumn[]> {
    return this.databaseConnectorService.columns(
      this._datasetWizardStore.idConnector(),
      this._datasetWizardStore.connectorEntity(),
    );
  }

  private loadAmazonSqsColumns(): Observable<ConnectorMetadataColumn[]> {
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: 'dataPath',
      valoreStringa: this.sqsStore.selectedPath(),
    });
    const schema = this.sqsStore.connector()?.payloadSchema || '';
    if (!schema.trim()) {
      return of([]);
    }

    return this.jsonConnectorService
      .columns(schema, this.sqsStore.selectedPath())
      .pipe(map((cols: ConnectorMetadataColumn[]) => cols.filter((c) => c.dataType !== 'unknown')));
  }

  private loadSalesforceColumns(): Observable<ConnectorMetadataColumn[]> {
    if (this.isSalesforceSavedQuerySource()) {
      const savedQueryId = resolveSalesforceSavedQueryId(this._datasetWizardStore.datasetConnectorParams());
      if (!savedQueryId) {
        return of([]);
      }
      return this.salesforceConnectorService.savedQueryColumns(this._datasetWizardStore.idConnector(), savedQueryId);
    }

    return this.salesforceConnectorService.columns(
      this._datasetWizardStore.idConnector(),
      this._datasetWizardStore.connectorEntity(),
    );
  }

  private loadHubSpotColumns(): Observable<ConnectorMetadataColumn[]> {
    const connectorId = this._datasetWizardStore.idConnector();
    const objectTypeId = this._datasetWizardStore.connectorEntity();
    if (!connectorId || !objectTypeId) {
      return of([]);
    }
    return this.hubSpotConnectorService.columns({ connectorId, objectTypeId }).pipe(
      map((columns) => (columns.length > 0 ? columns : this.hubSpotSnapshotColumns())),
      catchError(() => of(this.hubSpotSnapshotColumns())),
    );
  }

  private loadApiSchemaColumns(saveDataPathParam: boolean): Observable<ConnectorMetadataColumn[]> {
    const schema = this.apiStepStore.jsonSchemaRaw() ?? '';
    const dataPath = this.apiStepStore.normalizedSelectedPath();

    if (!schema.trim()) {
      return of([]);
    }

    if (saveDataPathParam) {
      this.upsertDataPathParam(dataPath);
    }

    return this.jsonConnectorService
      .columns(schema, saveDataPathParam ? dataPath : undefined)
      .pipe(map((cols: ConnectorMetadataColumn[]) => cols.filter((c) => c.dataType !== 'unknown')));
  }

  private loadRestApiSchemaColumns(): Observable<ConnectorMetadataColumn[]> {
    const schema = this.resolveRestApiSchema();
    const dataPath = this.restApiStepStore.dataPath().trim();
    const schemaDataPath = this.shouldApplyRestApiDataPath() ? dataPath || undefined : undefined;

    if (!schema.trim()) {
      return of([]);
    }

    this.upsertDataPathParam(dataPath);

    return this.jsonConnectorService
      .columns(schema, schemaDataPath)
      .pipe(map((cols: ConnectorMetadataColumn[]) => cols.filter((c) => c.dataType !== 'unknown')));
  }

  previewData = signal<CustomStore>(
    new CustomStore({
      load: () => lastValueFrom(of([])),
    }),
  );

  addColumn() {
    this.columns_to_add.set([...this.columns_to_add(), { column: undefined }]);
  }

  openRenameDialog(column: ConnectorMetadataPreviewColumn): void {
    this.editingColumnName.set(column.columnName);
    this.renameAlias.set(column.alias ?? '');
    this.renameDialogVisible.set(true);
  }

  saveRename(): void {
    const columnName = this.editingColumnName();
    if (!columnName) {
      return;
    }
    this.updateSelectedColumn(columnName, (column) => ({
      ...column,
      alias: normalizeDatasetColumnAlias(this.renameAlias(), column.columnName),
    }));
    this.editingColumnName.set(null);
    this.renameDialogVisible.set(false);
    this.previewValidated.set(false);
    this.validateSelectedColumns();
  }

  closeRenameDialog(): void {
    this.renameDialogVisible.set(false);
    this.editingColumnName.set(null);
  }

  openCastDialog(column: ConnectorMetadataPreviewColumn): void {
    this.castEditingColumnName.set(column.columnName);
    this.castValidationResult.set(null);
    this.castDialogVisible.set(true);
  }

  closeCastDialog(): void {
    this.castDialogVisible.set(false);
    this.castEditingColumnName.set(null);
    this.castValidationLoading.set(false);
    this.castValidationResult.set(null);
  }

  requestCastValidation(cast: ColumnCastConfig): void {
    const editingColumn = this.getCastEditingColumn();
    if (!editingColumn) {
      return;
    }

    const sourceColumns = this.buildColumnsWithUpdatedCast(editingColumn.columnName, null);
    const castedColumns = this.buildColumnsWithUpdatedCast(editingColumn.columnName, cast);
    const sourcePreview$ = this.loadPreviewRows(sourceColumns)?.pipe(catchError(() => of([]))) ?? of([]);
    const castedPreview$ =
      this.loadPreviewRows(castedColumns)?.pipe(
        map((rows) => ({ ok: true as const, rows })),
        catchError((error) =>
          of({
            ok: false as const,
            error,
          }),
        ),
      ) ?? of({ ok: true as const, rows: [] });

    this.castValidationLoading.set(true);
    this.castValidationResult.set(null);
    forkJoin({
      sourceRows: sourcePreview$,
      castedPreview: castedPreview$,
    })
      .pipe(finalize(() => this.castValidationLoading.set(false)))
      .subscribe({
        next: ({ sourceRows, castedPreview }) => {
          if (castedPreview.ok) {
            this.castValidationResult.set(
              buildCastValidationResult({
                column: editingColumn,
                cast,
                sourceRows,
                castedRows: castedPreview.rows,
              }),
            );
            return;
          }

          const fallbackMessage = this.resolveErrorMessage(castedPreview.error, 'dataset.source.edit.preview.error');
          this.castValidationResult.set(
            buildCastValidationResult({
              column: editingColumn,
              cast,
              sourceRows,
              castedRows: null,
              fallbackErrorMessage: fallbackMessage,
            }),
          );
        },
        error: (error) => {
          this.castValidationResult.set({
            valid: false,
            rows: [
              {
                sourceValue: '',
                castResult: '',
                status: 'error',
                message: this.resolveErrorMessage(error, 'dataset.source.edit.preview.error'),
              },
            ],
            errorCount: 1,
            sampleCount: 0,
          });
        },
      });
  }

  saveCast(cast: ColumnCastConfig | null): void {
    const editingColumn = this.getCastEditingColumn();
    if (!editingColumn) {
      return;
    }
    const nextCast = cast;
    if (!nextCast) {
      this.applyCastUpdate(editingColumn.columnName, null);
      return;
    }

    const previewColumns = this.buildColumnsWithUpdatedCast(editingColumn.columnName, nextCast);
    const preview$ = this.loadPreviewRows(previewColumns);
    if (!preview$) {
      this.applyCastUpdate(editingColumn.columnName, nextCast);
      return;
    }

    this.castValidationLoading.set(true);
    preview$
      .pipe(
        take(1),
        finalize(() => this.castValidationLoading.set(false)),
      )
      .subscribe({
        next: (rows: any[]) => this.applyCastUpdate(editingColumn.columnName, nextCast, rows),
        error: (error) => {
          this.notify(this.resolveErrorMessage(error, 'dataset.source.edit.preview.error'), 'error', 5000);
        },
      });
  }

  openChooserDialog(): void {
    this.chooserDialogVisible.set(true);
  }

  getPreviewColumnActionsButtonId(column: PreviewGridColumn, index: number): string {
    return `dataset-column-actions-${index}-${column.dataField}`;
  }

  resolvePreviewGridColumn(dataField: string | null | undefined): PreviewGridColumn | undefined {
    if (!dataField) {
      return undefined;
    }
    return this.previewGridColumns().find((column) => column.dataField === dataField);
  }

  getPreviewColumnActionsButtonIdByDataField(dataField: string | null | undefined): string {
    return `dataset-column-actions-${(dataField ?? 'unknown').replace(/[^A-Za-z0-9_-]/g, '_')}`;
  }

  onPreviewColumnMenuItemSelected(column: ConnectorMetadataPreviewColumn, actionId: number): void {
    switch (actionId) {
      case DATASET_COLUMN_ACTION_RENAME:
        this.openRenameDialog(column);
        return;
      case DATASET_COLUMN_ACTION_CAST:
        this.openCastDialog(column);
        return;
      case DATASET_COLUMN_ACTION_DELETE:
        this.removeColumn(column);
        return;
      default:
        return;
    }
  }

  applyChooser(event: ColumnChooserApplyEvent): void {
    const selectedColumns = event.selectedColumns.map((column) => this.applySuggestedAlias(column));
    const selectedNames = new Set(selectedColumns.map((column) => column.columnName));
    const removedColumns = event.removedColumns.map((column) => ({
      ...column,
      alias: column.alias,
    }));

    this.columns_to_add.set(selectedColumns.map((column) => ({ column })));
    this.columns_removed.set(removedColumns.filter((column) => !selectedNames.has(column.columnName)));
    this.chooserDialogVisible.set(false);
    this.previewValidated.set(false);
    this.validateSelectedColumns();
  }

  columnToAddValueChanged(event: SelectionChangedEvent, col: ColumnListItem) {
    col.column = this.applySuggestedAlias(event.selectedItem as ConnectorMetadataPreviewColumn);
    this.columns_removed.set(this.columns_removed().filter((c) => c.columnName !== col.column?.columnName));
    this.columns_to_add.update((cols) => {
      const index = cols.indexOf(col);
      cols[index] = col;
      return cols;
    });
    this.previewValidated.set(false);
    this.validateSelectedColumns();
  }

  removeColumn(column: ConnectorMetadataPreviewColumn) {
    const colsToAdd = this.columns_to_add().filter((col) => col.column && col.column?.columnName !== column.columnName);
    const colsToRemove = [...this.columns_removed(), column];
    this.columns_to_add.set(colsToAdd);
    this.columns_removed.set(colsToRemove);
    this.previewValidated.set(false);
    this.validateSelectedColumns();
  }

  onColumnItemReordered() {
    this.columns_to_add.update((cols) => [...this.columns_to_add()]);
    this.previewValidated.set(false);
    this.validateSelectedColumns();
  }

  override canGoforward = computed((): boolean => {
    if (this.previewLoading()) {
      return false;
    }
    if (this.duplicateColumnsInList().length > 0) {
      return false;
    }
    if (this.columnsSelected().length === 0) {
      return false;
    }
    if (this.currentValidationIssues().size > 0) {
      return false;
    }
    if (this.requiresPreviewValidation()) {
      return this.previewValidated();
    }
    // For other cases, always allow forward navigation
    return true;
  });

  override onBackward(): void {
    if (this._datasetWizardStore.connectorType() === 'HOOK_API') {
      this.apiStepStore.unlockSelectedPath();
    }
    if (!this.isRestLikeConnector(this._datasetWizardStore.connectorType())) {
      this._datasetWizardStore.setDatasetColumns([]);
      this._datasetWizardStore.setCustomQuery('');
    }
  }

  override onForward(): void {
    if (this.isRestLikeConnector(this._datasetWizardStore.connectorType())) {
      const operation = this.restApiStepStore.selectedOperation();
      if (operation) {
        this._datasetWizardStore.setConnectorEntity(`${operation.method}:${operation.path}`);
      }
      this._datasetWizardStore.setDatasetConnectorParams(this.restApiStepStore.serializeDatasetConnectorParams());
    }
    if (this._datasetWizardStore.connectorType() === 'HUBSPOT') {
      this.persistHubSpotSelectedPropertiesSnapshot();
    }
    this._datasetWizardStore.setDatasetColumns(
      this.columns_to_add()
        .filter((c) => c.column !== undefined)
        .map((c) => c.column!),
    );
  }

  onAliasValueChanged(e: any, item: ColumnListItem) {
    const index = this.columns_to_add().findIndex(
      (col) => col.column && col.column.columnName === item.column?.columnName,
    );
    if (index < 0) {
      return;
    }
    const col = this.columns_to_add()[index];
    col.column!.alias = normalizeDatasetColumnAlias(e.value, col.column?.columnName);
    const cols = this.columns_to_add();
    cols[index] = col;
    this.columns_to_add.update((cols) => [...cols]);
    this.previewValidated.set(false);
    this.validateSelectedColumns();
  }

  showPreview(options: PreviewLoadOptions = {}) {
    if (!options.bootstrap) {
      this.columnsValidationLoading.set(true);
    }
    this.validateSelectedColumns();
    if (this.duplicateColumnsInList().length > 0) {
      if (!options.suppressDuplicateAlert) {
        alert(
          `${this._translateService.instant('join.column.alias.validation.error')}`,
          this._translateService.instant('error.generic'),
        );
      }
      this.previewValidated.set(false);
      this.finishBootstrapLoading(options);
      return;
    }
    const selectedColumns = this.columnsSelected();
    if (selectedColumns.length === 0) {
      this.previewValidated.set(false);
      this.clearPreview();
      this.finishBootstrapLoading(options);
      return;
    }
    const validationSignature = buildExtractColumnsValidationSignature(selectedColumns);
    this.runPreviewFlow(selectedColumns, validationSignature, options);
  }

  notify(message: string | undefined, type: string, displayTime: number): void {
    notify(message, type, displayTime);
  }

  clearPreview() {
    this.previewRows.set([]);
    this.previewData = signal<CustomStore>(
      new CustomStore({
        load: () => lastValueFrom(of([])),
      }),
    );
  }

  isDupplicated(item: ColumnListItem): boolean {
    return this.duplicateColumnsInList().some((col) => col.columnName === item.column?.columnName);
  }

  hasValidationIssues(item: ColumnListItem): boolean {
    if (!item.column) {
      return false;
    }
    return (this.currentValidationIssues().get(item.column.columnName)?.length ?? 0) > 0;
  }

  getValidationMessage(item: ColumnListItem): string {
    if (!item.column) {
      return '';
    }
    const issues = this.currentValidationIssues().get(item.column.columnName) ?? [];
    const invalidColumn = this.getBackendInvalidColumn(item.column.columnName);
    return issues.map((issue) => this.translateValidationIssue(issue, item.column!, invalidColumn)).join('\n');
  }

  isInvalidMetadataColumn(
    column: ConnectorMetadataPreviewColumn | ConnectorMetadataColumn | null | undefined,
  ): boolean {
    return !!column && !isMetadataColumnIdentifierValid(column);
  }

  getMetadataValidationMessage(
    column: ConnectorMetadataPreviewColumn | ConnectorMetadataColumn | null | undefined,
  ): string {
    const baseMessage = this._translateService.instant('dataset.columns.validation.issue.sourceNameRequiresAlias');
    return this.withSuggestedAlias(baseMessage, resolveColumnSuggestedAlias(column));
  }

  getTooltipTargetId(scope: string, value: string | null | undefined): string {
    const sanitized = (value ?? 'unknown').replace(/[^A-Za-z0-9_-]/g, '_');
    return `${scope}-${sanitized}`;
  }

  private countOccurrences<T>(items: T[], keyFn: (item: T) => string): Map<string, number> {
    const counts = new Map<string, number>();
    items.forEach((item) => {
      const key = keyFn(item);
      counts.set(key, (counts.get(key) || 0) + 1);
    });
    return counts;
  }

  private validateSelectedColumns() {
    const selected = this.columnsSelected();
    const outputNameCounts = this.countOccurrences(selected, (col) =>
      resolveDatasetColumnOutputName(col.columnName, col.alias),
    );
    const invalidColumns: ConnectorMetadataPreviewColumn[] = [];
    const processedColumns = new Set<string>();

    for (const [outputName, count] of outputNameCounts) {
      if (count <= 1) {
        continue;
      }

      selected
        .filter((col) => resolveDatasetColumnOutputName(col.columnName, col.alias) === outputName)
        .forEach((col) => {
          const key = col.columnName;
          if (!processedColumns.has(key)) {
            invalidColumns.push(col);
            processedColumns.add(key);
          }
        });
    }

    this.duplicateColumnsInList.set(invalidColumns);
  }

  private runPreviewFlow(
    selectedColumns: ConnectorMetadataPreviewColumn[],
    validationSignature: string,
    options: PreviewLoadOptions,
  ): void {
    this._datasetConnectorService
      .validateExtractColumns(selectedColumns)
      .pipe(
        switchMap((response) => {
          if (!response.valid) {
            return of({ kind: 'invalid', response, validationSignature } satisfies PreviewLoadResult);
          }

          const preview$ = this.loadPreviewRows(selectedColumns);
          return (preview$ ?? of([])).pipe(
            map(
              (rows) =>
                ({
                  kind: 'success',
                  response,
                  validationSignature,
                  rows,
                }) satisfies PreviewLoadResult,
            ),
          );
        }),
        finalize(() => {
          this.columnsValidationLoading.set(false);
          this.finishBootstrapLoading(options);
        }),
      )
      .subscribe({
        next: (result) => this.handlePreviewLoadResult(result),
        error: (error) => {
          this.previewValidated.set(false);
          this.clearPreview();
          this.notify(this.resolveErrorMessage(error, 'dataset.columns.validation.failed'), 'error', 5000);
        },
      });
  }

  private handlePreviewLoadResult(result: PreviewLoadResult): void {
    this._datasetWizardStore.setColumnsValidationResult(result.response, result.validationSignature);
    if (result.kind === 'invalid') {
      this.previewValidated.set(false);
      this.clearPreview();
      this.notify(this._translateService.instant('dataset.columns.validation.failed'), 'warning', 4000);
      return;
    }

    this.setPreviewRows(result.rows);
    this.previewValidated.set(true);
  }

  private finishBootstrapLoading(options: PreviewLoadOptions): void {
    if (options.bootstrap) {
      this.stepBootstrapLoading.set(false);
    }
  }

  private translateValidationIssue(
    issue: ExtractColumnsValidationIssueCode,
    column?: ConnectorMetadataPreviewColumn,
    invalidColumn?: ExtractColumnsInvalidColumn,
  ): string {
    switch (issue) {
      case 'SOURCE_NAME_INVALID_REQUIRES_ALIAS':
        return this.withSuggestedAlias(
          this._translateService.instant('dataset.columns.validation.issue.sourceNameRequiresAlias'),
          column
            ? resolveValidationSuggestedAlias(column, this._datasetWizardStore.invalidColumns())
            : (invalidColumn?.suggestedAlias ?? null),
        );
      case 'ALIAS_INVALID':
        return this.withSuggestedAlias(
          this._translateService.instant('dataset.columns.validation.issue.aliasInvalid'),
          invalidColumn?.suggestedAlias ?? null,
        );
      case 'OUTPUT_NAME_ALREADY_EXISTS':
        return this._translateService.instant('dataset.columns.validation.issue.outputAlreadyExists');
      case 'OUTPUT_NAME_DUPLICATE':
      default:
        return this._translateService.instant('dataset.columns.validation.issue.outputDuplicate');
    }
  }

  private getBackendInvalidColumn(columnName: string): ExtractColumnsInvalidColumn | undefined {
    return this._datasetWizardStore.invalidColumns().find((invalidColumn) => invalidColumn.columnName === columnName);
  }

  private applySuggestedAlias(column: ConnectorMetadataPreviewColumn): ConnectorMetadataPreviewColumn {
    if (column.alias?.trim() || isMetadataColumnIdentifierValid(column)) {
      return column;
    }
    const suggestedAlias = resolveColumnSuggestedAlias(column);
    if (!suggestedAlias) {
      return column;
    }
    return {
      ...column,
      alias: suggestedAlias,
    };
  }

  private resolveSalesforceValidationMetadata(
    columnName: string,
  ): Pick<ConnectorMetadataPreviewColumn, 'identifierValid' | 'suggestedAlias'> | null {
    if (this._datasetWizardStore.connectorType() !== 'SALESFORCE' || !columnName.includes('.')) {
      return null;
    }

    const suggestedAlias = columnName
      .trim()
      .replace(/[^A-Za-z0-9_]+/g, '_')
      .replace(/^_+|_+$/g, '');

    if (!suggestedAlias) {
      return null;
    }

    return {
      identifierValid: false,
      suggestedAlias,
    };
  }

  private withSuggestedAlias(message: string, suggestedAlias: string | null | undefined): string {
    if (!suggestedAlias) {
      return message;
    }
    return `${message} ${this._translateService.instant('dataset.columns.validation.suggestedAlias', { alias: suggestedAlias })}`;
  }

  private resolveErrorMessage(error: any, fallbackKey: string): string {
    const message = error?.error?.message ?? error?.error ?? error?.message ?? fallbackKey;
    return this._translateService.instant(message);
  }

  private isCloudMode(): boolean {
    return this._datasetWizardStore.sourceFamily() === 'CLOUD';
  }

  private getDatasetParamString(paramCode: string): string | null {
    return (
      this._datasetWizardStore.datasetConnectorParams().find((param) => param.codParametro === paramCode)
        ?.valoreStringa ?? null
    );
  }

  private getDatasetParamBoolean(paramCode: string, fallback: boolean): boolean {
    return (
      this._datasetWizardStore.datasetConnectorParams().find((param) => param.codParametro === paramCode)
        ?.valoreBooleano ?? fallback
    );
  }

  private getInferColumnTypesParam(): boolean | null {
    return (
      this._datasetWizardStore
        .datasetConnectorParams()
        .find((param) => param.codParametro === DatasetColumnSelectorComponent.INFER_COLUMN_TYPES_PARAM)
        ?.valoreBooleano ?? null
    );
  }

  private buildCloudRequest(fileType: ConnectorType.CSV | ConnectorType.EXCEL): CloudFileRequest | null {
    const connectorId = this._datasetWizardStore.idConnector()?.trim();
    const filePath = this._datasetWizardStore.connectorEntity()?.trim();
    if (!connectorId || !filePath) {
      return null;
    }

    return {
      connectorId,
      filePath,
      fileType,
      hasHeader: this.getDatasetParamBoolean(DatasetColumnSelectorComponent.HAS_HEADER_PARAM, true),
      inferColumnTypes: this.getInferColumnTypesParam(),
      sheetName: this.getDatasetParamString(DatasetColumnSelectorComponent.SHEET_PARAM),
      separator: this.getDatasetParamString(DatasetColumnSelectorComponent.SEPARATOR_PARAM),
      quoteChar: this.getDatasetParamString(DatasetColumnSelectorComponent.QUOTE_CHAR_PARAM),
    };
  }

  private isSalesforceSavedQuerySource(): boolean {
    return (
      this._datasetWizardStore.connectorType() === 'SALESFORCE' &&
      resolveSalesforceSourceType(this._datasetWizardStore.datasetConnectorParams()) ===
        SALESFORCE_SOURCE_TYPE_SAVED_QUERY
    );
  }

  getColumnTypeMeta(column: ConnectorMetadataPreviewColumn | null | undefined): ColumnTypeMeta {
    return resolveColumnTypeMeta(this.getEffectiveColumnType(column), (value) =>
      this._dataGridColumnTypeMapper.mapType(value),
    );
  }

  getEffectiveColumnType(column: ConnectorMetadataPreviewColumn | null | undefined): string {
    return column ? getEffectiveColumnType(column) : 'Utf8';
  }

  getColumnTitle(column: ConnectorMetadataPreviewColumn | null | undefined): string {
    return column ? getColumnTitle(column) : '';
  }

  hasColumnCast(column: ConnectorMetadataPreviewColumn | null | undefined): boolean {
    return column ? hasCast(column) : false;
  }

  getEditingColumn(): ConnectorMetadataPreviewColumn | undefined {
    const columnName = this.editingColumnName();
    if (!columnName) {
      return undefined;
    }
    return this.columnsSelected().find((column) => column.columnName === columnName);
  }

  getCastEditingColumn(): ConnectorMetadataPreviewColumn | undefined {
    const columnName = this.castEditingColumnName();
    if (!columnName) {
      return undefined;
    }
    return this.columnsSelected().find((column) => column.columnName === columnName);
  }

  hasCast(column: ConnectorMetadataPreviewColumn): boolean {
    return hasCast(column);
  }

  private updateSelectedColumn(
    columnName: string,
    updater: (column: ConnectorMetadataPreviewColumn) => ConnectorMetadataPreviewColumn,
  ): void {
    this.columns_to_add.update((items) =>
      items.map((item) =>
        item.column?.columnName === columnName
          ? {
              ...item,
              column: updater(item.column),
            }
          : item,
      ),
    );
  }

  private applyCastUpdate(columnName: string, cast: ColumnCastConfig | null, previewRows?: any[]): void {
    this.updateSelectedColumn(columnName, (column) => ({
      ...column,
      cast,
    }));
    this.castEditingColumnName.set(null);
    this.castDialogVisible.set(false);
    this.castValidationResult.set(null);
    this.validateSelectedColumns();
    if (previewRows) {
      this.setPreviewRows(previewRows);
      this.previewValidated.set(true);
      return;
    }
    this.previewValidated.set(false);
    this.clearPreview();
  }

  private setPreviewRows(rows: any[]): void {
    const normalizedRows = normalizeDatasetColumnSelectorPreviewRows(rows, this.columnsSelected());
    this.previewRows.set(normalizedRows);
    this.previewData.set(
      new CustomStore({
        load: () => lastValueFrom(of(normalizedRows)),
      }),
    );
  }

  private buildColumnsWithUpdatedCast(
    columnName: string,
    cast: ColumnCastConfig | null,
  ): ConnectorMetadataPreviewColumn[] {
    return this.columnsSelected().map((column) =>
      column.columnName === columnName
        ? {
            ...column,
            cast,
          }
        : column,
    );
  }

  private loadPreviewRows(columns: ConnectorMetadataPreviewColumn[]): Observable<any[]> | null {
    return loadDatasetColumnSelectorPreviewRows(
      columns,
      {
        connectorType: this._datasetWizardStore.connectorType(),
        connectorId: this._datasetWizardStore.idConnector(),
        connector: this._datasetWizardStore.connector(),
        connectorEntity: this._datasetWizardStore.connectorEntity(),
        customQuery: this._datasetWizardStore.customQuery?.() || '',
        isCloudMode: this.isCloudMode(),
        sheetName: this.getDatasetParamString(DatasetColumnSelectorComponent.SHEET_PARAM) ?? '',
        hasHeader: this.getDatasetParamBoolean(DatasetColumnSelectorComponent.HAS_HEADER_PARAM, true),
        inferColumnTypes: this.getInferColumnTypesParam(),
        separator: this.getDatasetParamString(DatasetColumnSelectorComponent.SEPARATOR_PARAM),
        quoteChar: this.getDatasetParamString(DatasetColumnSelectorComponent.QUOTE_CHAR_PARAM),
        hubSpotFilterGroups: this.getHubSpotFilterGroups(),
        salesforceSavedQueryId: this.isSalesforceSavedQuerySource()
          ? resolveSalesforceSavedQueryId(this._datasetWizardStore.datasetConnectorParams())
          : null,
      },
      {
        csvConnectorService: this.csvConnectorService,
        excelConnectorService: this.excelConnectorService,
        databaseConnectorService: this.databaseConnectorService,
        sqsStore: this.sqsStore,
        apiStepStore: this.apiStepStore,
        restApiStepStore: this.restApiStepStore,
        salesforceConnectorService: this.salesforceConnectorService,
        hubSpotConnectorService: this.hubSpotConnectorService,
      },
    );
  }

  private bindLockedHookApiPath(): void {
    const lockedPath = this.getDatasetParamString(DatasetColumnSelectorComponent.DATA_PATH_PARAM) ?? '';
    this.apiStepStore.setSelectedPath(lockedPath);
    this.apiStepStore.lockSelectedPath();
    this.upsertDataPathParam(lockedPath);
  }

  private upsertDataPathParam(dataPath: string): void {
    const currentDataPath = this.getDatasetParamString(DatasetColumnSelectorComponent.DATA_PATH_PARAM);
    if (currentDataPath === dataPath) {
      return;
    }
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: DatasetColumnSelectorComponent.DATA_PATH_PARAM,
      valoreStringa: dataPath,
    });
  }

  private requiresPreviewValidation(): boolean {
    return ['DATABASE', 'HUBSPOT'].includes(this._datasetWizardStore.connectorType() ?? '');
  }

  private getHubSpotFilterGroups(): HubSpotSearchFilterGroup[] {
    const filtersPayload = this.getDatasetParamJson<HubSpotSearchFiltersPayload>(
      DatasetColumnSelectorComponent.HUBSPOT_SEARCH_FILTERS_PARAM,
    );
    return filtersPayload?.filterGroups ?? [];
  }

  private hubSpotSnapshotColumns(): ConnectorMetadataColumn[] {
    const snapshot = this.getDatasetParamJson<HubSpotDiscoverySnapshot>(
      DatasetColumnSelectorComponent.HUBSPOT_DISCOVERY_SNAPSHOT_PARAM,
    );
    return (snapshot?.properties ?? [])
      .filter((property) => property.name)
      .map((property) => ({
        columnName: property.name,
        dataType: property.type ?? 'string',
        length: undefined,
        precision: undefined,
      }));
  }

  private persistHubSpotSelectedPropertiesSnapshot(): void {
    const existingSnapshot = this.getDatasetParamJson<HubSpotDiscoverySnapshot>(
      DatasetColumnSelectorComponent.HUBSPOT_DISCOVERY_SNAPSHOT_PARAM,
    );
    const selectedProperties = this.resolveHubSpotSelectedProperties(existingSnapshot);
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: DatasetColumnSelectorComponent.HUBSPOT_DISCOVERY_SNAPSHOT_PARAM,
      valoreJson: {
        objectTypeId: this._datasetWizardStore.connectorEntity(),
        name: existingSnapshot?.name,
        label: existingSnapshot?.label,
        custom: existingSnapshot?.custom,
        properties: selectedProperties,
      },
    });
  }

  private resolveHubSpotSelectedProperties(snapshot?: HubSpotDiscoverySnapshot | null): any[] {
    const selectedNames = new Set(this.columnsSelected().map((column) => column.columnName));
    const discoveredProperties = snapshot?.properties ?? [];
    if (discoveredProperties.length > 0) {
      return discoveredProperties.filter((property) => selectedNames.has(property.name));
    }
    return this.columnsSelected().map((column) => ({
      name: column.columnName,
      type: column.type,
      length: column.length,
      precision: column.precision,
    }));
  }

  private getDatasetParamJson<T>(paramCode: string): T | null {
    return (
      (this._datasetWizardStore.datasetConnectorParams().find((param) => param.codParametro === paramCode)
        ?.valoreJson as T | undefined) ?? null
    );
  }
}
