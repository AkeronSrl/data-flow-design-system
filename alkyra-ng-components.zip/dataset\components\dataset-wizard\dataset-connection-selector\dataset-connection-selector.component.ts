import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { ChangeDetectionStrategy, Component, computed, inject, signal, viewChild } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';

import { DatasetWizardStore } from '../+store/dataset-wizard.store';
import { DatasetColumnSelectorComponent } from '../dataset-column-selector/dataset-column-selector.component';
import { DatasetFlowContext } from '../flow-steps/dataset-flow-context.model';
import { SelectorAmazonSqsComponent } from './selector-amazon-sqs/selector-amazon-sqs.component';
import { SelectorCsvComponent } from './selector-csv/selector-csv.component';
import { SelectorDatabaseComponent } from './selector-database/selector-database.component';
import { SelectorExcelComponent } from './selector-excel/selector-excel.component';
import { SelectorHookApiComponent } from './selector-hook-api/selector-hook-api.component';
import { SelectorHubSpotComponent } from './selector-hubspot/selector-hubspot.component';
import { SelectorRestApiComponent } from './selector-rest-api/selector-rest-api.component';
import { SelectorSalesforceComponent } from './selector-salesforce/selector-salesforce.component';
import { StepSelector } from './step-selector.model';

@Component({
  selector: 'alk-dataset-connection-selector',
  templateUrl: './dataset-connection-selector.component.html',
  styleUrls: ['./dataset-connection-selector.component.scss'],
  standalone: true,
  imports: [
    TiaraSuiteWizardStepComponent,
    TranslatePipe,
    SelectorDatabaseComponent,
    SelectorSalesforceComponent,
    SelectorCsvComponent,
    SelectorExcelComponent,
    SelectorAmazonSqsComponent,
    SelectorHookApiComponent,
    SelectorHubSpotComponent,
    SelectorRestApiComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DatasetConnectionSelectorComponent extends FlowWizardStep<DatasetFlowContext> {
  static readonly stepId = 'dataset-source-config';
  static readonly candidates: readonly FlowWizardStepClass<DatasetFlowContext>[] = [DatasetColumnSelectorComponent];

  stepComponentRef = viewChild<StepSelector>('stepComponent');
  validComponentSignal = signal<boolean>(false);
  readonly _datasetWizardStore = inject(DatasetWizardStore);

  onValidChange(event: boolean) {
    this.validComponentSignal.set(event);
  }

  override canGoforward = computed((): boolean => {
    return this.validComponentSignal();
  });

  override onBackward(): void {
    this.stepComponentRef()?.clearStore();
  }

  override onForward(): void {
    this.stepComponentRef()?.onForward?.();
  }
}
