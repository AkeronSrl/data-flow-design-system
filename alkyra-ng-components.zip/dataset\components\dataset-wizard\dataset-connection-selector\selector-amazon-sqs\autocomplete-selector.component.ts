import { ScreenLockStore } from '@alkyra/screen-lock/+store/screen-lock.store';
import { Component, inject, OnInit } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';

import { SqsStepStore } from '../../+store/sqs-step.store';
@Component({
  selector: 'alk-sqs-autocomplete-list',
  standalone: true,
  imports: [DxTextAreaModule, DxButtonModule, TranslateModule],
  template: `
    <div class="autocomplete-panel">
      <dx-text-area
        class="input"
        [value]="selectedPath()"
        [disabled]="false"
        [readOnly]="false"
        (onValueChanged)="onValueChange($event.value)"
        [placeholder]="'Type JSON path (e.g. root.Body.email)' | translate"
        width="100%"
        height="50px"
      ></dx-text-area>
    </div>
  `,
  styles: [
    `
      .autocomplete-panel {
        display: flex;
        flex-direction: column;
        gap: 8px;
      }
      .row {
        display: flex;
        gap: 4px;
        align-items: center;
      }
    `,
  ],
})
export class SqsAutocompleteListComponent implements OnInit {
  private readonly store = inject(SqsStepStore);
  private readonly _screenLockStore = inject(ScreenLockStore);

  selectedPath = this.store.selectedPath;

  ngOnInit(): void {
    this.store.clearSelectedPaths();
  }

  onValueChange(value: string) {
    if (this.store.validateJsonPaths(value)) {
      this.store.selectPath(value);
    } else {
      this._screenLockStore.unlockScreen({ message: `Invalid JSON path: ${value}`, status: 'error' });
    }
  }

  /**
   * Validates that a single dot-notated path exists in the given object.
   * @param obj The object to check
   * @param path The path string, e.g. "root.body.id"
   */
}
