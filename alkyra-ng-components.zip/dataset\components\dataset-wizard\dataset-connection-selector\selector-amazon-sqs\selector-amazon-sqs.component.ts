import { TiaraCollapsableContainerComponent } from '@akeron-ng/tiara-ng/tiara-collapsable-container';
import { ChangeDetectionStrategy, Component, effect, inject, OnInit, output } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';

import { DatasetWizardStore } from '../../+store/dataset-wizard.store';
import { SqsStepStore } from '../../+store/sqs-step.store';
import { StepSelector } from '../step-selector.model';
import { SqsAutocompleteListComponent } from './autocomplete-selector.component';
import { SqsTreeSelectorComponent } from './tree-selector.component';

@Component({
  selector: 'alk-selector-amazon-sqs',
  templateUrl: './selector-amazon-sqs.component.html',
  styleUrl: './selector-amazon-sqs.component.scss',
  standalone: true,
  imports: [
    TranslatePipe,
    TiaraCollapsableContainerComponent,
    SqsAutocompleteListComponent,
    SqsTreeSelectorComponent,
    DxScrollViewModule,
    DxDataGridModule,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SelectorAmazonSqsComponent implements OnInit, StepSelector {
  valid = output<boolean>();
  readonly _datasetWizardStore = inject(DatasetWizardStore);
  private readonly store = inject(SqsStepStore);

  previewData = this.store.previewData;

  constructor() {
    this.store.getSqsJson();
    effect(() => {
      const value = this.store.selectedPath();
      if (value === '') {
        this.valid.emit(false);
        return;
      }

      this.valid.emit(this.store.validateJsonPaths(value));
    });
  }
  ngOnInit(): void {
    this._datasetWizardStore.setIdConnector(this.store.getValoreStringaFromPipeLineParamByCode('connectionId') || '');
    this._datasetWizardStore.setConnectorEntity('AMAZON_SQS');
  }

  clearStore(): void {
    this._datasetWizardStore.setIdConnector('');
    this._datasetWizardStore.setConnectorEntity('');
    this._datasetWizardStore.setDatasetConnectorParams([]);
    this.store.clearSelectedPaths();
  }
}
