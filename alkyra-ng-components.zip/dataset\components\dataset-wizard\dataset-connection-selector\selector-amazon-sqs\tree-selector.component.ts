import { AfterViewInit, Component, effect, inject, ViewChild } from '@angular/core';
import { DxTreeViewComponent, DxTreeViewModule } from 'devextreme-angular/ui/tree-view';

import { SqsStepStore } from '../../+store/sqs-step.store';

@Component({
  selector: 'alk-sqs-tree-selector',
  standalone: true,
  imports: [DxTreeViewModule],
  template: `
    <dx-tree-view
      #treeView
      dataStructure="tree"
      [focusStateEnabled]="false"
      [expandedExpr]="'expanded'"
      [items]="treeData"
      selectionMode="single"
      [height]="'100%'"
      [width]="'100%'"
      [selectByClick]="true"
      [selectNodesRecursive]="true"
      [hasItemsExpr]="'lastChild'"
      (onItemSelectionChanged)="onSelect($event)"
    >
    </dx-tree-view>
  `,
  styles: [
    `
      .tree-selector-container {
        display: flex;
        box-sizing: border-box;
        overflow: auto;
      }
    `,
  ],
})
export class SqsTreeSelectorComponent implements AfterViewInit {
  private readonly store = inject(SqsStepStore);
  treeData: any[] = [];

  jsonData = {};
  @ViewChild('treeView', { static: false }) treeView!: DxTreeViewComponent;

  constructor() {
    effect(() => {
      const schema = this.store.jsonSchema();
      const treeNodes = this.jsonToTree(schema ?? {}, '', false);

      this.jsonData = schema ?? {};

      this.treeData = treeNodes;

      if (this.treeView?.instance) {
        // ensure UI reflects the updated data in case view already rendered
        this.treeView.instance.option('items', this.treeData);
        this.treeView.instance.expandAll();
      }
    });
  }

  ngAfterViewInit(): void {
    // Wait for initial render before trying to expand
    setTimeout(() => {
      if (this.treeView?.instance) {
        this.treeView.instance.expandAll();
      }
    });
  }

  onSelect(e: any) {
    const node = e.node;
    // console.log('Selected node:', node);

    this.store.selectPath(node.key);
  }

  /**
   * Converts a JSON object to a tree structure for dx-tree-view.
   * @param obj The JSON object
   * @param parent The parent path
   * @param includeLastChild If true, include all properties (leafs and objects). If false, only include object children (skip leafs).
   */
  private jsonToTree(obj: any, parent = '', includeLastChild = true): any[] {
    return Object.keys(obj)
      .filter((key) => includeLastChild || (typeof obj[key] === 'object' && obj[key] !== null))
      .map((key) => {
        const fullPath = parent ? `${parent}.${key}` : key;
        const node: any = { id: fullPath, text: key };
        if (typeof obj[key] === 'object' && obj[key] !== null) {
          const children = this.jsonToTree(obj[key], fullPath, includeLastChild);
          if (children.length > 0) {
            node.items = children;
          }
        }
        return node;
      });
  }
}
