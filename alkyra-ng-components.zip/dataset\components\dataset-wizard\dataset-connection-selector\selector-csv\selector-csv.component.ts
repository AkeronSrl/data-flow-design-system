import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { TiaraCollapsableContainerComponent } from '@akeron-ng/tiara-ng/tiara-collapsable-container';
import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { CsvConnector } from '@alkyra/csv-connector/models/csv-connector.model';
import { CsvConnectorService } from '@alkyra/csv-connector/services/csv-connector.service';
import { CloudFileRequest } from '@alkyra/dataset/components/dataset-wizard/models/cloud-file-request.model';
import { ScreenLockStore } from '@alkyra/screen-lock/+store/screen-lock.store';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, inject, OnInit, output, signal } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { CustomStore } from 'devextreme/common/data';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxCheckBoxModule } from 'devextreme-angular/ui/check-box';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxDropDownBoxModule } from 'devextreme-angular/ui/drop-down-box';
import { DxFormModule } from 'devextreme-angular/ui/form';
import { DxListModule } from 'devextreme-angular/ui/list';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxTreeViewModule } from 'devextreme-angular/ui/tree-view';
import { lastValueFrom, Observable, of } from 'rxjs';

import { DatasetWizardStore } from '../../+store/dataset-wizard.store';
import { StepSelector } from '../step-selector.model';

@Component({
  selector: 'alk-selector-csv',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    DxListModule,
    DxFormModule,
    DxButtonModule,
    DxScrollViewModule,
    DxDropDownBoxModule,
    DxTreeViewModule,
    DxDataGridModule,
    DxCheckBoxModule,
    DxTextBoxModule,
    TiaraCollapsableContainerComponent,
    TiaraCircularIllustrationComponent,
    TiaraNameDescriptionLabelComponent,
  ],
  templateUrl: './selector-csv.component.html',
  styleUrl: './selector-csv.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SelectorCsvComponent implements OnInit, StepSelector {
  private static readonly HAS_HEADER_PARAM = 'hasHeader';
  private static readonly INFER_COLUMN_TYPES_PARAM = 'inferColumnTypes';
  private static readonly SEPARATOR_PARAM = 'separator';
  private static readonly QUOTE_CHAR_PARAM = 'quoteChar';

  private readonly _screenLockStore = inject(ScreenLockStore);
  valid = output<boolean>();

  readonly _datasetWizardStore = inject(DatasetWizardStore);
  private readonly _csvConnectorService = inject(CsvConnectorService);
  readonly isCloudMode = computed(() => this._datasetWizardStore.sourceFamily() === 'CLOUD');
  readonly cloudFilePath = computed(() => this._datasetWizardStore.connectorEntity());
  readonly hasHeader = signal(true);
  readonly inferColumnTypes = signal(true);
  readonly separator = signal(',');
  readonly quoteChar = signal('"');
  readonly isCloudPreviewExecuted = signal(false);
  readonly cloudPreviewDisabled = computed(() => !this.buildCloudRequest());
  readonly cloudFormData = computed(() => ({
    fileName: this.cloudFilePath(),
    hasHeader: this.hasHeader(),
    inferColumnTypes: this.inferColumnTypes(),
    separator: this.separator(),
    textQualifier: this.quoteChar(),
  }));

  $connectors: Observable<CsvConnector[]> = of([]);
  sourceMetadata = signal<any[]>([]);
  selectedItemsKey = signal<string[]>([]);
  previewData = signal<CustomStore>(
    new CustomStore({
      load: () => lastValueFrom(of([])),
    }),
  );

  isFormValid = effect(() => {
    const connector = this._datasetWizardStore.idConnector();
    if (this.isCloudMode()) {
      this.valid.emit(
        !!connector?.trim() && !!this._datasetWizardStore.connectorEntity()?.trim() && !!this.separator()?.trim(),
      );
      return;
    }

    this.valid.emit(!!connector?.trim());
  });

  ngOnInit(): void {
    this.initializeInferColumnTypesDefault();
    if (this.isCloudMode()) {
      this.initializeCloudDefaults();
      this.resetData();
      this.isCloudPreviewExecuted.set(false);
      return;
    }

    this.$connectors = this._csvConnectorService.findCsvConnectors();
  }

  clearStore(): void {
    if (this.isCloudMode()) {
      this._datasetWizardStore.removeConnecotorParam(SelectorCsvComponent.HAS_HEADER_PARAM);
      this._datasetWizardStore.removeConnecotorParam(SelectorCsvComponent.INFER_COLUMN_TYPES_PARAM);
      this._datasetWizardStore.removeConnecotorParam(SelectorCsvComponent.SEPARATOR_PARAM);
      this._datasetWizardStore.removeConnecotorParam(SelectorCsvComponent.QUOTE_CHAR_PARAM);
      this.isCloudPreviewExecuted.set(false);
      this.resetData();
      return;
    }

    this._datasetWizardStore.setIdConnector('');
    this._datasetWizardStore.setConnectorEntity('');
    this._datasetWizardStore.removeConnecotorParam(SelectorCsvComponent.INFER_COLUMN_TYPES_PARAM);
  }

  onDatasourceSelected(event: any): void {
    const selectedId = event.addedItems[0]?.id;
    this._datasetWizardStore.setIdConnector(selectedId);
    this._screenLockStore.lockScreen();
    lastValueFrom(this._csvConnectorService.findConnector(selectedId)).then((connector) => {
      this._datasetWizardStore.setConnector(connector);
      this.loadData(connector);
      this._datasetWizardStore.setConnectorEntity(connector.fileName);
    });
    this._screenLockStore.unlockScreen();
  }

  resetData(): void {
    const previewCustomStore = new CustomStore({
      load: () => lastValueFrom(of([])),
    });
    this.previewData.set(previewCustomStore);
  }

  loadData(actualCsvConnector: CsvConnector): void {
    if (!this._datasetWizardStore.idConnector()?.trim()) {
      this.resetData();
      return;
    }
    const previewCustomStore = new CustomStore({
      load: () =>
        lastValueFrom(
          this._csvConnectorService.csvPreview(actualCsvConnector, false, undefined, this.inferColumnTypes()),
        ),
    });
    this.previewData.set(previewCustomStore);
  }

  onHasHeaderChanged(event: boolean | { value?: boolean }): void {
    const hasHeader = typeof event === 'boolean' ? event : !!event?.value;
    this.hasHeader.set(hasHeader);
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: SelectorCsvComponent.HAS_HEADER_PARAM,
      valoreBooleano: hasHeader,
    });
    this.resetCloudPreview();
  }

  onSeparatorChanged(event: string | { value?: string }): void {
    const separator = typeof event === 'string' ? event : (event?.value ?? '');
    this.separator.set(separator);
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: SelectorCsvComponent.SEPARATOR_PARAM,
      valoreStringa: separator,
    });
    this.resetCloudPreview();
  }

  onQuoteCharChanged(event: string | { value?: string }): void {
    const quoteChar = typeof event === 'string' ? event : (event?.value ?? '');
    this.quoteChar.set(quoteChar);
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: SelectorCsvComponent.QUOTE_CHAR_PARAM,
      valoreStringa: quoteChar,
    });
    this.resetCloudPreview();
  }

  onInferColumnTypesChanged(event: boolean | { value?: boolean }): void {
    const inferColumnTypes = typeof event === 'boolean' ? event : !!event?.value;
    this.inferColumnTypes.set(inferColumnTypes);
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: SelectorCsvComponent.INFER_COLUMN_TYPES_PARAM,
      valoreBooleano: inferColumnTypes,
    });

    if (this.isCloudMode()) {
      this.resetCloudPreview();
      return;
    }

    const connector = this._datasetWizardStore.connector() as CsvConnector | null;
    if (!connector || !this._datasetWizardStore.idConnector()?.trim()) {
      this.resetData();
      return;
    }

    this.loadData(connector);
  }

  private initializeCloudDefaults(): void {
    const hasHeaderParam = this._datasetWizardStore
      .datasetConnectorParams()
      .find((param) => param.codParametro === SelectorCsvComponent.HAS_HEADER_PARAM)?.valoreBooleano;
    const separatorParam = this._datasetWizardStore
      .datasetConnectorParams()
      .find((param) => param.codParametro === SelectorCsvComponent.SEPARATOR_PARAM)?.valoreStringa;
    const quoteCharParam = this._datasetWizardStore
      .datasetConnectorParams()
      .find((param) => param.codParametro === SelectorCsvComponent.QUOTE_CHAR_PARAM)?.valoreStringa;

    this.hasHeader.set(hasHeaderParam ?? true);
    this.separator.set(separatorParam?.trim() || ',');
    this.quoteChar.set(quoteCharParam ?? '"');

    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: SelectorCsvComponent.HAS_HEADER_PARAM,
      valoreBooleano: this.hasHeader(),
    });
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: SelectorCsvComponent.SEPARATOR_PARAM,
      valoreStringa: this.separator(),
    });
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: SelectorCsvComponent.QUOTE_CHAR_PARAM,
      valoreStringa: this.quoteChar(),
    });
  }

  private initializeInferColumnTypesDefault(): void {
    const inferColumnTypesParam = this._datasetWizardStore
      .datasetConnectorParams()
      .find((param) => param.codParametro === SelectorCsvComponent.INFER_COLUMN_TYPES_PARAM)?.valoreBooleano;

    this.inferColumnTypes.set(inferColumnTypesParam ?? true);
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: SelectorCsvComponent.INFER_COLUMN_TYPES_PARAM,
      valoreBooleano: this.inferColumnTypes(),
    });
  }

  showCloudPreview(): void {
    const request = this.buildCloudRequest();
    if (!request) {
      this.resetData();
      this.isCloudPreviewExecuted.set(false);
      return;
    }

    const previewCustomStore = new CustomStore({
      load: () => lastValueFrom(this._csvConnectorService.cloudCsvPreview(request)),
    });
    this.previewData.set(previewCustomStore);
    this.isCloudPreviewExecuted.set(true);
  }

  private buildCloudRequest(): CloudFileRequest | null {
    const connectorId = this._datasetWizardStore.idConnector()?.trim();
    const filePath = this._datasetWizardStore.connectorEntity()?.trim();
    const separator = this.separator().trim();

    if (!connectorId) {
      return null;
    }

    if (!filePath) {
      return null;
    }

    if (!separator) {
      return null;
    }

    return {
      connectorId,
      filePath,
      fileType: ConnectorType.CSV,
      hasHeader: this.hasHeader(),
      inferColumnTypes: this.inferColumnTypes(),
      separator,
      quoteChar: this.quoteChar().trim() || null,
    };
  }

  private resetCloudPreview(): void {
    if (!this.isCloudMode()) {
      return;
    }

    this.resetData();
    this.isCloudPreviewExecuted.set(false);
  }
}
