import { TiaraSectionPanelComponent } from '@akeron-ng/tiara-ng/tiara-section-panel';
import { ConnectorMetadataColumn } from '@alkyra/connector/models/connector-metadata-column.model';
import { DBMSType } from '@alkyra/connector/models/dbms-type.model';
import { DatabaseConnector } from '@alkyra/database-connector/models/database-connector.model';
import { DatabaseSourceMetadata } from '@alkyra/database-connector/models/database-source-metadata.model';
import { DatabaseConnectorService } from '@alkyra/database-connector/services/database-connector.service';
import { sanitizeCustomQueryForPreview } from '@alkyra/dataset/utils/custom-query-sanitizer.util';
import { ScreenLockStore } from '@alkyra/screen-lock/+store/screen-lock.store';
import {
  SchemaDiscoveryExpandEvent,
  SchemaDiscoveryNode,
  SchemaDiscoverySelectionEvent,
} from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import { ExpressionEditorConfig } from '@alkyra/ui/smart-expression-editor/models/expression-editor.model';
import { SmartExpressionEditorComponent } from '@alkyra/ui/smart-expression-editor/smart-expression-editor.component';
import { dbmsTypeToExpressionDialect } from '@alkyra/ui/smart-expression-editor/utils/expression-dialect.util';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, inject, OnInit, output, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { CustomStore } from 'devextreme/common/data';
import { alert } from 'devextreme/ui/dialog';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { catchError, lastValueFrom, map, Observable, of, take, tap } from 'rxjs';

import { DatasetWizardStore } from '../../+store/dataset-wizard.store';
import {
  DatasetConnectionContextComponent,
  DatasetConnectionContextItem,
} from '../../shared/dataset-connection-context/dataset-connection-context.component';
import { DatasetResourceSelectionLayoutComponent } from '../../shared/dataset-resource-selection-layout/dataset-resource-selection-layout.component';
import { StepSelector } from '../step-selector.model';

interface ColumnState {
  expanded: boolean;
  loading: boolean;
  loaded: boolean;
  columns: ConnectorMetadataColumn[];
}

@Component({
  selector: 'alk-selector-database',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    DxDataGridModule,
    TiaraSectionPanelComponent,
    DxButtonModule,
    SmartExpressionEditorComponent,
    SchemaDiscoveryComponent,
    DatasetConnectionContextComponent,
    DatasetResourceSelectionLayoutComponent,
  ],
  templateUrl: './selector-database.component.html',
  styleUrl: './selector-database.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SelectorDatabaseComponent implements OnInit, StepSelector {
  private readonly _screenLockStore = inject(ScreenLockStore);
  private readonly _translateService: TranslateService = inject(TranslateService);
  valid = output<boolean>();

  readonly _datasetWizardStore = inject(DatasetWizardStore);
  private readonly _databaseConnectorService = inject(DatabaseConnectorService);
  customQuery = signal<string>(this._datasetWizardStore.customQuery?.() || '');
  tableColumns = signal<string[]>([]);

  $connectors: Observable<DatabaseConnector[]> = of([]);
  sourceMetadata = signal<DatabaseSourceMetadata[]>([]);
  selectedNodeId = signal<string | null>(null);
  private readonly _columnStates = signal(new Map<string, ColumnState>());
  schemaNodes = computed(() => this.mapDatabaseMetadataToSchemaNodes(this.sourceMetadata(), this._columnStates()));
  previewGridColumns = signal<string[]>([]);
  previewData = signal<CustomStore>(
    new CustomStore({
      load: () => lastValueFrom(of([])),
    }),
  );

  /** Track if preview was run after custom query change (for DATABASE connectors) */
  previewValidated = signal<boolean>(false);
  queryEditorConfig = computed<ExpressionEditorConfig>(() => ({
    dialect: dbmsTypeToExpressionDialect(this._datasetWizardStore.connector()?.dbmsType as DBMSType | undefined),
    columns: this.tableColumns(),
    enforceWherePrefix: true,
    warnOnUnknownFunctions: true,
    maxSuggestions: 25,
  }));

  isFormValid = effect(() => {
    const connector = this._datasetWizardStore.idConnector();
    const tableName = this._datasetWizardStore.connectorEntity();
    this.valid.emit(!!connector?.trim() && !!tableName?.trim() && this.previewValidated());
  });

  ngOnInit(): void {
    this.$connectors = this._databaseConnectorService.findAll().pipe(
      tap((connectors) => {
        const storedConnectorId = this._datasetWizardStore.idConnector()?.trim();
        if (!storedConnectorId || this.sourceMetadata().length > 0) {
          return;
        }

        const connector = connectors.find((item) => item.id === storedConnectorId);
        if (connector?.id) {
          this.loadConnection(connector.id, false);
        }
      }),
    );
    const tableNameInput: string = this._datasetWizardStore.connectorEntity();
    if (this._datasetWizardStore.idConnector()) {
      this._datasetWizardStore.setIdConnector(this._datasetWizardStore.idConnector());
      if (tableNameInput) {
        this._datasetWizardStore.setConnectorEntity(tableNameInput);
      }
    }
  }

  clearStore(): void {
    this._datasetWizardStore.setIdConnector('');
    this._datasetWizardStore.setConnectorEntity('');
    this._datasetWizardStore.setCustomQuery('');
    this._datasetWizardStore.removeConnecotorParam('customQuery');
    this.customQuery.set('');
    this.tableColumns.set([]);
    this.previewGridColumns.set([]);
  }

  toConnectionItems(connectors: DatabaseConnector[] | null): DatasetConnectionContextItem<DatabaseConnector>[] {
    return (connectors ?? [])
      .filter((connector): connector is DatabaseConnector & { id: string } => !!connector.id?.trim())
      .map((connector) => ({
        id: connector.id,
        title: connector.dbname || connector.description || connector.id,
        subtitle: connector.description,
        typeLabel: connector.dbmsType,
        iconSrc: this.databaseIcon(connector.dbmsType),
        iconAlt: connector.dbmsType,
        raw: connector,
      }));
  }

  onConnectionContextSelected(item: DatasetConnectionContextItem<DatabaseConnector>): void {
    this.loadConnection(item.id, item.id !== this._datasetWizardStore.idConnector());
  }

  onDatasourceSelected(event: any): void {
    const selectedId = event.addedItems[0]?.id;
    this.loadConnection(selectedId, true);
  }

  onSchemaNodeSelected(event: SchemaDiscoverySelectionEvent): void {
    const metadata = event.node.data as DatabaseSourceMetadata | undefined;
    if (!metadata?.tableName) {
      return;
    }

    this.selectedNodeId.set(event.nodeId);
    this._datasetWizardStore.setConnectorEntity(metadata.tableName);
    this.loadTableColumns(this._datasetWizardStore.idConnector() ?? '', metadata.tableName);
    this._datasetWizardStore.setCustomQuery('');
    this._datasetWizardStore.removeConnecotorParam('customQuery');
    this.customQuery.set('');
    this.previewValidated.set(false);
    this.previewGridColumns.set([]);
    this.resetData();
  }

  onNodeExpanded(event: SchemaDiscoveryExpandEvent): void {
    const metadata = event.node.data as DatabaseSourceMetadata | undefined;
    if (!metadata?.tableName) return;
    this.updateColumnState(metadata.tableName, { expanded: true });
    this.loadColumnsIfNeeded(metadata.tableName);
  }

  onNodeCollapsed(event: SchemaDiscoveryExpandEvent): void {
    const metadata = event.node.data as DatabaseSourceMetadata | undefined;
    if (metadata?.tableName) {
      this.updateColumnState(metadata.tableName, { expanded: false });
    }
  }

  private loadConnection(selectedId: string | undefined, resetResourceState: boolean): void {
    this._datasetWizardStore.setIdConnector(selectedId ?? '');
    if (resetResourceState) {
      this._datasetWizardStore.resetResourceSelectionState();
      this.customQuery.set('');
      this.tableColumns.set([]);
      this.previewValidated.set(false);
      this.previewGridColumns.set([]);
      this.resetData();
    }
    this._screenLockStore.lockScreen();
    this.sourceMetadata.set([]);
    this.selectedNodeId.set(null);
    this._columnStates.set(new Map());
    if (selectedId) {
      this._databaseConnectorService.findConnector(selectedId).subscribe((connector) => {
        this._datasetWizardStore.setConnector(connector);
      });
      this._databaseConnectorService.getMetadata(this._datasetWizardStore.idConnector()!).subscribe({
        next: (metadata: DatabaseSourceMetadata[]) => {
          const selectedMetadata: DatabaseSourceMetadata | undefined = metadata.find(
            (m: DatabaseSourceMetadata) => m.tableName === this._datasetWizardStore.connectorEntity(),
          );

          this.sourceMetadata.set(metadata);

          if (!selectedMetadata) {
            this._datasetWizardStore.setConnectorEntity('');
            this.resetData();
            this.selectedNodeId.set(null);
            this.tableColumns.set([]);
          } else {
            this.loadTableColumns(selectedId, selectedMetadata.tableName ?? '');
            this.selectedNodeId.set(this.databaseNodeId(selectedMetadata));
            this.previewValidated.set(false);
            this.resetData();
          }
          this._screenLockStore.unlockScreen();
        },
        error: () => {
          this._screenLockStore.unlockScreen();
        },
      });
    } else {
      this._datasetWizardStore.setIdConnector('');
      this.tableColumns.set([]);
      this.resetData();
      this._screenLockStore.unlockScreen();
    }
  }

  onTableValueChanged(e: any) {
    const tableName = e.itemData?.tableName ?? '';
    const metadata = this.sourceMetadata().find((item) => item.tableName === tableName);
    if (metadata) {
      this.onSchemaNodeSelected({ nodeId: this.databaseNodeId(metadata), node: this.mapDatabaseEntityNode(metadata) });
    }
  }

  resetData(): void {
    const previewCustomStore = new CustomStore({
      load: () => lastValueFrom(of([])),
    });
    this.previewData.set(previewCustomStore);
    this.previewGridColumns.set([]);
    return;
  }

  loadData(): void {
    const idConnector = this._datasetWizardStore.idConnector()?.trim();
    const tableName = this._datasetWizardStore.connectorEntity()?.trim();

    if (!idConnector || !tableName) {
      this.resetData();
      return;
    }
    const previewCustomStore = new CustomStore({
      load: () =>
        lastValueFrom(
          this._databaseConnectorService
            .getPreview(
              this._datasetWizardStore.connector(),
              this._datasetWizardStore.connectorEntity(),
              [],
              this.getSanitizedQuery(),
            )
            .pipe(
              tap(() => this.handlePreviewQueryValidation()),
              catchError(() => {
                this.previewValidated.set(false);
                this.previewGridColumns.set([]);
                return of([]);
              }),
              map((rows) => {
                this.previewGridColumns.set(this.extractPreviewColumns(rows));
                return rows;
              }),
            ),
        ),
    });
    this.previewData.set(previewCustomStore);
    this.persistCustomQueryParam();
  }

  private handlePreviewQueryValidation(): void {
    const query = this.getSanitizedQuery();
    this.previewValidated.set(!query || query.includes('WHERE'));
    if (query && !query.includes('WHERE')) {
      alert(
        this._translateService.instant('dataset.filter.wrong.syntax.toast'),
        this._translateService.instant('error.generic'),
      );
    }
  }

  private persistCustomQueryParam(): void {
    const query = this.getSanitizedQuery();
    if (query) {
      this._datasetWizardStore.addDatasetConnectorParam({
        codParametro: 'customQuery',
        valoreStringa: query,
      });
    } else {
      this._datasetWizardStore.removeConnecotorParam('customQuery');
    }
  }

  /**
   * Sanitize and escape custom query for SQL execution
   * - Converts all text to UPPERCASE
   * - Adds single quotes around LIKE patterns if missing
   * - Adds %% wildcards to LIKE patterns
   */
  getSanitizedQuery(): string {
    const query = sanitizeCustomQueryForPreview(this.customQuery());
    this._datasetWizardStore.setCustomQuery(query);
    return query;
  }

  onCustomQueryChanged(newQuery: string): void {
    this.customQuery.set(newQuery);
    // Invalidate preview when user changes the query
    this.previewValidated.set(false);
  }

  private loadTableColumns(connectorId: string, tableName: string): void {
    const normalizedConnectorId = connectorId?.trim();
    const normalizedTableName = tableName?.trim();

    if (!normalizedConnectorId || !normalizedTableName) {
      this.tableColumns.set([]);
      return;
    }

    this._databaseConnectorService
      .columns(normalizedConnectorId, normalizedTableName)
      .pipe(take(1))
      .subscribe({
        next: (columns) => this.tableColumns.set(columns.map((column) => column.columnName)),
        error: () => this.tableColumns.set([]),
      });
  }

  private extractPreviewColumns(rows: unknown): string[] {
    const firstRow = this.getFirstPreviewRow(rows);
    return firstRow ? Object.keys(firstRow) : [];
  }

  private getFirstPreviewRow(rows: unknown): Record<string, unknown> | null {
    if (!Array.isArray(rows) || rows.length === 0) {
      return null;
    }

    const [firstRow] = rows;
    return this.isPreviewRow(firstRow) ? firstRow : null;
  }

  private isPreviewRow(row: unknown): row is Record<string, unknown> {
    return !!row && typeof row === 'object';
  }

  private mapDatabaseMetadataToSchemaNodes(
    metadata: DatabaseSourceMetadata[],
    colStates: Map<string, ColumnState>,
  ): SchemaDiscoveryNode[] {
    const tables = metadata.filter((item) => item.tableType !== 'VIEW');
    const views = metadata.filter((item) => item.tableType === 'VIEW');
    const nodes: SchemaDiscoveryNode[] = [];

    if (tables.length > 0) {
      nodes.push(this.mapDatabaseSectionNode('tables', 'Tables', tables, colStates));
    }

    if (views.length > 0) {
      nodes.push(this.mapDatabaseSectionNode('views', 'Views', views, colStates));
    }

    return nodes;
  }

  private mapDatabaseSectionNode(
    id: string,
    label: string,
    metadata: DatabaseSourceMetadata[],
    colStates: Map<string, ColumnState>,
  ): SchemaDiscoveryNode {
    return {
      id: `dataset-database-section-${id}`,
      kind: 'group' as const,
      label,
      badge: { text: `${metadata.length}` },
      selectable: false,
      expanded: true,
      hasItems: true,
      iconClass: 'dx-icon dx-icon-activefolder',
      items: metadata.map((item) => this.mapDatabaseEntityNode(item, colStates.get(item.tableName))),
    };
  }

  private mapDatabaseEntityNode(metadata: DatabaseSourceMetadata, colState?: ColumnState): SchemaDiscoveryNode {
    return {
      id: this.databaseNodeId(metadata),
      kind: 'entity' as const,
      label: metadata.tableName,
      description: metadata.description,
      searchText: [metadata.tableName, metadata.description, metadata.tableType].filter(Boolean).join(' '),
      selectable: true,
      expanded: colState?.expanded === true,
      hasItems: true,
      loading: colState?.loading === true,
      iconClass: metadata.tableType === 'VIEW' ? 'dx-icon dx-icon-chevrondoubleright' : 'dx-icon dx-icon-fixcolumnleft',
      items: this.buildColumnNodes(metadata.tableName, colState),
      data: metadata,
    };
  }

  private loadColumnsIfNeeded(tableName: string): void {
    const state = this._columnStates().get(tableName);
    if (state?.loading || state?.loaded) return;
    const connectorId = this._datasetWizardStore.idConnector()?.trim();
    if (!connectorId) return;
    this.updateColumnState(tableName, { loading: true });
    this._databaseConnectorService
      .columns(connectorId, tableName)
      .pipe(take(1))
      .subscribe({
        next: (cols) => this.updateColumnState(tableName, { loading: false, loaded: true, columns: cols }),
        error: () => this.updateColumnState(tableName, { loading: false, loaded: true, columns: [] }),
      });
  }

  private buildColumnNodes(tableName: string, colState: ColumnState | undefined): SchemaDiscoveryNode[] {
    if (!colState) {
      return [{ id: `dataset-db-col-idle-${tableName}`, kind: 'status', label: '', selectable: false }];
    }
    if (!colState.loading && !colState.loaded) {
      return [{ id: `dataset-db-col-idle-${tableName}`, kind: 'status', label: '', selectable: false }];
    }
    if (colState.loading) {
      return [
        {
          id: `dataset-db-col-loading-${tableName}`,
          kind: 'status',
          label: 'Loading columns...',
          selectable: false,
          iconClass: 'dx-icon dx-icon-info',
        },
      ];
    }
    if (colState.columns.length === 0) {
      return [
        {
          id: `dataset-db-col-empty-${tableName}`,
          kind: 'status',
          label: 'No columns available',
          selectable: false,
          iconClass: 'dx-icon dx-icon-info',
        },
      ];
    }
    return colState.columns.map((col, i) => ({
      id: `dataset-db-col-${tableName}-${i}`,
      kind: 'property' as const,
      label: col.columnName,
      description: col.dataType,
      searchText: [col.columnName, col.dataType].filter((v): v is string => !!v).join(' '),
      selectable: false,
      iconClass: 'dx-icon dx-icon-codeblock',
      data: col,
    }));
  }

  private updateColumnState(tableName: string, patch: Partial<ColumnState>): void {
    this._columnStates.update((m) => {
      const prev = m.get(tableName) ?? { expanded: false, loading: false, loaded: false, columns: [] };
      return new Map(m).set(tableName, { ...prev, ...patch });
    });
  }

  private databaseNodeId(metadata: DatabaseSourceMetadata): string {
    return `dataset-database-${metadata.tableType ?? 'TABLE'}-${metadata.tableName}`;
  }

  private databaseIcon(dbmsType: DBMSType | undefined): string | undefined {
    switch (dbmsType) {
      case 'POSTGRES':
        return 'assets/db-icon/pg.png';
      case 'SQLSERVER':
        return 'assets/db-icon/mssql.png';
      case 'ORACLE':
        return 'assets/db-icon/oracle.png';
      case 'SAPHANA':
        return 'assets/db-icon/sap.png';
      default:
        return undefined;
    }
  }
}
