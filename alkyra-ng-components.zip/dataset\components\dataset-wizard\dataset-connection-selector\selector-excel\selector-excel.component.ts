import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { TiaraCollapsableContainerComponent } from '@akeron-ng/tiara-ng/tiara-collapsable-container';
import { S3BucketConnector } from '@alkyra/amazon-s3-connector/models/s3-bucket-connector.model';
import { AzureBlobConnector } from '@alkyra/azure-blob-connector/models/azure-blob-connector.model';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { CloudFileRequest } from '@alkyra/dataset/components/dataset-wizard/models/cloud-file-request.model';
import { ExcelConnector } from '@alkyra/excel-connector/models/excel-connector.model';
import { ExcelConnectorService } from '@alkyra/excel-connector/services/excel-connector.service';
import { ScreenLockStore } from '@alkyra/screen-lock/+store/screen-lock.store';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, inject, OnInit, output, signal } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { CustomStore } from 'devextreme/common/data';
import { DxCheckBoxModule } from 'devextreme-angular/ui/check-box';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxDropDownBoxModule } from 'devextreme-angular/ui/drop-down-box';
import { DxListModule } from 'devextreme-angular/ui/list';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTreeViewModule } from 'devextreme-angular/ui/tree-view';
import { lastValueFrom, of } from 'rxjs';

import { DatasetWizardStore } from '../../+store/dataset-wizard.store';
import { StepSelector } from '../step-selector.model';

type CloudStorageConnector = AzureBlobConnector | S3BucketConnector;

function isS3BucketConnector(connector: CloudStorageConnector): connector is S3BucketConnector {
  return connector.type === ConnectorType.S3_BUCKET || connector.connectorType === ConnectorType.S3_BUCKET;
}

@Component({
  selector: 'alk-selector-excel',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    DxListModule,
    DxDropDownBoxModule,
    DxTreeViewModule,
    DxDataGridModule,
    TiaraCollapsableContainerComponent,
    TiaraCircularIllustrationComponent,
    DxSelectBoxModule,
    DxCheckBoxModule,
  ],
  templateUrl: './selector-excel.component.html',
  styleUrl: './selector-excel.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SelectorExcelComponent implements OnInit, StepSelector {
  private readonly SHEET_PARAM = 'sheetName';
  private readonly HAS_HEADER_PARAM = 'hasHeader';

  private readonly _screenLockStore = inject(ScreenLockStore);
  valid = output<boolean>();

  readonly _datasetWizardStore = inject(DatasetWizardStore);
  private readonly _excelConnectorService = inject(ExcelConnectorService);
  readonly isCloudMode = computed(() => this._datasetWizardStore.sourceFamily() === 'CLOUD');
  readonly selectedCloudConnector = computed(
    () => this._datasetWizardStore.connector() as CloudStorageConnector | null,
  );
  readonly cloudFilePath = computed(() => this._datasetWizardStore.connectorEntity());
  readonly selectedCloudConnectorIcon = computed(() =>
    this.selectedCloudConnector()?.connectorType === ConnectorType.S3_BUCKET
      ? 'assets/cloud-icon/s3.png'
      : 'assets/cloud-icon/azure.png',
  );
  readonly selectedCloudConnectorAlt = computed(() =>
    this.selectedCloudConnector()?.connectorType === ConnectorType.S3_BUCKET ? 'Amazon S3' : 'Azure Blob',
  );
  readonly selectedCloudConnectorDescription = computed(() => {
    const connector = this.selectedCloudConnector();
    if (!connector) {
      return '';
    }

    return isS3BucketConnector(connector) ? connector.bucketName : connector.containerName;
  });

  connectors = signal<ExcelConnector[]>([]);
  sheets = signal<string[]>([]);
  selectedSheet = signal<string | null>(null);
  hasHeader = signal<boolean>(true);
  selectedConnector = signal<ExcelConnector | null>(null);
  sourceMetadata = signal<any[]>([]);
  selectedItemsKey = signal<string[]>([]);
  previewData = computed<CustomStore>(() => {
    const sheetName = this.selectedSheet();

    if (this.isCloudMode()) {
      const request = this.buildCloudRequest(sheetName);
      if (request) {
        return new CustomStore({
          load: () => lastValueFrom(this._excelConnectorService.cloudExcelPreview(request)),
        });
      }
    } else {
      const connector = this.selectedConnector();
      if (connector && sheetName) {
        return new CustomStore({
          load: () =>
            lastValueFrom(this._excelConnectorService.excelPreview(connector, false, sheetName, this.hasHeader())),
        });
      }
    }

    return new CustomStore({
      load: () => lastValueFrom(of([])),
    });
  });

  isFormValid = effect(() => {
    const connector = this._datasetWizardStore.idConnector();
    const sheet = this.selectedSheet();

    if (this.isCloudMode()) {
      this.valid.emit(!!connector?.trim() && !!this._datasetWizardStore.connectorEntity()?.trim() && !!sheet?.trim());
      return;
    }

    this.valid.emit(!!connector?.trim() && !!sheet?.trim());
  });

  ngOnInit(): void {
    const storedHasHeader = this._datasetWizardStore
      .datasetConnectorParams()
      .find((p) => p.codParametro === this.HAS_HEADER_PARAM)?.valoreBooleano;
    this.hasHeader.set(storedHasHeader ?? true);
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: this.HAS_HEADER_PARAM,
      valoreBooleano: this.hasHeader(),
    });

    if (this.isCloudMode()) {
      const storedSheet = this._datasetWizardStore
        .datasetConnectorParams()
        .find((p) => p.codParametro === this.SHEET_PARAM)?.valoreStringa;
      this.changeSheet(storedSheet ?? null);
      this.loadCloudSheets();
      return;
    }

    this._excelConnectorService.findExcelConnectors().subscribe((connectors) => {
      this.connectors.set(connectors);
    });
  }

  clearStore(): void {
    this._datasetWizardStore.removeConnecotorParam(this.HAS_HEADER_PARAM);
    this._datasetWizardStore.removeConnecotorParam(this.SHEET_PARAM);
    if (this.isCloudMode()) {
      this.sheets.set([]);
      this.changeSheet(null);
      return;
    }

    this._datasetWizardStore.setIdConnector('');
    this._datasetWizardStore.setConnectorEntity('');
    this._datasetWizardStore.setDatasetConnectorParams([]);
  }

  onDatasourceSelected(event: any): void {
    const selectedId = event.addedItems[0]?.id;
    this.sheets.set([]);
    this.changeSheet(null);
    this._datasetWizardStore.setIdConnector(selectedId);
    this._screenLockStore.lockScreen();
    lastValueFrom(this._excelConnectorService.findConnector(selectedId)).then((connector) => {
      this._datasetWizardStore.setConnector(connector);
      this.selectedConnector.set(connector);
      this._datasetWizardStore.setConnectorEntity(connector.fileName);
      this._excelConnectorService.sheets(connector, false).subscribe((sheets) => {
        this.sheets.set(sheets);
        if (sheets.length > 0) {
          this.changeSheet(sheets[0]);
        }
      });
    });
    this._screenLockStore.unlockScreen();
  }

  changeSheet(sheet: string | null): void {
    this.selectedSheet.set(sheet);
    if (sheet) {
      this._datasetWizardStore.addDatasetConnectorParam({
        codParametro: this.SHEET_PARAM,
        valoreStringa: sheet,
      });
    } else {
      this._datasetWizardStore.removeConnecotorParam(this.SHEET_PARAM);
    }
  }

  changeHasHeaders(hasHeader: boolean): void {
    this.hasHeader.set(hasHeader);
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: this.HAS_HEADER_PARAM,
      valoreBooleano: hasHeader,
    });
  }

  private loadCloudSheets(): void {
    const request = this.buildCloudRequest(this.selectedSheet());
    if (!request) {
      this.sheets.set([]);
      return;
    }

    this._excelConnectorService.cloudSheets(request).subscribe((sheets) => {
      this.sheets.set(sheets);
      if (sheets.length === 0) {
        this.changeSheet(null);
        return;
      }

      if (this.selectedSheet() && sheets.includes(this.selectedSheet()!)) {
        return;
      }

      this.changeSheet(sheets[0]);
    });
  }

  private buildCloudRequest(sheetName: string | null): CloudFileRequest | null {
    const connectorId = this._datasetWizardStore.idConnector()?.trim();
    const filePath = this._datasetWizardStore.connectorEntity()?.trim();
    if (!connectorId || !filePath) {
      return null;
    }

    return {
      connectorId,
      filePath,
      fileType: ConnectorType.EXCEL,
      hasHeader: this.hasHeader(),
      sheetName,
    };
  }
}
