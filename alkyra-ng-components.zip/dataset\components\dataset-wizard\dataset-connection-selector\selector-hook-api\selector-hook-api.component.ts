import { TiaraCollapsableContainerComponent } from '@akeron-ng/tiara-ng/tiara-collapsable-container';
import { ApiStepStore } from '@alkyra/dataset/components/dataset-wizard/+store/api-step.store';
import { ChangeDetectionStrategy, Component, computed, effect, inject, OnInit, output } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';
import { DxTreeViewModule } from 'devextreme-angular/ui/tree-view';

import { DatasetWizardStore } from '../../+store/dataset-wizard.store';
import { StepSelector } from '../step-selector.model';

@Component({
  selector: 'alk-selector-hook-api',
  templateUrl: './selector-hook-api.component.html',
  styleUrl: './selector-hook-api.component.scss',
  standalone: true,
  imports: [
    TranslatePipe,
    TiaraCollapsableContainerComponent,
    DxScrollViewModule,
    DxDataGridModule,
    DxTextAreaModule,
    DxTreeViewModule,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SelectorHookApiComponent implements OnInit, StepSelector {
  private static readonly DATA_PATH_PARAM = 'dataPath';

  valid = output<boolean>();
  readonly _datasetWizardStore = inject(DatasetWizardStore);
  readonly apiStepStore = inject(ApiStepStore);

  previewData = this.apiStepStore.previewData;
  selectedPath = this.apiStepStore.selectedPath;
  treeData = computed(() => this.jsonToTree(this.apiStepStore.jsonSchemaTree() ?? {}, '', false));

  constructor() {
    effect(() => {
      this.valid.emit(this.apiStepStore.validateJsonPath(this.selectedPath()));
    });
  }

  ngOnInit(): void {
    this._datasetWizardStore.setIdConnector('');
    this._datasetWizardStore.setConnectorEntity('HOOK_API');
    this.apiStepStore.loadApiConfig();
  }

  onPathChanged(path: string | null | undefined): void {
    this.apiStepStore.selectPath(path);
  }

  onTreeSelect(event: any): void {
    this.apiStepStore.selectPath(event?.node?.key);
  }

  onForward(): void {
    const lockedPath = this.apiStepStore.normalizedSelectedPath();
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: SelectorHookApiComponent.DATA_PATH_PARAM,
      valoreStringa: lockedPath,
    });
    this.apiStepStore.lockSelectedPath();
  }

  clearStore(): void {
    this._datasetWizardStore.setIdConnector('');
    this._datasetWizardStore.setConnectorEntity('');
    this._datasetWizardStore.setDatasetConnectorParams([]);
    this.apiStepStore.unlockSelectedPath();
    this.apiStepStore.clearSelectedPath();
  }

  private jsonToTree(obj: Record<string, any>, parent = '', includeLastChild = false): any[] {
    return Object.keys(obj)
      .filter((key) => includeLastChild || (typeof obj[key] === 'object' && obj[key] !== null))
      .map((key) => {
        const fullPath = parent ? `${parent}.${key}` : key;
        const node: any = { id: fullPath, text: key };
        if (typeof obj[key] === 'object' && obj[key] !== null) {
          const children = this.jsonToTree(obj[key], fullPath, includeLastChild);
          if (children.length > 0) {
            node.items = children;
          }
        }
        return node;
      });
  }
}
