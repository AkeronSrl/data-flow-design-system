import { TiaraSectionPanelComponent } from '@akeron-ng/tiara-ng/tiara-section-panel';
import {
  TiaraSuiteTreeGroupNode,
  TiaraSuiteTreeItemNode,
  TiaraSuiteTreeNode,
  TiaraSuiteTreeSelectionEvent,
} from '@akeron-ng/tiara-ng-suite/tiara-tree-view';
import { ConnectorMetadataPreviewColumn } from '@alkyra/connector/models/connector-metadata-preview-column.model';
import { DatasetConnectorParamCreateDto } from '@alkyra/dataset/models/dataset-connector-param.model';
import {
  HubSpotConnector,
  HubSpotConnectorStatus,
  HubSpotDiscoverySnapshot,
  HubSpotObject,
  HubSpotProperty,
  HubSpotPropertyOption,
  HubSpotSearchFilter,
  HubSpotSearchFilterGroup,
  HubSpotSearchFiltersPayload,
  HubSpotSearchOperator,
} from '@alkyra/hubspot-connector/models/hubspot-connector.model';
import { HubSpotConnectorService } from '@alkyra/hubspot-connector/services/hubspot-connector.service';
import {
  SchemaDiscoveryExpandEvent,
  SchemaDiscoveryNode,
  SchemaDiscoverySelectionEvent,
} from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, inject, OnInit, output, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { CustomStore } from 'devextreme/common/data';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTagBoxModule } from 'devextreme-angular/ui/tag-box';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { catchError, finalize, lastValueFrom, map, Observable, of, take } from 'rxjs';

import { DatasetWizardStore } from '../../+store/dataset-wizard.store';
import {
  DatasetConnectionContextComponent,
  DatasetConnectionContextItem,
} from '../../shared/dataset-connection-context/dataset-connection-context.component';
import { DatasetResourceSelectionLayoutComponent } from '../../shared/dataset-resource-selection-layout/dataset-resource-selection-layout.component';
import { StepSelector } from '../step-selector.model';

const HUBSPOT_SEARCH_FILTERS_PARAM = 'hubSpotSearchFilters';
const HUBSPOT_DISCOVERY_SNAPSHOT_PARAM = 'hubSpotDiscoverySnapshot';
const MULTI_VALUE_OPERATORS = new Set<HubSpotSearchOperator>(['IN', 'NOT_IN']);
const VALUELESS_OPERATORS = new Set<HubSpotSearchOperator>(['HAS_PROPERTY', 'NOT_HAS_PROPERTY']);
const NUMERIC_OR_DATE_TYPES = new Set<string>(['number', 'date', 'datetime']);

type HubSpotNodeStatus = 'idle' | 'loading' | 'loaded' | 'error';
type HubSpotTreeSectionValue = { nodeType: 'category'; id: string };
type HubSpotTreePropertyValue = { nodeType: 'property'; objectTypeId: string; propertyName: string };
type HubSpotTreePlaceholderValue = { nodeType: 'placeholder'; id: string };
type HubSpotTreeGroupValue = HubSpotObject | HubSpotTreeSectionValue;
type HubSpotTreeItemValue = HubSpotTreePropertyValue | HubSpotTreePlaceholderValue;
type HubSpotTreeNode = TiaraSuiteTreeNode<HubSpotTreeGroupValue, HubSpotTreeItemValue>;
type HubSpotObjectSelection = TiaraSuiteTreeSelectionEvent & { kind: 'group'; value: HubSpotObject };

interface HubSpotFilterRow {
  id: string;
  propertyName: string;
  operator: HubSpotSearchOperator;
  value: string | null;
  values: string[];
}

interface HubSpotOperatorOption {
  label: string;
  value: HubSpotSearchOperator;
}

interface HubSpotObjectNodeState {
  object: HubSpotObject;
  status: HubSpotNodeStatus;
  properties: HubSpotProperty[];
}

interface HubSpotSchemaCategoryConfig {
  id: string;
  labelKey: string;
  states: HubSpotObjectNodeState[];
}

interface HubSpotSchemaStatusConfig {
  objectTypeId: string;
  status: string;
  labelKey?: string;
}

@Component({
  selector: 'alk-selector-hubspot',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    TiaraSectionPanelComponent,
    DxButtonModule,
    DxDataGridModule,
    DxLoadIndicatorModule,
    DxSelectBoxModule,
    DxTagBoxModule,
    DxTextBoxModule,
    SchemaDiscoveryComponent,
    DatasetConnectionContextComponent,
    DatasetResourceSelectionLayoutComponent,
  ],
  templateUrl: './selector-hubspot.component.html',
  styleUrl: './selector-hubspot.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SelectorHubSpotComponent implements OnInit, StepSelector {
  readonly _datasetWizardStore = inject(DatasetWizardStore);
  private readonly hubSpotConnectorService = inject(HubSpotConnectorService);
  private readonly translateService = inject(TranslateService);

  valid = output<boolean>();
  $connectors: Observable<HubSpotConnector[]> = of([]);
  objectStates = signal<Record<string, HubSpotObjectNodeState>>({});
  properties = signal<HubSpotProperty[]>([]);
  filters = signal<HubSpotFilterRow[]>([]);
  previewData = signal<CustomStore>(this.createEmptyPreviewStore());
  previewGridColumns = signal<string[]>([]);
  previewValidated = signal<boolean>(false);
  isLoadingObjects = signal<boolean>(false);
  isLoadingDescribe = signal<boolean>(false);
  searchQuery = signal<string>('');
  selectedObject = signal<HubSpotObject | null>(null);
  selectedTreeNodeId = signal<string | null>(null);
  private filterSequence = 0;

  readonly searchableProperties = computed(() => this.properties().filter((property) => property.name));
  readonly objectTreeNodes = computed<HubSpotTreeNode[]>(() => this.buildObjectTreeNodes());
  readonly schemaNodes = computed<SchemaDiscoveryNode[]>(() => this.buildSchemaNodes());
  readonly visibleObjectTreeNodes = computed<HubSpotTreeNode[]>(() =>
    this.filterTreeNodesByQuery(this.objectTreeNodes(), this.searchQuery()),
  );
  readonly treeEmptyMessageKey = computed(() =>
    this.normalizeValue(this.searchQuery()) ? 'hubspot.objects.search.no.results' : 'hubspot.preview.empty',
  );
  readonly canApplyFilterPreview = computed(
    () =>
      !!this.selectedObject() && !this.isLoadingDescribe() && this.properties().length > 0 && this.areFiltersValid(),
  );

  isFormValid = effect(() => {
    const connectorSelected = !!this._datasetWizardStore.idConnector()?.trim();
    const objectSelected = !!this._datasetWizardStore.connectorEntity()?.trim();
    const propertiesLoaded = !this.isLoadingDescribe() && this.properties().length > 0;
    this.valid.emit(
      connectorSelected && objectSelected && propertiesLoaded && this.areFiltersValid() && this.previewValidated(),
    );
  });

  ngOnInit(): void {
    this.$connectors = this.hubSpotConnectorService
      .findAll()
      .pipe(map((connectors) => connectors.filter((connector) => connector.status === HubSpotConnectorStatus.VALID)));

    const connectorId = this._datasetWizardStore.idConnector();
    if (!connectorId) {
      return;
    }

    if (!this._datasetWizardStore.connector()) {
      this.hubSpotConnectorService
        .findConnector(connectorId)
        .pipe(take(1))
        .subscribe({
          next: (connector) => this._datasetWizardStore.setConnector(connector),
        });
    }

    this.loadObjects(connectorId, this._datasetWizardStore.connectorEntity());
  }

  clearStore(): void {
    this._datasetWizardStore.setIdConnector('');
    this._datasetWizardStore.setConnectorEntity('');
    this._datasetWizardStore.setConnector(null);
    this.clearObjectSelection();
    this.objectStates.set({});
    this.removeHubSpotParams();
  }

  onDatasourceSelected(selection: HubSpotConnector | { addedItems?: HubSpotConnector[] } | null | undefined): void {
    const connector = this.resolveConnectorSelection(selection);
    if (connector?.id !== this._datasetWizardStore.idConnector()) {
      this._datasetWizardStore.resetResourceSelectionState();
      this.removeHubSpotParams();
    }
    this.objectStates.set({});
    this.clearObjectSelection();
    if (!connector?.id) {
      this._datasetWizardStore.setIdConnector('');
      this._datasetWizardStore.setConnector(null);
      return;
    }

    this._datasetWizardStore.setIdConnector(connector.id);
    this._datasetWizardStore.setConnector(connector);
    this.loadObjects(connector.id);
  }

  toConnectionItems(connectors: HubSpotConnector[] | null): DatasetConnectionContextItem<HubSpotConnector>[] {
    return (connectors ?? [])
      .filter((connector): connector is HubSpotConnector & { id: string } => !!connector.id?.trim())
      .map((connector) => ({
        id: connector.id,
        title: connector.description || connector.hubDomain || connector.id,
        subtitle: connector.hubDomain || connector.status,
        typeLabel: 'HubSpot',
        iconSrc: 'assets/cloud-icon/hubspot.svg',
        iconAlt: 'HubSpot Connection',
        raw: connector,
      }));
  }

  onConnectionContextSelected(item: DatasetConnectionContextItem<HubSpotConnector>): void {
    if (item.id === this._datasetWizardStore.idConnector()) {
      return;
    }

    this.onDatasourceSelected(item.raw);
  }

  onSchemaNodeSelected(event: SchemaDiscoverySelectionEvent): void {
    const object = event.node.data as HubSpotObject | undefined;
    if (this.isHubSpotObject(object)) {
      this.selectObject(object);
    }
  }

  onSchemaNodeExpandRequested(event: SchemaDiscoveryExpandEvent): void {
    const object = event.node.data as HubSpotObject | undefined;
    if (this.isHubSpotObject(object)) {
      this.loadDescribe(object, false);
    }
  }

  onTreeNodeSelected(selection: TiaraSuiteTreeSelectionEvent | null): void {
    this.selectedTreeNodeId.set(selection?.nodeId ?? null);
    if (!this.isHubSpotObjectSelection(selection)) {
      return;
    }

    this.selectObject(selection.value);
  }

  onSearchValueChanged(value: string | null | undefined): void {
    this.searchQuery.set((value ?? '').trim());
  }

  addFilter(): void {
    const property = this.searchableProperties()[0];
    if (!property) {
      return;
    }

    this.filters.update((filters) => [...filters, this.createFilterRow(property)]);
    this.persistFilters();
    this.invalidatePreview();
  }

  removeFilter(row: HubSpotFilterRow): void {
    this.filters.update((filters) => filters.filter((filter) => filter.id !== row.id));
    this.persistFilters();
    this.invalidatePreview();
  }

  onFilterPropertyChanged(row: HubSpotFilterRow, event: any): void {
    const propertyName = event.value as string;
    const property = this.findProperty(propertyName);
    this.updateFilter(row.id, {
      propertyName,
      operator: property ? this.defaultOperator(property) : 'EQ',
      value: null,
      values: [],
    });
  }

  onFilterOperatorChanged(row: HubSpotFilterRow, event: any): void {
    this.updateFilter(row.id, {
      operator: event.value as HubSpotSearchOperator,
      value: null,
      values: [],
    });
  }

  onSingleValueChanged(row: HubSpotFilterRow, event: any): void {
    this.updateFilter(row.id, { value: this.toNullableString(event.value) });
  }

  onMultiValueChanged(row: HubSpotFilterRow, event: any): void {
    this.updateFilter(row.id, {
      values: Array.isArray(event.value) ? event.value.map((value: unknown) => String(value)) : [],
    });
  }

  operatorOptions(row: HubSpotFilterRow): HubSpotOperatorOption[] {
    const property = this.findProperty(row.propertyName);
    return this.operatorsForProperty(property).map((operator) => ({
      label: operator,
      value: operator,
    }));
  }

  enumOptions(row: HubSpotFilterRow): HubSpotPropertyOption[] {
    return this.findProperty(row.propertyName)?.options ?? [];
  }

  isEnumFilter(row: HubSpotFilterRow): boolean {
    return this.findProperty(row.propertyName)?.type === 'enumeration';
  }

  isMultiValueFilter(row: HubSpotFilterRow): boolean {
    return MULTI_VALUE_OPERATORS.has(row.operator);
  }

  needsValue(row: HubSpotFilterRow): boolean {
    return !VALUELESS_OPERATORS.has(row.operator);
  }

  applyFilter(): void {
    const connector = this._datasetWizardStore.connector() as HubSpotConnector | null;
    const object = this.selectedObject();
    const canPreview = !!connector && !!object && this.canApplyFilterPreview();
    if (!canPreview) {
      this.previewData.set(this.createEmptyPreviewStore());
      this.previewValidated.set(false);
      return;
    }

    const previewColumns = this.buildPreviewColumns();
    const filterGroups = this.toSearchFilterGroups();
    const previewStore = new CustomStore({
      load: () =>
        lastValueFrom(
          this.hubSpotConnectorService.preview(connector, object.objectTypeId, filterGroups, previewColumns).pipe(
            map((rows) => rows ?? []),
            map((rows) => {
              this.previewValidated.set(true);
              this.previewGridColumns.set(previewColumns.map((column) => column.columnName));
              return rows;
            }),
            catchError(() => {
              this.previewValidated.set(false);
              this.previewGridColumns.set([]);
              return of([]);
            }),
          ),
        ),
    });

    this.previewData.set(previewStore);
  }

  onForward(): void {
    this.persistFilters();
    this.persistDiscoverySnapshot();
  }

  private loadObjects(connectorId: string, selectedObjectTypeId?: string): void {
    this.isLoadingObjects.set(true);
    this.hubSpotConnectorService
      .getObjects({ connectorId })
      .pipe(finalize(() => this.isLoadingObjects.set(false)))
      .subscribe({
        next: (objects) => {
          const sortedObjects = [...(objects ?? [])].sort((left, right) =>
            (left.label || left.name).localeCompare(right.label || right.name),
          );
          this.objectStates.set(this.toObjectStates(sortedObjects));
          this.restoreSelectedObject(sortedObjects, selectedObjectTypeId);
        },
        error: () => {
          this.objectStates.set({});
          this.clearObjectSelection();
        },
      });
  }

  private restoreSelectedObject(objects: HubSpotObject[], selectedObjectTypeId?: string): void {
    if (!selectedObjectTypeId) {
      return;
    }

    const selectedObject = objects.find((object) => object.objectTypeId === selectedObjectTypeId);
    if (!selectedObject) {
      this.clearObjectSelection();
      return;
    }

    this._datasetWizardStore.setConnectorEntity(selectedObject.objectTypeId);
    this.selectedObject.set(selectedObject);
    this.selectedTreeNodeId.set(this.getObjectNodeId(selectedObject.objectTypeId));
    this.loadDescribe(selectedObject, true);
  }

  private selectObject(object: HubSpotObject): void {
    const currentObjectTypeId = this.selectedObject()?.objectTypeId;
    const objectChanged = currentObjectTypeId !== object.objectTypeId;

    this._datasetWizardStore.setConnectorEntity(object.objectTypeId);
    this.selectedObject.set(object);
    this.selectedTreeNodeId.set(this.getObjectNodeId(object.objectTypeId));
    if (objectChanged) {
      this.filters.set([]);
      this._datasetWizardStore.removeConnecotorParam(HUBSPOT_SEARCH_FILTERS_PARAM);
    }
    this.invalidatePreview();
    this.loadDescribe(object, false);
  }

  private loadDescribe(object: HubSpotObject, restorePersistedFilters: boolean): void {
    const connectorId = this._datasetWizardStore.idConnector();
    if (!connectorId) {
      return;
    }

    this.updateObjectState(object.objectTypeId, { status: 'loading', properties: [] });
    this.isLoadingDescribe.set(true);
    this.hubSpotConnectorService
      .describe({ connectorId, objectTypeId: object.objectTypeId })
      .pipe(
        catchError(() => of(null)),
        finalize(() => this.isLoadingDescribe.set(false)),
      )
      .subscribe((describe) => {
        const properties = (describe?.properties ?? []).filter((property) => !property.hidden);
        const status: HubSpotNodeStatus = describe ? 'loaded' : 'error';
        this.updateObjectState(object.objectTypeId, { status, properties });
        if (this.selectedObject()?.objectTypeId === object.objectTypeId) {
          this.properties.set(properties);
          if (restorePersistedFilters) {
            this.restoreFiltersFromParams();
          }
        }
      });
  }

  private updateFilter(id: string, patch: Partial<HubSpotFilterRow>): void {
    this.filters.update((filters) => filters.map((filter) => (filter.id === id ? { ...filter, ...patch } : filter)));
    this.persistFilters();
    this.invalidatePreview();
  }

  private persistFilters(): void {
    const filterGroups = this.toSearchFilterGroups();
    if (filterGroups.length === 0) {
      this._datasetWizardStore.removeConnecotorParam(HUBSPOT_SEARCH_FILTERS_PARAM);
      return;
    }

    const param: DatasetConnectorParamCreateDto = {
      codParametro: HUBSPOT_SEARCH_FILTERS_PARAM,
      valoreJson: { filterGroups },
    };
    this._datasetWizardStore.addDatasetConnectorParam(param);
  }

  private persistDiscoverySnapshot(): void {
    const object = this.selectedObject();
    if (!object) {
      return;
    }

    const snapshot: HubSpotDiscoverySnapshot = {
      objectTypeId: object.objectTypeId,
      name: object.name,
      label: object.label,
      custom: object.custom,
      properties: this.properties(),
    };
    this._datasetWizardStore.addDatasetConnectorParam({
      codParametro: HUBSPOT_DISCOVERY_SNAPSHOT_PARAM,
      valoreJson: snapshot as unknown as Record<string, any>,
    });
  }

  private restoreFiltersFromParams(): void {
    const groups = this.getPersistedFilterGroups();
    const filters = groups[0]?.filters ?? [];
    this.filterSequence = 0;
    this.filters.set(filters.map((filter) => this.createRestoredFilterRow(filter)));
    this.invalidatePreview();
  }

  private createRestoredFilterRow(filter: HubSpotSearchFilter): HubSpotFilterRow {
    return {
      id: `hubspot-filter-${++this.filterSequence}`,
      propertyName: filter.propertyName,
      operator: filter.operator,
      value: this.toNullableString(filter.value),
      values: Array.isArray(filter.values) ? filter.values.map((value) => String(value)) : [],
    };
  }

  private toSearchFilterGroups(): HubSpotSearchFilterGroup[] {
    const filters = this.toSearchFilters();
    return filters.length > 0 ? [{ filters }] : [];
  }

  private toSearchFilters(): HubSpotSearchFilter[] {
    return this.filters().flatMap((filter) => {
      if (!this.isFilterComplete(filter)) {
        return [];
      }
      return [this.toSearchFilter(filter)];
    });
  }

  private toSearchFilter(row: HubSpotFilterRow): HubSpotSearchFilter {
    const baseFilter = {
      propertyName: row.propertyName,
      operator: row.operator,
    };
    if (!this.needsValue(row)) {
      return baseFilter;
    }
    if (this.isMultiValueFilter(row)) {
      return { ...baseFilter, values: row.values };
    }
    return { ...baseFilter, value: row.value };
  }

  private isFilterComplete(row: HubSpotFilterRow): boolean {
    if (!row.propertyName || !row.operator) {
      return false;
    }
    if (!this.needsValue(row)) {
      return true;
    }
    if (this.isMultiValueFilter(row)) {
      return row.values.length > 0;
    }
    return !!row.value?.trim();
  }

  private areFiltersValid(): boolean {
    return this.filters().every((filter) => this.isFilterComplete(filter));
  }

  private clearObjectSelection(): void {
    this._datasetWizardStore.setConnectorEntity('');
    this.selectedObject.set(null);
    this.selectedTreeNodeId.set(null);
    this.properties.set([]);
    this.filters.set([]);
    this.invalidatePreview();
  }

  private invalidatePreview(): void {
    this.previewValidated.set(false);
    this.previewData.set(this.createEmptyPreviewStore());
    this.previewGridColumns.set([]);
  }

  private removeHubSpotParams(): void {
    this._datasetWizardStore.removeConnecotorParam(HUBSPOT_SEARCH_FILTERS_PARAM);
    this._datasetWizardStore.removeConnecotorParam(HUBSPOT_DISCOVERY_SNAPSHOT_PARAM);
  }

  private findProperty(propertyName: string): HubSpotProperty | undefined {
    return this.properties().find((property) => property.name === propertyName);
  }

  private defaultOperator(property: HubSpotProperty): HubSpotSearchOperator {
    return property.type === 'enumeration' ? 'IN' : 'EQ';
  }

  private operatorsForProperty(property: HubSpotProperty | undefined): HubSpotSearchOperator[] {
    if (!property) {
      return ['EQ', 'NEQ', 'HAS_PROPERTY', 'NOT_HAS_PROPERTY'];
    }
    if (property.type === 'enumeration') {
      return ['EQ', 'NEQ', 'IN', 'NOT_IN', 'HAS_PROPERTY', 'NOT_HAS_PROPERTY'];
    }
    if (NUMERIC_OR_DATE_TYPES.has(property.type ?? '')) {
      return ['EQ', 'NEQ', 'LT', 'LTE', 'GT', 'GTE', 'HAS_PROPERTY', 'NOT_HAS_PROPERTY'];
    }
    return ['EQ', 'NEQ', 'HAS_PROPERTY', 'NOT_HAS_PROPERTY'];
  }

  private toObjectStates(objects: HubSpotObject[]): Record<string, HubSpotObjectNodeState> {
    return Object.fromEntries(
      objects.map((object) => [
        object.objectTypeId,
        {
          object,
          status: 'idle' as const,
          properties: [],
        },
      ]),
    );
  }

  private updateObjectState(objectTypeId: string, patch: Partial<HubSpotObjectNodeState>): void {
    this.objectStates.update((states) => {
      const current = states[objectTypeId];
      if (!current) {
        return states;
      }

      return {
        ...states,
        [objectTypeId]: {
          ...current,
          ...patch,
        },
      };
    });
  }

  private buildObjectTreeNodes(): HubSpotTreeNode[] {
    const states = Object.values(this.objectStates());
    if (states.length === 0) {
      return [];
    }

    const standardObjects = states.filter((state) => !state.object.custom);
    const customObjects = states.filter((state) => state.object.custom);
    const nodes: HubSpotTreeNode[] = [];

    if (standardObjects.length > 0) {
      nodes.push(
        this.createCategoryNode(
          'standard',
          `${this.translateService.instant('hubspot.preview.standard.objects')} (${standardObjects.length})`,
          standardObjects,
        ),
      );
    }

    if (customObjects.length > 0) {
      nodes.push(
        this.createCategoryNode(
          'custom',
          `${this.translateService.instant('hubspot.preview.custom.objects')} (${customObjects.length})`,
          customObjects,
        ),
      );
    }

    return nodes;
  }

  private buildSchemaNodes(): SchemaDiscoveryNode[] {
    const states = Object.values(this.objectStates());
    if (states.length === 0) {
      return [];
    }

    const standardObjects = states.filter((state) => !state.object.custom);
    const customObjects = states.filter((state) => state.object.custom);
    const nodes: SchemaDiscoveryNode[] = [];

    if (standardObjects.length > 0) {
      nodes.push(
        this.createSchemaCategoryNode({
          id: 'standard',
          labelKey: 'hubspot.preview.standard.objects',
          states: standardObjects,
        }),
      );
    }

    if (customObjects.length > 0) {
      nodes.push(
        this.createSchemaCategoryNode({
          id: 'custom',
          labelKey: 'hubspot.preview.custom.objects',
          states: customObjects,
        }),
      );
    }

    return nodes;
  }

  private createSchemaCategoryNode(config: HubSpotSchemaCategoryConfig): SchemaDiscoveryNode {
    return {
      id: `hubspot-category-${config.id}`,
      kind: 'group',
      label: this.translateService.instant(config.labelKey),
      badge: { text: `${config.states.length}` },
      selectable: false,
      expanded: true,
      hasItems: true,
      iconClass: 'dx-icon dx-icon-activefolder',
      items: config.states.map((state) => this.createSchemaObjectNode(state)),
    };
  }

  private createSchemaObjectNode(state: HubSpotObjectNodeState): SchemaDiscoveryNode {
    const isSelected = this.selectedObject()?.objectTypeId === state.object.objectTypeId;
    return {
      id: this.getObjectNodeId(state.object.objectTypeId),
      kind: 'entity',
      label: state.object.label || state.object.name,
      description: state.object.label ? state.object.name : undefined,
      searchText: [state.object.label, state.object.name, state.object.objectTypeId]
        .filter((value): value is string => !!value)
        .join(' '),
      selectable: true,
      expanded: isSelected && state.status !== 'idle',
      hasItems: true,
      loading: state.status === 'loading',
      iconClass: 'dx-icon dx-icon-fields',
      items: this.buildSchemaObjectChildren(state),
      data: state.object,
    };
  }

  private buildSchemaObjectChildren(state: HubSpotObjectNodeState): SchemaDiscoveryNode[] {
    if (state.status === 'loading') {
      return [
        this.createSchemaStatusNode({
          objectTypeId: state.object.objectTypeId,
          status: 'loading',
          labelKey: 'hubspot.preview.loading.node',
        }),
      ];
    }

    if (state.status === 'error') {
      return [
        this.createSchemaStatusNode({
          objectTypeId: state.object.objectTypeId,
          status: 'error',
          labelKey: 'hubspot.preview.click.to.load',
        }),
      ];
    }

    if (state.status === 'idle') {
      return [this.createSchemaStatusNode({ objectTypeId: state.object.objectTypeId, status: 'idle' })];
    }

    if (state.properties.length === 0) {
      return [
        this.createSchemaStatusNode({
          objectTypeId: state.object.objectTypeId,
          status: 'empty',
          labelKey: 'hubspot.preview.no.properties',
        }),
      ];
    }

    return state.properties.map((property) => ({
      id: `hubspot-property-${state.object.objectTypeId}-${property.name}`,
      kind: 'property',
      label: property.label || property.name,
      description: property.label ? property.name : property.type,
      searchText: [property.label, property.name, property.type].filter((value): value is string => !!value).join(' '),
      selectable: false,
      iconClass: 'dx-icon dx-icon-codeblock',
      data: property,
    }));
  }

  private createSchemaStatusNode(config: HubSpotSchemaStatusConfig): SchemaDiscoveryNode {
    return {
      id: `hubspot-status-${config.objectTypeId}-${config.status}`,
      kind: 'status',
      label: config.labelKey ? this.translateService.instant(config.labelKey) : '',
      selectable: false,
      iconClass: config.labelKey ? 'dx-icon dx-icon-info' : undefined,
    };
  }

  private createCategoryNode(
    id: string,
    title: string,
    states: HubSpotObjectNodeState[],
  ): TiaraSuiteTreeGroupNode<HubSpotTreeGroupValue, HubSpotTreeItemValue> {
    return {
      id: `hubspot-category-${id}`,
      kind: 'group',
      title,
      selectable: false,
      expanded: true,
      value: { nodeType: 'category', id },
      children: states.map((state) => this.createObjectNode(state)),
    };
  }

  private createObjectNode(
    state: HubSpotObjectNodeState,
  ): TiaraSuiteTreeGroupNode<HubSpotTreeGroupValue, HubSpotTreeItemValue> {
    const isSelected = this.selectedObject()?.objectTypeId === state.object.objectTypeId;
    return {
      id: this.getObjectNodeId(state.object.objectTypeId),
      kind: 'group',
      title: state.object.label ? `${state.object.label} (${state.object.name})` : state.object.name,
      selectable: true,
      expanded: isSelected && state.status !== 'idle',
      value: state.object,
      children: this.buildObjectNodeChildren(state),
    };
  }

  private buildObjectNodeChildren(
    state: HubSpotObjectNodeState,
  ): TiaraSuiteTreeItemNode<HubSpotTreeGroupValue, HubSpotTreeItemValue>[] {
    if (state.status === 'loading') {
      return [this.createPlaceholderNode(`loading-${state.object.objectTypeId}`, 'hubspot.preview.loading.node')];
    }

    if (state.status === 'error') {
      return [this.createPlaceholderNode(`error-${state.object.objectTypeId}`, 'hubspot.preview.click.to.load')];
    }

    if (state.status === 'loaded' && state.properties.length === 0) {
      return [this.createPlaceholderNode(`empty-${state.object.objectTypeId}`, 'hubspot.preview.no.properties')];
    }

    if (state.status === 'idle') {
      return [this.createPlaceholderNode(`idle-${state.object.objectTypeId}`, 'hubspot.preview.click.to.load')];
    }

    if (state.status !== 'loaded') {
      return [this.createPlaceholderNode(`pending-${state.object.objectTypeId}`, 'hubspot.preview.click.to.load')];
    }

    return state.properties.map((property) => ({
      id: `hubspot-property-${state.object.objectTypeId}-${property.name}`,
      kind: 'item',
      title: property.label ? `${property.label} (${property.name})` : property.name,
      selectable: false,
      value: {
        nodeType: 'property',
        objectTypeId: state.object.objectTypeId,
        propertyName: property.name,
      },
    }));
  }

  private createPlaceholderNode(
    idSuffix: string,
    titleKey: string,
  ): TiaraSuiteTreeItemNode<HubSpotTreeGroupValue, HubSpotTreeItemValue> {
    return {
      id: `hubspot-placeholder-${idSuffix}`,
      kind: 'item',
      title: this.translateService.instant(titleKey),
      selectable: false,
      value: {
        nodeType: 'placeholder',
        id: idSuffix,
      },
    };
  }

  private buildPreviewColumns(): ConnectorMetadataPreviewColumn[] {
    return this.properties()
      .filter((property) => property.name)
      .map((property, index) => ({
        columnName: property.name,
        type: property.type ?? 'string',
        order: index + 1,
      }));
  }

  private filterTreeNodesByQuery(nodes: HubSpotTreeNode[], query: string): HubSpotTreeNode[] {
    const normalizedQuery = this.normalizeValue(query);
    if (!normalizedQuery) {
      return nodes;
    }

    return nodes.reduce<HubSpotTreeNode[]>((result, node) => {
      if (node.kind === 'item') {
        if (this.matchesTreeNode(node.title, normalizedQuery)) {
          result.push(node);
        }
        return result;
      }

      const groupMatches = this.matchesTreeNode(node.title, normalizedQuery);
      const filteredChildren = this.filterTreeNodesByQuery(node.children as HubSpotTreeNode[], normalizedQuery);

      if (!groupMatches && filteredChildren.length === 0) {
        return result;
      }

      result.push({
        ...node,
        expanded: true,
        children: groupMatches ? node.children : filteredChildren,
      });
      return result;
    }, []);
  }

  private getPersistedFilterGroups(): HubSpotSearchFilterGroup[] {
    const payload = this.getDatasetParamJson<HubSpotSearchFiltersPayload>(HUBSPOT_SEARCH_FILTERS_PARAM);
    return payload?.filterGroups ?? [];
  }

  private getDatasetParamJson<T>(paramCode: string): T | null {
    const param = this._datasetWizardStore
      .datasetConnectorParams()
      .find((datasetParam) => datasetParam.codParametro === paramCode);
    return (param?.valoreJson as T | undefined) ?? null;
  }

  private isHubSpotObjectSelection(
    selection: TiaraSuiteTreeSelectionEvent | null,
  ): selection is HubSpotObjectSelection {
    return !!selection && selection.kind === 'group' && this.isHubSpotObject(selection.value);
  }

  private isHubSpotObject(value: unknown): value is HubSpotObject {
    return !!value && typeof value === 'object' && 'objectTypeId' in value && 'name' in value;
  }

  private createFilterRow(property: HubSpotProperty): HubSpotFilterRow {
    return {
      id: `hubspot-filter-${++this.filterSequence}`,
      propertyName: property.name,
      operator: this.defaultOperator(property),
      value: null,
      values: [],
    };
  }

  private getObjectNodeId(objectTypeId: string): string {
    return `hubspot-object-${objectTypeId}`;
  }

  private resolveConnectorSelection(
    selection: HubSpotConnector | { addedItems?: HubSpotConnector[] } | null | undefined,
  ): HubSpotConnector | undefined {
    if (!selection) {
      return undefined;
    }

    if ('addedItems' in selection) {
      return selection.addedItems?.[0];
    }

    return selection as HubSpotConnector;
  }

  private createEmptyPreviewStore(): CustomStore {
    return new CustomStore({
      load: () => lastValueFrom(of([])),
    });
  }

  private matchesTreeNode(value: string | undefined, query: string): boolean {
    return this.normalizeValue(value).includes(query);
  }

  private toNullableString(value: unknown): string | null {
    if (value == null) {
      return null;
    }

    const normalized = String(value).trim();
    return normalized.length > 0 ? normalized : null;
  }

  private normalizeValue(value: string | undefined): string {
    return (value ?? '').trim().toLowerCase();
  }
}
