import { TiaraCollapsableContainerComponent } from '@akeron-ng/tiara-ng/tiara-collapsable-container';
import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import { RestApiOperationParameterVm } from '@alkyra/dataset/components/dataset-wizard/+store/rest-api-step.state';
import { RestApiStepStore } from '@alkyra/dataset/components/dataset-wizard/+store/rest-api-step.store';
import { DatasetConnectorParamCreateDto } from '@alkyra/dataset/models/dataset-connector-param.model';
import { RestApiOpenApiResourceItem } from '@alkyra/rest-api-connector/models/rest-api-connection-test-result.model';
import { RestApiConnector } from '@alkyra/rest-api-connector/models/rest-api-connector.model';
import { RestApiOperationSelection } from '@alkyra/rest-api-connector/models/rest-api-operation-preview.model';
import { RestApiConnectorService } from '@alkyra/rest-api-connector/services/rest-api-connector.service';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, inject, OnInit, output, signal } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxAccordionModule } from 'devextreme-angular/ui/accordion';
import { DxListModule } from 'devextreme-angular/ui/list';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { take } from 'rxjs';

import { DatasetWizardStore } from '../../+store/dataset-wizard.store';
import { RestApiPaginationConfigComponent } from '../../rest-api-wizard/rest-api-pagination-config/rest-api-pagination-config.component';
import { StepSelector } from '../step-selector.model';

type OperationListItem = { key: string; label: string; operation: RestApiOpenApiResourceItem };

@Component({
  selector: 'alk-selector-rest-api',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    TiaraCollapsableContainerComponent,
    TiaraNameDescriptionLabelComponent,
    DxListModule,
    DxLoadIndicatorModule,
    DxTextBoxModule,
    DxAccordionModule,
    RestApiPaginationConfigComponent,
  ],
  templateUrl: './selector-rest-api.component.html',
  styleUrl: './selector-rest-api.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SelectorRestApiComponent implements OnInit, StepSelector {
  valid = output<boolean>();
  readonly _datasetWizardStore = inject(DatasetWizardStore);
  readonly _restApiStepStore = inject(RestApiStepStore);

  private readonly _restApiConnectorService = inject(RestApiConnectorService);

  connectors = signal<RestApiConnector[]>([]);
  pendingHydrationParams = signal<DatasetConnectorParamCreateDto[] | null>(null);

  readonly operations = this._restApiStepStore.getResources;
  readonly requiredParamDefinitions = this._restApiStepStore.requiredParamDefinitions;
  readonly advancedParamDefinitions = this._restApiStepStore.advancedParamDefinitions;
  readonly errorKey = this._restApiStepStore.errorKey;
  readonly isLoading = this._restApiStepStore.loading;
  readonly dataPath = this._restApiStepStore.dataPath;

  readonly selectedOperationKey = computed(() => this.toOperationKey(this._restApiStepStore.selectedOperation()));
  readonly operationItems = computed<OperationListItem[]>(() =>
    this.operations().map((operation) => ({
      key: this.toOperationKey(this.toOperationSelection(operation)),
      label: this.operationLabel(operation),
      operation,
    })),
  );
  readonly selectedOperation = computed(() =>
    this.operations().find(
      (operation) => this.toOperationKey(this.toOperationSelection(operation)) === this.selectedOperationKey(),
    ),
  );
  readonly isValid = computed(() => this._restApiStepStore.isCurrentConfigurationValid());

  constructor() {
    effect(() => {
      this.valid.emit(this.isValid());
    });

    effect(() => {
      const pendingParams = this.pendingHydrationParams();
      if (!pendingParams || this.isLoading()) {
        return;
      }

      this._restApiStepStore.hydrateFromSerializedParams(pendingParams);
      this.pendingHydrationParams.set(null);
    });
  }

  ngOnInit(): void {
    this.loadConnectors();

    if (this._restApiStepStore.selectedConnectorId()) {
      return;
    }

    const connectorId = this._datasetWizardStore.idConnector()?.trim();
    if (!connectorId) {
      return;
    }

    this._restApiConnectorService
      .findConnector(connectorId)
      .pipe(take(1))
      .subscribe({
        next: (connector) => {
          this._restApiStepStore.loadConnectorOperations(connectorId, connector.description);
          this.pendingHydrationParams.set(this._datasetWizardStore.datasetConnectorParams());
        },
        error: () => {
          this._restApiStepStore.loadConnectorOperations(connectorId, null);
          this.pendingHydrationParams.set(this._datasetWizardStore.datasetConnectorParams());
        },
      });
  }

  clearStore(): void {
    this._datasetWizardStore.setIdConnector('');
    this._datasetWizardStore.setConnectorEntity('');
    this._datasetWizardStore.setDatasetConnectorParams([]);
    this._restApiStepStore.reset();
    this.pendingHydrationParams.set(null);
  }

  onForward(): void {
    const operation = this._restApiStepStore.selectedOperation();
    if (!operation) {
      return;
    }

    this._datasetWizardStore.setIdConnector(this._restApiStepStore.selectedConnectorId() ?? '');
    this._datasetWizardStore.setConnectorEntity(`${operation.method}:${operation.path}`);
    this._datasetWizardStore.setDatasetConnectorParams(this._restApiStepStore.serializeDatasetConnectorParams());
  }

  onDatasourceSelected(event: any): void {
    const connector = event?.addedItems?.[0] as RestApiConnector | undefined;
    if (!connector?.id) {
      this.clearStore();
      return;
    }

    this._datasetWizardStore.setIdConnector(connector.id);
    this._restApiStepStore.loadConnectorOperations(connector.id, connector.description);
  }

  onOperationSelected(event: any): void {
    const operation = (event?.addedItems?.[0] as OperationListItem | undefined)?.operation;
    if (!operation) {
      this._restApiStepStore.selectOperation(null);
      return;
    }

    this._restApiStepStore.selectOperation(this.toOperationSelection(operation));
  }

  onRequiredParamChanged(parameter: RestApiOperationParameterVm, event: any): void {
    this._restApiStepStore.setRequiredParamValue(parameter.key, event?.value ?? '');
  }

  onAdvancedParamChanged(parameter: RestApiOperationParameterVm, event: any): void {
    this._restApiStepStore.setAdvancedParamValue(parameter.key, event?.value ?? '');
  }

  onDataPathChanged(event: any): void {
    this._restApiStepStore.setDataPath(event?.value ?? '');
  }

  requiredParamValue(parameter: RestApiOperationParameterVm): string {
    return this._restApiStepStore.requiredParams()[parameter.key] ?? '';
  }

  advancedParamValue(parameter: RestApiOperationParameterVm): string {
    return this._restApiStepStore.advancedParams()[parameter.key] ?? '';
  }

  operationLabel(operation: RestApiOpenApiResourceItem): string {
    const summary = operation.summary?.trim();
    if (summary) {
      return `${operation.method.toUpperCase()} ${operation.path} - ${summary}`;
    }
    return `${operation.method.toUpperCase()} ${operation.path}`;
  }

  private loadConnectors(): void {
    this._restApiConnectorService
      .findAll()
      .pipe(take(1))
      .subscribe({
        next: (connectors) => {
          this.connectors.set(connectors ?? []);
        },
        error: () => {
          this.connectors.set([]);
        },
      });
  }

  toOperationSelection(operation: RestApiOpenApiResourceItem): RestApiOperationSelection {
    return {
      method: 'GET',
      path: operation.path,
      operationId: operation.operationId!,
    };
  }

  toOperationKey(operation: RestApiOperationSelection | null | undefined): string {
    if (!operation) {
      return '';
    }

    return `${operation.method}:${operation.path}:${operation.operationId ?? ''}`;
  }
}
