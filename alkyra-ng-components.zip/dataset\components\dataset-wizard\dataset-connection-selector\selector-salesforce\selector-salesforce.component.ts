import { TiaraSectionPanelComponent } from '@akeron-ng/tiara-ng/tiara-section-panel';
import { ConnectorMetadataPreviewColumn } from '@alkyra/connector/models/connector-metadata-preview-column.model';
import { DatasetConnectorParamCreateDto } from '@alkyra/dataset/models/dataset-connector-param.model';
import {
  resolveSalesforceSavedQueryId,
  resolveSalesforceSourceType,
  SALESFORCE_SAVED_QUERY_ID_PARAM,
  SALESFORCE_SOURCE_TYPE_OBJECT,
  SALESFORCE_SOURCE_TYPE_PARAM,
  SALESFORCE_SOURCE_TYPE_SAVED_QUERY,
} from '@alkyra/dataset/utils/salesforce-source-config.util';
import { SavedQuery } from '@alkyra/query-analyzer/models/saved-query.model';
import { SavedQueryService } from '@alkyra/query-analyzer/services/saved-query.service';
import { SalesforceConnector } from '@alkyra/salesforce-connector/models/salesforce-connector.model';
import { SalesforceField } from '@alkyra/salesforce-connector/models/salesforce-field.model';
import { SalesforceObject } from '@alkyra/salesforce-connector/models/salesforce-object.model';
import { SalesforceConnectorService } from '@alkyra/salesforce-connector/services/salesforce-connector.service';
import {
  SchemaDiscoveryExpandEvent,
  SchemaDiscoveryNode,
  SchemaDiscoverySelectionEvent,
} from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import { ExpressionEditorConfig } from '@alkyra/ui/smart-expression-editor/models/expression-editor.model';
import { SmartExpressionEditorComponent } from '@alkyra/ui/smart-expression-editor/smart-expression-editor.component';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, inject, OnInit, output, signal } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { CustomStore } from 'devextreme/common/data';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { catchError, finalize, lastValueFrom, Observable, of, take, tap } from 'rxjs';

import { DatasetWizardStore } from '../../+store/dataset-wizard.store';
import {
  DatasetConnectionContextComponent,
  DatasetConnectionContextItem,
} from '../../shared/dataset-connection-context/dataset-connection-context.component';
import { DatasetResourceSelectionLayoutComponent } from '../../shared/dataset-resource-selection-layout/dataset-resource-selection-layout.component';
import { StepSelector } from '../step-selector.model';

const FULL_SOQL_QUERY_PATTERN = /^\s*SELECT\b/i;
const SOQL_WHERE_CLAUSE_PATTERN = /\bWHERE\b\s+([\s\S]*)$/i;
const LEADING_WHERE_PATTERN = /^\s*WHERE\b\s*/i;
const OBJECTS_ROOT_ID = 'salesforce-objects-root';
const SAVED_QUERIES_ROOT_ID = 'salesforce-saved-queries-root';
const OBJECT_LEAF_PREFIX = 'salesforce-object:';
const SAVED_QUERY_LEAF_PREFIX = 'salesforce-saved-query:';

type SalesforceTreeNodeKind = 'group' | 'object' | 'saved-query';
type SalesforceTreeRootKind = 'objects' | 'saved-queries' | null;

interface SalesforcePreviewRequest {
  connector: SalesforceConnector;
  objectName: string;
  soqlFilter: string;
}

interface SalesforceTreeNode {
  id: string;
  kind: SalesforceTreeNodeKind;
  parentId?: string | null;
  name: string;
  tableName?: string;
  labelKey?: string;
  hasItems: boolean;
  expanded?: boolean;
  selected?: boolean;
  items?: SalesforceTreeNode[];
}

type SalesforceSchemaNodeData =
  | { kind: 'object'; objectName: string }
  | { kind: 'saved-query'; savedQueryId: string; savedQueryName: string };

interface FieldState {
  expanded: boolean;
  status: 'idle' | 'loading' | 'loaded' | 'error';
  fields: SalesforceField[];
}

const normalizeSoqlFilterInput = (queryValue: string | null | undefined): string => {
  const cleaned = (queryValue ?? '').trim();
  if (!cleaned) {
    return '';
  }

  if (FULL_SOQL_QUERY_PATTERN.test(cleaned)) {
    const predicate = cleaned.match(SOQL_WHERE_CLAUSE_PATTERN)?.[1]?.trim() ?? '';
    return predicate ? `WHERE ${predicate}` : '';
  }

  const predicate = cleaned.replace(LEADING_WHERE_PATTERN, '').trim();
  return predicate ? `WHERE ${predicate}` : '';
};

@Component({
  selector: 'alk-selector-salesforce',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    DxDataGridModule,
    TiaraSectionPanelComponent,
    DxButtonModule,
    DxLoadIndicatorModule,
    SmartExpressionEditorComponent,
    SchemaDiscoveryComponent,
    DatasetConnectionContextComponent,
    DatasetResourceSelectionLayoutComponent,
  ],
  templateUrl: './selector-salesforce.component.html',
  styleUrl: './selector-salesforce.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SelectorSalesforceComponent implements OnInit, StepSelector {
  readonly _datasetWizardStore = inject(DatasetWizardStore);
  private readonly _salesforceConnectorService = inject(SalesforceConnectorService);
  private readonly _savedQueryService = inject(SavedQueryService);
  private sourceMetadataRequestId = 0;
  private objectDescribeRequestId = 0;
  private savedQueryRequestId = 0;
  private previewRequestId = 0;
  valid = output<boolean>();

  $connectors: Observable<SalesforceConnector[]> = of([]);
  objects = signal<SalesforceObject[]>([]);
  savedQueries = signal<SavedQuery[]>([]);
  selectedTreeKeys = signal<string[]>([]);
  currentConnectorId = signal<string>(this._datasetWizardStore.idConnector()?.trim() || '');
  customQuery = signal<string>(normalizeSoqlFilterInput(this._datasetWizardStore.customQuery?.()));
  queryFields = signal<string[]>([]);
  previewColumns = signal<ConnectorMetadataPreviewColumn[]>([]);
  displayedPreviewColumns = signal<ConnectorMetadataPreviewColumn[]>([]);
  selectedSavedQueryId = signal<string>('');
  objectsLoaded = signal<boolean>(false);
  savedQueriesLoaded = signal<boolean>(false);
  objectsRootExpanded = signal<boolean>(false);
  savedQueriesRootExpanded = signal<boolean>(false);
  isLoadingObjects = signal<boolean>(false);
  isLoadingSavedQueries = signal<boolean>(false);
  isLoadingQuery = signal<boolean>(false);
  isLoadingPreview = signal<boolean>(false);
  isApplyingFilter = signal<boolean>(false);
  selectedSourceType = signal<string>(SALESFORCE_SOURCE_TYPE_OBJECT);
  private readonly _fieldStates = signal(new Map<string, FieldState>());
  isLoadingSourceSelection = computed(() => this.isLoadingQuery() || this.isLoadingPreview());

  previewData = signal<CustomStore>(
    new CustomStore({
      load: () => lastValueFrom(of([])),
    }),
  );

  previewValidated = signal<boolean>(false);
  treeNodes = computed<SalesforceTreeNode[]>(() => [
    {
      id: this.objectsRootNodeId(),
      kind: 'group',
      name: 'query.analyzer.schema.objects',
      labelKey: 'query.analyzer.schema.objects',
      hasItems: true,
      expanded: this.objectsRootExpanded(),
      items: this.buildObjectTreeNodes(),
    },
    {
      id: this.savedQueriesRootNodeId(),
      kind: 'group',
      name: 'query.analyzer.saved.section.title',
      labelKey: 'query.analyzer.saved.section.title',
      hasItems: true,
      expanded: this.savedQueriesRootExpanded(),
      items: this.buildSavedQueryTreeNodes(),
    },
  ]);
  schemaNodes = computed<SchemaDiscoveryNode[]>(() => this.buildSalesforceSchemaNodes());
  queryEditorConfig = computed<ExpressionEditorConfig>(() => ({
    dialect: 'soql',
    columns: this.queryFields(),
    enforceWherePrefix: true,
    warnOnUnknownFunctions: true,
    maxSuggestions: 25,
  }));
  gridColumns = computed(() =>
    this.displayedPreviewColumns().map((column) => ({
      dataField: column.columnName,
      caption: column.alias ?? column.columnName,
      calculateCellValue: (rowData: Record<string, unknown>) => this.resolveGridCellValue(rowData, column.columnName),
    })),
  );

  isFormValid = effect(() => {
    const connector = this._datasetWizardStore.idConnector();
    const objectName = this._datasetWizardStore.connectorEntity();
    this.valid.emit(!!connector?.trim() && !!objectName?.trim() && this.previewValidated());
  });

  ngOnInit(): void {
    this.$connectors = this._salesforceConnectorService.findAll();
    const normalizedQuery = normalizeSoqlFilterInput(this._datasetWizardStore.customQuery?.());
    this.customQuery.set(normalizedQuery);
    this._datasetWizardStore.setCustomQuery(normalizedQuery);
    this.selectedSourceType.set(resolveSalesforceSourceType(this._datasetWizardStore.datasetConnectorParams()));
    const connectorId = this._datasetWizardStore.idConnector();
    if (connectorId) {
      this.currentConnectorId.set(connectorId.trim());
      this._datasetWizardStore.setIdConnector(connectorId);
      if (!this._datasetWizardStore.connector()) {
        this._salesforceConnectorService.findConnector(connectorId).subscribe((connector) => {
          this._datasetWizardStore.setConnector(connector);
        });
      }
      this.loadSources(connectorId);
    }
  }

  clearStore(): void {
    this.bumpRequestSequence();
    this.currentConnectorId.set('');
    this._datasetWizardStore.setIdConnector('');
    this._datasetWizardStore.setConnectorEntity('');
    this._datasetWizardStore.setCustomQuery('');
    this._datasetWizardStore.removeConnecotorParam('customQuery');
    this.customQuery.set('');
    this.selectedTreeKeys.set([]);
    this.objects.set([]);
    this.savedQueries.set([]);
    this.queryFields.set([]);
    this.previewColumns.set([]);
    this.displayedPreviewColumns.set([]);
    this.objectsLoaded.set(false);
    this.savedQueriesLoaded.set(false);
    this.objectsRootExpanded.set(false);
    this.savedQueriesRootExpanded.set(false);
    this.selectedSourceType.set(SALESFORCE_SOURCE_TYPE_OBJECT);
    this.selectedSavedQueryId.set('');
    this._fieldStates.set(new Map());
    this.clearSalesforceSourceParams();
    this.resetData();
  }

  onDatasourceSelected(event: any): void {
    const selectedId = event.addedItems[0]?.id;
    this.loadConnection(selectedId, true);
  }

  toConnectionItems(connectors: SalesforceConnector[] | null): DatasetConnectionContextItem<SalesforceConnector>[] {
    return (connectors ?? [])
      .filter((connector): connector is SalesforceConnector & { id: string } => !!connector.id?.trim())
      .map((connector) => ({
        id: connector.id,
        title: connector.description || connector.id,
        subtitle: connector.loginUrl,
        typeLabel: 'Salesforce',
        iconClass: 'fa-solid fa-cloud',
        raw: connector,
      }));
  }

  onConnectionContextSelected(item: DatasetConnectionContextItem<SalesforceConnector>): void {
    this.loadConnection(item.id, item.id !== this._datasetWizardStore.idConnector());
  }

  onSchemaNodeSelected(event: SchemaDiscoverySelectionEvent): void {
    const data = event.node.data as SalesforceSchemaNodeData | undefined;
    if (!data) {
      return;
    }

    if (data.kind === 'object') {
      this.selectObjectByName(data.objectName);
      return;
    }

    const savedQuery = this.savedQueries().find((query) => query.id === data.savedQueryId);
    this.selectSavedQuery(
      savedQuery ?? ({ id: data.savedQueryId, name: data.savedQueryName } as SavedQuery),
      data.savedQueryId,
    );
  }

  onSchemaNodeExpanded(event: SchemaDiscoveryExpandEvent): void {
    const data = event.node.data as SalesforceSchemaNodeData | undefined;
    if (!data || data.kind !== 'object') return;
    const objectName = data.objectName;
    this.updateFieldState(objectName, { expanded: true });
    const state = this._fieldStates().get(objectName);
    if (state?.status === 'loading' || state?.status === 'loaded') return;
    const connectorId = this._datasetWizardStore.idConnector()?.trim();
    if (!connectorId) return;
    this.updateFieldState(objectName, { status: 'loading' });
    this._salesforceConnectorService
      .describe(connectorId, objectName)
      .pipe(take(1))
      .subscribe({
        next: (fields) => this.updateFieldState(objectName, { status: 'loaded', fields }),
        error: () => this.updateFieldState(objectName, { status: 'error', fields: [] }),
      });
  }

  onSchemaNodeCollapsed(event: SchemaDiscoveryExpandEvent): void {
    const data = event.node.data as SalesforceSchemaNodeData | undefined;
    if (data?.kind === 'object') {
      this.updateFieldState(data.objectName, { expanded: false });
    }
  }

  private loadConnection(selectedId: string | undefined, resetResourceState: boolean): void {
    this.bumpRequestSequence();
    this.currentConnectorId.set(selectedId?.trim() || '');
    this._datasetWizardStore.setIdConnector(selectedId ?? '');
    if (resetResourceState) {
      this._datasetWizardStore.resetResourceSelectionState();
    }
    this._datasetWizardStore.setConnectorEntity('');
    this.resetSourceSelection();
    if (selectedId) {
      this._salesforceConnectorService.findConnector(selectedId).subscribe((connector) => {
        this._datasetWizardStore.setConnector(connector);
      });
      this.loadSources(selectedId);
    } else {
      this.objects.set([]);
      this.savedQueries.set([]);
      this.queryFields.set([]);
      this.previewColumns.set([]);
      this.objectsLoaded.set(false);
      this.savedQueriesLoaded.set(false);
      this.isLoadingObjects.set(false);
      this.isLoadingSavedQueries.set(false);
    }
  }

  loadSources(connectorId: string): void {
    const sourceType = resolveSalesforceSourceType(this._datasetWizardStore.datasetConnectorParams());
    const selectedObject =
      sourceType === SALESFORCE_SOURCE_TYPE_OBJECT ? this._datasetWizardStore.connectorEntity() : undefined;
    const savedQueryId =
      sourceType === SALESFORCE_SOURCE_TYPE_SAVED_QUERY
        ? resolveSalesforceSavedQueryId(this._datasetWizardStore.datasetConnectorParams())
        : '';

    this.selectedTreeKeys.set([]);
    this.objects.set([]);
    this.savedQueries.set([]);
    this.objectsLoaded.set(false);
    this.savedQueriesLoaded.set(false);
    this.objectsRootExpanded.set(false);
    this.savedQueriesRootExpanded.set(false);

    if (selectedObject) {
      this.objectsRootExpanded.set(true);
    }

    if (savedQueryId) {
      this.savedQueriesRootExpanded.set(true);
    }

    this.loadObjects(connectorId, selectedObject);
    this.loadSavedQueries(connectorId, savedQueryId || undefined);
  }

  loadObjects(connectorId: string, selectedObject?: string): void {
    const requestId = this.sourceMetadataRequestId;
    this.isLoadingObjects.set(true);
    this._salesforceConnectorService
      .getObjects(connectorId)
      .pipe(
        finalize(() => {
          if (requestId === this.sourceMetadataRequestId) {
            this.isLoadingObjects.set(false);
          }
        }),
      )
      .subscribe({
        next: (objects) => {
          if (requestId !== this.sourceMetadataRequestId || connectorId !== this.currentConnectorId()) {
            return;
          }
          this.objects.set(objects);
          this.objectsLoaded.set(true);
          if (selectedObject && this.selectedSourceType() === SALESFORCE_SOURCE_TYPE_OBJECT) {
            this.restoreSelectedObject(objects, selectedObject);
          }
        },
        error: () => {
          if (requestId !== this.sourceMetadataRequestId || connectorId !== this.currentConnectorId()) {
            return;
          }
          this.objects.set([]);
          this.objectsLoaded.set(true);
          this.queryFields.set([]);
          this.previewColumns.set([]);
        },
      });
  }

  loadSavedQueries(connectorId: string, selectedSavedQueryId?: string): void {
    const requestId = this.sourceMetadataRequestId;
    this.isLoadingSavedQueries.set(true);
    this._savedQueryService
      .getByConnection(connectorId)
      .pipe(
        finalize(() => {
          if (requestId === this.sourceMetadataRequestId) {
            this.isLoadingSavedQueries.set(false);
          }
        }),
      )
      .subscribe({
        next: (savedQueries) => {
          if (requestId !== this.sourceMetadataRequestId || connectorId !== this.currentConnectorId()) {
            return;
          }
          this.savedQueries.set(savedQueries);
          this.savedQueriesLoaded.set(true);
          if (selectedSavedQueryId && this.selectedSourceType() === SALESFORCE_SOURCE_TYPE_SAVED_QUERY) {
            const selectedQuery = savedQueries.find((query) => query.id === selectedSavedQueryId);
            this.selectSavedQuery(
              selectedQuery ?? ({ id: selectedSavedQueryId, name: selectedSavedQueryId } as SavedQuery),
              selectedSavedQueryId,
            );
          }
        },
        error: () => {
          if (requestId !== this.sourceMetadataRequestId || connectorId !== this.currentConnectorId()) {
            return;
          }
          this.savedQueries.set([]);
          this.savedQueriesLoaded.set(true);
        },
      });
  }

  onObjectSelected(event: any) {
    const objectName = event.addedItems[0]?.name;
    if (objectName) {
      this.selectObjectByName(objectName);
    }
  }

  onSavedQuerySelected(event: any): void {
    const savedQuery = event.addedItems[0] as SavedQuery | undefined;
    if (savedQuery) {
      this.selectSavedQuery(savedQuery, savedQuery.id?.trim());
    }
  }

  onTreeSelectionChanged(event: any): void {
    const selectedNode = this.resolveTreeNode(event);
    if (!selectedNode || selectedNode.kind === 'group') {
      return;
    }

    if (selectedNode.kind === 'object') {
      this.selectObjectByName(selectedNode.name);
      return;
    }

    this.selectSavedQuery(
      {
        id: this.extractSavedQueryIdFromNodeId(selectedNode.id),
        name: selectedNode.name,
        description: '',
        connectionId: this._datasetWizardStore.idConnector() ?? '',
        queryValue: '',
      },
      this.extractSavedQueryIdFromNodeId(selectedNode.id),
    );
  }

  onTreeItemExpanded(event: any): void {
    const selectedNode = this.resolveTreeNode(event);
    const connectorId = this.currentConnectorId();
    const rootKind = this.resolveTreeRootKind(selectedNode);

    if (!connectorId || !rootKind) {
      return;
    }

    this.setTreeRootExpanded(rootKind, true);
    this.loadTreeRootChildren(rootKind, connectorId);
  }

  onTreeItemCollapsed(event: any): void {
    const selectedNode = this.resolveTreeNode(event);
    const rootKind = this.resolveTreeRootKind(selectedNode);
    if (!rootKind) {
      return;
    }
    this.setTreeRootExpanded(rootKind, false);
  }

  loadDescribeAndQuery(objectName: string, overrideQuery: boolean, requestId = this.objectDescribeRequestId): void {
    const connectorId = this._datasetWizardStore.idConnector();
    if (!connectorId) return;

    this.isLoadingPreview.set(true);
    this.isLoadingQuery.set(true);
    this._salesforceConnectorService
      .describe(connectorId, objectName)
      .pipe(finalize(() => this.isLoadingQuery.set(false)))
      .subscribe({
        next: (fields) => {
          if (requestId !== this.objectDescribeRequestId) {
            return;
          }
          this.queryFields.set(fields.map((field) => field.name));
          this.previewColumns.set(this.mapDescribeFieldsToPreviewColumns(fields));
          if (overrideQuery) {
            this.clearCustomQuery();
          }
          this.previewValidated.set(false);
          this.resetData();
          this.isLoadingPreview.set(false);
        },
        error: () => {
          if (requestId !== this.objectDescribeRequestId) {
            return;
          }
          this.queryFields.set([]);
          this.previewColumns.set([]);
          if (overrideQuery) {
            this.clearCustomQuery();
          }
          this.isLoadingPreview.set(false);
        },
      });
  }

  loadSavedQueryPreview(savedQueryId: string, savedQueryName?: string, requestId = this.savedQueryRequestId): void {
    const connectorId = this._datasetWizardStore.idConnector();
    if (!connectorId) {
      return;
    }

    this.isLoadingPreview.set(true);
    this.isLoadingQuery.set(true);
    this._salesforceConnectorService
      .savedQueryColumns(connectorId, savedQueryId)
      .pipe(finalize(() => this.isLoadingQuery.set(false)))
      .subscribe({
        next: (columns) => {
          if (requestId !== this.savedQueryRequestId) {
            return;
          }
          this.queryFields.set(columns.map((column) => column.columnName));
          this.previewColumns.set(this.mapSavedQueryColumnsToPreviewColumns(columns));
          if (savedQueryName) {
            this._datasetWizardStore.setConnectorEntity(savedQueryName);
          }
          this.previewValidated.set(false);
          this.resetData();
          this.isLoadingPreview.set(false);
        },
        error: () => {
          if (requestId !== this.savedQueryRequestId) {
            return;
          }
          this.queryFields.set([]);
          this.previewColumns.set([]);
          this.previewValidated.set(false);
          this.resetData();
          this.isLoadingPreview.set(false);
        },
      });
  }

  resetData(): void {
    const previewCustomStore = new CustomStore({
      load: () => lastValueFrom(of([])),
    });
    this.previewData.set(previewCustomStore);
    this.displayedPreviewColumns.set([]);
  }

  loadData(): void {
    const request = this.resolvePreviewRequest();
    if (!request) {
      this.cancelPreviewLoading();
      this.resetData();
      return;
    }

    const { connector, objectName, soqlFilter } = request;
    this.isLoadingPreview.set(true);
    this.customQuery.set(soqlFilter);
    this._datasetWizardStore.setCustomQuery(soqlFilter);
    this._datasetWizardStore.setConnectorEntity(objectName);

    const requestId = ++this.previewRequestId;
    const previewCustomStore = new CustomStore({
      load: () =>
        lastValueFrom(
          this._salesforceConnectorService.preview(connector, objectName, soqlFilter, this.previewColumns()).pipe(
            tap(() => this.previewValidated.set(true)),
            catchError(() => {
              this.previewValidated.set(false);
              this.displayedPreviewColumns.set([]);
              return of([]);
            }),
            finalize(() => this.completePreviewLoading(requestId)),
          ),
        ),
    });
    this.previewData.set(previewCustomStore);
    this.displayedPreviewColumns.set(this.previewColumns());

    if (soqlFilter) {
      const param: DatasetConnectorParamCreateDto = {
        codParametro: 'customQuery',
        valoreStringa: soqlFilter,
      };
      this._datasetWizardStore.addDatasetConnectorParam(param);
    } else {
      this._datasetWizardStore.removeConnecotorParam('customQuery');
    }
  }

  loadSavedQueryData(savedQueryId: string): void {
    const connector = this._datasetWizardStore.connector();
    if (!connector || !savedQueryId) {
      this.cancelPreviewLoading();
      this.resetData();
      return;
    }

    this.isLoadingPreview.set(true);
    const requestId = ++this.previewRequestId;
    const previewCustomStore = new CustomStore({
      load: () =>
        lastValueFrom(
          this._salesforceConnectorService.previewSavedQuery(connector, savedQueryId, this.previewColumns()).pipe(
            tap(() => this.previewValidated.set(true)),
            catchError(() => {
              this.previewValidated.set(false);
              this.displayedPreviewColumns.set([]);
              return of([]);
            }),
            finalize(() => this.completePreviewLoading(requestId)),
          ),
        ),
    });
    this.previewData.set(previewCustomStore);
    this.displayedPreviewColumns.set(this.previewColumns());
  }

  applyFilter(): void {
    this.runPreview();
  }

  runPreview(): void {
    if (this.selectedSourceType() !== SALESFORCE_SOURCE_TYPE_OBJECT) {
      const savedQueryId =
        this.selectedSavedQueryId() || resolveSalesforceSavedQueryId(this._datasetWizardStore.datasetConnectorParams());
      if (savedQueryId) {
        this.isApplyingFilter.set(true);
        this.loadSavedQueryData(savedQueryId);
      }
      return;
    }
    this.isApplyingFilter.set(true);
    this.loadData();
  }

  onCustomQueryChanged(newQuery: string): void {
    this.customQuery.set(newQuery);
    this.previewValidated.set(false);
  }

  private selectObjectByName(objectName: string): void {
    const selectedObject = objectName?.trim();
    if (!selectedObject) {
      return;
    }

    this.savedQueryRequestId += 1;
    const requestId = ++this.objectDescribeRequestId;
    this.selectedSourceType.set(SALESFORCE_SOURCE_TYPE_OBJECT);
    this.selectedSavedQueryId.set('');
    this.persistSourceType(SALESFORCE_SOURCE_TYPE_OBJECT);
    this._datasetWizardStore.removeConnecotorParam(SALESFORCE_SAVED_QUERY_ID_PARAM);
    this._datasetWizardStore.setConnectorEntity(selectedObject);
    this.selectedTreeKeys.set([this.objectNodeId(selectedObject)]);
    this.resetPreviewMetadata();
    this._datasetWizardStore.removeConnecotorParam('customQuery');
    this.loadDescribeAndQuery(selectedObject, true, requestId);
  }

  private selectSavedQuery(savedQuery: SavedQuery | null, savedQueryId?: string): void {
    const selectedSavedQueryId = (savedQueryId ?? savedQuery?.id ?? '').trim();
    if (!selectedSavedQueryId) {
      return;
    }

    const savedQueryName = savedQuery?.name ?? '';
    this.objectDescribeRequestId += 1;
    const requestId = ++this.savedQueryRequestId;
    this.selectedSourceType.set(SALESFORCE_SOURCE_TYPE_SAVED_QUERY);
    this.selectedSavedQueryId.set(selectedSavedQueryId);
    this.persistSourceType(SALESFORCE_SOURCE_TYPE_SAVED_QUERY);
    this.persistSavedQueryId(selectedSavedQueryId);
    this._datasetWizardStore.setConnectorEntity(savedQueryName);
    this._datasetWizardStore.setCustomQuery('');
    this._datasetWizardStore.removeConnecotorParam('customQuery');
    this.customQuery.set('');
    this.selectedTreeKeys.set([this.savedQueryNodeId(selectedSavedQueryId)]);
    this.resetPreviewMetadata();
    this.loadSavedQueryPreview(selectedSavedQueryId, savedQueryName, requestId);
  }

  private resolvePreviewRequest(): SalesforcePreviewRequest | null {
    if (!this.isObjectSourceSelected()) {
      return null;
    }

    const objectName = this._datasetWizardStore.connectorEntity()?.trim();
    const connector = this._datasetWizardStore.connector();

    if (!this.hasActiveObjectPreviewTarget(objectName, connector)) {
      return null;
    }

    return {
      connector,
      objectName,
      soqlFilter: normalizeSoqlFilterInput(this.customQuery()),
    };
  }

  private resetSourceSelection(): void {
    this.bumpRequestSequence();
    this.clearCustomQuery();
    this._datasetWizardStore.removeConnecotorParam('customQuery');
    this.selectedTreeKeys.set([]);
    this.previewValidated.set(false);
    this.resetData();
    this.queryFields.set([]);
    this.previewColumns.set([]);
    this.objectsLoaded.set(false);
    this.savedQueriesLoaded.set(false);
    this.objectsRootExpanded.set(false);
    this.savedQueriesRootExpanded.set(false);
    this.objects.set([]);
    this.savedQueries.set([]);
    this.selectedSourceType.set(SALESFORCE_SOURCE_TYPE_OBJECT);
    this.selectedSavedQueryId.set('');
    this._fieldStates.set(new Map());
    this.clearSalesforceSourceParams();
  }

  private clearSalesforceSourceParams(): void {
    this._datasetWizardStore.removeConnecotorParam(SALESFORCE_SOURCE_TYPE_PARAM);
    this._datasetWizardStore.removeConnecotorParam(SALESFORCE_SAVED_QUERY_ID_PARAM);
  }

  private persistSourceType(sourceType: string): void {
    const param: DatasetConnectorParamCreateDto = {
      codParametro: SALESFORCE_SOURCE_TYPE_PARAM,
      valoreStringa: sourceType,
    };
    this._datasetWizardStore.addDatasetConnectorParam(param);
  }

  private persistSavedQueryId(savedQueryId: string): void {
    const param: DatasetConnectorParamCreateDto = {
      codParametro: SALESFORCE_SAVED_QUERY_ID_PARAM,
      valoreStringa: savedQueryId,
    };
    this._datasetWizardStore.addDatasetConnectorParam(param);
  }

  private buildSalesforceSchemaNodes(): SchemaDiscoveryNode[] {
    const fieldStates = this._fieldStates();
    return [
      {
        id: this.objectsRootNodeId(),
        kind: 'group',
        label: 'Objects',
        badge: { text: `${this.objects().length}` },
        selectable: false,
        expanded: this.objectsRootExpanded(),
        hasItems: true,
        iconClass: 'dx-icon dx-icon-activefolder',
        items: this.objects().map((object) => this.mapObjectToSchemaNode(object, fieldStates.get(object.name))),
      },
      {
        id: this.savedQueriesRootNodeId(),
        kind: 'group',
        label: 'Saved Queries',
        badge: { text: `${this.savedQueries().length}` },
        selectable: false,
        expanded: this.savedQueriesRootExpanded(),
        hasItems: true,
        iconClass: 'dx-icon dx-icon-activefolder',
        items: this.savedQueries().map((savedQuery) => this.mapSavedQueryToSchemaNode(savedQuery)),
      },
    ];
  }

  private mapObjectToSchemaNode(object: SalesforceObject, fieldState?: FieldState): SchemaDiscoveryNode {
    return {
      id: this.objectNodeId(object.name),
      kind: 'entity',
      label: object.label || object.name,
      description: object.label ? object.name : undefined,
      searchText: [object.name, object.label].filter((value): value is string => !!value).join(' '),
      selectable: true,
      expanded: fieldState?.expanded === true,
      hasItems: true,
      loading: fieldState?.status === 'loading',
      iconClass: object.custom ? 'dx-icon dx-icon-chevrondoubleright' : 'dx-icon dx-icon-fixcolumnleft',
      items: this.buildObjectFieldNodes(object.name, fieldState),
      data: { kind: 'object', objectName: object.name } satisfies SalesforceSchemaNodeData,
    };
  }

  private buildObjectFieldNodes(objectName: string, fieldState: FieldState | undefined): SchemaDiscoveryNode[] {
    const nodeId = this.objectNodeId(objectName);
    if (!fieldState || fieldState.status === 'idle') {
      return [{ id: `${nodeId}-idle`, kind: 'status', label: '', selectable: false }];
    }
    if (fieldState.status === 'loading') {
      return [
        {
          id: `${nodeId}-loading`,
          kind: 'status',
          label: 'Loading fields...',
          selectable: false,
          iconClass: 'dx-icon dx-icon-info',
        },
      ];
    }
    if (fieldState.status === 'error') {
      return [
        {
          id: `${nodeId}-error`,
          kind: 'status',
          label: 'Fields unavailable',
          selectable: false,
          iconClass: 'dx-icon dx-icon-info',
        },
      ];
    }
    if (fieldState.fields.length === 0) {
      return [
        {
          id: `${nodeId}-empty`,
          kind: 'status',
          label: 'No fields available',
          selectable: false,
          iconClass: 'dx-icon dx-icon-info',
        },
      ];
    }
    return fieldState.fields.map((field, i) => ({
      id: `${nodeId}-field-${i}`,
      kind: 'property' as const,
      label: field.label?.trim() || field.name,
      description: field.type,
      searchText: [field.name, field.label, field.type].filter((v): v is string => !!v).join(' '),
      selectable: false,
      iconClass: 'dx-icon dx-icon-codeblock',
      data: field,
    }));
  }

  private updateFieldState(objectName: string, patch: Partial<FieldState>): void {
    this._fieldStates.update((m) => {
      const prev = m.get(objectName) ?? { expanded: false, status: 'idle' as const, fields: [] };
      return new Map(m).set(objectName, { ...prev, ...patch });
    });
  }

  private mapSavedQueryToSchemaNode(savedQuery: SavedQuery): SchemaDiscoveryNode {
    const savedQueryId = savedQuery.id?.trim() || savedQuery.name;
    return {
      id: this.savedQueryNodeId(savedQueryId),
      kind: 'entity',
      label: savedQuery.name,
      description: savedQuery.description,
      searchText: [savedQuery.name, savedQuery.description].filter((value): value is string => !!value).join(' '),
      selectable: true,
      expanded: false,
      hasItems: false,
      iconClass: 'dx-icon dx-icon-save',
      data: {
        kind: 'saved-query',
        savedQueryId,
        savedQueryName: savedQuery.name,
      } satisfies SalesforceSchemaNodeData,
    };
  }

  private buildObjectTreeNodes(): SalesforceTreeNode[] {
    return this.objects().map((object) => ({
      id: this.objectNodeId(object.name),
      kind: 'object',
      name: object.name,
      tableName: object.label || object.name,
      hasItems: false,
      selected: this.selectedTreeKeys()[0] === this.objectNodeId(object.name),
    }));
  }

  private buildSavedQueryTreeNodes(): SalesforceTreeNode[] {
    return this.savedQueries().map((savedQuery) => {
      const savedQueryId = savedQuery.id?.trim() || savedQuery.name;

      return {
        id: this.savedQueryNodeId(savedQueryId),
        kind: 'saved-query',
        name: savedQuery.name,
        tableName: savedQuery.name,
        hasItems: false,
        selected: this.selectedTreeKeys()[0] === this.savedQueryNodeId(savedQueryId),
      };
    });
  }

  private resolveTreeNode(event: any): SalesforceTreeNode | null {
    return (event?.node?.itemData ?? event?.itemData ?? event?.addedItems?.[0] ?? null) as SalesforceTreeNode | null;
  }

  private restoreSelectedObject(objects: SalesforceObject[], objectName: string): void {
    const selectedObject = objectName?.trim();
    if (!selectedObject || !objects.some((object) => object.name === selectedObject)) {
      return;
    }

    this.selectedTreeKeys.set([this.objectNodeId(selectedObject)]);
    this._datasetWizardStore.setConnectorEntity(selectedObject);
    this.resetPreviewMetadata();
    this.loadDescribeAndQuery(selectedObject, false, this.objectDescribeRequestId);
  }

  private objectsRootNodeId(): string {
    return `${OBJECTS_ROOT_ID}:${this.currentConnectorKey()}`;
  }

  private savedQueriesRootNodeId(): string {
    return `${SAVED_QUERIES_ROOT_ID}:${this.currentConnectorKey()}`;
  }

  private objectNodeId(objectName: string): string {
    return `${OBJECT_LEAF_PREFIX}${this.currentConnectorKey()}::${objectName}`;
  }

  private savedQueryNodeId(savedQueryId: string): string {
    return `${SAVED_QUERY_LEAF_PREFIX}${this.currentConnectorKey()}::${savedQueryId}`;
  }

  private extractSavedQueryIdFromNodeId(nodeId: string): string {
    const [prefix, savedQueryId = ''] = nodeId.split('::');
    return prefix.startsWith(SAVED_QUERY_LEAF_PREFIX) ? savedQueryId : '';
  }

  private resolveTreeRootKind(node: SalesforceTreeNode | null): SalesforceTreeRootKind {
    if (!node || node.kind !== 'group') {
      return null;
    }
    if (node.id === this.objectsRootNodeId()) {
      return 'objects';
    }
    if (node.id === this.savedQueriesRootNodeId()) {
      return 'saved-queries';
    }
    return null;
  }

  private setTreeRootExpanded(rootKind: SalesforceTreeRootKind, expanded: boolean): void {
    if (rootKind === 'objects') {
      this.objectsRootExpanded.set(expanded);
      return;
    }
    if (rootKind === 'saved-queries') {
      this.savedQueriesRootExpanded.set(expanded);
    }
  }

  private loadTreeRootChildren(rootKind: SalesforceTreeRootKind, connectorId: string): void {
    if (rootKind === 'objects') {
      if (!this.objectsLoaded()) {
        this.loadObjects(connectorId);
      }
      return;
    }

    if (rootKind === 'saved-queries' && !this.savedQueriesLoaded()) {
      this.loadSavedQueries(connectorId);
    }
  }

  private mapDescribeFieldsToPreviewColumns(fields: any[]): ConnectorMetadataPreviewColumn[] {
    return fields.map((field, index) => ({
      columnName: field.name,
      type: field.type || 'string',
      length: field.length,
      precision: field.precision,
      order: index + 1,
    }));
  }

  private mapSavedQueryColumnsToPreviewColumns(columns: any[]): ConnectorMetadataPreviewColumn[] {
    return columns.map((column, index) => ({
      columnName: column.columnName,
      type: column.dataType || 'string',
      length: column.length,
      precision: column.precision,
      order: index + 1,
    }));
  }

  private clearCustomQuery(): void {
    this.customQuery.set('');
    this._datasetWizardStore.setCustomQuery('');
  }

  private isObjectSourceSelected(): boolean {
    return this.selectedSourceType() === SALESFORCE_SOURCE_TYPE_OBJECT;
  }

  private hasActiveObjectPreviewTarget(
    objectName: string | undefined,
    connector: SalesforceConnector | null | undefined,
  ): connector is SalesforceConnector {
    return !!this._datasetWizardStore.idConnector()?.trim() && !!objectName && !!connector;
  }

  private currentConnectorKey(): string {
    return this.currentConnectorId() || 'no-connector';
  }

  private bumpRequestSequence(): void {
    this.sourceMetadataRequestId += 1;
    this.objectDescribeRequestId += 1;
    this.savedQueryRequestId += 1;
    this.previewRequestId += 1;
    this.cancelPreviewLoading(false);
  }

  private resetPreviewMetadata(): void {
    this.previewValidated.set(false);
    this.queryFields.set([]);
    this.previewColumns.set([]);
    this.displayedPreviewColumns.set([]);
  }

  private resolveGridCellValue(rowData: Record<string, unknown> | null | undefined, key: string): unknown {
    if (!rowData) {
      return undefined;
    }
    if (Object.prototype.hasOwnProperty.call(rowData, key)) {
      return rowData[key];
    }

    return key.split('.').reduce<unknown>((current, segment) => {
      if (!current || typeof current !== 'object') {
        return undefined;
      }
      return (current as Record<string, unknown>)[segment];
    }, rowData);
  }

  private completePreviewLoading(requestId: number): void {
    if (requestId !== this.previewRequestId) {
      return;
    }
    this.cancelPreviewLoading(false);
  }

  private cancelPreviewLoading(resetRequestId = true): void {
    if (resetRequestId) {
      this.previewRequestId += 1;
    }
    this.isLoadingPreview.set(false);
    this.isApplyingFilter.set(false);
  }
}
