import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import notify from 'devextreme/ui/notify';
import { ValueChangedEvent as TextAreaValueChangedEvent } from 'devextreme/ui/text_area';
import { ValueChangedEvent as TextBoxValueChangedEvent } from 'devextreme/ui/text_box';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';

import { DatasetWizardStore } from '../+store/dataset-wizard.store';
import { DatasetFlowContext } from '../flow-steps/dataset-flow-context.model';
@Component({
  selector: 'alk-dataset-edit-name',
  templateUrl: './dataset-edit-name.component.html',
  styleUrls: ['./dataset-edit-name.component.scss'],
  standalone: true,
  imports: [DxTextBoxModule, DxTextAreaModule, TiaraSuiteWizardStepComponent, TranslatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DatasetNamingComponent extends FlowWizardStep<DatasetFlowContext> {
  static readonly stepId = 'dataset-name';
  static readonly candidates: readonly FlowWizardStepClass<DatasetFlowContext>[] = [];

  readonly _datasetWizardStore = inject(DatasetWizardStore);

  name: string = '';
  description: string = '';

  override canGoforward = computed((): boolean => {
    return this.canonForward();
  });
  canonForward(): boolean {
    if (!this.isFormValid) {
      return false;
    }
    return true;
  }
  get isFormValid(): boolean {
    const name = this._datasetWizardStore.name();
    return !!name?.trim();
  }

  onNameChange(value: TextBoxValueChangedEvent) {
    this._datasetWizardStore.setName(value.value);
  }

  onDescriptionChange(value: TextAreaValueChangedEvent) {
    this._datasetWizardStore.setDescription(value.value);
  }

  override onBackward(): void {
    this._datasetWizardStore.setDescription('');
    this._datasetWizardStore.setName('');
  }
  notify(message: string | undefined, type: string, displayTime: number): void {
    notify(message, type, displayTime);
  }
}
