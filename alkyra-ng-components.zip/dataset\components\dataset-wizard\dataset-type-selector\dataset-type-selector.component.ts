import {
  OptionButtonItem,
  TiaraSuiteOptionButtonSelectionComponent,
} from '@akeron-ng/tiara-ng-suite/tiara-option-button';
import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { PipelineType } from '@alkyra/pipeline/models/pipeline.model';
import { FlowResolveResult, FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { ChangeDetectionStrategy, Component, computed, inject, OnInit, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';

import { ApiStepStore } from '../+store/api-step.store';
import { DatasetWizardStore } from '../+store/dataset-wizard.store';
import { DatasetCloudSourceComponent } from '../dataset-cloud-source/dataset-cloud-source.component';
import { DatasetColumnSelectorComponent } from '../dataset-column-selector/dataset-column-selector.component';
import { DatasetConnectionSelectorComponent } from '../dataset-connection-selector/dataset-connection-selector.component';
import { DatasetFlowContext } from '../flow-steps/dataset-flow-context.model';
import { DatasetSourceFamily } from '../models/dataset-source-family.model';
import { RestApiConnectionStepComponent } from '../rest-api-wizard/rest-api-connection-step/rest-api-connection-step.component';
import { RestApiDataPathStepComponent } from '../rest-api-wizard/rest-api-data-path-step/rest-api-data-path-step.component';

@Component({
  selector: 'alk-dataset-type-selector',
  templateUrl: './dataset-type-selector.component.html',
  styleUrls: ['./dataset-type-selector.component.scss'],
  standalone: true,
  imports: [TiaraSuiteOptionButtonSelectionComponent, TiaraSuiteWizardStepComponent, TranslatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DatasetTypeSelectorComponent extends FlowWizardStep<DatasetFlowContext> implements OnInit {
  static readonly stepId = 'dataset-source-type';
  static readonly candidates: readonly FlowWizardStepClass<DatasetFlowContext>[] = [
    DatasetConnectionSelectorComponent,
    DatasetCloudSourceComponent,
    DatasetColumnSelectorComponent,
    RestApiConnectionStepComponent,
    RestApiDataPathStepComponent,
  ];

  readonly _datasetWizardStore = inject(DatasetWizardStore);

  private readonly _translateService: TranslateService = inject(TranslateService);

  selected = signal<boolean>(false);
  selectedSourceFamily = signal<DatasetSourceFamily | null>(null);

  private readonly _apiStepState = inject(ApiStepStore);

  pipelineType = computed(() => this._apiStepState.selectedPipeline()?.pipelineType || PipelineType.BATCH);

  options = computed<OptionButtonItem[]>(() => {
    const opts: OptionButtonItem[] = [
      this.createOption(
        ConnectorType.DATABASE,
        this._translateService.instant('dataset.connector.type.selector.connection.db'),
        this._translateService.instant('dataset.connector.type.selector.connection.db.subtitle'),
        'database',
      ),
      this.createOption(
        ConnectorType.SALESFORCE,
        this._translateService.instant('dataset.connector.type.selector.salesforce'),
        this._translateService.instant('dataset.connector.type.selector.salesforce.subtitle'),
        'cloud',
      ),
      this.createOption(
        ConnectorType.HUBSPOT,
        this._translateService.instant('dataset.connector.type.selector.hubspot'),
        this._translateService.instant('dataset.connector.type.selector.hubspot.subtitle'),
        'circle-nodes',
      ),
      this.createOption(
        ConnectorType.CSV,
        this._translateService.instant('dataset.connector.type.selector.csv'),
        this._translateService.instant('dataset.connector.type.selector.csv.subtitle'),
        'file-csv',
      ),
      this.createOption(
        ConnectorType.EXCEL,
        this._translateService.instant('dataset.connector.type.selector.excel'),
        this._translateService.instant('dataset.connector.type.selector.excel.subtitle'),
        'file-excel',
      ),
      this.createOption(
        ConnectorType.REST_API,
        this._translateService.instant('dataset.connector.type.selector.rest.api'),
        this._translateService.instant('dataset.connector.type.selector.rest.api.subtitle'),
        'globe',
      ),
      this.createOption(
        ConnectorType.BUSINESS_CENTRAL,
        this._translateService.instant('dataset.connector.type.selector.business.central'),
        this._translateService.instant('dataset.connector.type.selector.business.central.subtitle'),
        'globe',
      ),
      this.createOption(
        'CLOUD',
        this._translateService.instant('dataset.connector.type.selector.cloud'),
        this._translateService.instant('dataset.connector.type.selector.cloud.subtitle'),
        'cloud',
      ),
    ];
    if (this.pipelineType() === PipelineType.QUEUE) {
      opts.push(
        this.createOption(
          ConnectorType.AMAZON_SQS,
          this._translateService.instant('dataset.connector.type.selector.sqs'),
          this._translateService.instant('dataset.connector.type.selector.sqs.subtitle'),
          'diagram-sankey',
        ),
      );
    }
    if (this.pipelineType() === PipelineType.API) {
      opts.push(
        this.createOption(
          ConnectorType.HOOK_API,
          this._translateService.instant('dataset.connector.type.selector.api.ingest'),
          this._translateService.instant('dataset.connector.type.selector.api.ingest.subtitle'),
          'arrow-down-square',
        ),
      );
    }
    return opts;
  });

  ngOnInit(): void {
    const storedSourceFamily = this._datasetWizardStore.sourceFamily();
    if (storedSourceFamily) {
      this.selected.set(true);
      this.selectedSourceFamily.set(storedSourceFamily);
    } else {
      this.selected.set(false);
      this.selectedSourceFamily.set(null);
    }
  }

  override canGoforward = computed((): boolean => {
    return this.selected();
  });

  override resolveNext(
    context: DatasetFlowContext,
    candidates: readonly FlowWizardStepClass<DatasetFlowContext>[],
  ): FlowResolveResult<DatasetFlowContext> {
    const sourceFamily = this.selectedSourceFamily();
    if (!this.selected() || !sourceFamily) {
      return { kind: 'pending' };
    }

    let next: FlowWizardStepClass<DatasetFlowContext> = DatasetConnectionSelectorComponent;
    if (sourceFamily === 'CLOUD') {
      next = DatasetCloudSourceComponent;
    } else if (sourceFamily === ConnectorType.REST_API || sourceFamily === ConnectorType.BUSINESS_CENTRAL) {
      next = RestApiConnectionStepComponent;
    }

    if (!candidates.some((candidate) => candidate === next)) {
      return { kind: 'pending' };
    }

    return { kind: 'next', next };
  }

  override onForward(): void {
    const sourceFamily = this.selectedSourceFamily();
    if (!sourceFamily) {
      return;
    }
    this._datasetWizardStore.resetSourceConfiguration();
    this._datasetWizardStore.setSourceFamily(sourceFamily);
    if (sourceFamily !== 'CLOUD') {
      this._datasetWizardStore.setConnectorType(sourceFamily as ConnectorType);
    }
    if (sourceFamily === ConnectorType.HOOK_API) {
      this._datasetWizardStore.setIdConnector('');
      this._datasetWizardStore.setConnectorEntity(ConnectorType.HOOK_API);
    }
  }

  private createOption(value: DatasetSourceFamily, title: string, subtitle: string, icon: string): OptionButtonItem {
    return {
      title,
      subtitle,
      icon,
      isSelected: this.selected() && this.selectedSourceFamily() === value,
      onSelect: () => {
        this.selected.set(true);
        this.selectedSourceFamily.set(value);
      },
      onDeselect: () => {
        if (this.selectedSourceFamily() === value) {
          this.selected.set(false);
          this.selectedSourceFamily.set(null);
        }
      },
    };
  }
}
