import { buildExtractColumnsValidationSignature } from '@alkyra/dataset/components/shared/extract-columns-validation.utils';
import { ExtractColumnsValidationResponse } from '@alkyra/dataset/models/extract-columns-validation.model';
import { DatasetConnectorService } from '@alkyra/dataset/services/dataset-connector.service';
import { Id } from '@alkyra/shared-models/id.model';
import { FlowWizardComponent } from '@alkyra/ui/flow-wizard/flow-wizard.component';
import { FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { ChangeDetectionStrategy, Component, inject, input, OnInit, output } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import notify from 'devextreme/ui/notify';

import { DatasetWizardStore } from './+store/dataset-wizard.store';
import { RestApiStepStore } from './+store/rest-api-step.store';
import { DatasetTypeSelectorComponent } from './dataset-type-selector/dataset-type-selector.component';
import { DatasetFlowContext } from './flow-steps/dataset-flow-context.model';

@Component({
  selector: 'alk-dataset-wizard',
  standalone: true,
  imports: [TranslatePipe, FlowWizardComponent],
  templateUrl: './dataset-wizard.component.html',
  styleUrl: './dataset-wizard.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [DatasetWizardStore, RestApiStepStore],
})
export class DatasetWizardComponent implements OnInit {
  onClose = output<void>();
  onSavedDataset = output<Id>();
  pipelineId = input<string | null>();
  private readonly _translateService: TranslateService = inject(TranslateService);
  private readonly _datasetConnectorService = inject(DatasetConnectorService);
  readonly _datasetWizardStore = inject(DatasetWizardStore);
  readonly flowContext: DatasetFlowContext = {
    store: this._datasetWizardStore,
  };
  readonly startStep: FlowWizardStepClass<DatasetFlowContext> = DatasetTypeSelectorComponent;

  ngOnInit(): void {
    this._datasetWizardStore.setPipelineId(this.pipelineId()!);
  }

  close() {
    this.onClose.emit();
  }

  complete() {
    const columns = this._datasetWizardStore.columns();
    const validationSignature = buildExtractColumnsValidationSignature(columns);

    if (validationSignature === this._datasetWizardStore.lastSuccessfulValidationSignature()) {
      this.createDataset();
      return;
    }

    this._datasetConnectorService.validateExtractColumns(columns).subscribe({
      next: (response) => this.handleValidationBeforeCreate(response, validationSignature),
      error: (error) => {
        this.notify(this.resolveErrorMessage(error, 'dataset.columns.validation.failed'), 'error', 4000);
      },
    });
  }

  notify(message: string | undefined, type: string, displayTime: number): void {
    notify(message, type, displayTime);
  }

  private handleValidationBeforeCreate(response: ExtractColumnsValidationResponse, validationSignature: string): void {
    this._datasetWizardStore.setColumnsValidationResult(response, validationSignature);
    if (!response.valid) {
      this.notify(this._translateService.instant('dataset.columns.validation.failed'), 'warning', 4000);
      return;
    }
    this.createDataset();
  }

  private createDataset(): void {
    this._datasetWizardStore.addDataset().subscribe({
      next: (datasetId: Id) => {
        this.onSavedDataset.emit(datasetId);
        this.onClose.emit();
      },
      error: (error) => {
        this.notify(this.resolveErrorMessage(error, 'dataset.error.createdataset'), 'error', 4000);
      },
    });
  }

  private resolveErrorMessage(error: any, fallbackKey: string): string {
    const message = error?.error?.message ?? error?.error ?? error?.message ?? fallbackKey;
    return this._translateService.instant(message);
  }
}
