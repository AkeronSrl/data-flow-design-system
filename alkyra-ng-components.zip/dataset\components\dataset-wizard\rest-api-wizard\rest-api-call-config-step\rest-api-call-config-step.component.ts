import { TiaraSectionPanelComponent } from '@akeron-ng/tiara-ng/tiara-section-panel';
import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import {
  RestApiOperationParameterVm,
  RestApiQueryMode,
} from '@alkyra/dataset/components/dataset-wizard/+store/rest-api-step.state';
import { RestApiStepStore } from '@alkyra/dataset/components/dataset-wizard/+store/rest-api-step.store';
import { FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { ValidationCallbackData } from 'devextreme-angular/common';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxValidatorModule } from 'devextreme-angular/ui/validator';
import { DatasetWizardStore } from '../../+store/dataset-wizard.store';
import { DatasetFlowContext } from '../../flow-steps/dataset-flow-context.model';
import { RestApiDataPathStepComponent } from '../rest-api-data-path-step/rest-api-data-path-step.component';
import { RestApiPaginationConfigComponent } from '../rest-api-pagination-config/rest-api-pagination-config.component';

const ODATA_QUERY_PARAM_NAMES = new Set(['$filter', '$orderby', '$select', '$expand']);

@Component({
  selector: 'alk-rest-api-call-config-step',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    TiaraSuiteWizardStepComponent,
    TiaraSectionPanelComponent,
    DxTextBoxModule,
    DxSelectBoxModule,
    DxValidatorModule,
    RestApiPaginationConfigComponent,
  ],
  templateUrl: './rest-api-call-config-step.component.html',
  styleUrl: './rest-api-call-config-step.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RestApiCallConfigStepComponent extends FlowWizardStep<DatasetFlowContext> {
  static readonly stepId = 'dataset-rest-call-config';
  static readonly candidates: readonly FlowWizardStepClass<DatasetFlowContext>[] = [RestApiDataPathStepComponent];

  readonly _datasetWizardStore = inject(DatasetWizardStore);
  readonly _restApiStepStore = inject(RestApiStepStore);
  private readonly _translateService = inject(TranslateService);

  readonly activeTab = signal<'params' | 'headers'>('params');
  readonly requiredParamDefinitions = this._restApiStepStore.requiredParamDefinitions;
  readonly advancedParamDefinitions = this._restApiStepStore.advancedParamDefinitions;
  readonly queryMode = this._restApiStepStore.queryMode;
  readonly isQueryModeLocked = this._restApiStepStore.isQueryModeLocked;
  readonly queryModeOptions = signal([
    { value: 'REST_STANDARD' as RestApiQueryMode, labelKey: 'dataset.rest.query.mode.rest.standard' },
    { value: 'ODATA' as RestApiQueryMode, labelKey: 'dataset.rest.query.mode.odata' },
  ]);

  readonly allParamDefinitions = computed(() => [
    ...this.requiredParamDefinitions(),
    ...this.advancedParamDefinitions(),
  ]);

  readonly pathAndQueryDefinitions = computed(() =>
    this.allParamDefinitions().filter((definition) => definition.location !== 'header'),
  );
  readonly pathVariableDefinitions = computed(() =>
    this.pathAndQueryDefinitions().filter((definition) => definition.location === 'path'),
  );
  readonly standardRequestParamDefinitions = computed(() =>
    this.pathAndQueryDefinitions().filter(
      (definition) => definition.location === 'query' && !ODATA_QUERY_PARAM_NAMES.has(definition.name),
    ),
  );
  readonly requiredStandardRequestParamDefinitions = computed(() =>
    this.standardRequestParamDefinitions().filter((definition) => definition.required),
  );
  readonly oDataRequestParamDefinitions = computed((): RestApiOperationParameterVm[] => [
    ...this.requiredStandardRequestParamDefinitions(),
    { key: 'query:$filter', name: '$filter', location: 'query', required: false },
    { key: 'query:$orderby', name: '$orderby', location: 'query', required: false },
    { key: 'query:$select', name: '$select', location: 'query', required: false },
    { key: 'query:$expand', name: '$expand', location: 'query', required: false },
  ]);
  readonly requestParamDefinitions = computed(() =>
    this.queryMode() === 'ODATA' ? this.oDataRequestParamDefinitions() : this.standardRequestParamDefinitions(),
  );

  readonly headerDefinitions = computed(() =>
    this.allParamDefinitions().filter((definition) => definition.location === 'header'),
  );

  override canGoforward = computed(() => this._restApiStepStore.isCurrentConfigurationValid());

  override onForward(): void {
    const operation = this._restApiStepStore.selectedOperation();
    const connectorId = this._restApiStepStore.selectedConnectorId()?.trim();
    if (!operation || !connectorId) {
      return;
    }

    this._datasetWizardStore.setIdConnector(connectorId);
    this._datasetWizardStore.setConnectorEntity(`${operation.method}:${operation.path}`);
    this._datasetWizardStore.setDatasetConnectorParams(this._restApiStepStore.serializeDatasetConnectorParams());
  }

  setActiveTab(tab: 'params' | 'headers'): void {
    this.activeTab.set(tab);
  }

  queryModeDisplayExpr = (item: { labelKey: string } | null): string => {
    if (!item?.labelKey) {
      return '';
    }
    return this._translateService.instant(item.labelKey);
  };

  onQueryModeChanged(event: any): void {
    this._restApiStepStore.setQueryMode(event?.value ?? 'REST_STANDARD');
  }

  paramValue(parameter: RestApiOperationParameterVm): string {
    if (parameter.required) {
      return this._restApiStepStore.requiredParams()[parameter.key] ?? '';
    }
    return this._restApiStepStore.advancedParams()[parameter.key] ?? '';
  }

  onParamChanged(parameter: RestApiOperationParameterVm, event: any): void {
    if (parameter.required) {
      this._restApiStepStore.setRequiredParamValue(parameter.key, event?.value ?? '');
      return;
    }
    this._restApiStepStore.setAdvancedParamValue(parameter.key, event?.value ?? '');
  }

  oDataValidationCallback(paramName: string, e: ValidationCallbackData): boolean {
    return this._restApiStepStore.isODataParamValueValid(paramName, `${e.value ?? ''}`);
  }

  oDataValidationMessageKey(paramName: string): string {
    return `dataset.rest.odata.${paramName.replace('$', '').toLowerCase()}.invalid`;
  }

  fieldLabel(param: RestApiOperationParameterVm): string {
    return param.required ? `${param.name} *` : param.name;
  }

  paramDescription(param: RestApiOperationParameterVm): string {
    if (this.isODataRequestParam(param)) {
      return this._translateService.instant(
        `dataset.rest.odata.${param.name.replace('$', '').toLowerCase()}.description`,
      );
    }
    return param.description?.trim() ?? '';
  }

  isODataRequestParam(param: RestApiOperationParameterVm): boolean {
    return ODATA_QUERY_PARAM_NAMES.has(param.name);
  }
}
