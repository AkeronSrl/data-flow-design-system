import { TiaraSectionPanelComponent } from '@akeron-ng/tiara-ng/tiara-section-panel';
import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { BusinessCentralConnector } from '@alkyra/business-central-connector/models/business-central-connector.model';
import { BusinessCentralConnectorService } from '@alkyra/business-central-connector/services/business-central-connector.service';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import {
  RestApiOperationParameterVm,
  RestApiQueryMode,
  RestLikeConnectorType,
} from '@alkyra/dataset/components/dataset-wizard/+store/rest-api-step.state';
import { RestApiStepStore } from '@alkyra/dataset/components/dataset-wizard/+store/rest-api-step.store';
import { RestApiOpenApiResourceItem } from '@alkyra/rest-api-connector/models/rest-api-connection-test-result.model';
import { RestApiConnector } from '@alkyra/rest-api-connector/models/rest-api-connector.model';
import { RestApiConnectorService } from '@alkyra/rest-api-connector/services/rest-api-connector.service';
import { FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { mapRestApiResourcesToSchemaDiscoveryNodes } from '@alkyra/ui/schema-discovery/mappers/rest-api-schema-discovery.mapper';
import {
  SchemaDiscoveryNode,
  SchemaDiscoverySelectionEvent,
} from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject, OnInit, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { ValidationCallbackData } from 'devextreme-angular/common';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxTreeViewModule } from 'devextreme-angular/ui/tree-view';
import { DxValidatorModule } from 'devextreme-angular/ui/validator';
import { Observable, take } from 'rxjs';

import { DatasetWizardStore } from '../../+store/dataset-wizard.store';
import { DatasetColumnSelectorComponent } from '../../dataset-column-selector/dataset-column-selector.component';
import { DatasetFlowContext } from '../../flow-steps/dataset-flow-context.model';
import {
  DatasetConnectionContextComponent,
  DatasetConnectionContextItem,
} from '../../shared/dataset-connection-context/dataset-connection-context.component';
import { DatasetResourceSelectionLayoutComponent } from '../../shared/dataset-resource-selection-layout/dataset-resource-selection-layout.component';
import { RestApiPaginationConfigComponent } from '../rest-api-pagination-config/rest-api-pagination-config.component';

type RestLikeConnector = RestApiConnector | BusinessCentralConnector;
type RestApiConnectorSelection = Pick<RestLikeConnector, 'description' | 'id'> & Partial<RestLikeConnector>;
type RestApiConnectorSelectionEvent = { addedItems?: RestApiConnectorSelection[] };
const ODATA_QUERY_PARAM_NAMES = new Set(['$filter', '$orderby', '$select', '$expand']);

@Component({
  selector: 'alk-rest-api-connection-step',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    TiaraSuiteWizardStepComponent,
    TiaraSectionPanelComponent,
    DxLoadIndicatorModule,
    DxButtonModule,
    DxDataGridModule,
    DxSelectBoxModule,
    DxTextBoxModule,
    DxTreeViewModule,
    DxValidatorModule,
    SchemaDiscoveryComponent,
    DatasetConnectionContextComponent,
    DatasetResourceSelectionLayoutComponent,
    RestApiPaginationConfigComponent,
  ],
  templateUrl: './rest-api-connection-step.component.html',
  styleUrl: './rest-api-connection-step.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RestApiConnectionStepComponent extends FlowWizardStep<DatasetFlowContext> implements OnInit {
  static readonly stepId = 'dataset-rest-connection';
  static readonly candidates: readonly FlowWizardStepClass<DatasetFlowContext>[] = [DatasetColumnSelectorComponent];

  readonly _datasetWizardStore = inject(DatasetWizardStore);
  readonly _restApiStepStore = inject(RestApiStepStore);
  private readonly _restApiConnectorService = inject(RestApiConnectorService);
  private readonly _businessCentralConnectorService = inject(BusinessCentralConnectorService);
  private readonly _translateService = inject(TranslateService);

  readonly connectors = signal<RestLikeConnector[]>([]);
  readonly activeTab = signal<'params' | 'headers'>('params');
  readonly isPreviewLoading = signal(false);
  readonly previewErrorKey = signal<string | null>(null);
  readonly warningOnly = signal(false);
  readonly previewMessage = signal('');
  readonly previewRows = signal<any[]>([]);
  readonly sourceConnectorType = computed<RestLikeConnectorType>(() =>
    this._datasetWizardStore.connectorType() === ConnectorType.BUSINESS_CENTRAL
      ? ConnectorType.BUSINESS_CENTRAL
      : ConnectorType.REST_API,
  );
  readonly operations = this._restApiStepStore.getResources;
  readonly schemaNodes = computed(() =>
    mapRestApiResourcesToSchemaDiscoveryNodes(this._restApiStepStore.getResources()),
  );
  readonly selectedOperationKey = computed(() => this.findSelectedOperationNodeId(this.schemaNodes()));
  readonly canProceed = computed(
    () => !!this._restApiStepStore.selectedConnectorId()?.trim() && !!this._restApiStepStore.selectedOperation(),
  );
  readonly requiredParamDefinitions = this._restApiStepStore.requiredParamDefinitions;
  readonly advancedParamDefinitions = this._restApiStepStore.advancedParamDefinitions;
  readonly queryMode = this._restApiStepStore.queryMode;
  readonly dataPath = this._restApiStepStore.dataPath;
  readonly responseSchemaTree = computed(() => schemaToTree(this._restApiStepStore.responseJsonSchema()));
  readonly treeData = computed(() => this.jsonToTree(this.responseSchemaTree() ?? {}, '', false));
  readonly showTree = computed(() => this.treeData().length > 0);
  readonly canValidateDataPath = computed(() => this.showTree() && this.responseSchemaTree() !== null);
  readonly isDataPathValid = computed(() =>
    this.canValidateDataPath() ? this.validateJsonPath(this.responseSchemaTree(), this.dataPath()) : true,
  );
  readonly isQueryModeLocked = this._restApiStepStore.isQueryModeLocked;
  readonly queryModeOptions = signal([
    { value: 'REST_STANDARD' as RestApiQueryMode, labelKey: 'dataset.rest.query.mode.rest.standard' },
    { value: 'ODATA' as RestApiQueryMode, labelKey: 'dataset.rest.query.mode.odata' },
  ]);
  readonly allParamDefinitions = computed(() => [
    ...this.requiredParamDefinitions(),
    ...this.advancedParamDefinitions(),
  ]);
  readonly pathAndQueryDefinitions = computed(() =>
    this.allParamDefinitions().filter((definition) => definition.location !== 'header'),
  );
  readonly pathVariableDefinitions = computed(() =>
    this.pathAndQueryDefinitions().filter((definition) => definition.location === 'path'),
  );
  readonly standardRequestParamDefinitions = computed(() =>
    this.pathAndQueryDefinitions().filter(
      (definition) => definition.location === 'query' && !ODATA_QUERY_PARAM_NAMES.has(definition.name),
    ),
  );
  readonly requiredStandardRequestParamDefinitions = computed(() =>
    this.standardRequestParamDefinitions().filter((definition) => definition.required),
  );
  readonly oDataRequestParamDefinitions = computed((): RestApiOperationParameterVm[] => [
    ...this.requiredStandardRequestParamDefinitions(),
    { key: 'query:$filter', name: '$filter', location: 'query', required: false },
    { key: 'query:$orderby', name: '$orderby', location: 'query', required: false },
    { key: 'query:$select', name: '$select', location: 'query', required: false },
    { key: 'query:$expand', name: '$expand', location: 'query', required: false },
  ]);
  readonly requestParamDefinitions = computed(() =>
    this.queryMode() === 'ODATA' ? this.oDataRequestParamDefinitions() : this.standardRequestParamDefinitions(),
  );
  readonly headerDefinitions = computed(() =>
    this.allParamDefinitions().filter((definition) => definition.location === 'header'),
  );
  readonly isLoading = this._restApiStepStore.loading;
  readonly connectionIcon = computed(() =>
    this.sourceConnectorType() === ConnectorType.BUSINESS_CENTRAL
      ? 'assets/cloud-icon/business-central.png'
      : 'assets/cloud-icon/rest-api.png',
  );
  readonly emptyConnectionsKey = computed(() =>
    this.sourceConnectorType() === ConnectorType.BUSINESS_CENTRAL
      ? 'dataset.business.central.connection.empty'
      : 'export.rest.api.connection.empty',
  );

  override canGoforward = computed(
    () =>
      this.canProceed() &&
      !this.isLoading() &&
      !this.isPreviewLoading() &&
      this.isDataPathValid() &&
      this._restApiStepStore.isCurrentConfigurationValid(),
  );

  ngOnInit(): void {
    this._restApiStepStore.setSourceConnectorType(this.sourceConnectorType());
    this.loadConnectors();

    const selectedConnectorId = this._restApiStepStore.selectedConnectorId()?.trim();
    const connectorId = selectedConnectorId ?? this._datasetWizardStore.idConnector()?.trim();
    if (!connectorId) {
      return;
    }
    if (selectedConnectorId && this.operations().length > 0) {
      return;
    }

    this.findConnector(connectorId)
      .pipe(take(1))
      .subscribe({
        next: (connector) => {
          this._restApiStepStore.loadConnectorOperations(
            connectorId,
            connector.description,
            this.sourceConnectorType(),
          );
        },
        error: () => {
          this._restApiStepStore.loadConnectorOperations(connectorId, null, this.sourceConnectorType());
        },
      });
  }

  override onForward(): void {
    const connectorId = this._restApiStepStore.selectedConnectorId()?.trim();
    const operation = this._restApiStepStore.selectedOperation();
    if (!connectorId || !operation) {
      return;
    }

    this._datasetWizardStore.setIdConnector(connectorId);
    this._datasetWizardStore.setConnectorEntity(`${operation.method}:${operation.path}`);
    this._datasetWizardStore.setDatasetConnectorParams(this._restApiStepStore.serializeDatasetConnectorParams());
  }

  onDatasourceSelected(selection: RestApiConnectorSelection | RestApiConnectorSelectionEvent | null): void {
    const connector = this.resolveConnectorSelection(selection);
    if (!connector?.id) {
      return;
    }
    this._datasetWizardStore.setIdConnector(connector.id);
    this._datasetWizardStore.resetResourceSelectionState();
    this._restApiStepStore.loadConnectorOperations(connector.id, connector.description, this.sourceConnectorType());
  }

  toConnectionItems(connectors: RestLikeConnector[]): DatasetConnectionContextItem<RestLikeConnector>[] {
    return connectors
      .filter((connector): connector is RestLikeConnector & { id: string } => !!connector.id?.trim())
      .map((connector) => ({
        id: connector.id,
        title: connector.description || connector.id,
        subtitle: this.connectorSubtitle(connector),
        typeLabel: this.sourceConnectorType() === ConnectorType.BUSINESS_CENTRAL ? 'Business Central' : 'REST API',
        iconSrc: this.connectionIcon(),
        iconAlt: 'Connection',
        raw: connector,
      }));
  }

  onConnectionContextSelected(item: DatasetConnectionContextItem<RestLikeConnector>): void {
    if (!item.raw || item.id === this._restApiStepStore.selectedConnectorId()) {
      return;
    }

    this.onDatasourceSelected(item.raw);
  }

  onEndpointSelected(selection: SchemaDiscoverySelectionEvent | null): void {
    const resource = selection?.node.data as RestApiOpenApiResourceItem | undefined;
    if (!resource) {
      this._restApiStepStore.selectOperation(null);
      return;
    }

    this._restApiStepStore.selectOperation({
      method: 'GET',
      path: resource.path,
      operationId: resource.operationId ?? undefined,
    });
    this.resetPreviewState();
  }

  setActiveTab(tab: 'params' | 'headers'): void {
    this.activeTab.set(tab);
  }

  queryModeDisplayExpr = (item: { labelKey: string } | null): string => {
    return item?.labelKey ? this._translateService.instant(item.labelKey) : '';
  };

  onQueryModeChanged(event: any): void {
    this._restApiStepStore.setQueryMode(event?.value ?? 'REST_STANDARD');
    this.resetPreviewState();
  }

  paramValue(parameter: RestApiOperationParameterVm): string {
    return parameter.required
      ? (this._restApiStepStore.requiredParams()[parameter.key] ?? '')
      : (this._restApiStepStore.advancedParams()[parameter.key] ?? '');
  }

  onParamChanged(parameter: RestApiOperationParameterVm, event: any): void {
    if (parameter.required) {
      this._restApiStepStore.setRequiredParamValue(parameter.key, event?.value ?? '');
    } else {
      this._restApiStepStore.setAdvancedParamValue(parameter.key, event?.value ?? '');
    }
    this.resetPreviewState();
  }

  oDataValidationCallback(paramName: string, e: ValidationCallbackData): boolean {
    return this._restApiStepStore.isODataParamValueValid(paramName, `${e.value ?? ''}`);
  }

  oDataValidationMessageKey(paramName: string): string {
    return `dataset.rest.odata.${paramName.replace('$', '').toLowerCase()}.invalid`;
  }

  fieldLabel(param: RestApiOperationParameterVm): string {
    return param.required ? `${param.name} *` : param.name;
  }

  paramDescription(param: RestApiOperationParameterVm): string {
    if (this.isODataRequestParam(param)) {
      return this._translateService.instant(
        `dataset.rest.odata.${param.name.replace('$', '').toLowerCase()}.description`,
      );
    }
    return param.description?.trim() ?? '';
  }

  isODataRequestParam(param: RestApiOperationParameterVm): boolean {
    return ODATA_QUERY_PARAM_NAMES.has(param.name);
  }

  onTreeSelect(event: any): void {
    this._restApiStepStore.setDataPath(event?.node?.key ?? event?.itemData?.id ?? '');
    this.resetPreviewState();
  }

  onDataPathChanged(event: any): void {
    this._restApiStepStore.setDataPath(event?.value ?? '');
    this.resetPreviewState();
  }

  runPreview(): void {
    const request = this._restApiStepStore.buildOperationPreviewRequest(true);
    if (!request) {
      this.previewRows.set([]);
      return;
    }

    this.isPreviewLoading.set(true);
    this.previewErrorKey.set(null);
    this.warningOnly.set(false);
    this.previewMessage.set('');

    this._restApiStepStore
      .livePreview(request)
      .pipe(take(1))
      .subscribe({
        next: (result) => {
          const jsonSchema = toOptionalTrimmedString(result?.jsonSchema) ?? null;
          const jsonSample = toOptionalTrimmedString(result?.jsonSample) ?? null;
          const previewRows = Array.isArray(result?.previewRows) ? result.previewRows : [];
          const source = `${result?.source ?? 'empty'}`;

          this.previewRows.set(previewRows);
          this.warningOnly.set(source === 'empty');
          this.previewMessage.set(`${result?.message ?? ''}`);
          this._restApiStepStore.setPreviewPayload(jsonSchema, jsonSample);
          this.isPreviewLoading.set(false);
        },
        error: (err) => {
          this.previewRows.set([]);
          this.warningOnly.set(false);
          this.previewMessage.set('');
          this.previewErrorKey.set(extractErrorKey(err));
          this._restApiStepStore.clearPreviewPayload();
          this.isPreviewLoading.set(false);
        },
      });
  }

  private findSelectedOperationNodeId(nodes: SchemaDiscoveryNode[]): string | null {
    const operation = this._restApiStepStore.selectedOperation();
    if (!operation) {
      return null;
    }

    for (const node of nodes) {
      if (this.isSelectedOperationNode(node, operation)) {
        return node.id;
      }

      const childMatch = this.findSelectedOperationNodeId(node.items ?? []);
      if (childMatch) {
        return childMatch;
      }
    }

    return null;
  }

  private isSelectedOperationNode(
    node: SchemaDiscoveryNode,
    operation: { method: string; path: string; operationId?: string },
  ): boolean {
    const resource = node.data as RestApiOpenApiResourceItem | undefined;
    if (!resource) {
      return false;
    }

    return (
      (resource.method ?? 'GET').toUpperCase() === operation.method.toUpperCase() &&
      resource.path === operation.path &&
      (!operation.operationId || resource.operationId === operation.operationId)
    );
  }

  private resetPreviewState(): void {
    this.previewRows.set([]);
    this.previewErrorKey.set(null);
    this.warningOnly.set(false);
    this.previewMessage.set('');
    this._restApiStepStore.clearPreviewPayload();
  }

  private loadConnectors(): void {
    this.findAllConnectors()
      .pipe(take(1))
      .subscribe({
        next: (connectors) => this.connectors.set(connectors ?? []),
        error: () => this.connectors.set([]),
      });
  }

  private findAllConnectors(): Observable<RestLikeConnector[]> {
    if (this.sourceConnectorType() === ConnectorType.BUSINESS_CENTRAL) {
      return this._businessCentralConnectorService.findAll();
    }
    return this._restApiConnectorService.findAll();
  }

  private findConnector(connectorId: string): Observable<RestLikeConnector> {
    if (this.sourceConnectorType() === ConnectorType.BUSINESS_CENTRAL) {
      return this._businessCentralConnectorService.findConnector(connectorId);
    }
    return this._restApiConnectorService.findConnector(connectorId);
  }

  connectorSubtitle(connector: RestLikeConnector): string {
    if (this.isBusinessCentralConnector(connector)) {
      return [connector.tenantId, connector.environmentName, connector.companyId].filter(Boolean).join(' / ');
    }
    return connector.endpoint;
  }

  private isBusinessCentralConnector(connector: RestLikeConnector): connector is BusinessCentralConnector {
    return (
      connector.connectorType === ConnectorType.BUSINESS_CENTRAL || connector.type === ConnectorType.BUSINESS_CENTRAL
    );
  }

  private resolveConnectorSelection(
    selection: RestApiConnectorSelection | RestApiConnectorSelectionEvent | null,
  ): RestApiConnectorSelection | undefined {
    if (!selection) {
      return undefined;
    }
    if (this.isConnectorSelectionEvent(selection)) {
      return selection.addedItems?.[0];
    }
    return selection;
  }

  private isConnectorSelectionEvent(
    selection: RestApiConnectorSelection | RestApiConnectorSelectionEvent,
  ): selection is RestApiConnectorSelectionEvent {
    return !('id' in selection);
  }

  private jsonToTree(obj: Record<string, any>, parent = '', includeLastChild = false): any[] {
    return Object.keys(obj)
      .filter((key) => includeLastChild || (typeof obj[key] === 'object' && obj[key] !== null))
      .map((key) => {
        const fullPath = parent ? `${parent}.${key}` : key;
        const node: any = { id: fullPath, text: key };
        if (typeof obj[key] === 'object' && obj[key] !== null) {
          const children = this.jsonToTree(obj[key], fullPath, includeLastChild);
          if (children.length > 0) {
            node.items = children;
          }
        }
        return node;
      });
  }

  private validateJsonPath(tree: Record<string, any> | null, path: string | null | undefined): boolean {
    const normalizedPath = normalizePathToken(path);
    if (!normalizedPath) {
      return true;
    }

    return isValidPathSegments(normalizedPath) && treeHasPath(tree, normalizedPath);
  }
}

function schemaToTree(jsonSchemaRaw: string | null): Record<string, any> | null {
  if (!jsonSchemaRaw?.trim()) {
    return null;
  }
  return buildSchemaTree(safeJsonParse(jsonSchemaRaw));
}

function buildSchemaTree(schema: any): Record<string, any> | null {
  if (!schema || typeof schema !== 'object') {
    return null;
  }

  const schemaNode = schema as Record<string, any>;
  if (schemaNode['type'] === 'array') {
    return buildSchemaTree(schemaNode['items']);
  }

  if (!isObjectSchemaNode(schemaNode)) {
    return null;
  }

  return Object.entries(schemaNode['properties']).reduce<Record<string, any>>((acc, [key, value]) => {
    acc[key] = buildSchemaTree(value);
    return acc;
  }, {});
}

function toOptionalTrimmedString(value: unknown): string | undefined {
  if (typeof value !== 'string') {
    return undefined;
  }
  const trimmed = value.trim();
  return trimmed ? trimmed : undefined;
}

function safeJsonParse(raw: string): any {
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function normalizePathToken(path: string | null | undefined): string {
  if (path === null || path === undefined) {
    return '';
  }
  return path.trim();
}

function isObjectSchemaNode(schemaNode: Record<string, any>): boolean {
  return schemaNode['type'] === 'object' && !!schemaNode['properties'] && typeof schemaNode['properties'] === 'object';
}

function isValidPathSegments(path: string): boolean {
  return !path
    .split('.')
    .map((segment) => segment.trim())
    .some((segment) => !segment);
}

function treeHasPath(tree: Record<string, any> | null, path: string): boolean {
  if (!tree || typeof tree !== 'object') {
    return false;
  }

  let current: Record<string, any> | null = tree;
  for (const segment of path.split('.').map((value) => value.trim())) {
    if (!current || !(segment in current)) {
      return false;
    }
    current = toTreeNode(current[segment]);
  }
  return true;
}

function toTreeNode(value: unknown): Record<string, any> | null {
  return value && typeof value === 'object' ? (value as Record<string, any>) : null;
}

function extractErrorKey(err: any): string {
  return (
    err?.error?.captionKey ??
    err?.error?.messageKey ??
    err?.error?.message ??
    err?.message ??
    'mstd.error.rest.api.operation.preview.failed'
  );
}
