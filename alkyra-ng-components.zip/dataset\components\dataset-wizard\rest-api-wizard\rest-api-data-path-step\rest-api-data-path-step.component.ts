import { TiaraCollapsableContainerComponent } from '@akeron-ng/tiara-ng/tiara-collapsable-container';
import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { RestApiStepStore } from '@alkyra/dataset/components/dataset-wizard/+store/rest-api-step.store';
import { FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxTreeViewModule } from 'devextreme-angular/ui/tree-view';
import { take } from 'rxjs';

import { DatasetWizardStore } from '../../+store/dataset-wizard.store';
import { DatasetColumnSelectorComponent } from '../../dataset-column-selector/dataset-column-selector.component';
import { DatasetFlowContext } from '../../flow-steps/dataset-flow-context.model';

@Component({
  selector: 'alk-rest-api-data-path-step',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    TiaraSuiteWizardStepComponent,
    TiaraCollapsableContainerComponent,
    DxButtonModule,
    DxTreeViewModule,
    DxDataGridModule,
    DxLoadIndicatorModule,
  ],
  templateUrl: './rest-api-data-path-step.component.html',
  styleUrl: './rest-api-data-path-step.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RestApiDataPathStepComponent extends FlowWizardStep<DatasetFlowContext> {
  static readonly stepId = 'dataset-rest-data-path';
  static readonly candidates: readonly FlowWizardStepClass<DatasetFlowContext>[] = [DatasetColumnSelectorComponent];

  readonly _datasetWizardStore = inject(DatasetWizardStore);
  readonly _restApiStepStore = inject(RestApiStepStore);

  readonly dataPath = this._restApiStepStore.dataPath;

  readonly isLoading = signal(false);
  readonly errorKey = signal<string | null>(null);
  readonly warningOnly = signal(false);
  readonly previewMessage = signal('');
  readonly previewRows = signal<any[]>([]);

  readonly responseSchemaTree = computed(() => schemaToTree(this._restApiStepStore.responseJsonSchema()));
  readonly treeData = computed(() => this.jsonToTree(this.responseSchemaTree() ?? {}, '', false));
  readonly showTree = computed(() => this.treeData().length > 0);
  readonly leftPanelWidth = computed(() => (this.showTree() ? '350px' : '0px'));
  readonly canValidateDataPath = computed(() => this.showTree() && this.responseSchemaTree() !== null);
  readonly isDataPathValid = computed(() =>
    this.canValidateDataPath() ? this.validateJsonPath(this.responseSchemaTree(), this.dataPath()) : true,
  );

  override canGoforward = computed(() => !this.isLoading() && this.isDataPathValid());

  constructor() {
    super();
  }

  override onForward(): void {
    const connectorId = this._restApiStepStore.selectedConnectorId()?.trim();
    const operation = this._restApiStepStore.selectedOperation();
    if (connectorId) {
      this._datasetWizardStore.setIdConnector(connectorId);
    }
    if (operation) {
      this._datasetWizardStore.setConnectorEntity(`${operation.method}:${operation.path}`);
    }
    this._datasetWizardStore.setDatasetConnectorParams(this._restApiStepStore.serializeDatasetConnectorParams());
  }

  onTreeSelect(event: any): void {
    this._restApiStepStore.setDataPath(event?.node?.key ?? event?.itemData?.id ?? '');
  }

  runPreview(): void {
    const request = this._restApiStepStore.buildOperationPreviewRequest(true);
    if (!request) {
      this.previewRows.set([]);
      return;
    }

    this.isLoading.set(true);
    this.errorKey.set(null);
    this.warningOnly.set(false);
    this.previewMessage.set('');

    this._restApiStepStore
      .livePreview(request)
      .pipe(take(1))
      .subscribe({
        next: (result) => {
          const jsonSchema = toOptionalTrimmedString(result?.jsonSchema) ?? null;
          const jsonSample = toOptionalTrimmedString(result?.jsonSample) ?? null;
          const previewRows = Array.isArray(result?.previewRows) ? result.previewRows : [];
          const source = `${result?.source ?? 'empty'}`;

          this.previewRows.set(previewRows);
          this.warningOnly.set(source === 'empty');
          this.previewMessage.set(`${result?.message ?? ''}`);
          this._restApiStepStore.setPreviewPayload(jsonSchema, jsonSample);

          this.isLoading.set(false);
        },
        error: (err) => {
          this.previewRows.set([]);
          this.warningOnly.set(false);
          this.previewMessage.set('');
          this.errorKey.set(extractErrorKey(err));
          this._restApiStepStore.clearPreviewPayload();
          this.isLoading.set(false);
        },
      });
  }

  private jsonToTree(obj: Record<string, any>, parent = '', includeLastChild = false): any[] {
    return Object.keys(obj)
      .filter((key) => includeLastChild || (typeof obj[key] === 'object' && obj[key] !== null))
      .map((key) => {
        const fullPath = parent ? `${parent}.${key}` : key;
        const node: any = { id: fullPath, text: key };
        if (typeof obj[key] === 'object' && obj[key] !== null) {
          const children = this.jsonToTree(obj[key], fullPath, includeLastChild);
          if (children.length > 0) {
            node.items = children;
          }
        }
        return node;
      });
  }

  private validateJsonPath(tree: Record<string, any> | null, path: string | null | undefined): boolean {
    const normalizedPath = normalizePathToken(path);
    if (!normalizedPath) {
      return true;
    }

    return isValidPathSegments(normalizedPath) && treeHasPath(tree, normalizedPath);
  }
}

function schemaToTree(jsonSchemaRaw: string | null): Record<string, any> | null {
  if (!jsonSchemaRaw?.trim()) {
    return null;
  }
  return buildSchemaTree(safeJsonParse(jsonSchemaRaw));
}

function buildSchemaTree(schema: any): Record<string, any> | null {
  if (!schema || typeof schema !== 'object') {
    return null;
  }

  const schemaNode = schema as Record<string, any>;
  if (schemaNode['type'] === 'array') {
    return buildSchemaTree(schemaNode['items']);
  }

  if (!isObjectSchemaNode(schemaNode)) {
    return null;
  }

  return Object.entries(schemaNode['properties']).reduce<Record<string, any>>((acc, [key, value]) => {
    acc[key] = buildSchemaTree(value);
    return acc;
  }, {});
}

function toOptionalTrimmedString(value: unknown): string | undefined {
  if (typeof value !== 'string') {
    return undefined;
  }
  const trimmed = value.trim();
  return trimmed ? trimmed : undefined;
}

function safeJsonParse(raw: string): any {
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function normalizePathToken(path: string | null | undefined): string {
  if (path === null || path === undefined) {
    return '';
  }
  return path.trim();
}

function isObjectSchemaNode(schemaNode: Record<string, any>): boolean {
  return schemaNode['type'] === 'object' && !!schemaNode['properties'] && typeof schemaNode['properties'] === 'object';
}

function isValidPathSegments(path: string): boolean {
  return !path
    .split('.')
    .map((segment) => segment.trim())
    .some((segment) => !segment);
}

function treeHasPath(tree: Record<string, any> | null, path: string): boolean {
  if (!tree || typeof tree !== 'object') {
    return false;
  }

  let current: Record<string, any> | null = tree;
  for (const segment of path.split('.').map((value) => value.trim())) {
    if (!current || !(segment in current)) {
      return false;
    }
    current = toTreeNode(current[segment]);
  }
  return true;
}

function toTreeNode(value: unknown): Record<string, any> | null {
  return value && typeof value === 'object' ? (value as Record<string, any>) : null;
}

function extractErrorKey(err: any): string {
  return (
    err?.error?.captionKey ??
    err?.error?.messageKey ??
    err?.error?.message ??
    err?.message ??
    'mstd.error.rest.api.operation.preview.failed'
  );
}
