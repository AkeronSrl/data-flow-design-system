import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { RestApiStepStore } from '@alkyra/dataset/components/dataset-wizard/+store/rest-api-step.store';
import { RestApiOpenApiResourceItem } from '@alkyra/rest-api-connector/models/rest-api-connection-test-result.model';
import { RestApiOperationSelection } from '@alkyra/rest-api-connector/models/rest-api-operation-preview.model';
import { FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxListModule } from 'devextreme-angular/ui/list';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';

import { DatasetWizardStore } from '../../+store/dataset-wizard.store';
import { DatasetFlowContext } from '../../flow-steps/dataset-flow-context.model';
import { RestApiCallConfigStepComponent } from '../rest-api-call-config-step/rest-api-call-config-step.component';

type OperationListItem = { key: string; label: string; operation: RestApiOpenApiResourceItem };

@Component({
  selector: 'alk-rest-api-operation-step',
  standalone: true,
  imports: [CommonModule, TranslatePipe, TiaraSuiteWizardStepComponent, DxListModule, DxLoadIndicatorModule],
  templateUrl: './rest-api-operation-step.component.html',
  styleUrl: './rest-api-operation-step.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RestApiOperationStepComponent extends FlowWizardStep<DatasetFlowContext> {
  static readonly stepId = 'dataset-rest-operation';
  static readonly candidates: readonly FlowWizardStepClass<DatasetFlowContext>[] = [RestApiCallConfigStepComponent];

  readonly _datasetWizardStore = inject(DatasetWizardStore);
  readonly _restApiStepStore = inject(RestApiStepStore);

  readonly isLoading = this._restApiStepStore.loading;
  readonly operations = this._restApiStepStore.getResources;
  readonly selectedOperationKey = computed(() => this.toOperationKey(this._restApiStepStore.selectedOperation()));
  readonly operationItems = computed<OperationListItem[]>(() =>
    this.operations().map((operation) => ({
      key: this.toOperationKey(this.toOperationSelection(operation)),
      label: this.operationLabel(operation),
      operation,
    })),
  );

  override canGoforward = computed(() => !!this._restApiStepStore.selectedOperation() && !this.isLoading());

  override onForward(): void {
    const operation = this._restApiStepStore.selectedOperation();
    if (!operation) {
      return;
    }
    this._datasetWizardStore.setConnectorEntity(`${operation.method}:${operation.path}`);
  }

  onOperationSelected(event: any): void {
    const operation = (event?.addedItems?.[0] as OperationListItem | undefined)?.operation;
    if (!operation) {
      this._restApiStepStore.selectOperation(null);
      return;
    }

    this._restApiStepStore.selectOperation(this.toOperationSelection(operation));
  }

  private toOperationSelection(operation: RestApiOpenApiResourceItem): RestApiOperationSelection {
    return {
      method: 'GET',
      path: operation.path,
      operationId: operation.operationId,
    };
  }

  private toOperationKey(operation: RestApiOperationSelection | null | undefined): string {
    if (!operation) {
      return '';
    }
    return `${operation.method}:${operation.path}:${operation.operationId ?? ''}`;
  }

  operationLabel(operation: RestApiOpenApiResourceItem): string {
    const summary = operation.summary?.trim();
    if (summary) {
      return `${operation.method.toUpperCase()} ${operation.path} - ${summary}`;
    }
    return `${operation.method.toUpperCase()} ${operation.path}`;
  }
}
