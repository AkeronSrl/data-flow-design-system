import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import { REST_API_PAGINATION_TYPES } from '@alkyra/dataset/components/dataset-wizard/+store/rest-api-step.state';
import { RestApiStepStore } from '@alkyra/dataset/components/dataset-wizard/+store/rest-api-step.store';
import {
  RestApiPaginationConfig,
  RestApiPaginationType,
} from '@alkyra/rest-api-connector/models/rest-api-operation-preview.model';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, Input, inject } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { DxNumberBoxModule } from 'devextreme-angular/ui/number-box';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';

type RestApiPaginationSelectableType = Exclude<RestApiPaginationType, 'NONE'> | 'ODATA_TOP_SKIP';
type RestApiPaginationUiType = RestApiPaginationSelectableType | null;
type PaginationTypeOption = { value: RestApiPaginationSelectableType; label: string };

const ODATA_SKIP_PARAM = '$skip';
const ODATA_TOP_PARAM = '$top';

@Component({
  selector: 'alk-rest-api-pagination-config',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    TiaraNameDescriptionLabelComponent,
    DxNumberBoxModule,
    DxSelectBoxModule,
    DxTextBoxModule,
  ],
  templateUrl: './rest-api-pagination-config.component.html',
  styleUrl: './rest-api-pagination-config.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RestApiPaginationConfigComponent {
  @Input() showHeader = true;

  readonly _restApiStepStore = inject(RestApiStepStore);
  private readonly _translateService = inject(TranslateService);

  readonly pagination = this._restApiStepStore.pagination;
  readonly queryMode = this._restApiStepStore.queryMode;
  readonly selectedPaginationType = computed<RestApiPaginationUiType>(() => this.resolveSelectedPaginationType());
  readonly paginationTypeOptions = computed<PaginationTypeOption[]>(() => this.buildPaginationTypeOptions());
  readonly batchSizeLabelKey = computed(() => this.resolveBatchSizeLabelKey());
  readonly showBatchSize = computed(() => this.selectedPaginationType() !== null);
  readonly showCustomFields = computed(() => this.selectedPaginationType() === 'CUSTOM');

  onPaginationTypeChanged(event: any): void {
    const selectedType = (event?.value ?? null) as RestApiPaginationUiType;
    if (!selectedType) {
      this._restApiStepStore.setPaginationType('NONE');
      return;
    }
    if (selectedType === 'ODATA_TOP_SKIP') {
      this.applyODataTopSkipPreset();
      return;
    }
    this._restApiStepStore.setPaginationType(selectedType);
  }

  onPaginationBatchSizeChanged(event: any): void {
    this._restApiStepStore.setPaginationBatchSize(event?.value);
  }

  onPaginationFieldChanged(
    field: 'pageParam' | 'sizeParam' | 'startPage' | 'offsetParam' | 'limitParam' | 'startOffset',
    event: any,
  ): void {
    this._restApiStepStore.setPaginationField(field, event?.value ?? null);
  }

  private buildPaginationTypeOptions(): PaginationTypeOption[] {
    if (this.queryMode() === 'ODATA') {
      return [
        {
          value: 'ODATA_TOP_SKIP',
          label: this._translateService.instant('dataset.rest.pagination.odata_top_skip'),
        },
      ];
    }

    return REST_API_PAGINATION_TYPES.filter((type) => type !== 'NONE').map((type) => this.toPaginationTypeOption(type));
  }

  private toPaginationTypeOption(type: Exclude<RestApiPaginationType, 'NONE'>): PaginationTypeOption {
    return {
      value: type,
      label: this._translateService.instant(`dataset.rest.pagination.${type.toLowerCase()}`),
    };
  }

  private resolveSelectedPaginationType(): RestApiPaginationUiType {
    const pagination = this.pagination();
    if (this.queryMode() === 'ODATA' && this.isODataTopSkipPagination(pagination)) {
      return 'ODATA_TOP_SKIP';
    }
    if (pagination.type === 'NONE') {
      return null;
    }
    return pagination.type;
  }

  private resolveBatchSizeLabelKey(): string {
    switch (this.selectedPaginationType()) {
      case 'ODATA_TOP_SKIP':
        return 'dataset.rest.pagination.batch.size.top';
      case 'OFFSET_LIMIT':
        return 'dataset.rest.pagination.batch.size.limit';
      case 'PAGE_SIZE':
        return 'dataset.rest.pagination.batch.size.size';
      default:
        return 'dataset.rest.pagination.batch.size';
    }
  }

  private applyODataTopSkipPreset(): void {
    this._restApiStepStore.setPaginationType('OFFSET_LIMIT');
    this._restApiStepStore.setPaginationField('offsetParam', ODATA_SKIP_PARAM);
    this._restApiStepStore.setPaginationField('limitParam', ODATA_TOP_PARAM);
    this._restApiStepStore.setPaginationField('startOffset', 0);
  }

  private isODataTopSkipPagination(pagination: RestApiPaginationConfig): boolean {
    return (
      pagination.type === 'OFFSET_LIMIT' &&
      pagination.offsetParam === ODATA_SKIP_PARAM &&
      pagination.limitParam === ODATA_TOP_PARAM
    );
  }
}
