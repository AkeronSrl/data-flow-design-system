import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';

export interface DatasetConnectionContextItem<T = unknown> {
  id: string;
  title: string;
  subtitle?: string;
  typeLabel?: string;
  iconSrc?: string;
  iconAlt?: string;
  iconClass?: string;
  raw?: T;
}

@Component({
  selector: 'alk-dataset-connection-context',
  standalone: true,
  imports: [CommonModule, TranslatePipe, DxSelectBoxModule, DxTextBoxModule],
  templateUrl: './dataset-connection-context.component.html',
  styleUrl: './dataset-connection-context.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DatasetConnectionContextComponent<T = unknown> {
  readonly items = input<DatasetConnectionContextItem<T>[]>([]);
  readonly selectedId = input<string | null | undefined>('');
  readonly placeholder = input('connection.select');
  readonly emptyMessage = input('query.analyzer.filter.empty');

  readonly connectionSelected = output<DatasetConnectionContextItem<T>>();

  protected readonly displayConnectionItem = (item: DatasetConnectionContextItem<T> | null): string => {
    if (!item) {
      return '';
    }

    return [item.title, item.typeLabel, item.subtitle].filter(Boolean).join(' - ');
  };

  protected onValueChanged(event: { value?: string | null }): void {
    const selectedId = event.value?.trim();
    const item = this.items().find((connection) => connection.id === selectedId);
    if (!item || item.id === this.selectedId()) {
      return;
    }

    this.connectionSelected.emit(item);
  }

  protected trackConnection(_: number, item: DatasetConnectionContextItem<T>): string {
    return item.id;
  }
}
