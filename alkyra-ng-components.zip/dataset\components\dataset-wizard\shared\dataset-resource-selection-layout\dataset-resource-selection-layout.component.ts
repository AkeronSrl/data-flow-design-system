import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';

@Component({
  selector: 'alk-dataset-resource-selection-layout',
  standalone: true,
  imports: [CommonModule, TranslatePipe, TiaraCircularIllustrationComponent],
  templateUrl: './dataset-resource-selection-layout.component.html',
  styleUrl: './dataset-resource-selection-layout.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DatasetResourceSelectionLayoutComponent {
  readonly hasConnection = input(false);
  readonly emptyMessage = input('connection.select');
}
