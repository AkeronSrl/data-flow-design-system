import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import { VulkiField } from '@alkyra/vulki-connector/models/vulki-connector.model';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { ValidationCallbackData } from 'devextreme-angular/common';
import { DxAutocompleteModule } from 'devextreme-angular/ui/autocomplete';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxValidatorModule } from 'devextreme-angular/ui/validator';

import { ExportColumnOption } from '../../models/export-column-option.model';

@Component({
  selector: 'alk-config-map-item',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    DxAutocompleteModule,
    DxSelectBoxModule,
    DxTextBoxModule,
    DxValidatorModule,
    TiaraNameDescriptionLabelComponent,
  ],
  templateUrl: './config-map-item.component.html',
  styleUrl: './config-map-item.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ConfigMapItemComponent {
  private readonly _translateService = inject(TranslateService);
  field = input<VulkiField & { description?: string }>({ name: '', required: true, tipo: '' });
  selectedDatasourceColumns = input<ExportColumnOption[]>([]);
  selectedValue = input<string>('');
  isPathParam = input<boolean>(false);
  allowLiteral = input<boolean>(false);
  showPathHint = input<boolean>(true);
  validationCallback = input<((e: ValidationCallbackData) => boolean) | undefined>(undefined);
  validationMessage = input<string>('');

  private autoSelectedValue = signal<string | undefined>(undefined);
  private hasAutoSelected = signal<boolean>(false);
  resolvedValue = computed(() => this.selectedValue() || this.autoSelectedValue() || '');

  // Show autocomplete for path params when columns available, dropdown for regular fields
  showAutocomplete = computed(() => {
    return (this.isPathParam() || this.allowLiteral()) && this.selectedDatasourceColumns().length > 0;
  });

  showDropdown = computed(() => {
    return !this.isPathParam() && !this.allowLiteral() && this.selectedDatasourceColumns().length > 0;
  });

  showTextBox = computed(() => {
    return !this.showAutocomplete() && !this.showDropdown();
  });

  fieldLabel = computed(() => {
    const field = this.field();
    return field.required ? `${field.name} *` : field.name;
  });

  fieldDescription = computed(() => {
    const f = this.field();
    const parts: string[] = [];
    if (f.tipo) {
      parts.push(f.tipo);
    }
    if (this.isPathParam() && this.showPathHint()) {
      parts.push(this._translateService.instant('export.vulki.path.param.hint'));
    }
    if (f.description?.trim()) {
      parts.push(f.description.trim());
    }
    return parts.join(' - ');
  });

  fieldChanged = output<{ fieldName: string; value: string }>();

  constructor() {
    effect(() => {
      const fieldName = this.field()?.name || '';

      if (!fieldName) {
        return;
      }

      if (this.selectedValue() || this.hasAutoSelected()) {
        this.autoSelectedValue.set(undefined);
        return;
      }

      const guess = this.findBestMatch(fieldName, this.selectedDatasourceColumns());
      if (guess) {
        this.autoSelectedValue.set(guess);
        this.hasAutoSelected.set(true);
        this.onFieldChanged(guess);
      }
    });
  }

  onFieldChanged(value: string): void {
    this.fieldChanged.emit({
      fieldName: this.field().name,
      value: value,
    });
  }

  private findBestMatch(fieldName: string, columns: ExportColumnOption[]): string | undefined {
    const normalizedField = this.normalize(this.extractMatchTarget(fieldName));

    let bestCandidate: string | undefined;
    let bestScore = Number.MAX_SAFE_INTEGER;

    for (const column of columns) {
      const candidates = [column.value, column.alias, column.name, column.displayName, column.label].filter(
        Boolean,
      ) as string[];

      for (const candidate of candidates) {
        const normalizedCandidate = this.normalize(candidate);

        if (normalizedCandidate === normalizedField) {
          return candidate;
        }

        const score = this.levenshtein(normalizedField, normalizedCandidate);
        if (score < bestScore) {
          bestScore = score;
          bestCandidate = candidate;
        }
      }
    }

    const threshold = Math.max(2, Math.floor(normalizedField.length * 0.2));
    return bestScore <= threshold ? bestCandidate : undefined;
  }

  private normalize(value: string): string {
    return value.toLowerCase().replace(/[^a-z0-9]/g, '');
  }

  private extractMatchTarget(fieldName: string): string {
    const trimmed = fieldName.trim();
    if (!trimmed) {
      return trimmed;
    }
    const parts = trimmed.split('.');
    return parts[parts.length - 1] || trimmed;
  }

  private levenshtein(a: string, b: string): number {
    if (a === b) {
      return 0;
    }
    if (a.length === 0) {
      return b.length;
    }
    if (b.length === 0) {
      return a.length;
    }

    const matrix: number[][] = Array.from({ length: a.length + 1 }, () => []);

    for (let i = 0; i <= a.length; i++) {
      matrix[i][0] = i;
    }

    for (let j = 0; j <= b.length; j++) {
      matrix[0][j] = j;
    }

    for (let i = 1; i <= a.length; i++) {
      for (let j = 1; j <= b.length; j++) {
        const cost = a[i - 1] === b[j - 1] ? 0 : 1;

        matrix[i][j] = Math.min(matrix[i - 1][j] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j - 1] + cost);
      }
    }

    return matrix[a.length][b.length];
  }
}
