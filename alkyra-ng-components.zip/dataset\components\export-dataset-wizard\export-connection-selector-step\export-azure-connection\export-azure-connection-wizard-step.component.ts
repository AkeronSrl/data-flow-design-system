import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { FlowResolveResult, FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';

import { ExportWizardStore } from '../../+store/export-wizard.store';
import { ExportS3ConfigWizardStepComponent } from '../../export-s3-config-step/export-s3-config-wizard-step.component';
import { ExportFlowContext } from '../../flow-steps/export-flow-context.model';
import { CloudTreeNodeSelection } from '../export-s3-connection/export-s3-connection.component';
import { ExportAzureConnectionComponent } from './export-azure-connection.component';

@Component({
  selector: 'alk-export-azure-connection-wizard-step',
  standalone: true,
  imports: [TiaraSuiteWizardStepComponent, TranslatePipe, ExportAzureConnectionComponent],
  templateUrl: './export-azure-connection-wizard-step.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportAzureConnectionWizardStepComponent extends FlowWizardStep<ExportFlowContext> {
  static readonly stepId = 'connection-azure';
  static readonly candidates: readonly FlowWizardStepClass<ExportFlowContext>[] = [ExportS3ConfigWizardStepComponent];

  private readonly _store = inject(ExportWizardStore);

  readonly selectedSourceId = computed(() => this._store.destinationAzure().sourceId);
  readonly selectedItemPath = computed(() => this._store.destinationAzure().selectedItemPath);

  override canGoforward = computed(() => this._store.isAzureFormValid());

  override resolveNext(
    context: ExportFlowContext,
    candidates: readonly FlowWizardStepClass<ExportFlowContext>[],
  ): FlowResolveResult<ExportFlowContext> {
    if (!context.store.isAzureFormValid()) {
      return { kind: 'pending' };
    }

    return super.resolveNext(context, candidates);
  }

  onSourceChanged(sourceId: string): void {
    const normalized = sourceId?.trim() ?? '';
    if (this._store.destinationAzure().sourceId !== normalized) {
      this._store.setCloudSelectedItem('', 'folder', null);
      this._store.setCloudFileType(null);
      this._store.setCloudSheetName(null);
    }
    this._store.setAzureSource(normalized);
  }

  onTreeNodeSelected(selection: CloudTreeNodeSelection): void {
    this._store.setCloudSelectedItem(selection.path, selection.kind, selection.fileType);
  }

  override onBackward(): void {
    this._store.setAzureSource('');
    this._store.setCloudSelectedItem('', 'folder', null);
    this._store.setCloudFileType(null);
    this._store.setCloudSheetName(null);
  }
}
