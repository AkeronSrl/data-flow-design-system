import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { TiaraSuiteTreeNode } from '@akeron-ng/tiara-ng-suite/tiara-tree-view';
import { AzureBlobConnector } from '@alkyra/azure-blob-connector/models/azure-blob-connector.model';
import { AzureBlobConnectorService } from '@alkyra/azure-blob-connector/services/azure-blob-connector.service';
import { resolveCloudFileType } from '@alkyra/dataset/components/dataset-wizard/dataset-cloud-source/cloud-file-tree.utils';
import { FileExplorerItem } from '@alkyra/file-explorer/models/file-explorer-item.model';
import { mapCloudTreeNodesToSchemaDiscoveryNodes } from '@alkyra/ui/schema-discovery/mappers/cloud-file-schema-discovery.mapper';
import { SchemaDiscoverySelectionEvent } from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  effect,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TranslatePipe } from '@ngx-translate/core';

import {
  DatasetConnectionContextComponent,
  DatasetConnectionContextItem,
} from '../../../dataset-wizard/shared/dataset-connection-context/dataset-connection-context.component';
import { buildExportCloudFileTreeNodes } from '../../utils/cloud-export-tree.utils';

import { CloudTreeNodeSelection } from '../export-s3-connection/export-s3-connection.component';

@Component({
  selector: 'alk-export-azure-connection',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    TiaraCircularIllustrationComponent,
    SchemaDiscoveryComponent,
    DatasetConnectionContextComponent,
  ],
  templateUrl: './export-azure-connection.component.html',
  styleUrl: '../shared/export-connection-selector.shared.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportAzureConnectionComponent {
  private readonly _azureBlobConnectorService = inject(AzureBlobConnectorService);
  private readonly _destroyRef = inject(DestroyRef);
  private readonly _loadedSourceId = signal('');

  selectedSourceId = input<string>('');
  selectedItemPath = input<string | null>(null);
  sourceChanged = output<string>();
  treeNodeSelected = output<CloudTreeNodeSelection>();

  connectors = signal<AzureBlobConnector[]>([]);
  selectedConnector = signal<AzureBlobConnector | null>(null);
  rawTreeItems = signal<FileExplorerItem[]>([]);
  isPreviewLoading = signal(false);

  readonly treeNodes = computed<TiaraSuiteTreeNode<FileExplorerItem, FileExplorerItem>[]>(() =>
    buildExportCloudFileTreeNodes(this.rawTreeItems()),
  );
  readonly connectionItems = computed(() => this.toConnectionItems(this.connectors()));
  readonly schemaNodes = computed(() => mapCloudTreeNodesToSchemaDiscoveryNodes(this.treeNodes()));
  readonly hasPreview = computed(() => this.schemaNodes().length > 0);
  readonly hasConnections = computed(() => this.connectors().length > 0);

  constructor() {
    this._azureBlobConnectorService
      .findAll()
      .pipe(takeUntilDestroyed(this._destroyRef))
      .subscribe((connectors) => {
        this.connectors.set(connectors ?? []);
      });

    effect(() => {
      const sourceId = this.selectedSourceId()?.trim() ?? '';
      if (!this.shouldHydrateConnection(sourceId)) {
        return;
      }

      this.loadConnection(sourceId);
    });
  }

  onConnectionContextSelected(item: DatasetConnectionContextItem<AzureBlobConnector>): void {
    if (!item.raw || item.id === this.selectedSourceId()) {
      return;
    }

    this.sourceChanged.emit(item.id);
    this.loadConnection(item.id);
  }

  onSchemaNodeSelected(event: SchemaDiscoverySelectionEvent): void {
    const item = event.node.data as FileExplorerItem | undefined;
    if (!item?.path) {
      return;
    }

    const kind: 'folder' | 'file' = event.node.kind === 'group' ? 'folder' : 'file';
    const fileType = kind === 'file' ? resolveCloudFileType(item.path) : null;
    this.treeNodeSelected.emit({ path: item.path, kind, fileType });
  }

  private toConnectionItems(connectors: AzureBlobConnector[]): DatasetConnectionContextItem<AzureBlobConnector>[] {
    return connectors
      .filter((connector): connector is AzureBlobConnector & { id: string } => !!connector.id?.trim())
      .map((connector) => ({
        id: connector.id,
        title: connector.description || connector.containerName || connector.id,
        subtitle: connector.containerName,
        typeLabel: 'Azure Blob',
        iconSrc: 'assets/cloud-icon/azure.png',
        iconAlt: 'Azure Blob',
        raw: connector,
      }));
  }

  private shouldHydrateConnection(sourceId: string): boolean {
    return !!sourceId && this.connectors().length > 0 && this._loadedSourceId() !== sourceId;
  }

  private loadConnection(connectorId: string): void {
    const normalized = connectorId?.trim() ?? '';
    this._loadedSourceId.set(normalized);
    this.rawTreeItems.set([]);

    if (!normalized) {
      this.selectedConnector.set(null);
      return;
    }

    this._azureBlobConnectorService
      .findConnector(normalized)
      .pipe(takeUntilDestroyed(this._destroyRef))
      .subscribe({
        next: (fullConnector) => {
          this.selectedConnector.set(fullConnector);
          this.loadTree(fullConnector);
        },
        error: () => {
          this.selectedConnector.set(null);
        },
      });
  }

  private loadTree(connector: AzureBlobConnector): void {
    this.isPreviewLoading.set(true);
    this._azureBlobConnectorService
      .connectionPreview(connector)
      .pipe(takeUntilDestroyed(this._destroyRef))
      .subscribe({
        next: (fileItems) => {
          this.rawTreeItems.set(fileItems ?? []);
        },
        error: () => {
          this.rawTreeItems.set([]);
        },
        complete: () => {
          this.isPreviewLoading.set(false);
        },
      });
  }
}
