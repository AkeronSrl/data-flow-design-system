import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { FlowResolveResult, FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { RestApiOperationSelection } from '../../+store/export-wizard.state';
import { ExportWizardStore } from '../../+store/export-wizard.store';
import { ExportRestApiBodyWizardStepComponent } from '../../export-rest-api-body-step/export-rest-api-body-wizard-step.component';
import { ExportFlowContext } from '../../flow-steps/export-flow-context.model';
import { ExportBusinessCentralConnectionComponent } from './export-business-central-connection.component';

@Component({
  selector: 'alk-export-business-central-connection-wizard-step',
  standalone: true,
  imports: [TiaraSuiteWizardStepComponent, TranslatePipe, ExportBusinessCentralConnectionComponent],
  templateUrl: './export-business-central-connection-wizard-step.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportBusinessCentralConnectionWizardStepComponent extends FlowWizardStep<ExportFlowContext> {
  static readonly stepId = 'connection-business-central';
  static readonly candidates: readonly FlowWizardStepClass<ExportFlowContext>[] = [
    ExportRestApiBodyWizardStepComponent,
  ];

  private readonly _store = inject(ExportWizardStore);

  readonly selectedSourceId = computed(() => this._store.destinationBusinessCentral().sourceId);
  readonly selectedOperationPath = computed(() => this._store.destinationBusinessCentral().operationPath);
  readonly selectedOperationMethod = computed(() => this._store.destinationBusinessCentral().operationMethod);

  override canGoforward = computed(() => this._store.isBusinessCentralFormValid());

  override resolveNext(
    context: ExportFlowContext,
    candidates: readonly FlowWizardStepClass<ExportFlowContext>[],
  ): FlowResolveResult<ExportFlowContext> {
    if (!context.store.isBusinessCentralFormValid()) {
      return { kind: 'pending' };
    }

    return super.resolveNext(context, candidates);
  }

  onSourceChanged(sourceId: string): void {
    this._store.setBusinessCentralSource(sourceId?.trim() ?? '');
  }

  onOperationSelected(selection: RestApiOperationSelection | null): void {
    this._store.setBusinessCentralOperation(selection);
  }
}
