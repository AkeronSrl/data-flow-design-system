import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { BusinessCentralConnector } from '@alkyra/business-central-connector/models/business-central-connector.model';
import { BusinessCentralConnectorService } from '@alkyra/business-central-connector/services/business-central-connector.service';
import { RestApiOpenApiResourceItem } from '@alkyra/rest-api-connector/models/rest-api-connection-test-result.model';
import { mapRestApiResourcesToSchemaDiscoveryNodes } from '@alkyra/ui/schema-discovery/mappers/rest-api-schema-discovery.mapper';
import { SchemaDiscoverySelectionEvent } from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  effect,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TranslatePipe } from '@ngx-translate/core';

import {
  DatasetConnectionContextComponent,
  DatasetConnectionContextItem,
} from '../../../dataset-wizard/shared/dataset-connection-context/dataset-connection-context.component';
import { RestApiOperationSelection, RestApiParameterDefinition } from '../../+store/export-wizard.state';

type BcOperationItem = RestApiOperationSelection & { id: string };
type RestApiParameterLocation = RestApiParameterDefinition['location'];
type CompositeSchemaKey = 'allOf' | 'anyOf' | 'oneOf';

const COMPOSITE_SCHEMA_KEYS: CompositeSchemaKey[] = ['allOf', 'anyOf', 'oneOf'];

@Component({
  selector: 'alk-export-business-central-connection',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    TiaraCircularIllustrationComponent,
    SchemaDiscoveryComponent,
    DatasetConnectionContextComponent,
  ],
  templateUrl: './export-business-central-connection.component.html',
  styleUrl: '../shared/export-connection-selector.shared.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportBusinessCentralConnectionComponent {
  private readonly _bcService = inject(BusinessCentralConnectorService);
  private readonly _destroyRef = inject(DestroyRef);
  private readonly _loadedSourceId = signal('');

  selectedSourceId = input<string>('');
  selectedOperationPath = input<string>('');
  selectedOperationMethod = input<string>('');
  sourceChanged = output<string>();
  operationSelected = output<RestApiOperationSelection | null>();

  connectors = signal<BusinessCentralConnector[]>([]);
  selectedConnector = signal<BusinessCentralConnector | null>(null);
  operations = signal<BcOperationItem[]>([]);
  isLoadingOperations = signal(false);
  loadError = signal<string | null>(null);

  readonly connectionItems = computed(() => this.toConnectionItems(this.connectors()));
  readonly schemaNodes = computed(() =>
    mapRestApiResourcesToSchemaDiscoveryNodes(this.operations().map((operation) => this.toSchemaResource(operation))),
  );
  readonly selectedNodeId = computed(
    () =>
      this.schemaNodes()
        .flatMap((group) => group.items ?? [])
        .find((node) => {
          const resource = node.data as RestApiOpenApiResourceItem | undefined;
          return (
            resource?.path === this.selectedOperationPath() &&
            (resource.method ?? '').toUpperCase() === (this.selectedOperationMethod() ?? '').toUpperCase()
          );
        })?.id ?? null,
  );

  constructor() {
    this._bcService
      .findAll()
      .pipe(takeUntilDestroyed(this._destroyRef))
      .subscribe((connectors) => this.connectors.set(connectors ?? []));

    effect(() => {
      const sourceId = this.selectedSourceId()?.trim() ?? '';
      if (!this.shouldHydrateConnection(sourceId)) {
        return;
      }

      this.loadConnectorById(sourceId);
    });
  }

  onConnectionContextSelected(item: DatasetConnectionContextItem<BusinessCentralConnector>): void {
    if (!item.raw || item.id === this.selectedSourceId()) {
      return;
    }

    this.sourceChanged.emit(item.id);
    this.operationSelected.emit(null);
    this.loadConnectorById(item.id);
  }

  onSchemaNodeSelected(event: SchemaDiscoverySelectionEvent): void {
    const resource = event.node.data as RestApiOpenApiResourceItem | undefined;
    if (!resource?.path) {
      this.operationSelected.emit(null);
      return;
    }

    const operation = this.operations().find(
      (item) => item.path === resource.path && item.method === (resource.method ?? '').toUpperCase(),
    );
    this.operationSelected.emit(operation ?? null);
  }

  private toConnectionItems(
    connectors: BusinessCentralConnector[],
  ): DatasetConnectionContextItem<BusinessCentralConnector>[] {
    return connectors
      .filter((connector): connector is BusinessCentralConnector & { id: string } => !!connector.id?.trim())
      .map((connector) => ({
        id: connector.id,
        title: connector.description || connector.id,
        subtitle: connector.environmentName,
        typeLabel: 'Business Central',
        iconSrc: 'assets/cloud-icon/business-central.png',
        iconAlt: 'Business Central',
        raw: connector,
      }));
  }

  private shouldHydrateConnection(sourceId: string): boolean {
    return !!sourceId && this.connectors().length > 0 && this._loadedSourceId() !== sourceId;
  }

  private loadConnectorById(connectorId: string): void {
    const normalized = connectorId?.trim() ?? '';
    this._loadedSourceId.set(normalized);
    if (!normalized) {
      this.resetSelection();
      return;
    }

    this.selectedConnector.set(null);
    this.operations.set([]);
    this.loadError.set(null);
    this.isLoadingOperations.set(true);

    this._bcService
      .findConnector(normalized)
      .pipe(takeUntilDestroyed(this._destroyRef))
      .subscribe({
        next: (fullConnector) => {
          this.selectedConnector.set(fullConnector);
          this.loadResources(fullConnector);
        },
        error: () => {
          this.isLoadingOperations.set(false);
          this.loadError.set('Impossibile caricare il connettore.');
          this.resetSelection();
        },
      });
  }

  private loadResources(connector: BusinessCentralConnector): void {
    this._bcService
      .openApiGetResources(connector)
      .pipe(takeUntilDestroyed(this._destroyRef))
      .subscribe({
        next: (resources) => {
          this.isLoadingOperations.set(false);
          this.operations.set(this.mapResources(resources));
        },
        error: () => {
          this.isLoadingOperations.set(false);
          this.loadError.set('Errore durante il recupero delle risorse. Verifica la connessione.');
          this.operations.set([]);
        },
      });
  }

  private mapResources(resources: RestApiOpenApiResourceItem[]): BcOperationItem[] {
    const items: BcOperationItem[] = [];
    for (const resource of resources ?? []) {
      const parameters = this.extractParameters(resource);
      const bodyFields = this.resolveBodyFields(resource, parameters);
      const method = this.resolveOperationMethod(resource.method);

      items.push({
        id: `${method}:${resource.path}`,
        method,
        path: resource.path,
        summary: resource.summary ?? resource.resourceName ?? '',
        description: resource.description ?? '',
        bodyFields,
        parameters,
      });
    }
    return items;
  }

  private resolveBodyFields(resource: RestApiOpenApiResourceItem, parameters: RestApiParameterDefinition[]): string[] {
    const parameterNames = new Set(parameters.map((parameter) => parameter.name));
    const requestBodyFields = this.extractRequestBodyFields(resource).filter((field) => !parameterNames.has(field));
    if (requestBodyFields.length > 0) {
      return requestBodyFields;
    }

    return (resource.fields ?? []).filter((field) => !parameterNames.has(field));
  }

  private resolveOperationMethod(method: string | null | undefined): string {
    const normalized = method?.toUpperCase() ?? '';
    return ['POST', 'PUT', 'PATCH'].includes(normalized) ? normalized : 'POST';
  }

  private toSchemaResource(operation: BcOperationItem): RestApiOpenApiResourceItem {
    return {
      method: operation.method,
      path: operation.path,
      summary: operation.summary,
      description: operation.description,
      resourceName: operation.summary,
      fields: operation.bodyFields,
      parameters: operation.parameters.map((parameter) => ({
        name: parameter.name,
        description: parameter.description,
        in: parameter.location,
        required: parameter.required,
        schema: parameter.type ? { type: parameter.type } : undefined,
      })),
    } as RestApiOpenApiResourceItem;
  }

  private extractRequestBodyFields(operation: RestApiOpenApiResourceItem): string[] {
    const requestBody = operation.requestBody;
    if (!requestBody || typeof requestBody !== 'object') {
      return [];
    }

    const content = (requestBody as Record<string, unknown>)['content'];
    if (!content || typeof content !== 'object') {
      return [];
    }

    const fields: string[] = [];
    for (const media of Object.values(content as Record<string, unknown>)) {
      if (!media || typeof media !== 'object') {
        continue;
      }
      this.extractSchemaFields((media as Record<string, unknown>)['schema'], '', fields);
    }

    return Array.from(new Set(fields));
  }

  private extractSchemaFields(schemaNode: unknown, prefix: string, fields: string[]): void {
    const schema = this.toRecord(schemaNode);
    if (!schema) {
      return;
    }

    for (const key of COMPOSITE_SCHEMA_KEYS) {
      for (const compositeSchema of this.toRecordList(schema[key])) {
        this.extractSchemaFields(compositeSchema, prefix, fields);
      }
    }

    const properties = this.toRecord(schema['properties']);
    if (properties) {
      this.extractPropertyFields(properties, prefix, fields);
      return;
    }

    const items = this.toRecord(schema['items']);
    if (items) {
      this.extractSchemaFields(items, prefix ? `${prefix}[]` : '', fields);
    }
  }

  private extractPropertyFields(properties: Record<string, unknown>, prefix: string, fields: string[]): void {
    for (const [name, propertySchema] of Object.entries(properties)) {
      const trimmed = name.trim();
      if (!trimmed) {
        continue;
      }
      const childPrefix = prefix ? `${prefix}.${trimmed}` : trimmed;
      fields.push(childPrefix);
      this.extractSchemaFields(propertySchema, childPrefix, fields);
    }
  }

  private extractParameters(operation: RestApiOpenApiResourceItem): RestApiParameterDefinition[] {
    const rawParameters = Array.isArray(operation.parameters) ? operation.parameters : [];
    const byKey = new Map<string, RestApiParameterDefinition>();

    for (const parameter of rawParameters) {
      if (!parameter || typeof parameter !== 'object') {
        continue;
      }

      const parsed = this.mapParameterObject(parameter as Record<string, unknown>);
      if (parsed) {
        byKey.set(`${parsed.location}:${parsed.name}`, parsed);
      }
    }

    return Array.from(byKey.values());
  }

  private mapParameterObject(parameter: Record<string, unknown>): RestApiParameterDefinition | null {
    const name = this.readTrimmedString(parameter['name']);
    const location = this.extractParameterLocation(parameter);
    if (!name || !location) {
      return null;
    }

    return {
      name,
      location,
      required: location === 'path' || parameter['required'] === true,
      type:
        this.readTrimmedString(this.toRecord(parameter['schema'])?.['type'] as string | undefined) ??
        this.readTrimmedString(parameter['type'] as string | undefined),
      description: this.readTrimmedString(parameter['description'] as string | undefined),
    };
  }

  private extractParameterLocation(parameter: Record<string, unknown>): RestApiParameterLocation | null {
    const location = (
      this.readTrimmedString(parameter['location'] as string | undefined) ??
      this.readTrimmedString(parameter['in'] as string | undefined)
    )?.toLowerCase();
    return location === 'path' || location === 'query' || location === 'header'
      ? (location as RestApiParameterLocation)
      : null;
  }

  private readTrimmedString(value: unknown): string | undefined {
    if (typeof value !== 'string') {
      return undefined;
    }
    const normalized = value.trim();
    return normalized || undefined;
  }

  private toRecord(value: unknown): Record<string, unknown> | null {
    return value && typeof value === 'object' ? (value as Record<string, unknown>) : null;
  }

  private toRecordList(value: unknown): Record<string, unknown>[] {
    if (!Array.isArray(value)) {
      return [];
    }
    return value.map((node) => this.toRecord(node)).filter((node): node is Record<string, unknown> => !!node);
  }

  private resetSelection(): void {
    this.sourceChanged.emit('');
    this.operationSelected.emit(null);
    this.selectedConnector.set(null);
    this.operations.set([]);
    this.isLoadingOperations.set(false);
    this.loadError.set(null);
  }
}
