import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { FlowResolveResult, FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';

import { ExportWizardStore } from '../../+store/export-wizard.store';
import { ExportDbConfigWizardStepComponent } from '../../export-db-config-step/export-db-config-wizard-step.component';
import { ExportFlowContext } from '../../flow-steps/export-flow-context.model';
import { ExportDbConnectionComponent } from './export-db-connection.component';

@Component({
  selector: 'alk-export-db-connection-wizard-step',
  standalone: true,
  imports: [TiaraSuiteWizardStepComponent, TranslatePipe, ExportDbConnectionComponent],
  templateUrl: './export-db-connection-wizard-step.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportDbConnectionWizardStepComponent extends FlowWizardStep<ExportFlowContext> {
  static readonly stepId = 'connection-db';
  static readonly candidates: readonly FlowWizardStepClass<ExportFlowContext>[] = [ExportDbConfigWizardStepComponent];

  private readonly _store = inject(ExportWizardStore);

  readonly selectedSourceId = computed(() => this._store.destinationDb().sourceId);
  readonly selectedTableName = computed(() => this._store.destinationDb().tableName);

  override canGoforward = computed(() => this._store.isDbFormValid());

  override resolveNext(
    context: ExportFlowContext,
    candidates: readonly FlowWizardStepClass<ExportFlowContext>[],
  ): FlowResolveResult<ExportFlowContext> {
    if (!context.store.isDbFormValid()) {
      return { kind: 'pending' };
    }

    return super.resolveNext(context, candidates);
  }

  onSourceChanged(sourceId: string): void {
    const normalized = sourceId?.trim() ?? '';
    if (this._store.destinationDb().sourceId !== normalized) {
      this._store.setDbTableName('');
    }
    this._store.setDbSource(normalized);
  }

  onTableChanged(tableName: string): void {
    this._store.setDbTableName(tableName ?? '');
  }

  override onBackward(): void {
    this._store.setDbSource('');
    this._store.setDbTableName('');
  }
}
