import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { DBMSType } from '@alkyra/connector/models/dbms-type.model';
import { DatabaseConnector } from '@alkyra/database-connector/models/database-connector.model';
import { DatabaseSourceMetadata } from '@alkyra/database-connector/models/database-source-metadata.model';
import { DatabaseConnectorService } from '@alkyra/database-connector/services/database-connector.service';
import {
  DatabaseSchemaState,
  mapDatabaseStatesToSchemaDiscoveryNodes,
} from '@alkyra/ui/schema-discovery/mappers/database-schema-discovery.mapper';
import {
  SchemaDiscoveryExpandEvent,
  SchemaDiscoveryNode,
  SchemaDiscoverySelectionEvent,
} from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  effect,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TranslatePipe } from '@ngx-translate/core';

import {
  DatasetConnectionContextComponent,
  DatasetConnectionContextItem,
} from '../../../dataset-wizard/shared/dataset-connection-context/dataset-connection-context.component';

@Component({
  selector: 'alk-export-db-connection',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    TiaraCircularIllustrationComponent,
    SchemaDiscoveryComponent,
    DatasetConnectionContextComponent,
  ],
  templateUrl: './export-db-connection.component.html',
  styleUrl: '../shared/export-connection-selector.shared.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportDbConnectionComponent {
  private readonly _databaseConnectorService = inject(DatabaseConnectorService);
  private readonly _destroyRef = inject(DestroyRef);
  private readonly _loadedSourceId = signal('');

  selectedSourceId = input<string>('');
  selectedTableName = input<string>('');

  sourceChanged = output<string>();
  tableChanged = output<string>();

  connectors = signal<DatabaseConnector[]>([]);
  metadataStates = signal<DatabaseSchemaState[]>([]);
  loading = signal(false);
  selectedNodeId = signal<string | null>(null);

  readonly connectionItems = computed(() => this.toConnectionItems(this.connectors()));
  readonly schemaNodes = computed(() =>
    this.toSelectableNodes(
      mapDatabaseStatesToSchemaDiscoveryNodes(this.metadataStates(), {
        tables: 'Tables',
        views: 'Views',
      }),
    ),
  );

  constructor() {
    this._databaseConnectorService
      .findAll()
      .pipe(takeUntilDestroyed(this._destroyRef))
      .subscribe((connectors) => {
        this.connectors.set(connectors ?? []);
      });

    effect(() => {
      const sourceId = this.selectedSourceId()?.trim() ?? '';
      if (!this.shouldHydrateConnection(sourceId)) {
        return;
      }

      this.loadConnection(sourceId);
    });
  }

  onConnectionContextSelected(item: DatasetConnectionContextItem<DatabaseConnector>): void {
    if (!item.raw || item.id === this.selectedSourceId()) {
      return;
    }

    this.sourceChanged.emit(item.id);
    this.tableChanged.emit('');
    this.loadConnection(item.id);
  }

  onSchemaNodeSelected(event: SchemaDiscoverySelectionEvent): void {
    const metadata = event.node.data as DatabaseSourceMetadata | undefined;
    if (!metadata?.tableName) {
      return;
    }

    this.selectedNodeId.set(event.nodeId);
    this.tableChanged.emit(metadata.tableName);
  }

  onNodeExpandRequested(event: SchemaDiscoveryExpandEvent): void {
    const metadata = event.node.data as DatabaseSourceMetadata | undefined;
    const sourceId = this.selectedSourceId()?.trim() ?? '';
    if (!this.canLoadColumns(metadata, sourceId)) {
      return;
    }

    const state = this.metadataStates().find((item) => item.resource.tableName === metadata.tableName);
    if (!this.shouldLoadColumns(state)) {
      return;
    }

    this.patchMetadataState(metadata.tableName, { columnsLoading: true, expanded: true });
    this._databaseConnectorService
      .columns(sourceId, metadata.tableName)
      .pipe(takeUntilDestroyed(this._destroyRef))
      .subscribe({
        next: (columns) => {
          this.patchMetadataState(metadata.tableName, {
            columns: columns ?? [],
            columnsLoaded: true,
            columnsLoading: false,
            expanded: true,
          });
        },
        error: () => {
          this.patchMetadataState(metadata.tableName, {
            columns: [],
            columnsLoaded: true,
            columnsLoading: false,
            expanded: true,
          });
        },
      });
  }

  private toConnectionItems(connectors: DatabaseConnector[]): DatasetConnectionContextItem<DatabaseConnector>[] {
    return connectors
      .filter((connector): connector is DatabaseConnector & { id: string } => !!connector.id?.trim())
      .map((connector) => ({
        id: connector.id,
        title: connector.dbname || connector.description || connector.id,
        subtitle: connector.description,
        typeLabel: connector.dbmsType,
        iconSrc: this.databaseIcon(connector.dbmsType),
        iconAlt: connector.dbmsType,
        raw: connector,
      }));
  }

  private shouldHydrateConnection(sourceId: string): boolean {
    return !!sourceId && this.connectors().length > 0 && this._loadedSourceId() !== sourceId;
  }

  private canLoadColumns(
    metadata: DatabaseSourceMetadata | undefined,
    sourceId: string,
  ): metadata is DatabaseSourceMetadata {
    return !!metadata?.tableName && !!sourceId;
  }

  private shouldLoadColumns(state: DatabaseSchemaState | undefined): state is DatabaseSchemaState {
    return !!state && !state.columnsLoaded && !state.columnsLoading;
  }

  private loadConnection(sourceId: string): void {
    const normalized = sourceId?.trim() ?? '';
    this._loadedSourceId.set(normalized);
    this.loading.set(true);
    this.metadataStates.set([]);

    if (!normalized) {
      this.selectedNodeId.set(null);
      this.loading.set(false);
      return;
    }

    this._databaseConnectorService
      .getMetadata(normalized)
      .pipe(takeUntilDestroyed(this._destroyRef))
      .subscribe({
        next: (metadata) => {
          const selectedTable = this.selectedTableName()?.trim() ?? '';
          this.metadataStates.set(
            (metadata ?? []).map((resource) => ({
              resource,
              expanded: resource.tableName === selectedTable,
            })),
          );

          const selectedMetadata = metadata.find((item) => item.tableName === selectedTable);
          this.selectedNodeId.set(selectedMetadata ? this.databaseNodeId(selectedMetadata) : null);
          this.loading.set(false);

          if (selectedMetadata) {
            this.onNodeExpandRequested({
              nodeId: this.databaseNodeId(selectedMetadata),
              node: {
                id: this.databaseNodeId(selectedMetadata),
                kind: 'entity',
                label: selectedMetadata.tableName,
                selectable: true,
                data: selectedMetadata,
              },
            });
          }
        },
        error: () => {
          this.metadataStates.set([]);
          this.selectedNodeId.set(null);
          this.loading.set(false);
        },
      });
  }

  private patchMetadataState(tableName: string, patch: Partial<DatabaseSchemaState>): void {
    this.metadataStates.update((states) =>
      states.map((state) =>
        state.resource.tableName === tableName
          ? {
              ...state,
              ...patch,
            }
          : state,
      ),
    );
  }

  private toSelectableNodes(nodes: SchemaDiscoveryNode[]): SchemaDiscoveryNode[] {
    return nodes.map((node) => ({
      ...node,
      selectable: node.kind === 'entity',
      items: node.items ? this.toSelectableNodes(node.items) : node.items,
    }));
  }

  private databaseNodeId(metadata: DatabaseSourceMetadata): string {
    return `schema-database-entity-${metadata.tableName}`;
  }

  private databaseIcon(dbmsType: DBMSType | undefined): string | undefined {
    switch (dbmsType) {
      case 'POSTGRES':
        return 'assets/db-icon/pg.png';
      case 'SQLSERVER':
        return 'assets/db-icon/mssql.png';
      case 'ORACLE':
        return 'assets/db-icon/oracle.png';
      case 'SAPHANA':
        return 'assets/db-icon/sap.png';
      default:
        return undefined;
    }
  }
}
