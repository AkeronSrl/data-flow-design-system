import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import {
  RestApiConnectionTestResult,
  RestApiOpenApiResourceItem,
} from '@alkyra/rest-api-connector/models/rest-api-connection-test-result.model';
import { RestApiConnector } from '@alkyra/rest-api-connector/models/rest-api-connector.model';
import { RestApiConnectorService } from '@alkyra/rest-api-connector/services/rest-api-connector.service';
import { mapRestApiResourcesToSchemaDiscoveryNodes } from '@alkyra/ui/schema-discovery/mappers/rest-api-schema-discovery.mapper';
import { SchemaDiscoverySelectionEvent } from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  effect,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TranslatePipe } from '@ngx-translate/core';

import {
  DatasetConnectionContextComponent,
  DatasetConnectionContextItem,
} from '../../../dataset-wizard/shared/dataset-connection-context/dataset-connection-context.component';
import {
  RestApiBulkConfig,
  RestApiOperationSelection,
  RestApiParameterDefinition,
} from '../../+store/export-wizard.state';

type RestApiOperationItem = RestApiOperationSelection & {
  id: string;
};
type RestApiParameterLocation = RestApiParameterDefinition['location'];
type CompositeSchemaKey = 'allOf' | 'anyOf' | 'oneOf';
type ArrayFieldSearch = {
  schema: Record<string, unknown>;
  prefix: string;
};
type ArrayFieldPropertySearch = {
  propertyName: string;
  propertySchema: unknown;
  parentPrefix: string;
};

const COMPOSITE_SCHEMA_KEYS: CompositeSchemaKey[] = ['allOf', 'anyOf', 'oneOf'];

const createDefaultBulkConfig = (): RestApiBulkConfig => ({
  enabled: false,
  batchSize: 100,
  payloadShape: 'ROOT_ARRAY',
  arrayFieldPath: '',
  correlationField: '',
  responseErrorItemsPath: '',
  responseErrorCorrelationPath: '',
});

@Component({
  selector: 'alk-export-rest-api-connection',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    TiaraCircularIllustrationComponent,
    SchemaDiscoveryComponent,
    DatasetConnectionContextComponent,
  ],
  templateUrl: './export-rest-api-connection.component.html',
  styleUrl: '../shared/export-connection-selector.shared.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportRestApiConnectionComponent {
  private readonly _restApiConnectorService = inject(RestApiConnectorService);
  private readonly _destroyRef = inject(DestroyRef);
  private readonly _loadedSourceId = signal('');

  selectedSourceId = input<string>('');
  selectedOperationPath = input<string>('');
  selectedOperationMethod = input<string>('');
  sourceChanged = output<string>();
  operationSelected = output<RestApiOperationSelection | null>();

  connectors = signal<RestApiConnector[]>([]);
  selectedConnector = signal<RestApiConnector | null>(null);
  operations = signal<RestApiOperationItem[]>([]);
  isLoadingOperations = signal(false);
  loadError = signal<string | null>(null);
  openApiWarning = signal<string | null>(null);

  readonly connectionItems = computed(() => this.toConnectionItems(this.connectors()));
  readonly schemaNodes = computed(() =>
    mapRestApiResourcesToSchemaDiscoveryNodes(this.operations().map((operation) => this.toSchemaResource(operation))),
  );
  readonly selectedNodeId = computed(
    () =>
      this.schemaNodes()
        .flatMap((group) => group.items ?? [])
        .find((node) => {
          const resource = node.data as RestApiOpenApiResourceItem | undefined;
          return (
            resource?.path === this.selectedOperationPath() &&
            (resource.method ?? '').toUpperCase() === (this.selectedOperationMethod() ?? '').toUpperCase()
          );
        })?.id ?? null,
  );

  constructor() {
    this._restApiConnectorService
      .findAll()
      .pipe(takeUntilDestroyed(this._destroyRef))
      .subscribe((connectors) => this.connectors.set(connectors ?? []));

    effect(() => {
      const sourceId = this.selectedSourceId()?.trim() ?? '';
      if (!this.shouldHydrateConnection(sourceId)) {
        return;
      }

      this.loadConnectorById(sourceId);
    });
  }

  onConnectionContextSelected(item: DatasetConnectionContextItem<RestApiConnector>): void {
    if (!item.raw || item.id === this.selectedSourceId()) {
      return;
    }

    this.sourceChanged.emit(item.id);
    this.operationSelected.emit(null);
    this.loadConnectorById(item.id);
  }

  onSchemaNodeSelected(event: SchemaDiscoverySelectionEvent): void {
    const resource = event.node.data as RestApiOpenApiResourceItem | undefined;
    if (!resource?.path) {
      this.operationSelected.emit(null);
      return;
    }

    const operation = this.operations().find(
      (item) => item.path === resource.path && item.method === (resource.method ?? '').toUpperCase(),
    );
    this.operationSelected.emit(operation ?? null);
  }

  private toConnectionItems(connectors: RestApiConnector[]): DatasetConnectionContextItem<RestApiConnector>[] {
    return connectors
      .filter((connector): connector is RestApiConnector & { id: string } => !!connector.id?.trim())
      .map((connector) => ({
        id: connector.id,
        title: connector.description || connector.id,
        subtitle: connector.endpoint,
        typeLabel: 'REST API',
        iconSrc: 'assets/cloud-icon/rest-api.png',
        iconAlt: 'REST API',
        raw: connector,
      }));
  }

  private shouldHydrateConnection(sourceId: string): boolean {
    return !!sourceId && this.connectors().length > 0 && this._loadedSourceId() !== sourceId;
  }

  private loadConnectorById(connectorId: string): void {
    const normalized = connectorId?.trim() ?? '';
    this._loadedSourceId.set(normalized);
    if (!normalized) {
      this.resetSelection();
      return;
    }

    this.selectedConnector.set(null);
    this.operations.set([]);
    this.loadError.set(null);
    this.openApiWarning.set(null);
    this.isLoadingOperations.set(true);

    this._restApiConnectorService
      .findConnector(normalized)
      .pipe(takeUntilDestroyed(this._destroyRef))
      .subscribe({
        next: (fullConnector) => {
          this.selectedConnector.set(fullConnector);
          this.loadOperations(fullConnector);
        },
        error: () => {
          this.isLoadingOperations.set(false);
          this.loadError.set('Impossibile caricare il connettore.');
          this.resetSelection();
        },
      });
  }

  private loadOperations(connector: RestApiConnector): void {
    this._restApiConnectorService
      .testConnection(connector)
      .pipe(takeUntilDestroyed(this._destroyRef))
      .subscribe({
        next: (result) => {
          this.isLoadingOperations.set(false);
          if (!result.openApiSuccess) {
            this.openApiWarning.set(
              result.openApiMessage
                ? `OpenAPI non disponibile: ${result.openApiMessage}`
                : 'OpenAPI non disponibile: configura un OpenAPI URL sul connettore per scoprire le operazioni.',
            );
          }
          if (!result.connectionSuccess) {
            this.loadError.set(result.connectionMessage ?? 'Test connessione fallito.');
          }
          this.operations.set(this.mapOperations(result));
        },
        error: () => {
          this.isLoadingOperations.set(false);
          this.loadError.set('Errore durante il test connessione. Verifica che il servizio sia raggiungibile.');
          this.operations.set([]);
        },
      });
  }

  private mapOperations(result: RestApiConnectionTestResult): RestApiOperationItem[] {
    const items: RestApiOperationItem[] = [];
    for (const operation of result.resources ?? []) {
      if (!['POST', 'PUT', 'PATCH'].includes(operation.method?.toUpperCase() ?? '')) {
        continue;
      }

      const parameters = this.extractParameters(operation);
      const parameterNames = new Set(parameters.map((parameter) => parameter.name));
      const bodyFields = this.extractRequestBodyFields(operation).filter((field) => !parameterNames.has(field));
      items.push({
        id: `${operation.method}:${operation.path}`,
        method: operation.method.toUpperCase(),
        path: operation.path,
        summary: operation.summary ?? operation.resourceName ?? '',
        description: operation.description ?? '',
        bodyFields,
        parameters,
        bulkConfig: this.inferBulkConfig(operation),
      });
    }
    return items;
  }

  private toSchemaResource(operation: RestApiOperationItem): RestApiOpenApiResourceItem {
    return {
      method: operation.method,
      path: operation.path,
      summary: operation.summary,
      description: operation.description,
      resourceName: operation.summary,
      fields: operation.bodyFields,
      parameters: operation.parameters.map((parameter) => ({
        name: parameter.name,
        description: parameter.description,
        in: parameter.location,
        required: parameter.required,
        schema: parameter.type ? { type: parameter.type } : undefined,
      })),
    } as RestApiOpenApiResourceItem;
  }

  private extractRequestBodyFields(operation: RestApiOpenApiResourceItem): string[] {
    const requestBody = operation.requestBody;
    if (!requestBody || typeof requestBody !== 'object') {
      return [];
    }

    const content = (requestBody as Record<string, unknown>)['content'];
    if (!content || typeof content !== 'object') {
      return [];
    }

    const fields: string[] = [];
    for (const media of Object.values(content as Record<string, unknown>)) {
      if (!media || typeof media !== 'object') {
        continue;
      }
      this.extractSchemaFields((media as Record<string, unknown>)['schema'], '', fields);
    }

    return Array.from(new Set(fields));
  }

  private inferBulkConfig(operation: RestApiOpenApiResourceItem): RestApiBulkConfig | undefined {
    const requestBody = operation.requestBody;
    if (!requestBody || typeof requestBody !== 'object') {
      return undefined;
    }

    const content = this.toRecord((requestBody as Record<string, unknown>)['content']);
    if (!content) {
      return undefined;
    }

    for (const media of Object.values(content)) {
      const mediaRecord = this.toRecord(media);
      if (!mediaRecord) {
        continue;
      }

      const inferred = this.inferBulkConfigFromSchema(mediaRecord['schema']);
      if (inferred) {
        return inferred;
      }
    }

    return undefined;
  }

  private inferBulkConfigFromSchema(schemaNode: unknown): RestApiBulkConfig | undefined {
    const schema = this.toRecord(schemaNode);
    if (!schema) {
      return undefined;
    }

    if (this.isArraySchema(schema)) {
      return createDefaultBulkConfig();
    }

    return this.inferBulkConfigFromCompositeSchemas(schema) ?? this.inferBulkConfigFromArrayField(schema);
  }

  private inferBulkConfigFromCompositeSchemas(schema: Record<string, unknown>): RestApiBulkConfig | undefined {
    for (const compositeSchema of this.extractCompositeSchemas(schema)) {
      const inferred = this.inferBulkConfigFromSchema(compositeSchema);
      if (inferred) {
        return inferred;
      }
    }
    return undefined;
  }

  private inferBulkConfigFromArrayField(schema: Record<string, unknown>): RestApiBulkConfig | undefined {
    const arrayFieldPath = this.findArrayFieldPath({ schema, prefix: '' });
    return arrayFieldPath
      ? {
          ...createDefaultBulkConfig(),
          payloadShape: 'OBJECT_ARRAY_FIELD',
          arrayFieldPath,
        }
      : undefined;
  }

  private findArrayFieldPath(search: ArrayFieldSearch): string | undefined {
    if (search.prefix && this.isArraySchema(search.schema)) {
      return search.prefix;
    }

    return this.findArrayFieldPathInCompositeSchemas(search) ?? this.findArrayFieldPathInProperties(search);
  }

  private findArrayFieldPathInCompositeSchemas(search: ArrayFieldSearch): string | undefined {
    for (const compositeSchema of this.extractCompositeSchemas(search.schema)) {
      const result = this.findArrayFieldPath({ schema: compositeSchema, prefix: search.prefix });
      if (result) {
        return result;
      }
    }
    return undefined;
  }

  private findArrayFieldPathInProperties(search: ArrayFieldSearch): string | undefined {
    const properties = this.toRecord(search.schema['properties']);
    if (!properties) {
      return undefined;
    }

    for (const [propertyName, propertySchema] of Object.entries(properties)) {
      const result = this.findArrayFieldPathInProperty({
        propertyName,
        propertySchema,
        parentPrefix: search.prefix,
      });
      if (result) {
        return result;
      }
    }

    return undefined;
  }

  private findArrayFieldPathInProperty(search: ArrayFieldPropertySearch): string | undefined {
    const childPrefix = this.buildChildSchemaPath(search);
    const childSchema = this.toRecord(search.propertySchema);
    if (!childPrefix || !childSchema) {
      return undefined;
    }

    return this.findArrayFieldPath({ schema: childSchema, prefix: childPrefix });
  }

  private buildChildSchemaPath(search: ArrayFieldPropertySearch): string | undefined {
    const normalizedPropertyName = search.propertyName.trim();
    if (!normalizedPropertyName) {
      return undefined;
    }
    return search.parentPrefix ? `${search.parentPrefix}.${normalizedPropertyName}` : normalizedPropertyName;
  }

  private isArraySchema(schema: Record<string, unknown>): boolean {
    return this.readTrimmedString(schema['type'])?.toLowerCase() === 'array' || !!this.toRecord(schema['items']);
  }

  private extractSchemaFields(schemaNode: unknown, prefix: string, fields: string[]): void {
    const schema = this.toRecord(schemaNode);
    if (!schema) {
      return;
    }

    this.extractCompositeSchemaFields(schema, prefix, fields);
    if (this.extractPropertySchemaFields(schema, prefix, fields)) {
      return;
    }
    this.extractArraySchemaFields(schema, prefix, fields);
  }

  private extractCompositeSchemaFields(schema: Record<string, unknown>, prefix: string, fields: string[]): void {
    for (const compositeSchema of this.extractCompositeSchemas(schema)) {
      this.extractSchemaFields(compositeSchema, prefix, fields);
    }
  }

  private extractCompositeSchemas(schema: Record<string, unknown>): Record<string, unknown>[] {
    return COMPOSITE_SCHEMA_KEYS.flatMap((key) => this.toRecordList(schema[key]));
  }

  private toRecordList(value: unknown): Record<string, unknown>[] {
    if (!Array.isArray(value)) {
      return [];
    }
    return value.map((node) => this.toRecord(node)).filter((node): node is Record<string, unknown> => !!node);
  }

  private extractPropertySchemaFields(schema: Record<string, unknown>, prefix: string, fields: string[]): boolean {
    const properties = this.toRecord(schema['properties']);
    if (!properties) {
      return false;
    }

    for (const [propertyName, propertySchema] of Object.entries(properties)) {
      const normalizedPropertyName = propertyName.trim();
      if (!normalizedPropertyName) {
        continue;
      }
      const childPrefix = prefix ? `${prefix}.${normalizedPropertyName}` : normalizedPropertyName;
      fields.push(childPrefix);
      this.extractSchemaFields(propertySchema, childPrefix, fields);
    }

    return true;
  }

  private extractArraySchemaFields(schema: Record<string, unknown>, prefix: string, fields: string[]): void {
    const items = this.toRecord(schema['items']);
    if (!items) {
      return;
    }

    const arrayPrefix = prefix ? `${prefix}[]` : '';
    this.extractSchemaFields(items, arrayPrefix, fields);
  }

  private extractParameters(operation: RestApiOpenApiResourceItem): RestApiParameterDefinition[] {
    const rawParameters = Array.isArray(operation.parameters) ? operation.parameters : [];
    const parsed = rawParameters
      .map((parameter) => {
        if (!parameter || typeof parameter !== 'object') {
          return null;
        }

        const direct = this.mapOpenApiParameterObject(parameter as Record<string, unknown>);
        if (direct) {
          return direct;
        }

        return this.mapLegacyParameterDescription((parameter as Record<string, unknown>)['description']);
      })
      .filter((parameter): parameter is RestApiParameterDefinition => !!parameter);

    const byKey = new Map<string, RestApiParameterDefinition>();
    for (const parameter of parsed) {
      byKey.set(`${parameter.location}:${parameter.name}`, parameter);
    }

    return Array.from(byKey.values());
  }

  private mapOpenApiParameterObject(parameter: Record<string, unknown>): RestApiParameterDefinition | null {
    const name = this.readTrimmedString(parameter['name']);
    const location = this.extractParameterLocation(parameter);
    if (!name || !location) {
      return null;
    }

    return {
      name,
      location,
      required: location === 'path' || parameter['required'] === true,
      type: this.extractParameterType(parameter),
      description: this.readTrimmedString(parameter['description']),
    };
  }

  private mapLegacyParameterDescription(rawDescription: unknown): RestApiParameterDefinition | null {
    const legacyDescriptor = this.extractLegacyParameterDescriptor(rawDescription);
    if (legacyDescriptor) {
      return {
        name: legacyDescriptor.name,
        location: legacyDescriptor.location,
        required: legacyDescriptor.location === 'path',
      };
    }

    const rawParameter = this.toRecord(rawDescription);
    if (!rawParameter) {
      return null;
    }

    return this.mapOpenApiParameterObject(rawParameter);
  }

  private extractParameterLocation(parameter: Record<string, unknown>): RestApiParameterLocation | null {
    const preferredLocation = this.readTrimmedString(parameter['location']);
    const fallbackLocation = this.readTrimmedString(parameter['in']);
    const normalizedLocation = (preferredLocation ?? fallbackLocation)?.toLowerCase() ?? '';
    return this.isSupportedParameterLocation(normalizedLocation)
      ? (normalizedLocation as RestApiParameterLocation)
      : null;
  }

  private extractParameterType(parameter: Record<string, unknown>): string | undefined {
    const schema = this.toRecord(parameter['schema']);
    return this.readTrimmedString(schema?.['type']) ?? this.readTrimmedString(parameter['type']);
  }

  private extractLegacyParameterDescriptor(
    rawDescription: unknown,
  ): { name: string; location: RestApiParameterLocation } | null {
    if (typeof rawDescription !== 'string') {
      return null;
    }

    const [rawLocation, rawName] = rawDescription.split(':');
    const location = rawLocation?.trim().toLowerCase() ?? '';
    const name = rawName?.trim() ?? '';
    if (!name || !this.isSupportedParameterLocation(location)) {
      return null;
    }

    return { name, location: location as RestApiParameterLocation };
  }

  private isSupportedParameterLocation(location: string): boolean {
    return location === 'path' || location === 'query' || location === 'header';
  }

  private readTrimmedString(value: unknown): string | undefined {
    if (typeof value !== 'string') {
      return undefined;
    }

    const normalized = value.trim();
    return normalized ? normalized : undefined;
  }

  private toRecord(value: unknown): Record<string, unknown> | null {
    return value && typeof value === 'object' ? (value as Record<string, unknown>) : null;
  }

  private resetSelection(): void {
    this.sourceChanged.emit('');
    this.operationSelected.emit(null);
    this.selectedConnector.set(null);
    this.operations.set([]);
    this.isLoadingOperations.set(false);
    this.loadError.set(null);
    this.openApiWarning.set(null);
  }
}
