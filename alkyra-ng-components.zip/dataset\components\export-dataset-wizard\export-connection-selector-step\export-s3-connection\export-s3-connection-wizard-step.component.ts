import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { FlowResolveResult, FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';

import { ExportWizardStore } from '../../+store/export-wizard.store';
import { ExportS3ConfigWizardStepComponent } from '../../export-s3-config-step/export-s3-config-wizard-step.component';
import { ExportFlowContext } from '../../flow-steps/export-flow-context.model';
import { CloudTreeNodeSelection, ExportS3ConnectionComponent } from './export-s3-connection.component';

@Component({
  selector: 'alk-export-s3-connection-wizard-step',
  standalone: true,
  imports: [TiaraSuiteWizardStepComponent, TranslatePipe, ExportS3ConnectionComponent],
  templateUrl: './export-s3-connection-wizard-step.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportS3ConnectionWizardStepComponent extends FlowWizardStep<ExportFlowContext> {
  static readonly stepId = 'connection-s3';
  static readonly candidates: readonly FlowWizardStepClass<ExportFlowContext>[] = [ExportS3ConfigWizardStepComponent];

  private readonly _store = inject(ExportWizardStore);

  readonly selectedSourceId = computed(() => this._store.destinationS3().sourceId);
  readonly selectedItemPath = computed(() => this._store.destinationS3().selectedItemPath);

  override canGoforward = computed(() => this._store.isS3FormValid());

  override resolveNext(
    context: ExportFlowContext,
    candidates: readonly FlowWizardStepClass<ExportFlowContext>[],
  ): FlowResolveResult<ExportFlowContext> {
    if (!context.store.isS3FormValid()) {
      return { kind: 'pending' };
    }

    return super.resolveNext(context, candidates);
  }

  onSourceChanged(sourceId: string): void {
    const normalized = sourceId?.trim() ?? '';
    if (this._store.destinationS3().sourceId !== normalized) {
      this._store.setCloudSelectedItem('', 'folder', null);
      this._store.setCloudFileType(null);
      this._store.setCloudSheetName(null);
    }
    this._store.setS3Source(normalized);
  }

  onTreeNodeSelected(selection: CloudTreeNodeSelection): void {
    this._store.setCloudSelectedItem(selection.path, selection.kind, selection.fileType);
  }

  override onBackward(): void {
    this._store.setS3Source('');
    this._store.setCloudSelectedItem('', 'folder', null);
    this._store.setCloudFileType(null);
    this._store.setCloudSheetName(null);
    this._store.setS3FileName('');
  }
}
