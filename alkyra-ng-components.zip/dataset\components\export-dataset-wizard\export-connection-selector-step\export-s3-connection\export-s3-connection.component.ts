import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { TiaraSuiteTreeNode } from '@akeron-ng/tiara-ng-suite/tiara-tree-view';
import { S3BucketConnector } from '@alkyra/amazon-s3-connector/models/s3-bucket-connector.model';
import { S3BucketConnectorService } from '@alkyra/amazon-s3-connector/services/s3-bucket-connector.service';
import { resolveCloudFileType } from '@alkyra/dataset/components/dataset-wizard/dataset-cloud-source/cloud-file-tree.utils';
import { CloudFileType } from '@alkyra/dataset/components/dataset-wizard/models/cloud-file-type.model';
import { FileExplorerItem } from '@alkyra/file-explorer/models/file-explorer-item.model';
import { mapCloudTreeNodesToSchemaDiscoveryNodes } from '@alkyra/ui/schema-discovery/mappers/cloud-file-schema-discovery.mapper';
import { SchemaDiscoverySelectionEvent } from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  effect,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TranslatePipe } from '@ngx-translate/core';

import {
  DatasetConnectionContextComponent,
  DatasetConnectionContextItem,
} from '../../../dataset-wizard/shared/dataset-connection-context/dataset-connection-context.component';
import { buildExportCloudFileTreeNodes } from '../../utils/cloud-export-tree.utils';

export type CloudTreeNodeSelection = {
  path: string;
  kind: 'folder' | 'file';
  fileType: CloudFileType | null;
};

@Component({
  selector: 'alk-export-s3-connection',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    TiaraCircularIllustrationComponent,
    SchemaDiscoveryComponent,
    DatasetConnectionContextComponent,
  ],
  templateUrl: './export-s3-connection.component.html',
  styleUrl: '../shared/export-connection-selector.shared.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportS3ConnectionComponent {
  private readonly _s3BucketConnectorService = inject(S3BucketConnectorService);
  private readonly _destroyRef = inject(DestroyRef);
  private readonly _loadedSourceId = signal('');

  selectedSourceId = input<string>('');
  selectedItemPath = input<string | null>(null);
  sourceChanged = output<string>();
  treeNodeSelected = output<CloudTreeNodeSelection>();

  connectors = signal<S3BucketConnector[]>([]);
  selectedConnector = signal<S3BucketConnector | null>(null);
  rawTreeItems = signal<FileExplorerItem[]>([]);
  isPreviewLoading = signal(false);

  readonly treeNodes = computed<TiaraSuiteTreeNode<FileExplorerItem, FileExplorerItem>[]>(() =>
    buildExportCloudFileTreeNodes(this.rawTreeItems()),
  );
  readonly connectionItems = computed(() => this.toConnectionItems(this.connectors()));
  readonly schemaNodes = computed(() => mapCloudTreeNodesToSchemaDiscoveryNodes(this.treeNodes()));
  readonly hasPreview = computed(() => this.schemaNodes().length > 0);

  constructor() {
    this._s3BucketConnectorService
      .findAll()
      .pipe(takeUntilDestroyed(this._destroyRef))
      .subscribe((connectors) => {
        this.connectors.set(connectors ?? []);
      });

    effect(() => {
      const sourceId = this.selectedSourceId()?.trim() ?? '';
      if (!this.shouldHydrateConnection(sourceId)) {
        return;
      }

      this.loadConnection(sourceId);
    });
  }

  onConnectionContextSelected(item: DatasetConnectionContextItem<S3BucketConnector>): void {
    if (!item.raw || item.id === this.selectedSourceId()) {
      return;
    }

    this.sourceChanged.emit(item.id);
    this.loadConnection(item.id);
  }

  onSchemaNodeSelected(event: SchemaDiscoverySelectionEvent): void {
    const item = event.node.data as FileExplorerItem | undefined;
    if (!item?.path) {
      return;
    }

    const kind: 'folder' | 'file' = event.node.kind === 'group' ? 'folder' : 'file';
    const fileType = kind === 'file' ? resolveCloudFileType(item.path) : null;
    this.treeNodeSelected.emit({ path: item.path, kind, fileType });
  }

  private toConnectionItems(connectors: S3BucketConnector[]): DatasetConnectionContextItem<S3BucketConnector>[] {
    return connectors
      .filter((connector): connector is S3BucketConnector & { id: string } => !!connector.id?.trim())
      .map((connector) => ({
        id: connector.id,
        title: connector.description || connector.bucketName || connector.id,
        subtitle: connector.bucketName,
        typeLabel: 'Amazon S3',
        iconSrc: 'assets/cloud-icon/s3.png',
        iconAlt: 'Amazon S3',
        raw: connector,
      }));
  }

  private shouldHydrateConnection(sourceId: string): boolean {
    return !!sourceId && this.connectors().length > 0 && this._loadedSourceId() !== sourceId;
  }

  private loadConnection(connectorId: string): void {
    const normalized = connectorId?.trim() ?? '';
    this._loadedSourceId.set(normalized);
    this.rawTreeItems.set([]);

    if (!normalized) {
      this.selectedConnector.set(null);
      return;
    }

    this._s3BucketConnectorService
      .findConnector(normalized)
      .pipe(takeUntilDestroyed(this._destroyRef))
      .subscribe({
        next: (fullConnector) => {
          this.selectedConnector.set(fullConnector);
          this.loadTree();
        },
        error: () => {
          this.selectedConnector.set(null);
        },
      });
  }

  private loadTree(): void {
    const connector = this.selectedConnector();
    if (!connector) {
      return;
    }

    this.isPreviewLoading.set(true);
    this._s3BucketConnectorService
      .connectionPreview(connector)
      .pipe(takeUntilDestroyed(this._destroyRef))
      .subscribe({
        next: (fileItems) => {
          this.rawTreeItems.set(fileItems ?? []);
        },
        error: () => {
          this.rawTreeItems.set([]);
        },
        complete: () => {
          this.isPreviewLoading.set(false);
        },
      });
  }
}
