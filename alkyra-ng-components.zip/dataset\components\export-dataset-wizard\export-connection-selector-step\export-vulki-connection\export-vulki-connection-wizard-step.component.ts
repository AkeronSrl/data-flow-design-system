import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { FlowResolveResult, FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { VulkiVersionSelection } from '@alkyra/vulki-connector/models/vulki-connector.model';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';

import { ExportWizardStore } from '../../+store/export-wizard.store';
import { ExportVulkiConfigWizardStepComponent } from '../../export-vulki-config-step/export-vulki-config-wizard-step.component';
import { ExportFlowContext } from '../../flow-steps/export-flow-context.model';
import { ExportVulkiConnectionComponent } from './export-vulki-connection.component';

@Component({
  selector: 'alk-export-vulki-connection-wizard-step',
  standalone: true,
  imports: [TiaraSuiteWizardStepComponent, TranslatePipe, ExportVulkiConnectionComponent],
  templateUrl: './export-vulki-connection-wizard-step.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportVulkiConnectionWizardStepComponent extends FlowWizardStep<ExportFlowContext> {
  static readonly stepId = 'connection-vulki';
  static readonly candidates: readonly FlowWizardStepClass<ExportFlowContext>[] = [
    ExportVulkiConfigWizardStepComponent,
  ];

  private readonly _store = inject(ExportWizardStore);

  readonly selectedSourceId = computed(() => this._store.destinationVulki().sourceId);
  readonly selectedVersionName = computed(() => this._store.destinationVulki().name);
  readonly selectedPath = computed(() => this._store.destinationVulki().path);

  override canGoforward = computed(() => this._store.isVulkiFormValid());

  override resolveNext(
    context: ExportFlowContext,
    candidates: readonly FlowWizardStepClass<ExportFlowContext>[],
  ): FlowResolveResult<ExportFlowContext> {
    if (!context.store.isVulkiFormValid()) {
      return { kind: 'pending' };
    }

    return super.resolveNext(context, candidates);
  }

  onSourceChanged(sourceId: string): void {
    this._store.setVulkiSource(sourceId?.trim() ?? '');
    this.resetVulkiSelection();
  }

  onVersionSelected(selection: VulkiVersionSelection | null): void {
    if (!selection || !this.isValidVulkiSelection(selection)) {
      this.resetVulkiSelection();
      return;
    }
    this._store.setVulkiDetails(selection);
  }

  private isValidVulkiSelection(selection: VulkiVersionSelection): boolean {
    if (!selection.version?.trim()) return false;
    return selection.tagKind === 'bulk' || !!selection.path?.trim();
  }

  onConnectorTenantChanged(tenant: string): void {
    this._store.setVulkiConnectorTenant(tenant);
  }

  override onBackward(): void {
    this.resetSelectionState();
  }

  private resetVulkiSelection(): void {
    this._store.setVulkiDetails({
      name: '',
      version: '',
      fields: [],
      path: '',
      serviceName: '',
      connectionKind: 'legacy',
    });
  }

  private resetSelectionState(): void {
    this._store.setVulkiSource('');
    this.resetVulkiSelection();
  }
}
