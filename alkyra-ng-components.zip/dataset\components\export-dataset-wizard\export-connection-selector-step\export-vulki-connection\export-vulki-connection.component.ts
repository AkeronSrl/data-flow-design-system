import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { AkeronConnector, AkeronSchemaDiscoveryResponse } from '@alkyra/akeron-connector/models/akeron-connector.model';
import { AkeronConnectorService } from '@alkyra/akeron-connector/services/akeron-connector.service';
import {
  AkeronExportSelectionData,
  mapAkeronExportDiscoveryToNodes,
} from '@alkyra/ui/schema-discovery/mappers/akeron-export-schema-discovery.mapper';
import {
  mapVulkiTagsToSchemaDiscoveryNodes,
  VulkiSchemaSelectionData,
} from '@alkyra/ui/schema-discovery/mappers/vulki-schema-discovery.mapper';
import {
  SchemaDiscoveryNode,
  SchemaDiscoverySelectionEvent,
} from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import {
  DataloaderDefinition,
  DataloaderDiscoveryResponse,
} from '@alkyra/vulki-connector/models/dataloader-discovery.model';
import {
  VulkiSwaggerFieldDetail,
  VulkiSwaggerOperation,
  VulkiSwaggerResponse,
  VulkiSwaggerTagGroup,
} from '@alkyra/vulki-connector/models/vulki-connection-test-result.model';
import {
  VulkiConnector,
  VulkiField,
  VulkiVersionSelection,
} from '@alkyra/vulki-connector/models/vulki-connector.model';
import { VulkiConnectorService } from '@alkyra/vulki-connector/services/vulki-connector.service';
import {
  resolveDataloaderColumnLabel,
  resolveDataloaderColumnType,
} from '@alkyra/vulki-connector/utils/dataloader.utils';
import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  effect,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { of, switchMap } from 'rxjs';
import { catchError } from 'rxjs/operators';

import {
  DatasetConnectionContextComponent,
  DatasetConnectionContextItem,
} from '../../../dataset-wizard/shared/dataset-connection-context/dataset-connection-context.component';

type ConnectionContextSelection =
  | { kind: 'legacy'; connector: VulkiConnector }
  | { kind: 'akeron'; connector: AkeronConnector };

@Component({
  selector: 'alk-export-vulki-connection',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    TiaraCircularIllustrationComponent,
    DxLoadIndicatorModule,
    SchemaDiscoveryComponent,
    DatasetConnectionContextComponent,
  ],
  templateUrl: './export-vulki-connection.component.html',
  styleUrl: '../shared/export-connection-selector.shared.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportVulkiConnectionComponent {
  private readonly _vulkiConnectorService = inject(VulkiConnectorService);
  private readonly _akeronConnectorService = inject(AkeronConnectorService);
  private readonly _translateService = inject(TranslateService);
  private readonly _destroyRef = inject(DestroyRef);
  private readonly _loadedSourceId = signal('');
  readonly selectedContextId = signal('');

  selectedSourceId = input<string>('');
  selectedVersionName = input<string>('');
  selectedPath = input<string>('');
  sourceChanged = output<string>();
  versionSelected = output<VulkiVersionSelection | null>();
  connectorTenantChanged = output<string>();

  legacyConnectors = signal<VulkiConnector[]>([]);
  akeronConnectors = signal<AkeronConnector[]>([]);
  selectedLegacyConnector = signal<VulkiConnector | null>(null);
  selectedAkeronConnector = signal<AkeronConnector | null>(null);
  legacyPreviewData = signal<VulkiSwaggerTagGroup[]>([]);
  akeronExportDiscovery = signal<AkeronSchemaDiscoveryResponse>({ services: [] });
  isLoadingPreview = signal(false);

  readonly connectionItems = computed(() => [
    ...this.toAkeronConnectionItems(this.akeronConnectors()),
    ...this.toLegacyConnectionItems(this.legacyConnectors()),
  ]);
  readonly schemaNodes = computed(() => {
    if (this.selectedAkeronConnector()) {
      return mapAkeronExportDiscoveryToNodes(this.akeronExportDiscovery());
    }

    return mapVulkiTagsToSchemaDiscoveryNodes(this.legacyPreviewData(), {
      selectableVersions: true,
      showOperationDescription: true,
    });
  });
  readonly selectedNodeId = computed(() => this.resolveSelectedNodeId(this.schemaNodes()));

  constructor() {
    this._vulkiConnectorService
      .findAll()
      .pipe(takeUntilDestroyed(this._destroyRef))
      .subscribe((connectors) => {
        this.legacyConnectors.set(connectors ?? []);
      });

    this._akeronConnectorService
      .findAll()
      .pipe(takeUntilDestroyed(this._destroyRef))
      .subscribe((connectors) => {
        this.akeronConnectors.set((connectors ?? []).filter((connector) => connector.product === 'VULKI'));
      });

    effect(() => {
      const sourceId = this.selectedSourceId()?.trim() ?? '';
      if (!sourceId) {
        return;
      }

      this.hydrateSelection(sourceId);
    });
  }

  onConnectionContextSelected(item: DatasetConnectionContextItem<ConnectionContextSelection>): void {
    if (!item.raw) {
      return;
    }

    this.selectedContextId.set(item.id);

    if (item.id === this.selectedSourceId()) {
      return;
    }

    this.sourceChanged.emit(item.id);
    if (item.raw.kind === 'akeron') {
      this.loadAkeronConnectorById(item.id);
      return;
    }

    this.loadLegacyConnectorById(item.id);
  }

  onSchemaNodeSelected(event: SchemaDiscoverySelectionEvent): void {
    if (!this.isSelectableSchemaNode(event) || !event.node.data) {
      return;
    }

    if (this.isAkeronSelectionData(event.node.data)) {
      this.versionSelected.emit(this.buildAkeronSelection(event.node.data, event.node.label));
      return;
    }

    if (this.isLegacySelectionData(event.node.data)) {
      this.versionSelected.emit(this.buildLegacySelection(event.node.data, event.node.label));
    }
  }

  private toLegacyConnectionItems(
    connectors: VulkiConnector[],
  ): DatasetConnectionContextItem<ConnectionContextSelection>[] {
    return connectors
      .filter((connector): connector is VulkiConnector & { id: string } => !!connector.id?.trim())
      .map((connector) => ({
        id: connector.id,
        title: connector.description || connector.id,
        typeLabel: 'Vulki legacy',
        iconSrc: 'assets/vulki/logos/logo.png',
        iconAlt: 'Vulki',
        raw: { kind: 'legacy', connector },
      }));
  }

  private toAkeronConnectionItems(
    connectors: AkeronConnector[],
  ): DatasetConnectionContextItem<ConnectionContextSelection>[] {
    return connectors
      .filter(
        (connector): connector is AkeronConnector & { id: string } =>
          connector.product === 'VULKI' && !!connector.id?.trim(),
      )
      .map((connector) => ({
        id: connector.id,
        title: connector.description || connector.id,
        typeLabel: 'Akeron',
        iconSrc: 'assets/vulki/logos/logo.png',
        iconAlt: connector.description || connector.id,
        raw: { kind: 'akeron', connector },
      }));
  }

  private isSelectableSchemaNode(event: SchemaDiscoverySelectionEvent): boolean {
    return !!event.node.data && event.node.kind === 'entity' && event.node.selectable === true;
  }

  private loadLegacyConnectorById(connectorId: string): void {
    const normalized = connectorId?.trim() ?? '';
    this._loadedSourceId.set(normalized);
    if (!normalized) {
      this.resetSelectionState();
      return;
    }

    this.selectedLegacyConnector.set(null);
    this.selectedAkeronConnector.set(null);
    this.legacyPreviewData.set([]);
    this.akeronExportDiscovery.set({ services: [] });
    this.isLoadingPreview.set(true);

    this._vulkiConnectorService
      .findConnector(normalized)
      .pipe(takeUntilDestroyed(this._destroyRef))
      .subscribe({
        next: (fullConnector) => {
          this.selectedLegacyConnector.set(fullConnector);
          this.connectorTenantChanged.emit(fullConnector.tenant ?? '');
          this.loadLegacyPreview(fullConnector);
        },
        error: () => {
          this.selectedLegacyConnector.set(null);
          this.legacyPreviewData.set([]);
          this.isLoadingPreview.set(false);
        },
      });
  }

  private loadLegacyPreview(connector: VulkiConnector): void {
    this._vulkiConnectorService
      .exportSwagger(connector)
      .pipe(
        catchError(() => of({ tags: [], hasDataloader: false } as VulkiSwaggerResponse)),
        switchMap((swaggerResponse) => {
          const swaggerTags = swaggerResponse.tags ?? [];
          if (swaggerResponse.hasDataloader) {
            return this._vulkiConnectorService.dataloaderDiscoveryAll(connector).pipe(
              catchError(() => of({ definitions: [] } as DataloaderDiscoveryResponse)),
              switchMap((dataloaderResponse) => of({ swaggerTags, dataloaderResponse })),
            );
          }
          return of({ swaggerTags, dataloaderResponse: { definitions: [] } as DataloaderDiscoveryResponse });
        }),
        takeUntilDestroyed(this._destroyRef),
      )
      .subscribe({
        next: ({ swaggerTags, dataloaderResponse }) => {
          const bulkTags = this.buildBulkTagGroups(dataloaderResponse.definitions ?? []);
          const lineByLineTags = this.buildLineByLineTags(swaggerTags ?? []);
          this.legacyPreviewData.set([...bulkTags, ...lineByLineTags]);
          this.isLoadingPreview.set(false);
        },
        error: () => {
          this.legacyPreviewData.set([]);
          this.isLoadingPreview.set(false);
        },
      });
  }

  private loadAkeronConnectorById(connectorId: string): void {
    const normalized = connectorId?.trim() ?? '';
    this._loadedSourceId.set(normalized);
    if (!normalized) {
      this.resetSelectionState();
      return;
    }

    this.selectedLegacyConnector.set(null);
    this.selectedAkeronConnector.set(null);
    this.legacyPreviewData.set([]);
    this.akeronExportDiscovery.set({ services: [] });
    this.isLoadingPreview.set(true);

    this._akeronConnectorService
      .findConnector(normalized)
      .pipe(
        switchMap((connector) => {
          this.selectedAkeronConnector.set(connector);
          this.connectorTenantChanged.emit(connector.dbId ?? '');
          return this._akeronConnectorService
            .exportDiscovery(normalized)
            .pipe(catchError(() => of({ services: [] } as AkeronSchemaDiscoveryResponse)));
        }),
        takeUntilDestroyed(this._destroyRef),
      )
      .subscribe({
        next: (response) => {
          this.akeronExportDiscovery.set(response);
          this.isLoadingPreview.set(false);
        },
        error: () => {
          this.selectedAkeronConnector.set(null);
          this.akeronExportDiscovery.set({ services: [] });
          this.isLoadingPreview.set(false);
        },
      });
  }

  private buildBulkTagGroups(definitions: DataloaderDefinition[]): VulkiSwaggerTagGroup[] {
    const lang = this._translateService.currentLang || 'en';
    return definitions.map((definition) => {
      const columns = definition.entities?.[0]?.columns ?? [];
      const fields: VulkiSwaggerFieldDetail[] = columns.map((column) => {
        const label = resolveDataloaderColumnLabel(column, lang);
        const labelSuffix = label ? ` - ${label}` : '';
        return {
          name: column.name,
          type: `${resolveDataloaderColumnType(column)}${labelSuffix}`,
          required: column.required,
        };
      });

      return {
        name: `${definition.name} (bulk)`,
        description: undefined,
        tagKind: 'bulk' as const,
        dataloaderColumns: columns,
        dataloaderSupportedStrategies: definition.supportedStrategies ?? [],
        dataloaderDefinitionId: definition.name,
        versions: [
          {
            version: 'bulk',
            operations: [{ path: '', fields }],
          },
        ],
      };
    });
  }

  private buildLineByLineTags(swaggerTags: VulkiSwaggerTagGroup[]): VulkiSwaggerTagGroup[] {
    return swaggerTags.map((tag) => ({
      ...tag,
      name: `${tag.name} (line by line)`,
      tagKind: 'lineByLine' as const,
    }));
  }

  private buildLegacySelection(selectionData: VulkiSchemaSelectionData, label: string): VulkiVersionSelection {
    const { latestVersion, fields, tagGroup } = selectionData;
    return {
      name: label,
      version: latestVersion?.version ?? '',
      fields: this.toVulkiFields(fields),
      ...this.resolveVersionPaths(latestVersion?.operations),
      tagKind: tagGroup.tagKind,
      dataloaderColumns: tagGroup.dataloaderColumns,
      dataloaderSupportedStrategies: tagGroup.dataloaderSupportedStrategies,
      dataloaderDefinitionId: tagGroup.dataloaderDefinitionId,
      connectionKind: 'legacy',
    };
  }

  private buildAkeronSelection(selectionData: AkeronExportSelectionData, label: string): VulkiVersionSelection {
    return {
      name: label,
      version: selectionData.version,
      fields: selectionData.fields,
      path: selectionData.path,
      serviceName: selectionData.serviceName,
      tagKind: selectionData.tagKind,
      dataloaderDefinitionId: selectionData.dataloaderDefinitionId,
      dataloaderSupportedStrategies: selectionData.dataloaderSupportedStrategies,
      dataloaderColumns: selectionData.dataloaderColumns,
      connectionKind: 'akeron',
    };
  }

  private resolveVersionPaths(
    operations: VulkiSwaggerOperation[] | undefined,
  ): Pick<VulkiVersionSelection, 'path' | 'operations'> {
    const normalizedOperations = operations ?? [];
    return {
      path: normalizedOperations[0]?.path ?? '',
      operations: normalizedOperations.map((operation) => ({ path: operation.path })),
    };
  }

  private toVulkiFields(fields: VulkiSwaggerFieldDetail[]): VulkiField[] {
    return fields.map((field) => ({
      name: field.name,
      tipo: field.type,
      required: field.required,
    }));
  }

  private hydrateSelection(sourceId: string): void {
    if (this._loadedSourceId() === sourceId) {
      return;
    }

    const legacyConnector = this.legacyConnectors().find((connector) => connector.id === sourceId);
    if (legacyConnector) {
      this.selectedContextId.set(sourceId);
      this.loadLegacyConnectorById(sourceId);
      return;
    }

    const akeronConnector = this.akeronConnectors().find((connector) => connector.id === sourceId);
    if (!akeronConnector) {
      return;
    }

    this.selectedContextId.set(sourceId);
    this.loadAkeronConnectorById(sourceId);
  }

  private resolveSelectedNodeId(nodes: SchemaDiscoveryNode[]): string | null {
    const flattened = this.flattenNodes(nodes);
    const selectedPath = this.selectedPath()?.trim() ?? '';
    const selectedName = this.selectedVersionName()?.trim() ?? '';

    if (selectedPath) {
      const matchByPath = flattened.find(
        (node) => node.kind === 'entity' && this.readNodePath(node.data) === selectedPath,
      );
      if (matchByPath) {
        return matchByPath.id;
      }
    }

    return flattened.find((node) => node.kind === 'entity' && node.label === selectedName)?.id ?? null;
  }

  private flattenNodes(nodes: SchemaDiscoveryNode[]): SchemaDiscoveryNode[] {
    const flat: SchemaDiscoveryNode[] = [];
    nodes.forEach((node) => {
      flat.push(node);
      if (node.items?.length) {
        flat.push(...this.flattenNodes(node.items));
      }
    });
    return flat;
  }

  private readNodePath(data: unknown): string {
    if (this.isAkeronSelectionData(data)) {
      return data.path;
    }

    if (this.isLegacySelectionData(data)) {
      return data.latestVersion?.operations?.[0]?.path ?? '';
    }

    return '';
  }

  private isLegacySelectionData(data: unknown): data is VulkiSchemaSelectionData {
    return !!data && typeof data === 'object' && 'tagGroup' in data && 'latestVersion' in data;
  }

  private isAkeronSelectionData(data: unknown): data is AkeronExportSelectionData {
    return !!data && typeof data === 'object' && 'serviceName' in data && 'path' in data && 'fields' in data;
  }

  private resetSelectionState(): void {
    this.sourceChanged.emit('');
    this.versionSelected.emit(null);
    this.legacyPreviewData.set([]);
    this.akeronExportDiscovery.set({ services: [] });
    this.selectedLegacyConnector.set(null);
    this.selectedAkeronConnector.set(null);
    this.isLoadingPreview.set(false);
    this._loadedSourceId.set('');
  }
}
