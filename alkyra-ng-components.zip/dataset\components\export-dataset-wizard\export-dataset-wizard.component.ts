import { Connector, ConnectorType } from '@alkyra/connector/models/connector.model';
import { CloudFileType } from '@alkyra/dataset/components/dataset-wizard/models/cloud-file-type.model';
import { DatasetConnector } from '@alkyra/dataset/models/dataset-connector.model';
import {
  DatasetConnectorExportCreate,
  DatasetExportColumnKeySeparator,
  DatasetExportType,
} from '@alkyra/dataset/models/dataset-connector-export.model';
import { DatasetConnectorParamCreateDto } from '@alkyra/dataset/models/dataset-connector-param.model';
import { DatasetService } from '@alkyra/dataset/services/dataset.service';
import { DatasetConnectorService } from '@alkyra/dataset/services/dataset-connector.service';
import { ExportType } from '@alkyra/pipeline/models/pipeline.model';
import { FlowWizardComponent } from '@alkyra/ui/flow-wizard/flow-wizard.component';
import { FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject, input, OnInit, output } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import notify from 'devextreme/ui/notify';
import { RestApiBulkConfig, VulkiDestinationDetails } from './+store/export-wizard.state';
import { ExportWizardStore } from './+store/export-wizard.store';
import { ExportDestinationWizardStepComponent } from './export-destination-step/export-destination-wizard-step.component';
import { ExportRestApiBodyWizardStepComponent } from './export-rest-api-body-step/export-rest-api-body-wizard-step.component';
import { ExportFlowContext } from './flow-steps/export-flow-context.model';
import { composeCloudConnectorEntity } from './utils/cloud-export-path.utils';

type SaveContext = {
  destination: ExportType;
  exportType: DatasetExportType;
  columnsSelected: string[];
  backendExportType: DatasetExportType;
  connectorContext: { connectorId: string; connectorEntity: string };
  cloudFileType: CloudFileType | null;
  cloudSheetName: string | null;
};

@Component({
  selector: 'alk-export-dataset-wizard',
  standalone: true,
  imports: [CommonModule, FlowWizardComponent, TranslatePipe],
  templateUrl: './export-dataset-wizard.component.html',
  styleUrl: './export-dataset-wizard.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [ExportWizardStore],
})
export class ExportDatasetWizardComponent implements OnInit {
  datasetConnectorService = inject(DatasetConnectorService);
  datasetService = inject(DatasetService);
  private readonly _store = inject(ExportWizardStore);
  private readonly _translateService = inject(TranslateService);

  datasetId = input<string>();
  connectors = input<Connector[]>([]);
  existingExportConnectors = input<DatasetConnector[]>([]);
  initialType = input<ExportType | null>();
  editingExportId = input<string | null>(null);
  onSavedExport = output<void>();
  onHiddenExport = output<void>();

  readonly wizardTitle = computed(() => {
    const destination = this._store.selectedDestination();
    if (destination === ExportType.BUSINESS_CENTRAL) {
      return `${this._translateService.instant('pipeline.export')} Business Central`;
    }
    return this._translateService.instant('pipeline.export');
  });

  readonly flowContext: ExportFlowContext = {
    store: this._store,
  };

  startStep: FlowWizardStepClass<ExportFlowContext> = ExportDestinationWizardStepComponent;
  initialHistory: string[] = [];

  ngOnInit(): void {
    this.startStep = this.resolveInitialStep();
    this.initialHistory = [];

    const datasetId = this.datasetId();
    if (datasetId) {
      this._store.setDatasetId(datasetId);
      this.datasetService.getDatasetColumns(datasetId).subscribe((columns) => {
        this._store.setColumnsList(columns);
      });
    }

    this._store.setConnectors(this.connectors() ?? []);

    const preset = this.initialType();
    if (preset) {
      this._store.setSelectedDestination(preset);
    }

    const editId = this.editingExportId();
    if (editId) {
      const editKind = preset === ExportType.BUSINESS_CENTRAL ? ('businessCentral' as const) : undefined;
      this.datasetConnectorService.getExportDataset(editId).subscribe((detail) => {
        this._store.loadForEdit(detail, editKind);
      });
    }
  }

  private resolveInitialStep(): FlowWizardStepClass<ExportFlowContext> {
    return this.editingExportId() ? ExportRestApiBodyWizardStepComponent : ExportDestinationWizardStepComponent;
  }

  /**
   * Extract path parameters from a URL path like /ws/rest/v1/attr/{DbId}/{numAttr}
   * Returns array of parameter names: ['DbId', 'numAttr']
   */
  private extractPathParams(path: string): string[] {
    const regex = /\{([^}]+)\}/g;
    const params: string[] = [];
    let match;
    while ((match = regex.exec(path)) !== null) {
      params.push(match[1]);
    }
    return params;
  }

  private resolveConnectorContext(destination: ExportType): { connectorId: string; connectorEntity: string } {
    switch (destination) {
      case ExportType.S3: {
        const s3 = this._store.destinationS3();
        return {
          connectorId: s3.sourceId,
          connectorEntity: composeCloudConnectorEntity(s3.directoryPath, s3.fileName),
        };
      }
      case ExportType.AZURE_BLOB: {
        const azure = this._store.destinationAzure();
        return {
          connectorId: azure.sourceId,
          connectorEntity: composeCloudConnectorEntity(azure.directoryPath, azure.fileName),
        };
      }
      case ExportType.REST_API: {
        const restApi = this._store.destinationRestApi();
        return { connectorId: restApi.sourceId, connectorEntity: restApi.operationPath };
      }
      case ExportType.BUSINESS_CENTRAL: {
        const bc = this._store.destinationBusinessCentral();
        return { connectorId: bc.sourceId, connectorEntity: bc.operationPath };
      }
      case ExportType.VULKI: {
        const vulki = this._store.destinationVulki();
        return { connectorId: vulki.sourceId, connectorEntity: vulki.path || vulki.name };
      }
      default: {
        const db = this._store.destinationDb();
        return { connectorId: db.sourceId, connectorEntity: db.tableName };
      }
    }
  }

  private resolveBackendExportType(destination: ExportType, exportType: DatasetExportType): DatasetExportType {
    if (destination === ExportType.VULKI && exportType === DatasetExportType.INSERT) {
      return DatasetExportType.INSERT_UPDATE;
    }
    if (destination === ExportType.VULKI && exportType === DatasetExportType.DATALOADER) {
      return DatasetExportType.INSERT;
    }
    return exportType;
  }

  private buildFileExportParams(
    fileType: CloudFileType | null,
    sheetName: string | null,
  ): DatasetConnectorParamCreateDto[] {
    const params: DatasetConnectorParamCreateDto[] = [
      { codParametro: 'lineTerminator', valoreStringa: `\n` },
      { codParametro: 'separator', valoreStringa: `,` },
      { codParametro: 'quoteChar', valoreStringa: `"` },
      { codParametro: 'includeHeader', valoreBooleano: true },
      { codParametro: 'encoding', valoreStringa: `utf-8` },
      { codParametro: 'fileType', valoreStringa: (fileType ?? ConnectorType.CSV).toLowerCase() },
    ];

    if (fileType === ConnectorType.EXCEL && sheetName?.trim()) {
      params.push({ codParametro: 'sheetName', valoreStringa: sheetName.trim() });
    }

    return params;
  }

  private buildVulkiParams(originalExportType: DatasetExportType): DatasetConnectorParamCreateDto[] {
    const destinationVulki = this._store.destinationVulki();
    const isDataloader = originalExportType === DatasetExportType.DATALOADER;

    const params: DatasetConnectorParamCreateDto[] = [
      { codParametro: 'path', valoreStringa: destinationVulki.path },
      { codParametro: 'version', valoreStringa: destinationVulki.version },
      { codParametro: 'exportType', valoreStringa: originalExportType },
    ];

    this.appendDataloaderParams(params, destinationVulki, isDataloader);
    this.appendFieldMappingsAndDbId(params, destinationVulki);
    this.appendPathParams(params, destinationVulki, isDataloader);
    this.appendOptionalVulkiParams(params, destinationVulki);

    return params;
  }

  private appendDataloaderParams(
    params: DatasetConnectorParamCreateDto[],
    destination: VulkiDestinationDetails,
    isDataloader: boolean,
  ): void {
    if (!isDataloader) return;
    params.push({ codParametro: 'definitionId', valoreStringa: destination.dataloaderDefinitionId });
    if (destination.dataloaderStrategy?.trim()) {
      params.push({ codParametro: 'dataloaderStrategy', valoreStringa: destination.dataloaderStrategy.trim() });
    }
  }

  private appendFieldMappingsAndDbId(
    params: DatasetConnectorParamCreateDto[],
    destination: VulkiDestinationDetails,
  ): void {
    const allMappings = { ...(destination.fieldMappings || {}) };
    const dbIdValue = allMappings['DbId'] ?? destination.pathParamMappings?.['DbId'];
    if (dbIdValue && !destination.connectorTenant?.trim()) {
      params.push({ codParametro: 'DbId', valoreStringa: dbIdValue });
      delete allMappings['DbId'];
    }
    params.push({ codParametro: 'fieldMappings', valoreJson: allMappings });
  }

  private appendPathParams(
    params: DatasetConnectorParamCreateDto[],
    destination: VulkiDestinationDetails,
    isDataloader: boolean,
  ): void {
    if (isDataloader) return;
    const pathParams = this.extractPathParams(destination.path || '');
    for (const paramName of pathParams) {
      if (paramName === 'DbId') continue;
      const mappedValue = destination.pathParamMappings[paramName];
      if (mappedValue) {
        params.push({ codParametro: paramName, valoreStringa: mappedValue });
      }
    }
  }

  private appendOptionalVulkiParams(
    params: DatasetConnectorParamCreateDto[],
    destination: VulkiDestinationDetails,
  ): void {
    if (destination.connectionKind === 'akeron' && destination.serviceName?.trim()) {
      params.push({ codParametro: 'serviceName', valoreStringa: destination.serviceName.trim() });
    }
    const nullableObjects = destination.nullableObjects || {};
    if (Object.keys(nullableObjects).length > 0) {
      params.push({ codParametro: 'nullableObjects', valoreJson: nullableObjects });
    }
    if (destination.dlqConnectorId?.trim()) {
      params.push({ codParametro: 'dlqConnectorId', valoreStringa: destination.dlqConnectorId.trim() });
    }
  }

  private shouldPersistRestApiBulkConfig(bulkConfig: RestApiBulkConfig): boolean {
    return bulkConfig.enabled === true;
  }

  private buildRestApiBulkConfigParam(bulkConfig: RestApiBulkConfig): DatasetConnectorParamCreateDto {
    const normalizedBulkConfig = {
      enabled: bulkConfig.enabled === true,
      batchSize:
        Number.isFinite(bulkConfig.batchSize) && bulkConfig.batchSize > 0 ? Math.trunc(bulkConfig.batchSize) : 100,
      payloadShape: bulkConfig.payloadShape,
      arrayFieldPath: bulkConfig.arrayFieldPath?.trim() ?? '',
      correlationField: bulkConfig.correlationField?.trim() ?? '',
      responseErrorItemsPath: bulkConfig.responseErrorItemsPath?.trim() ?? '',
      responseErrorCorrelationPath: bulkConfig.responseErrorCorrelationPath?.trim() ?? '',
    };

    return {
      codParametro: 'bulkConfig',
      valoreJson: normalizedBulkConfig,
    };
  }

  private buildRestApiParams(): DatasetConnectorParamCreateDto[] {
    return this.buildWebApiParams(this._store.destinationRestApi());
  }

  private buildBusinessCentralParams(): DatasetConnectorParamCreateDto[] {
    return this.buildWebApiParams(this._store.destinationBusinessCentral());
  }

  private buildWebApiParams(destination: {
    operationMethod: string;
    fieldMappings: Record<string, string>;
    pathParamMappings: Record<string, string>;
    queryParamMappings: Record<string, string>;
    headerMappings: Record<string, string>;
    sampleJson: string;
    jsonSchema: string;
    bulkConfig: RestApiBulkConfig;
  }): DatasetConnectorParamCreateDto[] {
    const params: DatasetConnectorParamCreateDto[] = [
      { codParametro: 'httpMethod', valoreStringa: destination.operationMethod },
      { codParametro: 'fieldMappings', valoreJson: destination.fieldMappings || {} },
      { codParametro: 'pathParams', valoreJson: destination.pathParamMappings || {} },
      { codParametro: 'queryParams', valoreJson: destination.queryParamMappings || {} },
      { codParametro: 'headerParams', valoreJson: destination.headerMappings || {} },
      { codParametro: 'sampleJson', valoreStringa: destination.sampleJson || '' },
      { codParametro: 'jsonSchema', valoreStringa: destination.jsonSchema || '' },
    ];

    if (this.shouldPersistRestApiBulkConfig(destination.bulkConfig)) {
      params.push(this.buildRestApiBulkConfigParam(destination.bulkConfig));
    }

    return params;
  }

  private buildDbParams(): DatasetConnectorParamCreateDto[] {
    const destinationDbVariableMappings = this._store.destinationDbVariableMappings();
    return [
      {
        codParametro: 'variableMappings',
        valoreJson: destinationDbVariableMappings,
      },
    ];
  }

  private resolveConnectorParams(
    destination: ExportType,
    originalExportType: DatasetExportType,
    cloudFileType: CloudFileType | null,
    cloudSheetName: string | null,
  ): DatasetConnectorParamCreateDto[] {
    if (destination === ExportType.S3 || destination === ExportType.AZURE_BLOB) {
      return this.buildFileExportParams(cloudFileType, cloudSheetName);
    }
    if (destination === ExportType.VULKI) {
      return this.buildVulkiParams(originalExportType);
    }
    if (destination === ExportType.REST_API) {
      return this.buildRestApiParams();
    }
    if (destination === ExportType.BUSINESS_CENTRAL) {
      return this.buildBusinessCentralParams();
    }
    if (destination === ExportType.DB) {
      return this.buildDbParams();
    }
    return [];
  }

  private hasRequiredDbMappings(destination: ExportType): boolean {
    if (destination !== ExportType.DB) {
      return true;
    }
    return this._store.destinationDbVariableMappings().mappedVariables.length > 0;
  }

  private resolveCloudFileContext(destination: ExportType): Pick<SaveContext, 'cloudFileType' | 'cloudSheetName'> {
    if (destination === ExportType.S3) {
      const destinationS3 = this._store.destinationS3();
      return {
        cloudFileType: destinationS3.fileType,
        cloudSheetName: destinationS3.sheetName,
      };
    }

    if (destination === ExportType.AZURE_BLOB) {
      const destinationAzure = this._store.destinationAzure();
      return {
        cloudFileType: destinationAzure.fileType,
        cloudSheetName: destinationAzure.sheetName,
      };
    }

    return {
      cloudFileType: null,
      cloudSheetName: null,
    };
  }

  private buildSaveContext(): SaveContext | null {
    if (!this._store.hasMinimalContext()) {
      return null;
    }

    const destination = this._store.selectedDestination();
    const exportType = this._store.exportType();
    const columnsSelected = this._store.columnsSelected();
    if (!destination || !exportType) {
      return null;
    }

    if (!this.hasRequiredDbMappings(destination)) {
      return null;
    }

    const cloudFileContext = this.resolveCloudFileContext(destination);

    return {
      destination,
      exportType,
      columnsSelected,
      backendExportType: this.resolveBackendExportType(destination, exportType),
      connectorContext: this.resolveConnectorContext(destination),
      ...cloudFileContext,
    };
  }

  private buildExportCreatePayload(context: SaveContext): DatasetConnectorExportCreate {
    const requiresExportKey =
      (context.exportType === DatasetExportType.INSERT_UPDATE ||
        context.exportType === DatasetExportType.DELETE_INSERT) &&
      context.destination !== ExportType.REST_API &&
      context.destination !== ExportType.BUSINESS_CENTRAL;

    return {
      datasetId: this.datasetId()!,
      connectorId: context.connectorContext.connectorId,
      connectorEntity: context.connectorContext.connectorEntity || '',
      exportType: context.backendExportType,
      exportKey: requiresExportKey ? context.columnsSelected.join(DatasetExportColumnKeySeparator) : undefined,
      datasetConnectorParams: this.resolveConnectorParams(
        context.destination,
        context.exportType,
        context.cloudFileType,
        context.cloudSheetName,
      ),
    };
  }

  private hasDuplicateDestination(context: SaveContext): boolean {
    const connectorId = context.connectorContext.connectorId;
    const connectorEntity = context.connectorContext.connectorEntity || '';
    return this.existingExportConnectors().some(
      (ec) => ec.connector.id === connectorId && ec.connectorEntity === connectorEntity,
    );
  }

  private notifyDuplicateDestination(): void {
    notify(this._translateService.instant('dataset.export.duplicate.destination'), 'error', 4000);
  }

  private shouldAbortForDuplicateDestination(context: SaveContext): boolean {
    if (this.editingExportId()) {
      return false;
    }
    if (!this.hasDuplicateDestination(context)) {
      return false;
    }
    this.notifyDuplicateDestination();
    return true;
  }

  save() {
    const saveContext = this.buildSaveContext();
    if (!saveContext) {
      return;
    }

    if (this.shouldAbortForDuplicateDestination(saveContext)) {
      return;
    }

    const editId = this.editingExportId();
    const exportCreate = this.buildExportCreatePayload(saveContext);

    if (editId) {
      this.datasetConnectorService
        .updateExportDatasetFull(editId, {
          connectorEntity: exportCreate.connectorEntity,
          exportType: exportCreate.exportType,
          exportKey: exportCreate.exportKey,
          datasetConnectorParams: exportCreate.datasetConnectorParams,
        })
        .subscribe(() => this.onSavedExport.emit());
    } else {
      this.datasetConnectorService.addExportDataset(exportCreate).subscribe(() => this.onSavedExport.emit());
    }
  }

  onHidden() {
    this.onHiddenExport.emit();
  }
}
