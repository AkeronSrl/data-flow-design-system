import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { DatasetExportType } from '@alkyra/dataset/models/dataset-connector-export.model';
import { FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';

import { ExportWizardStore } from '../+store/export-wizard.store';
import { ExportDbMappingWizardStepComponent } from '../export-db-mapping-step/export-db-mapping-wizard-step.component';
import { ExportFlowContext } from '../flow-steps/export-flow-context.model';
import { ExportDbConfigComponent } from './export-db-config.component';

@Component({
  selector: 'alk-export-db-config-wizard-step',
  standalone: true,
  imports: [TiaraSuiteWizardStepComponent, TranslatePipe, ExportDbConfigComponent],
  templateUrl: './export-db-config-wizard-step.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportDbConfigWizardStepComponent extends FlowWizardStep<ExportFlowContext> {
  static readonly stepId = 'config-db';
  static readonly candidates: readonly FlowWizardStepClass<ExportFlowContext>[] = [ExportDbMappingWizardStepComponent];

  private readonly _store = inject(ExportWizardStore);
  private readonly _translateService = inject(TranslateService);

  readonly databaseConnectors = computed(() => this._store.databaseConnectors());
  readonly destinationDb = computed(() => this._store.destinationDb());
  readonly exportType = computed(() => this._store.exportType());
  readonly columnsList = computed(() => this._store.columnsList());
  readonly columnsSelected = computed(() => this._store.columnsSelected());
  readonly exportTypeOptions = computed(() =>
    this._store.activeExportTypeOptions().map((option) => ({
      value: option.value,
      description: this._translateService.instant(option.descriptionKey),
    })),
  );

  override canGoforward = computed(() => this._store.destinationKind() === 'db' && this._store.isActiveConfigValid());

  override onBackward(): void {
    this._store.setExportType(null);
    this._store.setColumnsSelected([]);
    this._store.setDbTableName('');
  }

  onTypeChanged(type: DatasetExportType): void {
    this._store.setExportType(type);
  }

  onColumnsChanged(columns: string[]): void {
    this._store.setColumnsSelected(columns);
  }

  onDbTableNameChanged(value: string): void {
    this._store.setDbTableName(value);
  }
}
