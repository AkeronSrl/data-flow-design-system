import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import { Connector } from '@alkyra/connector/models/connector.model';
import { DatasetColumn } from '@alkyra/dataset/models/dataset-column.model';
import { DatasetExportType } from '@alkyra/dataset/models/dataset-connector-export.model';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, input, output } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTagBoxModule } from 'devextreme-angular/ui/tag-box';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxValidatorModule } from 'devextreme-angular/ui/validator';

import { buildExportColumnOptions } from '../utils/export-column-option.utils';

@Component({
  selector: 'alk-export-db-config',
  standalone: true,
  imports: [
    CommonModule,
    DxSelectBoxModule,
    DxTagBoxModule,
    DxTextBoxModule,
    DxValidatorModule,
    TranslatePipe,
    TiaraNameDescriptionLabelComponent,
  ],
  templateUrl: './export-db-config.component.html',
  styleUrl: './export-db-config.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportDbConfigComponent {
  databaseConnectors = input<Connector[]>([]);
  destinationDb = input<{ tableName: string; sourceId: string }>({ tableName: '', sourceId: '' });
  exportTypeOptions = input<{ value: DatasetExportType; description: string }[]>([]);
  exportType = input<DatasetExportType | null>(null);
  columnsList = input<DatasetColumn[]>([]);
  columnsSelected = input<string[]>([]);

  typeChanged = output<DatasetExportType>();
  columnsChanged = output<string[]>();
  dbTableChanged = output<string>();

  readonly requiresKeyColumns = computed(() => {
    const type = this.exportType();
    return type === DatasetExportType.INSERT_UPDATE || type === DatasetExportType.DELETE_INSERT;
  });

  readonly columnsKeyLabel = computed(() =>
    this.exportType() === DatasetExportType.DELETE_INSERT ? 'columns.for.delete' : 'columns.for.update',
  );
  readonly exportColumnOptions = computed(() => buildExportColumnOptions(this.columnsList()));

  onTypeChanged(type: DatasetExportType): void {
    this.typeChanged.emit(type);
  }

  onColumnsChanged(columns: string[]): void {
    this.columnsChanged.emit(columns);
  }

  onDbTableNameChanged(value: string): void {
    this.dbTableChanged.emit(value ?? '');
  }
}
