import { TiaraSectionPanelComponent } from '@akeron-ng/tiara-ng/tiara-section-panel';
import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { ConnectorMetadataColumn } from '@alkyra/connector/models/connector-metadata-column.model';
import { DatabaseSourceMetadata } from '@alkyra/database-connector/models/database-source-metadata.model';
import { DatabaseConnectorService } from '@alkyra/database-connector/services/database-connector.service';
import { DatasetExportType } from '@alkyra/dataset/models/dataset-connector-export.model';
import { FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { VariableMappingComponent } from '@alkyra/ui/variable-mapping/variable-mapping.component';
import { MappingVariable } from '@alkyra/ui/variable-mapping/variable-mapping.model';
import { ChangeDetectionStrategy, Component, computed, effect, inject, signal, viewChild } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { catchError, map, of, switchMap } from 'rxjs';

import { ExportWizardStore } from '../+store/export-wizard.store';
import { ExportFlowContext } from '../flow-steps/export-flow-context.model';

type DbMappingCase = 'existing-table' | 'new-table' | null;
type MappingResolutionResult = {
  mappingCase: DbMappingCase;
  rightVariables: MappingVariable[];
  requiredRightVariables?: MappingVariable[];
  hasError?: boolean;
};

@Component({
  selector: 'alk-export-db-mapping-wizard-step',
  standalone: true,
  imports: [TiaraSuiteWizardStepComponent, TranslatePipe, TiaraSectionPanelComponent, VariableMappingComponent],
  templateUrl: './export-db-mapping-wizard-step.component.html',
  styleUrl: './export-db-mapping-wizard-step.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportDbMappingWizardStepComponent extends FlowWizardStep<ExportFlowContext> {
  static readonly stepId = 'config-db-mapping';
  static readonly candidates: readonly FlowWizardStepClass<ExportFlowContext>[] = [];

  private readonly _store = inject(ExportWizardStore);
  private readonly _databaseConnectorService = inject(DatabaseConnectorService);

  private readonly _lastRequestKey = signal('');
  private readonly _requestId = signal(0);

  readonly mappingComponent = viewChild(VariableMappingComponent);

  readonly isLoading = signal(false);
  readonly loadError = signal(false);
  readonly mappingCase = signal<DbMappingCase>(null);
  readonly rightVariables = signal<MappingVariable[]>([]);
  readonly requiredRightVariables = signal<MappingVariable[]>([]);

  readonly leftVariables = computed<MappingVariable[]>(() => {
    const names = new Set<string>();
    const result: MappingVariable[] = [];

    for (const column of this._store.columnsList()) {
      const name = (column.alias?.trim() || column.name?.trim()) ?? '';
      if (!name || names.has(name)) {
        continue;
      }
      names.add(name);
      result.push({ name });
    }

    return result;
  });

  readonly mappingCaseMessageKey = computed(() => {
    if (this.mappingCase() === 'existing-table') {
      return 'export.db.mapping.case.existing';
    }
    if (this.mappingCase() === 'new-table') {
      return 'export.db.mapping.case.new';
    }
    return 'export.db.mapping.case.unknown';
  });

  readonly textEditEnabled = computed(() => this.mappingCase() === 'new-table');

  override canGoforward = computed(() => {
    const mappingComponent = this.mappingComponent();
    return (
      this._store.destinationKind() === 'db' &&
      !this.isLoading() &&
      !this.loadError() &&
      this.leftVariables().length > 0 &&
      this.rightVariables().length > 0 &&
      !!mappingComponent &&
      mappingComponent.isValid()
    );
  });

  constructor() {
    super();

    effect(() => {
      if (this.mappingCase() !== 'new-table') {
        return;
      }

      this.rightVariables.set(this.leftVariables());
    });

    effect(() => {
      if (this._store.destinationKind() !== 'db') {
        this.resetStepState();
        return;
      }

      const { sourceId, tableName } = this._store.destinationDb();
      const exportType = this._store.exportType();
      const normalizedSourceId = sourceId.trim();
      const normalizedTableName = tableName.trim();
      const requestKey = `${normalizedSourceId}::${normalizedTableName}::${exportType ?? ''}`;

      if (!normalizedSourceId || !normalizedTableName) {
        this.resetStepState();
        return;
      }

      if (requestKey === this._lastRequestKey()) {
        return;
      }

      this._lastRequestKey.set(requestKey);

      if (exportType === DatasetExportType.DROP) {
        this.isLoading.set(false);
        this.loadError.set(false);
        this.mappingCase.set('new-table');
        this.requiredRightVariables.set([]);
        this.rightVariables.set(this.leftVariables());
        return;
      }

      this.loadDbMappingVariables(normalizedSourceId, normalizedTableName);
    });
  }

  override onForward(): void {
    const mappings = this.mappingComponent()?.getMappedVariables() ?? { mappedVariables: [] };
    this._store.setDbVariableMappings(mappings);
  }

  override onBackward(): void {
    this._store.resetDbVariableMappings();
  }

  private loadDbMappingVariables(sourceId: string, tableName: string): void {
    const nextRequestId = this._requestId() + 1;
    this._requestId.set(nextRequestId);
    this.isLoading.set(true);
    this.loadError.set(false);
    this.mappingCase.set(null);
    this.requiredRightVariables.set([]);
    this.rightVariables.set([]);

    this._databaseConnectorService
      .getMetadata(sourceId)
      .pipe(
        map((metadata) => this.tableExists(metadata, tableName)),
        switchMap((exists) => {
          if (!exists) {
            return of<MappingResolutionResult>({
              mappingCase: 'new-table',
              rightVariables: this.leftVariables(),
            });
          }

          return this._databaseConnectorService.columns(sourceId, tableName).pipe(
            map((columns) => ({
              mappingCase: 'existing-table' as const,
              rightVariables: this.toMappingVariables(columns),
              requiredRightVariables: this.toRequiredMappingVariables(columns),
            })),
          );
        }),
        catchError(() => {
          return of<MappingResolutionResult>({
            mappingCase: null,
            rightVariables: [],
            hasError: true,
          });
        }),
      )
      .subscribe((result) => {
        if (nextRequestId !== this._requestId()) {
          return;
        }

        this.isLoading.set(false);

        if ('hasError' in result && result.hasError) {
          this.mappingCase.set(null);
          this.rightVariables.set([]);
          this.requiredRightVariables.set([]);
          this.loadError.set(true);
          return;
        }

        this.mappingCase.set(result.mappingCase);
        this.rightVariables.set(result.rightVariables);
        this.requiredRightVariables.set(result.requiredRightVariables ?? []);
      });
  }

  private tableExists(metadata: DatabaseSourceMetadata[], tableName: string): boolean {
    const normalizedTableName = tableName.trim();
    return metadata.some((item) => item.tableName?.trim() === normalizedTableName);
  }

  private toMappingVariables(columns: ConnectorMetadataColumn[]): MappingVariable[] {
    return this.buildUniqueMappingVariables(columns, () => true);
  }

  private toRequiredMappingVariables(columns: ConnectorMetadataColumn[]): MappingVariable[] {
    return this.buildUniqueMappingVariables(columns, (column) => column.nullable === false);
  }

  private buildUniqueMappingVariables(
    columns: ConnectorMetadataColumn[],
    includeColumnPredicate: (column: ConnectorMetadataColumn) => boolean,
  ): MappingVariable[] {
    const names = new Set<string>();
    const variables: MappingVariable[] = [];

    for (const column of columns) {
      const name = column.columnName?.trim();
      const nameAlreadyPresent = !name || names.has(name);
      if (nameAlreadyPresent || !includeColumnPredicate(column)) {
        continue;
      }
      names.add(name);
      variables.push({ name });
    }

    return variables;
  }

  private resetStepState(): void {
    this.isLoading.set(false);
    this.loadError.set(false);
    this.mappingCase.set(null);
    this.rightVariables.set([]);
    this.requiredRightVariables.set([]);
    this._lastRequestKey.set('');
  }
}
