import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { ExportType } from '@alkyra/pipeline/models/pipeline.model';
import { FlowResolveResult, FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';

import { ExportWizardStore } from '../+store/export-wizard.store';
import { ExportAzureConnectionWizardStepComponent } from '../export-connection-selector-step/export-azure-connection/export-azure-connection-wizard-step.component';
import { ExportBusinessCentralConnectionWizardStepComponent } from '../export-connection-selector-step/export-business-central-connection/export-business-central-connection-wizard-step.component';
import { ExportDbConnectionWizardStepComponent } from '../export-connection-selector-step/export-db-connection/export-db-connection-wizard-step.component';
import { ExportRestApiConnectionWizardStepComponent } from '../export-connection-selector-step/export-rest-api-connection/export-rest-api-connection-wizard-step.component';
import { ExportS3ConnectionWizardStepComponent } from '../export-connection-selector-step/export-s3-connection/export-s3-connection-wizard-step.component';
import { ExportVulkiConnectionWizardStepComponent } from '../export-connection-selector-step/export-vulki-connection/export-vulki-connection-wizard-step.component';
import { ExportFlowContext } from '../flow-steps/export-flow-context.model';
import { ExportDestinationComponent } from './export-destination.component';

@Component({
  selector: 'alk-export-destination-wizard-step',
  standalone: true,
  imports: [TiaraSuiteWizardStepComponent, TranslatePipe, ExportDestinationComponent],
  templateUrl: './export-destination-wizard-step.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportDestinationWizardStepComponent extends FlowWizardStep<ExportFlowContext> {
  static readonly stepId = 'destination';
  static readonly candidates: readonly FlowWizardStepClass<ExportFlowContext>[] = [
    ExportDbConnectionWizardStepComponent,
    ExportS3ConnectionWizardStepComponent,
    ExportAzureConnectionWizardStepComponent,
    ExportRestApiConnectionWizardStepComponent,
    ExportVulkiConnectionWizardStepComponent,
    ExportBusinessCentralConnectionWizardStepComponent,
  ];

  private readonly _translateService = inject(TranslateService);
  private readonly _store = inject(ExportWizardStore);

  readonly exportDestinations = computed(() => [
    {
      value: ExportType.DB,
      text: this._translateService.instant('pipeline.export.db'),
    },
    {
      value: ExportType.S3,
      text: this._translateService.instant('pipeline.export.s3'),
    },
    {
      value: ExportType.AZURE_BLOB,
      text: this._translateService.instant('pipeline.export.azure.blob'),
    },
    {
      value: ExportType.REST_API,
      text: this._translateService.instant('pipeline.export.rest.api'),
    },
    {
      value: ExportType.VULKI,
      text: this._translateService.instant('Vulki'),
    },
    {
      value: ExportType.BUSINESS_CENTRAL,
      text: this._translateService.instant('pipeline.export.business.central'),
    },
  ]);

  readonly selectedDestination = computed(() => this._store.selectedDestination());

  override canGoforward = computed(() => this._store.selectedDestination() !== null);

  override resolveNext(
    _context: ExportFlowContext,
    candidates: readonly FlowWizardStepClass<ExportFlowContext>[],
  ): FlowResolveResult<ExportFlowContext> {
    const destination = this._store.selectedDestination();
    if (destination === null) {
      return { kind: 'pending' };
    }

    const next =
      destination === ExportType.DB
        ? ExportDbConnectionWizardStepComponent
        : destination === ExportType.S3
          ? ExportS3ConnectionWizardStepComponent
          : destination === ExportType.AZURE_BLOB
            ? ExportAzureConnectionWizardStepComponent
            : destination === ExportType.REST_API
              ? ExportRestApiConnectionWizardStepComponent
              : destination === ExportType.BUSINESS_CENTRAL
                ? ExportBusinessCentralConnectionWizardStepComponent
                : ExportVulkiConnectionWizardStepComponent;

    if (!candidates.some((candidate) => candidate === next)) {
      return { kind: 'pending' };
    }

    return { kind: 'next', next };
  }

  onDestinationSelected(destination: ExportType): void {
    this._store.setSelectedDestination(destination);
  }
}
