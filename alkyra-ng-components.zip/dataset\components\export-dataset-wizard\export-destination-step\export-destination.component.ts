import {
  OptionButtonItem,
  TiaraSuiteOptionButtonSelectionComponent,
} from '@akeron-ng/tiara-ng-suite/tiara-option-button';
import { ExportType } from '@alkyra/pipeline/models/pipeline.model';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';

@Component({
  selector: 'alk-export-destination',
  standalone: true,
  imports: [CommonModule, TiaraSuiteOptionButtonSelectionComponent],
  templateUrl: './export-destination.component.html',
  styleUrl: './export-destination.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportDestinationComponent {
  exportDestinations = input<{ value: ExportType; text: string }[]>([]);
  selectedDestination = input<ExportType | null>(null);
  selected = output<ExportType>();

  get options(): OptionButtonItem[] {
    return (this.exportDestinations() ?? []).map((destination) => ({
      title: destination.text,
      subtitle: '',
      icon: '',
      imgAlt: destination.text,
      imgSource: this.getImageSource(destination.value),
      isSelected: this.selectedDestination() === destination.value,
      onSelect: () => {
        this.selected.emit(destination.value);
      },
      onDeselect: () => undefined,
    }));
  }

  private getImageSource(source: ExportType): string {
    switch (source) {
      case ExportType.DB:
        return 'assets/db-icon/database-db-icon.png';
      case ExportType.S3:
        return 'assets/cloud-icon/s3.png';
      case ExportType.AZURE_BLOB:
        return 'assets/cloud-icon/azure.png';
      case ExportType.REST_API:
        return 'assets/cloud-icon/rest-api.png';
      case ExportType.VULKI:
        return 'assets/vulki/logos/logo.png';
      case ExportType.BUSINESS_CENTRAL:
        return 'assets/cloud-icon/business-central.png';
      default:
        return '';
    }
  }
}
