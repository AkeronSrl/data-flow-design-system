import { TiaraSectionPanelComponent } from '@akeron-ng/tiara-ng/tiara-section-panel';
import { DatasetColumn } from '@alkyra/dataset/models/dataset-column.model';
import { MessagePathSelectorComponent } from '@alkyra/pipeline/components/message-path-selector/message-path-selector.component';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { DxAccordionModule } from 'devextreme-angular/ui/accordion';
import { DxNumberBoxModule } from 'devextreme-angular/ui/number-box';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxTooltipModule } from 'devextreme-angular/ui/tooltip';

import { RestApiBulkConfig, RestApiDestinationDetails } from '../+store/export-wizard.state';
import { ConfigMapItemComponent } from '../export-config-step/config-map-item/config-map-item.component';
import { buildExportColumnOptions } from '../utils/export-column-option.utils';

type RestApiRequestType = 'SINGLE_ROW' | 'BULK';
type RestApiBodyMappingField = {
  key: string;
  field: {
    name: string;
    required: false;
    tipo: '';
  };
};
type RestApiBodyMappingGroup = {
  id: string;
  title: string | null;
  fields: RestApiBodyMappingField[];
};

const TREE_LEAF_MARKER = '__leaf';

@Component({
  selector: 'alk-export-rest-api-body',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    DxAccordionModule,
    DxNumberBoxModule,
    DxSelectBoxModule,
    DxTextBoxModule,
    DxTooltipModule,
    TiaraSectionPanelComponent,
    ConfigMapItemComponent,
    MessagePathSelectorComponent,
  ],
  templateUrl: './export-rest-api-body.component.html',
  styleUrl: './export-rest-api-body.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportRestApiBodyComponent {
  private readonly _translateService = inject(TranslateService);

  destinationRestApi = input<RestApiDestinationDetails>({
    sourceId: '',
    operationMethod: '',
    operationPath: '',
    operationSummary: '',
    operationDescription: '',
    bodyFields: [],
    parameters: [],
    fieldMappings: {},
    pathParamMappings: {},
    queryParamMappings: {},
    headerMappings: {},
    sampleJson: '',
    jsonSchema: '',
    bulkConfig: {
      enabled: false,
      batchSize: 100,
      payloadShape: 'ROOT_ARRAY',
      arrayFieldPath: '',
      correlationField: '',
      responseErrorItemsPath: '',
      responseErrorCorrelationPath: '',
    },
  });
  columnsList = input<DatasetColumn[]>([]);

  fieldMappingChanged = output<{ fieldName: string; value: string }>();
  pathParamChanged = output<{ paramName: string; value: string }>();
  queryParamChanged = output<{ paramName: string; value: string }>();
  headerParamChanged = output<{ paramName: string; value: string }>();
  bulkConfigChanged = output<RestApiBulkConfig>();

  readonly advancedSettingsSelectedIndex = signal(-1);
  readonly requestTypeOptions = [
    { value: 'SINGLE_ROW' as const, labelKey: 'export.rest.api.bulk.request.type.single.row' },
    { value: 'BULK' as const, labelKey: 'export.rest.api.bulk.request.type.bulk' },
  ];
  readonly responseErrorItemsPathOptions = ['errors', 'items', 'results', 'data.errors', 'response.errors'];
  readonly responseErrorCorrelationPathOptions = ['id', 'externalId', 'correlationId', 'item.id', 'item.externalId'];
  readonly translatedOptionDisplayExpr = (item: { labelKey: string } | null): string =>
    item ? this._translateService.instant(item.labelKey) : '';
  readonly displayExportDataNodeValue = (value: string | any[]): string => {
    const path = Array.isArray(value) ? (value[0] ?? '') : value;
    return formatRootPath(path);
  };

  readonly exportColumnOptions = computed(() => buildExportColumnOptions(this.columnsList()));
  readonly bulkConfig = computed(() => this.destinationRestApi().bulkConfig);
  readonly requestType = computed<RestApiRequestType>(() => (this.bulkConfig().enabled ? 'BULK' : 'SINGLE_ROW'));
  readonly exportDataNodePath = computed(() => {
    const bulkConfig = this.bulkConfig();
    return bulkConfig.payloadShape === 'OBJECT_ARRAY_FIELD' ? normalizeRestApiPath(bulkConfig.arrayFieldPath) : '';
  });
  readonly exportDataNodeTree = computed(() => {
    const details = this.destinationRestApi();
    return buildRestApiDataNodeTree(details.bodyFields, details.sampleJson, details.jsonSchema);
  });
  readonly mappingGroups = computed(() =>
    buildRestApiMappingGroups(this.destinationRestApi().bodyFields, this.exportDataNodePath()),
  );
  readonly pathParameters = computed(() =>
    this.destinationRestApi()
      .parameters.filter((parameter) => parameter.location === 'path')
      .map((parameter) => ({
        name: parameter.name,
        required: parameter.required,
        tipo: parameter.type ?? 'path',
        description: parameter.description,
      })),
  );
  readonly queryParameters = computed(() =>
    this.destinationRestApi()
      .parameters.filter((parameter) => parameter.location === 'query')
      .map((parameter) => ({
        name: parameter.name,
        required: parameter.required,
        tipo: parameter.type ?? 'query',
        description: parameter.description,
      })),
  );
  readonly headerParameters = computed(() =>
    this.destinationRestApi()
      .parameters.filter((parameter) => parameter.location === 'header')
      .map((parameter) => ({
        name: parameter.name,
        required: parameter.required,
        tipo: parameter.type ?? 'header',
        description: parameter.description,
      })),
  );
  readonly hasMappingFields = computed(() => this.mappingGroups().some((group) => group.fields.length > 0));
  readonly hasAdvancedFields = computed(
    () => this.pathParameters().length > 0 || this.queryParameters().length > 0 || this.headerParameters().length > 0,
  );
  readonly hasRequiredAdvancedFields = computed(() =>
    [...this.pathParameters(), ...this.queryParameters(), ...this.headerParameters()].some(
      (parameter) => parameter.required,
    ),
  );
  readonly operationSignature = computed(() => {
    const details = this.destinationRestApi();
    const params = details.parameters
      .map((parameter) => `${parameter.location}:${parameter.name}:${parameter.required ? '1' : '0'}`)
      .sort()
      .join('|');
    return `${details.operationMethod}|${details.operationPath}|${params}`;
  });
  private readonly _lastOperationSignature = signal('');

  constructor() {
    effect(() => {
      const signature = this.operationSignature();
      const shouldOpenAdvancedSettings = this.hasRequiredAdvancedFields() || this.bulkConfig().enabled;
      if (signature === this._lastOperationSignature()) {
        return;
      }

      this._lastOperationSignature.set(signature);
      this.advancedSettingsSelectedIndex.set(shouldOpenAdvancedSettings ? 0 : -1);
    });
  }

  onAdvancedSettingsSelectionChanged(event: any): void {
    const selectedIndex = typeof event?.component?.option === 'function' ? event.component.option('selectedIndex') : -1;
    this.advancedSettingsSelectedIndex.set(typeof selectedIndex === 'number' ? selectedIndex : -1);
  }

  onRequestTypeChanged(value: RestApiRequestType | string | null | undefined): void {
    this.patchBulkConfig({ enabled: value === 'BULK' });
  }

  onBulkBatchSizeChanged(value: number | null | undefined): void {
    const numericValue = typeof value === 'number' ? value : Number(value);
    const batchSize = Number.isFinite(numericValue) && numericValue > 0 ? Math.trunc(numericValue) : 100;
    this.patchBulkConfig({ batchSize });
  }

  onExportDataNodeSelected(value: string | string[] | null | undefined): void {
    const selectedPath = normalizeRestApiPath(Array.isArray(value) ? value[0] : value);
    if (!selectedPath) {
      this.patchBulkConfig({ payloadShape: 'ROOT_ARRAY', arrayFieldPath: '' });
      return;
    }
    this.patchBulkConfig({ payloadShape: 'OBJECT_ARRAY_FIELD', arrayFieldPath: selectedPath });
  }

  onBulkCorrelationFieldChanged(value: string | null | undefined): void {
    this.patchBulkConfig({ correlationField: value ?? '' });
  }

  onBulkResponseErrorItemsPathChanged(value: string | null | undefined): void {
    this.patchBulkConfig({ responseErrorItemsPath: value ?? '' });
  }

  onBulkResponseErrorCorrelationPathChanged(value: string | null | undefined): void {
    this.patchBulkConfig({ responseErrorCorrelationPath: value ?? '' });
  }

  onCustomPathCreating(event: { text?: string; customItem?: string }): void {
    event.customItem = event.text?.trim() ?? '';
  }

  private patchBulkConfig(update: Partial<RestApiBulkConfig>): void {
    this.bulkConfigChanged.emit({
      ...this.bulkConfig(),
      ...update,
    });
  }
}

function buildRestApiMappingGroups(fields: string[], dataNodePath: string): RestApiBodyMappingGroup[] {
  const uniqueFields = normalizeFieldList(fields);
  const visibleFields = uniqueFields.filter((field) => !isComplexField(field, uniqueFields));
  const normalizedDataNodePath = normalizeRestApiPath(dataNodePath);

  if (!normalizedDataNodePath) {
    return [
      {
        id: 'root',
        title: null,
        fields: visibleFields.map((field) => createMappingField(field, field)),
      },
    ].filter((group) => group.fields.length > 0);
  }

  const rootFields = visibleFields
    .filter((field) => !isFieldUnderDataNode(field, normalizedDataNodePath))
    .map((field) => createMappingField(field, field));
  const dataNodeFields = visibleFields
    .filter((field) => isFieldUnderDataNode(field, normalizedDataNodePath))
    .map((field) => createMappingField(field, stripDataNodePrefix(field, normalizedDataNodePath)))
    .filter((field) => !!field.field.name);

  return [
    { id: 'root', title: null, fields: rootFields },
    { id: `data-node:${normalizedDataNodePath}`, title: normalizedDataNodePath, fields: dataNodeFields },
  ].filter((group) => group.fields.length > 0);
}

function createMappingField(key: string, displayName: string): RestApiBodyMappingField {
  return {
    key,
    field: {
      name: displayName,
      required: false,
      tipo: '',
    },
  };
}

function normalizeFieldList(fields: string[]): string[] {
  return Array.from(new Set(fields.map((field) => field.trim()).filter(Boolean)));
}

function isComplexField(field: string, allFields: string[]): boolean {
  const normalizedField = normalizeRestApiPath(field);
  return allFields.some((candidate) => {
    if (candidate === field) {
      return false;
    }
    return normalizeRestApiPath(candidate).startsWith(`${normalizedField}.`);
  });
}

function isFieldUnderDataNode(field: string, dataNodePath: string): boolean {
  const normalizedField = normalizeRestApiPath(field);
  return normalizedField.startsWith(`${dataNodePath}.`);
}

function stripDataNodePrefix(field: string, dataNodePath: string): string {
  const normalizedField = normalizeRestApiPath(field);
  return normalizedField.startsWith(`${dataNodePath}.`)
    ? normalizedField.slice(dataNodePath.length + 1)
    : normalizedField;
}

function buildRestApiDataNodeTree(bodyFields: string[], sampleJson: string, jsonSchema: string): Record<string, any> {
  const treeFromFields = buildTreeFromFieldPaths(bodyFields);
  if (Object.keys(treeFromFields).length > 0) {
    return treeFromFields;
  }

  const treeFromSample = buildTreeFromSample(safeJsonParse(sampleJson));
  if (Object.keys(treeFromSample).length > 0) {
    return treeFromSample;
  }

  return buildTreeFromSchema(safeJsonParse(jsonSchema)) ?? {};
}

function buildTreeFromFieldPaths(fields: string[]): Record<string, any> {
  return normalizeFieldList(fields).reduce<Record<string, any>>((tree, field) => {
    appendPathToTree(tree, normalizeRestApiPath(field));
    return tree;
  }, {});
}

function appendPathToTree(tree: Record<string, any>, path: string): void {
  const segments = path.split('.').filter(Boolean);
  if (!segments.length) {
    return;
  }

  let cursor = tree;
  segments.forEach((segment, index) => {
    const isLastSegment = index === segments.length - 1;
    if (isLastSegment) {
      if (!isTreeNode(cursor[segment]) || isLeafTreeNode(cursor[segment])) {
        cursor[segment] = { [TREE_LEAF_MARKER]: true };
      }
      return;
    }

    if (!isTreeNode(cursor[segment]) || isLeafTreeNode(cursor[segment])) {
      cursor[segment] = {};
    }
    cursor = cursor[segment];
  });
}

function buildTreeFromSample(sample: unknown): Record<string, any> {
  if (!sample) {
    return {};
  }

  if (Array.isArray(sample)) {
    return buildTreeFromSample(sample[0]);
  }

  if (typeof sample === 'object') {
    return Object.entries(sample as Record<string, unknown>).reduce<Record<string, any>>((tree, [key, value]) => {
      const normalizedKey = key.trim();
      if (normalizedKey) {
        tree[normalizedKey] = buildTreeFromSample(value);
      }
      return tree;
    }, {});
  }

  return { [TREE_LEAF_MARKER]: true };
}

function buildTreeFromSchema(schema: unknown): Record<string, any> | null {
  if (!isTreeNode(schema)) {
    return null;
  }

  if (schema['type'] === 'array') {
    return buildTreeFromSchema(schema['items']) ?? {};
  }

  const compositeTree = mergeSchemaTrees(
    ['allOf', 'anyOf', 'oneOf'].flatMap((key) => buildCompositeSchemaTrees(schema[key])),
  );
  const properties = isTreeNode(schema['properties']) ? schema['properties'] : null;
  if (!properties) {
    return Object.keys(compositeTree).length > 0 ? compositeTree : { [TREE_LEAF_MARKER]: true };
  }

  const propertyTree = Object.entries(properties).reduce<Record<string, any>>((tree, [key, value]) => {
    const normalizedKey = key.trim();
    if (normalizedKey) {
      tree[normalizedKey] = buildTreeFromSchema(value) ?? { [TREE_LEAF_MARKER]: true };
    }
    return tree;
  }, {});

  return mergeSchemaTrees([compositeTree, propertyTree]);
}

function buildCompositeSchemaTrees(value: unknown): Record<string, any>[] {
  if (!Array.isArray(value)) {
    return [];
  }
  return value.map((item) => buildTreeFromSchema(item)).filter((tree): tree is Record<string, any> => !!tree);
}

function mergeSchemaTrees(trees: Record<string, any>[]): Record<string, any> {
  return trees.reduce<Record<string, any>>((merged, tree) => {
    Object.entries(tree).forEach(([key, value]) => {
      if (isTreeNode(merged[key]) && isTreeNode(value) && !isLeafTreeNode(merged[key]) && !isLeafTreeNode(value)) {
        merged[key] = mergeSchemaTrees([merged[key], value]);
        return;
      }
      merged[key] = value;
    });
    return merged;
  }, {});
}

function normalizeRestApiPath(value: unknown): string {
  if (typeof value !== 'string') {
    return '';
  }

  let path = value.trim();
  if (path.startsWith('$.')) {
    path = path.slice(2);
  } else if (path.startsWith('$')) {
    path = path.slice(1);
  }

  return path
    .replace(/\[\]/g, '')
    .split('.')
    .map((segment) => segment.trim())
    .filter(Boolean)
    .join('.');
}

function formatRootPath(value: unknown): string {
  const path = normalizeRestApiPath(value);
  return path ? `$.${path}` : '';
}

function safeJsonParse(value: string): unknown {
  if (!value?.trim()) {
    return null;
  }

  try {
    return JSON.parse(value);
  } catch {
    return null;
  }
}

function isTreeNode(value: unknown): value is Record<string, any> {
  return !!value && typeof value === 'object' && !Array.isArray(value);
}

function isLeafTreeNode(value: unknown): boolean {
  return isTreeNode(value) && Object.keys(value).every((key) => key === TREE_LEAF_MARKER);
}
