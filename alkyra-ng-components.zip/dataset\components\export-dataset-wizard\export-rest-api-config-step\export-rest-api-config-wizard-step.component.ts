import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';

import { ExportWizardStore } from '../+store/export-wizard.store';
import { ExportRestApiBodyWizardStepComponent } from '../export-rest-api-body-step/export-rest-api-body-wizard-step.component';
import { ExportFlowContext } from '../flow-steps/export-flow-context.model';
import { ExportRestApiConfigComponent } from './export-rest-api-config.component';

type WebApiKind = 'restApi' | 'businessCentral';
const WEB_API_KINDS = new Set<string>(['restApi', 'businessCentral']);

@Component({
  selector: 'alk-export-rest-api-config-wizard-step',
  standalone: true,
  imports: [TiaraSuiteWizardStepComponent, TranslatePipe, ExportRestApiConfigComponent],
  templateUrl: './export-rest-api-config-wizard-step.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportRestApiConfigWizardStepComponent extends FlowWizardStep<ExportFlowContext> {
  static readonly stepId = 'config-rest-api';
  static readonly candidates: readonly FlowWizardStepClass<ExportFlowContext>[] = [
    ExportRestApiBodyWizardStepComponent,
  ];

  private readonly _store = inject(ExportWizardStore);

  private readonly _kind = computed(() => this._store.destinationKind() as WebApiKind);

  readonly destinationRestApi = computed(() =>
    this._kind() === 'businessCentral' ? this._store.destinationBusinessCentral() : this._store.destinationRestApi(),
  );
  readonly columnsList = computed(() => this._store.columnsList());

  override canGoforward = computed(
    () => WEB_API_KINDS.has(this._store.destinationKind()) && this._store.isActiveConfigValid(),
  );

  onPathParamChanged(event: { paramName: string; value: string }): void {
    if (this._kind() === 'businessCentral') {
      this._store.setBusinessCentralPathParamMapping(event.paramName, event.value);
    } else {
      this._store.setRestApiPathParamMapping(event.paramName, event.value);
    }
  }

  onQueryParamChanged(event: { paramName: string; value: string }): void {
    if (this._kind() === 'businessCentral') {
      this._store.setBusinessCentralQueryParamMapping(event.paramName, event.value);
    } else {
      this._store.setRestApiQueryParamMapping(event.paramName, event.value);
    }
  }

  onHeaderParamChanged(event: { paramName: string; value: string }): void {
    if (this._kind() === 'businessCentral') {
      this._store.setBusinessCentralHeaderMapping(event.paramName, event.value);
    } else {
      this._store.setRestApiHeaderMapping(event.paramName, event.value);
    }
  }
}
