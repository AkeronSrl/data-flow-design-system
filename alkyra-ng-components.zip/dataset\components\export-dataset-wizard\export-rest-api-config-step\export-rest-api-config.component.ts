import { TiaraSectionPanelComponent } from '@akeron-ng/tiara-ng/tiara-section-panel';
import { DatasetColumn } from '@alkyra/dataset/models/dataset-column.model';
import { RestApiConnectorService } from '@alkyra/rest-api-connector/services/rest-api-connector.service';
import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  effect,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TranslatePipe } from '@ngx-translate/core';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';

import { RestApiDestinationDetails } from '../+store/export-wizard.state';
import { ConfigMapItemComponent } from '../export-config-step/config-map-item/config-map-item.component';
import { buildExportColumnOptions } from '../utils/export-column-option.utils';

@Component({
  selector: 'alk-export-rest-api-config',
  standalone: true,
  imports: [CommonModule, TranslatePipe, DxTextBoxModule, TiaraSectionPanelComponent, ConfigMapItemComponent],
  templateUrl: './export-rest-api-config.component.html',
  styleUrl: './export-rest-api-config.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportRestApiConfigComponent {
  private readonly _restApiConnectorService = inject(RestApiConnectorService);
  private readonly _destroyRef = inject(DestroyRef);

  destinationRestApi = input<RestApiDestinationDetails>({
    sourceId: '',
    operationMethod: '',
    operationPath: '',
    operationSummary: '',
    operationDescription: '',
    bodyFields: [],
    parameters: [],
    fieldMappings: {},
    pathParamMappings: {},
    queryParamMappings: {},
    headerMappings: {},
    sampleJson: '',
    jsonSchema: '',
    bulkConfig: {
      enabled: false,
      batchSize: 100,
      payloadShape: 'ROOT_ARRAY',
      arrayFieldPath: '',
      correlationField: '',
      responseErrorItemsPath: '',
      responseErrorCorrelationPath: '',
    },
  });
  columnsList = input<DatasetColumn[]>([]);

  pathParamChanged = output<{ paramName: string; value: string }>();
  queryParamChanged = output<{ paramName: string; value: string }>();
  headerParamChanged = output<{ paramName: string; value: string }>();

  readonly activeTab = signal<'params' | 'headers'>('params');
  readonly connectorEndpoint = signal('');
  readonly exportColumnOptions = computed(() => buildExportColumnOptions(this.columnsList()));

  readonly urlPreview = computed(() => {
    const details = this.destinationRestApi();
    const endpoint = this.connectorEndpoint().trim();
    const queryString = details.parameters
      .filter((parameter) => parameter.location === 'query')
      .map((parameter) => `${parameter.name}={${parameter.name}}`)
      .join('&');

    const method = (details.operationMethod || 'POST').toUpperCase();
    const baseUrl = this.joinUrl(endpoint, details.operationPath || '');
    const fullUrl = queryString ? `${baseUrl}?${queryString}` : baseUrl;
    return { method, fullUrl };
  });

  readonly pathParameters = computed(() =>
    this.destinationRestApi()
      .parameters.filter((parameter) => parameter.location === 'path')
      .map((parameter) => ({
        name: parameter.name,
        required: parameter.required,
        tipo: parameter.type ?? 'path',
        description: parameter.description,
      })),
  );

  readonly queryParameters = computed(() =>
    this.destinationRestApi()
      .parameters.filter((parameter) => parameter.location === 'query')
      .map((parameter) => ({
        name: parameter.name,
        required: parameter.required,
        tipo: parameter.type ?? 'query',
      })),
  );

  readonly headerParameters = computed(() =>
    this.destinationRestApi()
      .parameters.filter((parameter) => parameter.location === 'header')
      .map((parameter) => ({
        name: parameter.name,
        required: parameter.required,
        tipo: parameter.type ?? 'header',
      })),
  );

  readonly hasParams = computed(() => this.pathParameters().length > 0 || this.queryParameters().length > 0);

  constructor() {
    effect(() => {
      const sourceId = this.destinationRestApi().sourceId;
      if (!sourceId) {
        this.connectorEndpoint.set('');
        return;
      }

      this._restApiConnectorService
        .findConnector(sourceId)
        .pipe(takeUntilDestroyed(this._destroyRef))
        .subscribe({
          next: (connector) => {
            if (this.destinationRestApi().sourceId === sourceId) {
              this.connectorEndpoint.set(connector.endpoint ?? '');
            }
          },
          error: () => {
            if (this.destinationRestApi().sourceId === sourceId) {
              this.connectorEndpoint.set('');
            }
          },
        });
    });
  }

  setActiveTab(tab: 'params' | 'headers'): void {
    this.activeTab.set(tab);
  }

  private joinUrl(endpoint: string, path: string): string {
    if (!endpoint) {
      return path;
    }

    if (!path) {
      return endpoint;
    }

    const normalizedEndpoint = endpoint.replace(/\/+$/, '');
    const normalizedPath = path.startsWith('/') ? path : `/${path}`;
    return `${normalizedEndpoint}${normalizedPath}`;
  }
}
