import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { CloudFileType } from '@alkyra/dataset/components/dataset-wizard/models/cloud-file-type.model';
import { DatasetExportType } from '@alkyra/dataset/models/dataset-connector-export.model';
import { FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';

import { ExportWizardStore } from '../+store/export-wizard.store';
import { ExportFlowContext } from '../flow-steps/export-flow-context.model';
import { ExportS3ConfigComponent } from './export-s3-config.component';

@Component({
  selector: 'alk-export-s3-config-wizard-step',
  standalone: true,
  imports: [TiaraSuiteWizardStepComponent, TranslatePipe, ExportS3ConfigComponent],
  templateUrl: './export-s3-config-wizard-step.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportS3ConfigWizardStepComponent extends FlowWizardStep<ExportFlowContext> {
  static readonly stepId = 'config-s3';
  static readonly candidates: readonly FlowWizardStepClass<ExportFlowContext>[] = [];

  private readonly _store = inject(ExportWizardStore);
  private readonly _translateService = inject(TranslateService);

  readonly fileNameNoDotsPattern = /^[^.]+$/;

  readonly s3Connectors = computed(() => this._store.s3Connectors());
  readonly azureConnectors = computed(() => this._store.azureConnectors());
  readonly destinationS3 = computed(() =>
    this._store.destinationKind() === 'azure' ? this._store.destinationAzure() : this._store.destinationS3(),
  );
  readonly exportType = computed(() => this._store.exportType());
  readonly columnsList = computed(() => this._store.columnsList());
  readonly columnsSelected = computed(() => this._store.columnsSelected());
  readonly isAzure = computed(() => this._store.destinationKind() === 'azure');
  readonly fileTypeOptions = computed(() => [
    {
      value: 'CSV' as CloudFileType,
      description: this._translateService.instant('pipeline.export.cloud.filetype.csv'),
    },
    {
      value: 'EXCEL' as CloudFileType,
      description: this._translateService.instant('pipeline.export.cloud.filetype.excel'),
    },
  ]);
  readonly exportTypeOptions = computed(() =>
    this._store.activeExportTypeOptions().map((option) => ({
      value: option.value,
      description: this._translateService.instant(option.descriptionKey),
    })),
  );

  override canGoforward = computed(
    () =>
      (this._store.destinationKind() === 's3' || this._store.destinationKind() === 'azure') &&
      this._store.isActiveConfigValid(),
  );

  override onBackward(): void {
    this._store.setExportType(null);
    this._store.setColumnsSelected([]);
    // Do NOT reset fileName, fileType, sheetName: they may have been populated
    // from tree selection and must survive back/forward navigation (NAU-374).
  }

  onTypeChanged(type: DatasetExportType): void {
    this._store.setExportType(type);
  }

  onColumnsChanged(columns: string[]): void {
    this._store.setColumnsSelected(columns);
  }

  onS3FileNameChanged(value: string): void {
    this._store.setCloudFileName(value);
  }

  onFileTypeChanged(value: CloudFileType | null): void {
    this._store.setCloudFileType(value);
  }

  onSheetNameChanged(value: string | null): void {
    this._store.setCloudSheetName(value?.trim() || null);
  }
}
