import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import { Connector, ConnectorType } from '@alkyra/connector/models/connector.model';
import { CloudFileRequest } from '@alkyra/dataset/components/dataset-wizard/models/cloud-file-request.model';
import { CloudFileType } from '@alkyra/dataset/components/dataset-wizard/models/cloud-file-type.model';
import { DatasetColumn } from '@alkyra/dataset/models/dataset-column.model';
import { DatasetExportType } from '@alkyra/dataset/models/dataset-connector-export.model';
import { ExcelConnectorService } from '@alkyra/excel-connector/services/excel-connector.service';
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectionStrategy, Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTagBoxModule } from 'devextreme-angular/ui/tag-box';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxValidatorModule } from 'devextreme-angular/ui/validator';
import { catchError, of } from 'rxjs';

import { composeCloudConnectorEntity } from '../utils/cloud-export-path.utils';
import { buildExportColumnOptions } from '../utils/export-column-option.utils';

@Component({
  selector: 'alk-export-s3-config',
  standalone: true,
  imports: [
    CommonModule,
    DxSelectBoxModule,
    DxTagBoxModule,
    DxTextBoxModule,
    DxValidatorModule,
    TranslatePipe,
    TiaraNameDescriptionLabelComponent,
  ],
  templateUrl: './export-s3-config.component.html',
  styleUrl: './export-s3-config.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportS3ConfigComponent {
  private readonly _excelConnectorService = inject(ExcelConnectorService);
  private readonly _translateService = inject(TranslateService);

  s3Connectors = input<Connector[]>([]);
  azureConnectors = input<Connector[]>([]);
  isAzure = input<boolean>(false);
  destinationS3 = input<{
    fileName: string;
    sourceId: string;
    fileType: CloudFileType | null;
    sheetName: string | null;
    directoryPath: string;
    selectedItemPath: string | null;
    selectedItemKind: 'folder' | 'file' | null;
  }>({
    fileName: '',
    sourceId: '',
    fileType: null,
    sheetName: null,
    directoryPath: '',
    selectedItemPath: null,
    selectedItemKind: null,
  });
  exportTypeOptions = input<{ value: DatasetExportType; description: string }[]>([]);
  fileTypeOptions = input<{ value: CloudFileType; description: string }[]>([]);
  exportType = input<DatasetExportType | null>(null);
  columnsList = input<DatasetColumn[]>([]);
  columnsSelected = input<string[]>([]);
  fileNameNoDotsPattern = input<RegExp>(/^[^.]+$/);

  typeChanged = output<DatasetExportType>();
  columnsChanged = output<string[]>();
  s3FileChanged = output<string>();
  fileTypeChanged = output<CloudFileType | null>();
  sheetNameChanged = output<string | null>();

  sheets = signal<string[]>([]);

  readonly requiresKeyColumns = computed(() => {
    const type = this.exportType();
    return type === DatasetExportType.INSERT_UPDATE || type === DatasetExportType.DELETE_INSERT;
  });
  readonly isExcel = computed(() => this.destinationS3().fileType === 'EXCEL');
  readonly connectorOptions = computed(() => (this.isAzure() ? this.azureConnectors() : this.s3Connectors()));
  readonly connectorLabel = computed(() => (this.isAzure() ? 'datasource.azure.blob' : 'pipeline.export.s3'));
  readonly columnsKeyLabel = computed(() =>
    this.exportType() === DatasetExportType.DELETE_INSERT ? 'columns.for.delete' : 'columns.for.update',
  );
  readonly exportColumnOptions = computed(() => buildExportColumnOptions(this.columnsList()));

  readonly _loadAvailableSheets = effect((onCleanup) => {
    const { fileType, sourceId, fileName, sheetName, directoryPath } = this.destinationS3();
    if (fileType !== 'EXCEL' || !sourceId || !fileName.trim()) {
      this.sheets.set([]);
      return;
    }

    const subscription = this._excelConnectorService
      .cloudSheets(this.buildCloudSheetRequest({ fileName, sourceId, fileType, sheetName, directoryPath }))
      .pipe(
        catchError((error: HttpErrorResponse) => {
          this.sheets.set([]);
          if (error.status === 404) {
            if (!sheetName?.trim()) {
              this.sheetNameChanged.emit(this.defaultSheetName());
            }
            return of<string[] | null>(null);
          }

          return of<string[] | null>(null);
        }),
      )
      .subscribe((sheets) => {
        if (!sheets) {
          return;
        }

        this.sheets.set(sheets);
      });

    onCleanup(() => subscription.unsubscribe());
  });

  onTypeChanged(type: DatasetExportType): void {
    this.typeChanged.emit(type);
  }

  onColumnsChanged(columns: string[]): void {
    this.columnsChanged.emit(columns);
  }

  onS3FileNameChanged(value: string): void {
    this.s3FileChanged.emit(value ?? '');
  }

  onFileTypeChanged(value: CloudFileType | null): void {
    this.fileTypeChanged.emit(value);
  }

  onSheetNameChanged(value: string | null): void {
    this.sheetNameChanged.emit(value?.trim() || null);
  }

  onSheetCustomItemCreating(event: any): void {
    event.customItem = event.text;
  }

  private defaultSheetName(): string {
    return this._translateService.instant('pipeline.export.cloud.sheet.default');
  }

  private buildCloudSheetRequest(destination: {
    fileName: string;
    sourceId: string;
    fileType: CloudFileType | null;
    sheetName: string | null;
    directoryPath: string;
  }): CloudFileRequest {
    return {
      connectorId: destination.sourceId,
      filePath: `${composeCloudConnectorEntity(destination.directoryPath, destination.fileName)}.xlsx`,
      fileType: ConnectorType.EXCEL,
      hasHeader: true,
      sheetName: destination.sheetName,
    };
  }
}
