import { TiaraSuiteWizardStepComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { DatasetExportType } from '@alkyra/dataset/models/dataset-connector-export.model';
import { PipelineType } from '@alkyra/pipeline/models/pipeline.model';
import { FlowWizardStep, FlowWizardStepClass } from '@alkyra/ui/flow-wizard/models/flow-wizard-step';
import { VulkiConnectorService } from '@alkyra/vulki-connector/services/vulki-connector.service';
import { ChangeDetectionStrategy, Component, computed, DestroyRef, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { EMPTY, switchMap } from 'rxjs';

import { SqsStepStore } from '../../dataset-wizard/+store/sqs-step.store';
import { ExportWizardStore } from '../+store/export-wizard.store';
import { ExportFlowContext } from '../flow-steps/export-flow-context.model';
import { ExportVulkiConfigComponent } from './export-vulki-config.component';

@Component({
  selector: 'alk-export-vulki-config-wizard-step',
  standalone: true,
  imports: [TiaraSuiteWizardStepComponent, TranslatePipe, ExportVulkiConfigComponent],
  templateUrl: './export-vulki-config-wizard-step.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportVulkiConfigWizardStepComponent extends FlowWizardStep<ExportFlowContext> {
  static readonly stepId = 'config-vulki';
  static readonly candidates: readonly FlowWizardStepClass<ExportFlowContext>[] = [];

  private readonly _store = inject(ExportWizardStore);
  private readonly _translateService = inject(TranslateService);
  private readonly _sqsStore = inject(SqsStepStore);
  private readonly _vulkiConnectorService = inject(VulkiConnectorService);
  private readonly _destroyRef = inject(DestroyRef);

  readonly exportType = computed(() => this._store.exportType());
  readonly columnsList = computed(() => this._store.columnsList());
  readonly destinationVulki = computed(() => this._store.destinationVulki());
  readonly exportTypeOptions = computed(() =>
    this._store.activeExportTypeOptions().map((option) => ({
      value: option.strategyValue ?? option.value,
      description: option.strategyValue
        ? option.strategyValue.toLowerCase()
        : this._translateService.instant(option.descriptionKey),
      strategyValue: option.strategyValue,
    })),
  );

  readonly dlqConnectors = computed(() =>
    this._store.connectors().filter((connector) => connector.connectorType === ConnectorType.AMAZON_SQS),
  );

  readonly isQueue = computed(() => this._sqsStore.selectedPipeline()?.pipelineType === PipelineType.QUEUE);

  override canGoforward = computed(
    () =>
      this._store.destinationKind() === 'vulki' &&
      this._store.isActiveConfigValid() &&
      this._store.isVulkiFieldMappingValid(),
  );

  override onBackward(): void {
    this._store.setColumnsSelected([]);

    const currentDestination = this._store.destinationVulki();
    this._store.setVulkiDetails({
      name: currentDestination.name,
      version: currentDestination.version,
      fields: currentDestination.fields,
      path: currentDestination.path,
      serviceName: currentDestination.serviceName,
      connectionKind: currentDestination.connectionKind,
      tagKind: currentDestination.tagKind,
      dataloaderColumns: currentDestination.dataloaderColumns,
      dataloaderSupportedStrategies: currentDestination.dataloaderSupportedStrategies,
    });
  }

  onTypeChanged(value: string): void {
    const details = this._store.destinationVulki();

    if (details.tagKind === 'bulk') {
      this._store.setExportType(DatasetExportType.DATALOADER);
      this._store.setVulkiDataloaderStrategy(value);
      return;
    }

    const type = value as DatasetExportType;
    this._store.setExportType(type);

    if (type === DatasetExportType.INSERT || type === DatasetExportType.INSERT_UPDATE) {
      this.fetchDataloaderDiscovery();
    } else {
      this._store.setVulkiDataloaderColumns([]);
      this._store.setVulkiDataloaderSupportedStrategies([]);
      this._store.setVulkiDataloaderStrategy('');
    }
  }

  onFieldMappingChanged(event: { fieldName: string; value: string }): void {
    this._store.setVulkiFieldMapping(event.fieldName, event.value);
  }

  onDlqChanged(connectorId: string): void {
    this._store.setVulkiDlqConnectorId(connectorId);
  }

  private fetchDataloaderDiscovery(): void {
    const details = this._store.destinationVulki();
    const sourceId = details.sourceId;
    if (!sourceId || !details.dataloaderDefinitionId) {
      return;
    }

    this._vulkiConnectorService
      .findConnector(sourceId)
      .pipe(
        switchMap((connector) =>
          connector
            ? this._vulkiConnectorService.dataloaderDiscovery(connector, details.dataloaderDefinitionId)
            : EMPTY,
        ),
        takeUntilDestroyed(this._destroyRef),
      )
      .subscribe({
        next: (response) => this.applyDiscoveryDefinition(response?.definitions?.[0]),
        error: () => {
          this._store.setVulkiDataloaderColumns([]);
          this._store.setVulkiDataloaderSupportedStrategies([]);
        },
      });
  }

  private applyDiscoveryDefinition(definition: any): void {
    const firstEntity = definition?.entities?.[0];
    this._store.setVulkiDataloaderColumns(firstEntity?.columns ?? []);
    this._store.setVulkiDataloaderSupportedStrategies(definition?.supportedStrategies ?? []);
  }
}
