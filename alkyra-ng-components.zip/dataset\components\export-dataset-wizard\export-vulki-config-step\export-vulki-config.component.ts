import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import { TiaraSectionPanelComponent } from '@akeron-ng/tiara-ng/tiara-section-panel';
import { Connector } from '@alkyra/connector/models/connector.model';
import { DatasetColumn } from '@alkyra/dataset/models/dataset-column.model';
import { DatasetExportType } from '@alkyra/dataset/models/dataset-connector-export.model';
import { DataloaderColumn } from '@alkyra/vulki-connector/models/dataloader-discovery.model';
import { VulkiField } from '@alkyra/vulki-connector/models/vulki-connector.model';
import {
  resolveDataloaderColumnLabel,
  resolveDataloaderColumnType,
} from '@alkyra/vulki-connector/utils/dataloader.utils';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject, input, output, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { DxAutocompleteModule } from 'devextreme-angular/ui/autocomplete';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxValidatorModule } from 'devextreme-angular/ui/validator';

import { VulkiDestinationDetails } from '../+store/export-wizard.state';
import { ConfigMapItemComponent } from '../export-config-step/config-map-item/config-map-item.component';
import { buildExportColumnOptions } from '../utils/export-column-option.utils';

@Component({
  selector: 'alk-export-vulki-config',
  standalone: true,
  imports: [
    CommonModule,
    DxAutocompleteModule,
    DxSelectBoxModule,
    DxTextBoxModule,
    DxValidatorModule,
    TranslatePipe,
    TiaraNameDescriptionLabelComponent,
    TiaraSectionPanelComponent,
    ConfigMapItemComponent,
  ],
  templateUrl: './export-vulki-config.component.html',
  styleUrl: './export-vulki-config.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportVulkiConfigComponent {
  private readonly _translateService = inject(TranslateService);

  exportTypeOptions = input<{ value: string; description: string; strategyValue?: string }[]>([]);
  exportType = input<DatasetExportType | null>(null);
  columnsList = input<DatasetColumn[]>([]);
  destinationVulki = input<VulkiDestinationDetails>({
    version: '',
    sourceId: '',
    name: '',
    fields: [],
    fieldMappings: {},
    pathParamMappings: {},
    dlqConnectorId: '',
    path: '',
    nullableObjects: {},
    hasDataloader: false,
    dataloaderDefinitionId: '',
    dataloaderColumns: [],
    connectorTenant: '',
    dataloaderStrategy: '',
    dataloaderSupportedStrategies: [],
    serviceName: '',
    connectionKind: 'legacy',
    tagKind: undefined,
  });
  isQueue = input<boolean>(false);
  dlqConnectors = input<Connector[]>([]);

  typeChanged = output<string>();
  fieldMappingChanged = output<{ fieldName: string; value: string }>();
  dlqChanged = output<string>();

  searchValue = signal<string>('');

  readonly isBulkInsert = computed(() => this.destinationVulki().tagKind === 'bulk');
  readonly hasTenant = computed(() => !!this.destinationVulki().connectorTenant?.trim());

  readonly selectedExportOption = computed(() => {
    if (this.isBulkInsert()) {
      return this.destinationVulki().dataloaderStrategy || '';
    }
    return this.exportType() ?? '';
  });

  readonly fields = computed(() => {
    if (this.isBulkInsert()) {
      return this.buildFieldsFromDataloaderColumns();
    }
    const dataloaderColumns = this.destinationVulki().dataloaderColumns || [];
    if (dataloaderColumns.length > 0) {
      return this.buildMergedFields(dataloaderColumns);
    }
    return this.buildFieldsWithDbId();
  });

  readonly fieldMappings = computed(() => this.destinationVulki().fieldMappings || {});
  readonly dlqConnectorId = computed(() => this.destinationVulki().dlqConnectorId || '');
  readonly exportColumnOptions = computed(() => buildExportColumnOptions(this.columnsList()));

  readonly filteredFields = computed(() => {
    const search = this.searchValue().toLowerCase().trim();
    if (!search) {
      return this.fields();
    }
    return this.fields().filter(
      (field) => field.name.toLowerCase().includes(search) || (field.description ?? '').toLowerCase().includes(search),
    );
  });

  onTypeChanged(value: string): void {
    this.typeChanged.emit(value);
  }

  onFieldChanged(event: { fieldName: string; value: string }): void {
    this.fieldMappingChanged.emit(event);
  }

  searchValueChanged(event: any): void {
    this.searchValue.set(event.value ?? '');
  }

  onDlqChanged(event: any): void {
    this.dlqChanged.emit(event.value || '');
  }

  private buildFieldsWithDbId(): VulkiField[] {
    const baseFields = this.destinationVulki().fields || [];
    if (this.hasTenant()) {
      return baseFields;
    }
    const dbIdField: VulkiField = { name: 'DbId', tipo: 'string', required: true };
    return [dbIdField, ...baseFields];
  }

  private buildFieldsFromDataloaderColumns(): VulkiField[] {
    const columns = this.destinationVulki().dataloaderColumns || [];
    const lang = this._translateService.currentLang || 'en';
    const fields: VulkiField[] = [];

    if (!this.hasTenant()) {
      fields.push({ name: 'DbId', tipo: 'string', required: true });
    }

    for (const col of columns) {
      fields.push({
        name: col.name,
        tipo: resolveDataloaderColumnType(col),
        required: col.required,
        description: resolveDataloaderColumnLabel(col, lang),
      });
    }
    return fields;
  }

  private buildMergedFields(dataloaderColumns: DataloaderColumn[]): VulkiField[] {
    const baseFields = this.buildFieldsWithDbId();
    const lang = this._translateService.currentLang || 'en';
    const columnMap = new Map(dataloaderColumns.map((col) => [col.name, col]));
    const visitedColumnNames = new Set<string>();

    const mergedFields = baseFields.map((field) => {
      const col = columnMap.get(field.name);
      if (!col) return field;
      visitedColumnNames.add(field.name);
      return {
        ...field,
        tipo: resolveDataloaderColumnType(col),
        required: col.required || field.required,
        description: resolveDataloaderColumnLabel(col, lang),
      };
    });

    for (const col of dataloaderColumns) {
      if (visitedColumnNames.has(col.name)) continue;
      mergedFields.push({
        name: col.name,
        tipo: resolveDataloaderColumnType(col),
        required: col.required,
        description: resolveDataloaderColumnLabel(col, lang),
      });
    }

    return mergedFields;
  }
}
