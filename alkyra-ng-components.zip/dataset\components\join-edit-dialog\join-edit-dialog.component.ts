import { Dataset } from '@alkyra/dataset/models/dataset.model';
import { DatasetColumn } from '@alkyra/dataset/models/dataset-column.model';
import { DatasetJoinUpdate } from '@alkyra/dataset/models/dataset-join.model';
import { DatasetJoinService } from '@alkyra/dataset/services/dataset-join.service';
import { Id } from '@alkyra/shared-models/id.model';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  effect,
  inject,
  input,
  output,
  signal,
  ViewChild,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TranslatePipe } from '@ngx-translate/core';
import notify from 'devextreme/ui/notify';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxPopupModule } from 'devextreme-angular/ui/popup';

import { filterOutRightJoinColumns } from '../join-wizard/join-column-filter';
import {
  JoinColumnSelectorCoreComponent,
  JoinColumnSelectorData,
} from '../join-wizard/join-column-selector/join-column-selector-core.component';
import {
  JoinKeysMappingCoreComponent,
  JoinKeysMappingData,
  KeyMapping,
} from '../join-wizard/join-keys-mapping/join-keys-mapping-core.component';

/**
 * Edit Join Configuration Dialog (NAU-241/NAU-242)
 *
 * Allows modification of existing join datasets:
 * - Join columns (key mappings)
 * - Output columns (visible columns)
 *
 * Note: Join type cannot be modified after creation.
 * Uses standalone core components for direct integration without wizard dependencies.
 */
@Component({
  selector: 'alk-join-edit-dialog',
  templateUrl: './join-edit-dialog.component.html',
  styleUrl: './join-edit-dialog.component.scss',
  standalone: true,
  imports: [
    DxPopupModule,
    DxButtonModule,
    JoinKeysMappingCoreComponent,
    JoinColumnSelectorCoreComponent,
    TranslatePipe,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class JoinEditDialogComponent {
  private readonly _datasetJoinService = inject(DatasetJoinService);
  private readonly _destroyRef = inject(DestroyRef);

  // Inputs
  visible = input.required<boolean>();
  dataset = input.required<Dataset | null>();
  leftDataset = input.required<Dataset | null>();
  rightDataset = input.required<Dataset | null>();
  editMode = input<'mappings' | 'columns'>('mappings'); // Default to mappings
  joinType = input<string>('INNER'); // Join type from store

  // Outputs
  saved = output<Id>();
  closed = output<void>();

  // Component refs
  @ViewChild(JoinKeysMappingCoreComponent) keysMappingComponent?: JoinKeysMappingCoreComponent;
  @ViewChild(JoinColumnSelectorCoreComponent) columnSelectorComponent?: JoinColumnSelectorCoreComponent;

  // Internal state (join type is read-only, set from existing dataset)
  readonly currentJoinType = signal<string>('INNER');
  currentKeyMappings = signal<KeyMapping[]>([]);
  currentColumns = signal<DatasetColumn[]>([]);
  private initialEditColumns = signal<DatasetColumn[]>([]); // Set once from BE, not updated by columnsChanged
  private joinDetailsLoaded = signal(false);
  isSaving = signal(false);
  isColumnSelectorValid = signal(false);
  currentFilterExpression = signal<string>('');

  /** Popup opens only after join details are loaded — prevents double-open animation */
  readonly dialogVisible = computed(() => this.visible() && this.joinDetailsLoaded());

  // Data for core components
  keysMappingData = computed((): JoinKeysMappingData | null => {
    const leftDs = this.leftDataset();
    const rightDs = this.rightDataset();

    if (!leftDs?.id || !rightDs?.id) return null;

    return {
      leftDatasetId: leftDs.id,
      rightDatasetId: rightDs.id,
      initialMappings: this.currentKeyMappings(),
    };
  });

  columnSelectorData = computed((): JoinColumnSelectorData | null => {
    const leftDs = this.leftDataset();
    const rightDs = this.rightDataset();

    if (!leftDs || !rightDs || !this.joinDetailsLoaded()) return null;

    return {
      datasetId: this.dataset()?.id,
      leftDataset: {
        id: leftDs.id,
        name: leftDs.name,
        type: leftDs.type,
      },
      rightDataset: {
        id: rightDs.id,
        name: rightDs.name,
        type: rightDs.type,
      },
      keysMapping: this.currentKeyMappings(),
      joinType: this.currentJoinType(),
      initialColumns: this.initialEditColumns(), // Set once from BE, not re-fed by columnsChanged
    };
  });

  // Computed validation
  isValid = computed(() => {
    const hasValidMappings = this.currentKeyMappings().length > 0;

    // In 'mappings' mode, only validate key mappings
    if (this.editMode() === 'mappings') {
      return hasValidMappings;
    }

    // In 'columns' mode, validate both mappings and column selector
    return hasValidMappings && this.isColumnSelectorValid();
  });

  // Computed display flags
  showMappings = computed(() => this.editMode() === 'mappings');
  showColumns = computed(() => this.editMode() === 'columns');

  constructor() {
    // Auto-initialize when dataset changes and dialog becomes visible
    effect(() => {
      const dataset = this.dataset();
      const isVisible = this.visible();

      if (isVisible && dataset) {
        this.joinDetailsLoaded.set(false);
        // Fetch join details from backend to get join columns (mappings) and output columns
        this._datasetJoinService
          .getJoinDetails(dataset.id)
          .pipe(takeUntilDestroyed(this._destroyRef))
          .subscribe((joinDetails) => {
            this.initializeFromDataset(
              joinDetails.joinType,
              joinDetails.joinColumns,
              joinDetails.outputColumns || [], // Use outputColumns from BE (the configured output columns)
              joinDetails.filterExpression,
            );
          });
      } else if (!isVisible) {
        this.joinDetailsLoaded.set(false);
      }
    });
  }

  /**
   * Initialize dialog with existing join configuration.
   * Call this from parent when opening the dialog.
   */
  initializeFromDataset(
    currentJoinType: string,
    currentJoinColumns: { columnLeft: DatasetColumn; columnRight: DatasetColumn }[],
    currentOutputColumns: DatasetColumn[],
    filterExpression?: string,
  ): void {
    this.currentJoinType.set(currentJoinType);

    const mappings: KeyMapping[] = currentJoinColumns.map((jc) => ({
      fromColumn: jc.columnLeft,
      joinedColumn: jc.columnRight,
    }));
    this.currentKeyMappings.set(mappings);
    this.initialEditColumns.set([...currentOutputColumns]);
    this.currentColumns.set([...currentOutputColumns]);
    this.currentFilterExpression.set(filterExpression || '');
    this.joinDetailsLoaded.set(true);
  }

  onKeyMappingsChanged(mappings: KeyMapping[]): void {
    console.log('Dialog received mappings changed:', { count: mappings.length, isValidBefore: this.isValid() });
    this.currentKeyMappings.set(mappings);
    console.log('Dialog valid after mappings change:', this.isValid());
  }

  onColumnsChanged(columns: DatasetColumn[]): void {
    this.currentColumns.set(columns);
  }

  onColumnValidationChanged(isValid: boolean): void {
    this.isColumnSelectorValid.set(isValid);
  }

  onFilterExpressionChanged(filterExpression: string): void {
    this.currentFilterExpression.set(filterExpression);
  }

  save(): void {
    if (!this.isValid()) {
      notify('Please fill all required fields', 'error', 3000);
      return;
    }

    const datasetId = this.dataset()?.id;
    if (!datasetId) {
      notify('Dataset ID not found', 'error', 3000);
      return;
    }

    const updateDto = this.buildUpdateDto();
    this.isSaving.set(true);
    this._datasetJoinService.updateComplexDataset(datasetId, updateDto).subscribe({
      next: (id: Id) => {
        this.isSaving.set(false);
        notify('Join configuration updated successfully', 'success', 3000);
        this.saved.emit(id);
      },
      error: (error) => {
        this.isSaving.set(false);
        const message = error?.error?.message || 'Failed to update join configuration';
        notify(message, 'error', 5000);
      },
    });
  }

  private buildUpdateDto(): DatasetJoinUpdate {
    const rightDatasetId = this.rightDataset()?.id;
    const selectedColumns = this.columnSelectorComponent?.getSelectedColumns();
    const filteredColumns = selectedColumns
      ? selectedColumns
      : filterOutRightJoinColumns(this.currentColumns(), this.currentKeyMappings(), rightDatasetId);
    const filterExpression =
      this.columnSelectorComponent?.getFilterExpression() || this.currentFilterExpression() || undefined;

    return {
      joinType: this.currentJoinType(),
      joinColumns: this.currentKeyMappings().map((mapping) => ({
        columnLeft: mapping.fromColumn,
        columnRight: mapping.joinedColumn,
      })),
      columns: filteredColumns,
      filterExpression,
    };
  }

  cancel(): void {
    this.closed.emit();
  }
}
