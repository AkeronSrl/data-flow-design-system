import { TiaraCollapsableContainerComponent } from '@akeron-ng/tiara-ng/tiara-collapsable-container';
import { TiaraSectionPanelComponent } from '@akeron-ng/tiara-ng/tiara-section-panel';
import { DatasetType } from '@alkyra/dataset/models/dataset.model';
import { DatasetColumn, DatasetColumnType } from '@alkyra/dataset/models/dataset-column.model';
import { DatasetJoinPreview } from '@alkyra/dataset/models/dataset-join.model';
import { DatasetService } from '@alkyra/dataset/services/dataset.service';
import { DatasetColumnFormulaService } from '@alkyra/dataset/services/dataset-column-formula.service';
import {
  ExpressionEditorConfig,
  ExpressionValidationState,
} from '@alkyra/ui/smart-expression-editor/models/expression-editor.model';
import { SmartExpressionEditorComponent } from '@alkyra/ui/smart-expression-editor/smart-expression-editor.component';
import { ValidationResult } from '@alkyra/validation/models/validation-result.model';
import { CommonModule } from '@angular/common';
import {
  Component,
  computed,
  effect,
  inject,
  input,
  output,
  QueryList,
  signal,
  ViewChild,
  ViewChildren,
} from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import CustomStore from 'devextreme/data/custom_store';
import { alert } from 'devextreme/ui/dialog';
import { ItemReorderedEvent } from 'devextreme/ui/list';
import notify from 'devextreme/ui/notify';
import { SelectionChangedEvent } from 'devextreme/ui/select_box';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxCheckBoxModule } from 'devextreme-angular/ui/check-box';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxListComponent, DxListModule } from 'devextreme-angular/ui/list';
import { DxScrollViewComponent, DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxSelectBoxComponent, DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { catchError, combineLatest, lastValueFrom, Observable, of, take, tap } from 'rxjs';
import { normalizeDatasetColumnAlias, resolveDatasetColumnOutputName } from '../../shared/dataset-column-alias.utils';
import { buildNormalizedJoinColumnsPayload, filterOutRightJoinColumns, JoinKeyMapping } from '../join-column-filter';
import {
  AvailableColumnItem,
  AvailableColumnItemMetadata,
  JoinCastSavedEvent,
  JoinChooserChangedEvent,
  JoinColumnSide,
  JoinPreviewAreaComponent,
} from './join-preview-area.component';

export interface ColumnListItem {
  itemId: string;
  column?: DatasetColumn;
  sourceSide?: ColumnSide;
  sourceDatasetName?: string;
  sourceColumnName?: string;
}

export interface JoinDatasetInfo {
  id: string;
  name?: string;
  type?: DatasetType;
}

interface ColumnMaps {
  byColumnId: Map<string, DatasetColumn>;
  byName: Map<string, DatasetColumn>;
  byAlias: Map<string, DatasetColumn>;
}

interface ColumnMappingContext {
  leftDataset: JoinDatasetInfo;
  rightDataset: JoinDatasetInfo;
  leftMaps: ColumnMaps;
  rightMaps: ColumnMaps;
}

type ColumnSide = JoinColumnSide;

type ColumnSourceMetadata = AvailableColumnItemMetadata;

interface SourceColumnCandidate {
  side: ColumnSide;
  column: DatasetColumn;
  score: number;
}

export interface JoinColumnSelectorData {
  datasetId?: string;
  leftDataset: JoinDatasetInfo;
  rightDataset: JoinDatasetInfo;
  keysMapping: Array<{
    fromColumn: DatasetColumn;
    joinedColumn: DatasetColumn;
  }>;
  joinType: string;
  initialColumns?: DatasetColumn[]; // Optional: for edit mode, pre-populate with existing columns
}

@Component({
  selector: 'alk-join-column-selector-core',
  standalone: true,
  imports: [
    CommonModule,
    TiaraCollapsableContainerComponent,
    TiaraSectionPanelComponent,
    TranslatePipe,
    DxListModule,
    DxDataGridModule,
    DxTextBoxModule,
    DxCheckBoxModule,
    DxButtonModule,
    DxSelectBoxModule,
    DxScrollViewModule,
    SmartExpressionEditorComponent,
    JoinPreviewAreaComponent,
  ],
  templateUrl: './join-column-selector-core.component.html',
  styleUrls: ['./join-column-selector.component.scss'],
})
export class JoinColumnSelectorCoreComponent {
  // Inputs
  data = input.required<JoinColumnSelectorData>();
  containerHeight = input<string>('100%'); // Allow customization, default to 100% for wizard
  initialFilterExpression = input<string>(''); // For edit mode: pre-populate filter expression

  // Outputs
  columnsChanged = output<DatasetColumn[]>();
  validationChanged = output<boolean>();
  filterExpressionChange = output<string>();

  // Services
  translateService: TranslateService = inject(TranslateService);
  private readonly _datasetService = inject(DatasetService);
  private readonly _formulaService = inject(DatasetColumnFormulaService);

  @ViewChildren(DxListComponent) dxLists!: QueryList<DxListComponent>;
  @ViewChild(DxScrollViewComponent) scrollView?: DxScrollViewComponent;
  @ViewChildren(DxSelectBoxComponent) selectBoxes!: QueryList<DxSelectBoxComponent>;

  allColumnsSelected = signal<ColumnListItem[]>([]);
  columnsRemovedAll = signal<AvailableColumnItem[]>([]);
  duplicateColumnsInList = signal<DatasetColumn[]>([]);
  filterExpression = signal<string>('');
  filterExpressionValid = signal<boolean>(true);
  private allAvailableColumns = signal<AvailableColumnItem[] | null>(null);
  filterExpressionValidationState = signal<ExpressionValidationState>('none');
  filterExpressionValidationMessage = signal<string>('');
  previewRows = signal<any[]>([]);
  private nextItemId = 0;

  private initialized = signal<boolean>(false);

  columnsSelected = computed((): DatasetColumn[] => {
    return this.allColumnsSelected()
      .filter((c) => c.column !== undefined)
      .map((c, index) => this.buildPayloadColumn(c, index));
  });

  isEditMode = computed(() => this.data().initialColumns !== undefined);

  previewValidated = signal<boolean>(false);

  previewData = signal<CustomStore>(
    new CustomStore({
      load: () => lastValueFrom(of([])),
    }),
  );

  readonly loadPreviewRowsFn = (cols: DatasetColumn[]): Observable<any[]> =>
    this._datasetService.datasetJoinPreview(this.buildPreviewRequest(cols));

  comboDisplayColumnName = (item: AvailableColumnItem | DatasetColumn | null | undefined) => {
    if (!item) {
      return '';
    }
    const isAvailItem = !!item && 'column' in item && 'metadata' in item;
    const column = isAvailItem ? (item as AvailableColumnItem).column : (item as DatasetColumn);
    const datasetName = isAvailItem
      ? ((item as AvailableColumnItem).metadata.sourceDatasetName ?? this.getSourceDatasetNameForColumn(column))
      : (this.getSourceDatasetNameForColumn(column) ?? column.displayName ?? '');
    return `${column.alias ?? column.name} (${datasetName})`;
  };

  getColumnLabel(column?: DatasetColumn): string {
    if (!column) {
      return '';
    }
    return resolveDatasetColumnOutputName(column.name, column.alias);
  }

  constructor() {
    effect(() => {
      const inputData = this.data();
      const leftDataset = inputData.leftDataset;
      const rightDataset = inputData.rightDataset;

      if (!leftDataset?.id || !rightDataset?.id) return;

      const initialColumns = inputData.initialColumns;
      if (initialColumns !== undefined) {
        this.initEditMode(initialColumns, leftDataset, rightDataset);
      } else {
        this.initWizardMode(inputData.keysMapping, leftDataset, rightDataset);
      }
    });

    effect(() => {
      const initial = this.initialFilterExpression();
      if (initial) {
        this.filterExpression.set(initial);
      }
    });
  }

  private initEditMode(
    initialColumns: DatasetColumn[],
    leftDataset: JoinDatasetInfo,
    rightDataset: JoinDatasetInfo,
  ): void {
    const filteredInitialColumns = this.excludeRightJoinKeys(initialColumns);
    const initialItems = filteredInitialColumns.map((col) => this.createItem(col));
    this.allColumnsSelected.set(initialItems);
    this.initialized.set(true);

    this.fetchDatasetColumns(leftDataset.id, rightDataset.id).subscribe(([leftCols, rightCols]) => {
      const context: ColumnMappingContext = {
        leftDataset,
        rightDataset,
        leftMaps: this.buildColumnMaps(leftCols),
        rightMaps: this.buildColumnMaps(rightCols),
      };
      this.allColumnsSelected.set(this.enrichItemsWithEditMetadata(this.allColumnsSelected(), context));
      this.setAllAvailableFromMapped(leftCols, rightCols, leftDataset, rightDataset);
      this.refreshAvailableColumns();
      this.availableColumnsLoaded.set(true);
    });
  }

  private initWizardMode(
    keysMapping: JoinColumnSelectorData['keysMapping'],
    leftDataset: JoinDatasetInfo,
    rightDataset: JoinDatasetInfo,
  ): void {
    if (this.initialized()) return;
    this.initialized.set(true);

    const uniqueKeyMappingColumns = this.getUniqueColumnsFromKeyMapping(keysMapping);
    this.fetchDatasetColumns(leftDataset.id, rightDataset.id).subscribe(([leftCols, rightCols]) => {
      const allCols = this.createAvailableColumnItems(leftCols, rightCols, leftDataset, rightDataset);
      this.allAvailableColumns.set(allCols);
      const finalColumns = this.mergeColumns(uniqueKeyMappingColumns, allCols);
      this.allColumnsSelected.set(finalColumns);
      this.refreshAvailableColumns();
    });
  }

  private fetchDatasetColumns(leftId: string, rightId: string) {
    return combineLatest([
      this._datasetService.getDatasetColumns(leftId),
      this._datasetService.getDatasetColumns(rightId),
    ]).pipe(take(1));
  }

  private createAvailableColumnItems(
    leftCols: DatasetColumn[],
    rightCols: DatasetColumn[],
    leftDataset: JoinDatasetInfo,
    rightDataset: JoinDatasetInfo,
  ): AvailableColumnItem[] {
    const allCols = [
      ...this.mapColumns(leftCols, 'left', leftDataset),
      ...this.mapColumns(rightCols, 'right', rightDataset),
    ];
    return this.excludeRightJoinKeyItems(allCols);
  }

  private setAllAvailableFromMapped(
    leftCols: DatasetColumn[],
    rightCols: DatasetColumn[],
    leftDataset: JoinDatasetInfo,
    rightDataset: JoinDatasetInfo,
  ): void {
    const allCols = this.createAvailableColumnItems(leftCols, rightCols, leftDataset, rightDataset);
    this.allAvailableColumns.set(allCols);
  }

  onFilterExpressionChanged(newValue: string): void {
    const normalized = newValue ?? '';
    this.filterExpression.set(normalized);
    this.filterExpressionValid.set(true);
    this.filterExpressionValidationState.set('none');
    this.filterExpressionValidationMessage.set('');
    this.previewValidated.set(false);
    this.validationChanged.emit(false);
    this.filterExpressionChange.emit(normalized);
  }

  onFilterExpressionFocusOut(): void {
    this.validateFilterExpression();
  }

  private validateFilterExpression(): void {
    const expression = this.filterExpression();
    if (!expression.trim()) {
      this.filterExpressionValid.set(true);
      this.filterExpressionValidationState.set('none');
      this.filterExpressionValidationMessage.set('');
      this.updateForwardValidityFromCurrentState();
      return;
    }
    const columns = this.columnsSelected().map((col) => col.alias || col.name);
    this._formulaService.validateFormula({ expression, columns }).subscribe((result: ValidationResult) => {
      const isValid = result.status !== 'error';
      this.filterExpressionValid.set(isValid);
      if (isValid) {
        this.filterExpressionValidationState.set('valid');
        this.filterExpressionValidationMessage.set('');
        this.updateForwardValidityFromCurrentState();
        return;
      }

      this.filterExpressionValidationState.set('invalid');
      this.filterExpressionValidationMessage.set(result.message ?? '');
      this.previewValidated.set(false);
      this.validationChanged.emit(false);
    });
  }

  validateFilterExpressionAsync = (params: any): Promise<{ isValid: boolean; message?: string }> => {
    const expression = params.value ?? '';
    if (!expression.trim()) {
      this.filterExpressionValid.set(true);
      this.filterExpressionValidationState.set('none');
      this.filterExpressionValidationMessage.set('');
      this.updateForwardValidityFromCurrentState();
      return Promise.resolve({ isValid: true });
    }
    const columns = this.columnsSelected().map((col) => col.alias || col.name);
    return lastValueFrom(this._formulaService.validateFormula({ expression, columns }))
      .then((res: any) => {
        if (res.status !== 'error') {
          this.filterExpressionValid.set(true);
          this.filterExpressionValidationState.set('valid');
          this.filterExpressionValidationMessage.set('');
          this.updateForwardValidityFromCurrentState();
          return { isValid: true };
        } else {
          this.filterExpressionValid.set(false);
          this.filterExpressionValidationState.set('invalid');
          this.filterExpressionValidationMessage.set(res.message ?? '');
          this.previewValidated.set(false);
          this.validationChanged.emit(false);
          return { isValid: false, message: res.message };
        }
      })
      .catch((error) => {
        this.filterExpressionValid.set(false);
        this.filterExpressionValidationState.set('invalid');
        this.filterExpressionValidationMessage.set(String(error ?? ''));
        this.previewValidated.set(false);
        this.validationChanged.emit(false);
        return { isValid: false, message: error };
      });
  };

  private mapColumns(columns: DatasetColumn[], source: ColumnSide, dataset: JoinDatasetInfo): AvailableColumnItem[] {
    return columns.map((column) => ({
      column: this.cloneDatasetColumn(column),
      metadata: {
        sourceSide: source,
        sourceDatasetName: dataset.name,
        sourceColumnName: column.name,
      },
    }));
  }

  private enrichItemsWithEditMetadata(items: ColumnListItem[], context: ColumnMappingContext): ColumnListItem[] {
    const sideUsage = new Map<string, { left: number; right: number }>();
    return items.map((item) => {
      if (!item.column) {
        return item;
      }
      const metadata = this.resolveSourceMetadataForEdit(item.column, context, sideUsage);
      return { ...item, ...metadata };
    });
  }

  private resolveSourceMetadataForEdit(
    column: DatasetColumn,
    context: ColumnMappingContext,
    sideUsage?: Map<string, { left: number; right: number }>,
  ): ColumnSourceMetadata {
    const source = this.resolveSourceColumn(column, context, sideUsage);
    if (!source) {
      return this.buildDefaultSourceMetadata(column);
    }
    const side =
      source.dataset?.id === context.leftDataset.id
        ? 'left'
        : source.dataset?.id === context.rightDataset.id
          ? 'right'
          : undefined;
    return {
      sourceSide: side,
      sourceDatasetName:
        side === 'left' ? context.leftDataset.name : side === 'right' ? context.rightDataset.name : undefined,
      sourceColumnName: source.name,
    };
  }

  private resolveSourceColumn(
    column: DatasetColumn,
    context: ColumnMappingContext,
    sideUsage?: Map<string, { left: number; right: number }>,
  ): DatasetColumn | undefined {
    const datasetId = column.dataset?.id;

    if (datasetId === context.leftDataset.id) {
      return this.findSourceColumn(column, context.leftMaps);
    }
    if (datasetId === context.rightDataset.id) {
      return this.findSourceColumn(column, context.rightMaps);
    }
    const leftCandidate = this.findHighestScoredCandidate(
      column,
      this.collectSourceCandidates(column, context.leftMaps),
      'left',
    );
    const rightCandidate = this.findHighestScoredCandidate(
      column,
      this.collectSourceCandidates(column, context.rightMaps),
      'right',
    );
    return this.pickSourceCandidate(column, leftCandidate, rightCandidate, sideUsage);
  }

  private buildColumnMaps(columns: DatasetColumn[]): ColumnMaps {
    const byColumnId = new Map<string, DatasetColumn>();
    const byName = new Map<string, DatasetColumn>();
    const byAlias = new Map<string, DatasetColumn>();
    columns.forEach((col) => {
      if (col.column?.id) {
        byColumnId.set(col.column.id, col);
      }
      if (col.name) {
        byName.set(col.name, col);
      }
      if (col.alias) {
        byAlias.set(col.alias, col);
      }
    });
    return { byColumnId, byName, byAlias };
  }

  private findSourceColumn(column: DatasetColumn, maps: ColumnMaps): DatasetColumn | undefined {
    return (
      this.findSourceByColumnId(column.column?.id, maps) ??
      this.findByMapKey(column.name, maps.byName) ??
      this.findByMapKey(column.name, maps.byAlias) ??
      this.findByMapKey(this.normalizeLookupValue(column.alias), maps.byAlias) ??
      this.findByMapKey(this.normalizeLookupValue(column.alias), maps.byName) ??
      this.findByMapKey(this.normalizeLookupValue(column.displayName), maps.byAlias) ??
      this.findByMapKey(this.normalizeLookupValue(column.displayName), maps.byName)
    );
  }

  private findSourceByColumnId(columnId: string | undefined, maps: ColumnMaps): DatasetColumn | undefined {
    if (!columnId) {
      return undefined;
    }
    return maps.byColumnId.get(columnId);
  }

  private findByMapKey(key: string | undefined, map: Map<string, DatasetColumn>): DatasetColumn | undefined {
    if (!key) {
      return undefined;
    }
    return map.get(key);
  }

  private normalizeLookupValue(value: string | undefined): string | undefined {
    const trimmed = value?.trim();
    return trimmed || undefined;
  }

  private collectSourceCandidates(column: DatasetColumn, maps: ColumnMaps): DatasetColumn[] {
    const uniqueCandidates = new Map<string, DatasetColumn>();
    this.getSourceCandidateLookups(column, maps).forEach((candidate) => {
      if (!candidate) {
        return;
      }
      const key = this.getColumnIdentity(candidate) ?? `${candidate.name}::${candidate.alias ?? ''}`;
      uniqueCandidates.set(key, candidate);
    });
    return Array.from(uniqueCandidates.values());
  }

  private getSourceCandidateLookups(column: DatasetColumn, maps: ColumnMaps): Array<DatasetColumn | undefined> {
    const alias = this.normalizeLookupValue(column.alias);
    const displayName = this.normalizeLookupValue(column.displayName);
    return [
      this.findSourceColumn(column, maps),
      this.findByMapKey(alias, maps.byAlias),
      this.findByMapKey(alias, maps.byName),
      this.findByMapKey(displayName, maps.byAlias),
      this.findByMapKey(displayName, maps.byName),
      this.findByMapKey(column.column?.id, maps.byColumnId),
      this.findByMapKey(column.name, maps.byName),
      this.findByMapKey(column.name, maps.byAlias),
    ];
  }

  private findHighestScoredCandidate(
    target: DatasetColumn,
    candidates: DatasetColumn[],
    side: ColumnSide,
  ): SourceColumnCandidate | undefined {
    let best: SourceColumnCandidate | undefined;
    candidates.forEach((candidate) => {
      const score = this.scoreSourceMatch(target, candidate);
      const nextCandidate: SourceColumnCandidate | undefined =
        score > 0 ? { side, column: candidate, score } : undefined;
      if (!nextCandidate) {
        return;
      }
      if (!best || nextCandidate.score > best.score) {
        best = nextCandidate;
      }
    });
    return best;
  }

  private scoreSourceMatch(target: DatasetColumn, candidate: DatasetColumn): number {
    const targetAlias = this.normalizeLookupValue(target.alias);
    const targetDisplayName = this.normalizeLookupValue(target.displayName);
    const candidateDisplayName = candidate.alias ?? candidate.name;
    const exact = (a: string | undefined, b: string | undefined, pts: number) => (a && b && a === b ? pts : 0);
    return (
      exact(target.column?.id, candidate.column?.id, 20) +
      exact(target.name, candidate.name, 30) +
      exact(target.name, candidate.alias, 15) +
      exact(targetAlias, candidate.alias, 60) +
      exact(targetAlias, candidate.name, 20) +
      exact(targetDisplayName, candidateDisplayName, 45)
    );
  }

  private pickSourceCandidate(
    column: DatasetColumn,
    leftCandidate: SourceColumnCandidate | undefined,
    rightCandidate: SourceColumnCandidate | undefined,
    sideUsage?: Map<string, { left: number; right: number }>,
  ): DatasetColumn | undefined {
    const preferredCandidate = this.resolvePreferredCandidate(leftCandidate, rightCandidate);
    if (preferredCandidate !== null) {
      return preferredCandidate?.column;
    }
    return this.resolveCandidateByUsage(column, leftCandidate, rightCandidate, sideUsage)?.column;
  }

  private resolvePreferredCandidate(
    leftCandidate: SourceColumnCandidate | undefined,
    rightCandidate: SourceColumnCandidate | undefined,
  ): SourceColumnCandidate | null | undefined {
    const availableCandidates = [leftCandidate, rightCandidate].filter(
      (candidate): candidate is SourceColumnCandidate => !!candidate,
    );
    if (availableCandidates.length === 0) {
      return undefined;
    }
    if (availableCandidates.length === 1) {
      return availableCandidates[0];
    }
    const [left, right] = availableCandidates;
    if (left.score === right.score) {
      return null;
    }
    return left.score > right.score ? left : right;
  }

  private resolveCandidateByUsage(
    column: DatasetColumn,
    leftCandidate: SourceColumnCandidate | undefined,
    rightCandidate: SourceColumnCandidate | undefined,
    sideUsage?: Map<string, { left: number; right: number }>,
  ): SourceColumnCandidate | undefined {
    if (!leftCandidate || !rightCandidate) {
      return leftCandidate ?? rightCandidate;
    }
    const preferredSide = this.getPreferredSideForAmbiguousColumn(column, sideUsage);
    return preferredSide === 'left' ? leftCandidate : rightCandidate;
  }

  private getPreferredSideForAmbiguousColumn(
    column: DatasetColumn,
    sideUsage?: Map<string, { left: number; right: number }>,
  ): ColumnSide {
    const usageKey = `${column.column?.id ?? 'no-column-id'}::${column.name ?? 'no-name'}`;
    const usage = sideUsage?.get(usageKey) ?? { left: 0, right: 0 };
    const preferredSide: ColumnSide = usage.left > usage.right ? 'right' : 'left';
    usage[preferredSide] += 1;
    sideUsage?.set(usageKey, usage);
    return preferredSide;
  }

  private mergeColumns(keyMappingColumns: DatasetColumn[], allCols: AvailableColumnItem[]): ColumnListItem[] {
    const leftDataset = this.data().leftDataset;
    const keyItems = keyMappingColumns.map((keyCol) => this.createKeyColumnItem(keyCol, leftDataset));
    const keyIdentities = new Set(
      keyMappingColumns
        .map((column) => this.getColumnIdentity(column))
        .filter((identity): identity is string => Boolean(identity)),
    );
    const remainingItems = allCols
      .filter((item) => {
        const identity = this.getColumnIdentity(item.column);
        if (identity && keyIdentities.has(identity)) {
          return false;
        }
        return !this.isRightJoinKey(item.column);
      })
      .map((item) => this.createItem(item.column, item.metadata));

    return [...keyItems, ...remainingItems];
  }

  private createKeyColumnItem(keyCol: DatasetColumn, dataset: JoinDatasetInfo): ColumnListItem {
    return this.createItem(keyCol, {
      sourceSide: 'left',
      sourceDatasetName: dataset?.name,
      sourceColumnName: keyCol.name,
    });
  }

  // Track if available columns have been loaded from BE in edit mode
  private availableColumnsLoaded = signal<boolean>(false);

  /**
   * Scrolls to the end of the list and focuses on the dropdown of the newly added column
   */
  private scrollToEndAndFocus(): void {
    // Use setTimeout to ensure DOM is updated after signal change
    setTimeout(() => {
      // Scroll to the bottom of the list
      if (this.scrollView) {
        this.scrollView.instance.scrollTo({ top: this.scrollView.instance.scrollHeight() });
      }

      // Focus on the last select box (dropdown for the newly added column)
      const allItems = this.allColumnsSelected();
      const lastItemWithoutColumn = allItems
        .filter((item) => !item.column) // Only items without column (empty dropdowns)
        .slice(-1)[0]; // Get the last one

      if (lastItemWithoutColumn) {
        // Find the select box that corresponds to this item
        const selectBoxArray = this.selectBoxes.toArray();
        if (selectBoxArray.length > 0) {
          const lastSelectBox = selectBoxArray[selectBoxArray.length - 1];
          if (lastSelectBox && lastSelectBox.instance) {
            lastSelectBox.instance.focus();
          }
        }
      }
    }, 100);
  }

  addColumn() {
    // In edit mode, lazy load available columns from BE when first adding
    if (this.isEditMode() && !this.availableColumnsLoaded()) {
      // Load columns first, then add the empty row after they're loaded
      this.loadAvailableColumnsForEdit(() => {
        this.allColumnsSelected.set([...this.allColumnsSelected(), this.createItem()]);
        this.scrollToEndAndFocus();
      });
    } else {
      this.allColumnsSelected.set([...this.allColumnsSelected(), this.createItem()]);
      this.scrollToEndAndFocus();
    }
  }

  /**
   * Lazy load available columns from left/right datasets in edit mode
   * Only called when user wants to add a new column
   * Available candidates are always derived from allAvailable - selected
   */
  private loadAvailableColumnsForEdit(callback?: () => void): void {
    const inputData = this.data();
    const leftDataset = inputData.leftDataset;
    const rightDataset = inputData.rightDataset;

    if (!leftDataset?.id || !rightDataset?.id) {
      callback?.();
      return;
    }

    combineLatest([
      this._datasetService.getDatasetColumns(leftDataset.id),
      this._datasetService.getDatasetColumns(rightDataset.id),
    ])
      .pipe(take(1))
      .subscribe(([leftCols, rightCols]) => {
        const allCols = this.createAvailableColumnItems(leftCols, rightCols, leftDataset, rightDataset);
        this.allAvailableColumns.set(allCols);

        this.refreshAvailableColumns();
        this.availableColumnsLoaded.set(true);

        callback?.();
      });
  }

  columnToAddValueChanged(event: SelectionChangedEvent, col: ColumnListItem) {
    const selectedItem = event.selectedItem as AvailableColumnItem | undefined;
    col.column = selectedItem ? this.cloneDatasetColumn(selectedItem.column) : undefined;
    const metadata = selectedItem?.metadata ?? this.buildDefaultSourceMetadata(col.column);
    this.applySourceMetadata(col, metadata);
    this.allColumnsSelected.update((cols: ColumnListItem[]) => {
      const index = cols.indexOf(col);
      cols[index] = col;
      return [...cols];
    });
    this.refreshAvailableColumns();
    this.previewValidated.set(false);
    this.validateSelectedColumns();
    this.validationChanged.emit(false);
  }

  removeColumn(column: DatasetColumn) {
    const currentCols = this.allColumnsSelected();
    let index = currentCols.findIndex((f) => this.isSameColumn(f.column, column));

    if (index > -1) {
      const newCols = currentCols.filter((_, i) => i !== index);

      this.allColumnsSelected.set(newCols);
      this.refreshAvailableColumns();
      this.previewValidated.set(false);
      this.validateSelectedColumns();
    }
  }

  removeAllColumns() {
    const colAdded = this.allColumnsSelected()
      .filter((c: ColumnListItem) => c.column !== undefined)
      .map((c: ColumnListItem) => c.column!);
    colAdded.forEach((c: DatasetColumn) => {
      c.alias = undefined;
    });
    this.allColumnsSelected.set([]);
    this.refreshAvailableColumns();
    this.duplicateColumnsInList.set([]);
    this.previewValidated.set(false);
  }

  onColumnItemReordered(e: ItemReorderedEvent) {
    this.allColumnsSelected.update((cols: ColumnListItem[]) => [...this.allColumnsSelected()]);
    this.previewValidated.set(false);
    this.validateSelectedColumns();
    this.validationChanged.emit(false);
  }

  canAddColumn = computed((): boolean => this.columnsRemovedAll().length > 0);

  canGoforward = computed((): boolean => this.previewValidated());

  filterEditorConfig = computed<ExpressionEditorConfig>(() => ({
    dialect: 'formula',
    columns: this.columnsSelected()
      .map((column) => column.alias || column.name)
      .filter((columnName): columnName is string => !!columnName),
    warnOnUnknownFunctions: true,
    maxSuggestions: 15,
  }));

  onAliasValueChanged(e: any, item: ColumnListItem) {
    let index = this.allColumnsSelected().findIndex((col: ColumnListItem) =>
      this.isSameColumn(col.column, item.column),
    );
    if (index === -1) {
      return;
    }
    const col = this.allColumnsSelected()[index];
    col.column!.alias = normalizeDatasetColumnAlias(e.value, col.column?.name);
    const cols = this.allColumnsSelected();
    cols[index] = col;
    this.allColumnsSelected.update((cols: ColumnListItem[]) => [...cols]);
    this.previewValidated.set(false);
    this.validateSelectedColumns();
  }

  notify(message: string | undefined, type: string, displayTime: number): void {
    notify(message, type, displayTime);
  }

  showPreview() {
    const expression = this.filterExpression();
    if (!expression.trim()) {
      this.filterExpressionValid.set(true);
      this.filterExpressionValidationState.set('none');
      this.filterExpressionValidationMessage.set('');
      this.loadPreviewData();
      return;
    }

    const columns = this.columnsSelected().map((col) => col.alias || col.name);
    this._formulaService.validateFormula({ expression, columns }).subscribe((result: ValidationResult) => {
      const isValid = result.status !== 'error';
      this.filterExpressionValid.set(isValid);
      if (!isValid) {
        this.filterExpressionValidationState.set('invalid');
        this.filterExpressionValidationMessage.set(result.message ?? '');
        this.previewValidated.set(false);
        this.validationChanged.emit(false);
        if (result.message) {
          alert(result.message, this.translateService.instant('error.generic'));
        }
        return;
      }
      this.filterExpressionValidationState.set('valid');
      this.filterExpressionValidationMessage.set('');
      this.loadPreviewData();
    });
  }

  private loadPreviewData(): void {
    const selectedCols = this.columnsSelected();

    // Validate duplicates on full column list BEFORE filtering
    this.validateSelectedColumns();
    if (this.duplicateColumnsInList().length > 0) {
      this.previewValidated.set(false);
      alert(
        `${this.translateService.instant('join.column.alias.validation.error')}`,
        this.translateService.instant('error.generic'),
      );
      return;
    }

    this.previewData.set(
      new CustomStore({
        load: () => {
          return lastValueFrom(
            this._datasetService.datasetJoinPreview(this.buildPreviewRequest(selectedCols)).pipe(
              tap((rows) => {
                this.previewRows.set(rows);
                this.previewData.set(new CustomStore({ load: () => lastValueFrom(of(rows)) }));
                this.previewValidated.set(true);
                this.validationChanged.emit(true);
              }),
              catchError(() => {
                this.previewRows.set([]);
                this.previewValidated.set(false);
                this.validationChanged.emit(false);
                return of([]);
              }),
            ),
          );
        },
      }),
    );
  }

  clearPreview() {
    this.previewRows.set([]);
    this.previewData.set(new CustomStore({ load: () => lastValueFrom(of([])) }));
  }

  private applyColumnUpdate(updatedColumn: DatasetColumn): void {
    const identity = this.getColumnIdentity(updatedColumn);
    this.allColumnsSelected.update((items) =>
      items.map((item) =>
        item.column && this.getColumnIdentity(item.column) === identity
          ? { ...item, column: this.cloneDatasetColumn(updatedColumn) }
          : item,
      ),
    );
  }

  onCastSaved(event: JoinCastSavedEvent): void {
    this.applyColumnUpdate(event.column);
    this.previewRows.set(event.rows);
    this.previewData.set(new CustomStore({ load: () => lastValueFrom(of(event.rows)) }));
    this.previewValidated.set(true);
    this.validationChanged.emit(true);
  }

  onColumnRenamed(updatedColumn: DatasetColumn): void {
    this.applyColumnUpdate(updatedColumn);
    this.clearPreview();
    this.validateSelectedColumns();
    this.validationChanged.emit(false);
  }

  onChooserChanged(event: JoinChooserChangedEvent): void {
    const selectedItems = event.selected.map((column) =>
      this.createItem(column, this.resolveMetadataFromAvailableColumn(column)),
    );
    const removedItems: AvailableColumnItem[] = event.removed.map((column) => ({
      column,
      metadata: this.resolveMetadataFromAvailableColumn(column) ?? this.buildDefaultSourceMetadata(column),
    }));

    this.allColumnsSelected.set(selectedItems);
    this.columnsRemovedAll.set(removedItems);
    this.previewValidated.set(false);
    this.validateSelectedColumns();
    this.validationChanged.emit(false);
  }

  private buildPreviewRequest(columns: DatasetColumn[]): DatasetJoinPreview {
    const inputData = this.data();
    const mappingsWithIds = inputData.keysMapping.filter(
      (km) => km.fromColumn?.id && km.joinedColumn?.id,
    ) as JoinKeyMapping[];
    const filteredColumns = filterOutRightJoinColumns(columns, mappingsWithIds, inputData.rightDataset.id);

    this.columnsChanged.emit(filteredColumns);

    return {
      datasetId: inputData.datasetId,
      leftDatasetId: inputData.leftDataset.id,
      rightDatasetId: inputData.rightDataset.id,
      joinType: inputData.joinType,
      keysMapping: mappingsWithIds.map((km) => ({
        fromColumn: km.fromColumn!.id!,
        joinedColumn: km.joinedColumn!.id!,
      })),
      joinColumns: buildNormalizedJoinColumnsPayload(mappingsWithIds),
      columns: filteredColumns,
      filterExpression: this.filterExpression() || undefined,
    };
  }

  private getUniqueColumnsFromKeyMapping(keysMapping: any[]): DatasetColumn[] {
    if (!keysMapping?.length) return [];

    const uniqueColumns = new Map<string, DatasetColumn>();
    keysMapping.forEach((mapping) => {
      const fromColumn = mapping.fromColumn as DatasetColumn | undefined;
      if (!fromColumn) {
        return;
      }
      const key = fromColumn.id ?? this.getColumnIdentity(fromColumn);
      if (!key || uniqueColumns.has(key)) {
        return;
      }
      uniqueColumns.set(key, this.cloneDatasetColumn(fromColumn));
    });

    return Array.from(uniqueColumns.values());
  }

  private cloneDatasetColumn(column: DatasetColumn): DatasetColumn {
    return {
      ...column,
      column: column.column ? { ...column.column } : column.column,
    };
  }

  private createItem(column?: DatasetColumn, sourceMetadata?: ColumnSourceMetadata): ColumnListItem {
    const clonedColumn = column ? this.cloneDatasetColumn(column) : undefined;
    const defaultMetadata = this.buildDefaultSourceMetadata(clonedColumn);
    const metadata: ColumnSourceMetadata = {
      sourceSide: sourceMetadata?.sourceSide ?? defaultMetadata.sourceSide,
      sourceDatasetName: sourceMetadata?.sourceDatasetName ?? defaultMetadata.sourceDatasetName,
      sourceColumnName: sourceMetadata?.sourceColumnName ?? defaultMetadata.sourceColumnName,
    };
    return {
      itemId: this.buildItemId(clonedColumn),
      column: clonedColumn,
      ...metadata,
    };
  }

  private buildItemId(column?: DatasetColumn): string {
    if (!column) {
      return `tmp-${this.nextItemId++}`;
    }
    if (column.id) {
      return `col-${column.id}`;
    }
    const datasetId = column.dataset?.id ?? 'no-ds';
    const displayName = column.displayName ?? '';
    return `col-${datasetId}-${column.name}-${displayName}`;
  }

  private applySourceMetadata(item: ColumnListItem, metadata?: ColumnSourceMetadata): void {
    item.sourceSide = metadata?.sourceSide;
    item.sourceDatasetName = metadata?.sourceDatasetName;
    item.sourceColumnName = metadata?.sourceColumnName;
  }

  private resolveMetadataFromAvailableColumn(column?: DatasetColumn): ColumnSourceMetadata | undefined {
    const available = this.findAvailableItemForColumn(column);
    if (!available) {
      return undefined;
    }
    return { ...available.metadata };
  }

  private findAvailableItemForColumn(column?: DatasetColumn): AvailableColumnItem | undefined {
    if (!column) {
      return undefined;
    }
    const allColumns = this.allAvailableColumns();
    if (!allColumns) {
      return undefined;
    }
    const bySourceColumnId = this.findBySourceColumnId(allColumns, column.column?.id);
    if (bySourceColumnId) {
      return bySourceColumnId;
    }

    const byColumnId = this.findByColumnId(allColumns, column.id);
    if (byColumnId) {
      return byColumnId;
    }

    const sourceSide = this.getSourceSideByDatasetId(column.dataset?.id);
    return this.findBySourceName(allColumns, column.name, sourceSide);
  }

  private findBySourceColumnId(
    allColumns: AvailableColumnItem[],
    sourceColumnId?: string,
  ): AvailableColumnItem | undefined {
    if (!sourceColumnId) {
      return undefined;
    }
    return allColumns.find((item) => item.column.column?.id === sourceColumnId || item.column.id === sourceColumnId);
  }

  private findByColumnId(allColumns: AvailableColumnItem[], columnId?: string): AvailableColumnItem | undefined {
    if (!columnId) {
      return undefined;
    }
    return allColumns.find((item) => item.column.id === columnId || item.column.column?.id === columnId);
  }

  private findBySourceName(
    allColumns: AvailableColumnItem[],
    sourceName?: string,
    sourceSide?: ColumnSide,
  ): AvailableColumnItem | undefined {
    if (!sourceName) {
      return undefined;
    }
    if (sourceSide) {
      return allColumns.find(
        (item) =>
          item.metadata.sourceSide === sourceSide &&
          (item.metadata.sourceColumnName ?? item.column.name) === sourceName,
      );
    }
    return allColumns.find((item) => (item.metadata.sourceColumnName ?? item.column.name) === sourceName);
  }

  private getSourceDatasetNameForColumn(column?: DatasetColumn): string | undefined {
    if (!column) {
      return undefined;
    }
    const metadata = this.resolveMetadataFromAvailableColumn(column);
    if (metadata?.sourceDatasetName) {
      return metadata.sourceDatasetName;
    }
    return this.getDatasetNameBySide(this.getSourceSideByDatasetId(column.dataset?.id));
  }

  private excludeRightJoinKeys(columns: DatasetColumn[]): DatasetColumn[] {
    return columns.filter((column) => !this.isRightJoinKey(column));
  }

  private excludeRightJoinKeyItems(items: AvailableColumnItem[]): AvailableColumnItem[] {
    return items.filter((item) => !this.isRightJoinKey(item.column));
  }

  private isRightJoinKey(column?: DatasetColumn): boolean {
    if (!column || this.isFormulaColumn(column)) {
      return false;
    }
    const rightDatasetId = this.data().rightDataset.id;
    if (column.dataset?.id && column.dataset.id !== rightDatasetId) {
      return false;
    }
    return this.data().keysMapping.some((mapping) => this.matchesRightJoinKey(mapping.joinedColumn, column));
  }

  private matchesRightJoinKey(joinedColumn: DatasetColumn | undefined, candidate: DatasetColumn): boolean {
    if (!joinedColumn) {
      return false;
    }
    const joinedStrongIdentity = this.getStrongJoinIdentity(joinedColumn);
    const candidateStrongIdentity = this.getStrongJoinIdentity(candidate);
    if (joinedStrongIdentity && candidateStrongIdentity) {
      return joinedStrongIdentity === candidateStrongIdentity;
    }
    if (this.hasStrongJoinIdentity(joinedColumn) || this.hasStrongJoinIdentity(candidate)) {
      return false;
    }
    if (!this.areDatasetsCompatibleForNameFallback(joinedColumn, candidate)) {
      return false;
    }
    return joinedColumn.name === candidate.name;
  }

  private getStrongJoinIdentity(column?: DatasetColumn): string | null {
    if (!column) {
      return null;
    }
    if (column.column?.id) {
      return `source-col:${column.column.id}`;
    }
    if (column.id) {
      return `col:${column.id}`;
    }
    return null;
  }

  private hasStrongJoinIdentity(column?: DatasetColumn): boolean {
    return Boolean(this.getStrongJoinIdentity(column));
  }

  private areDatasetsCompatibleForNameFallback(joinedColumn: DatasetColumn, candidate: DatasetColumn): boolean {
    if (!joinedColumn.dataset?.id || !candidate.dataset?.id) {
      return true;
    }
    return joinedColumn.dataset.id === candidate.dataset.id;
  }

  private isFormulaColumn(column: DatasetColumn): boolean {
    return `${column.type ?? ''}`.toUpperCase() === DatasetColumnType.FORMULA;
  }

  private buildDefaultSourceMetadata(column?: DatasetColumn): ColumnSourceMetadata {
    if (!column) {
      return {};
    }
    const sourceSide = this.getSourceSideByDatasetId(column.dataset?.id);
    return {
      sourceSide,
      sourceDatasetName: this.getDatasetNameBySide(sourceSide),
      sourceColumnName: column.name,
    };
  }

  private getSourceSideByDatasetId(datasetId?: string): ColumnSide | undefined {
    if (!datasetId) {
      return undefined;
    }
    const { leftDataset, rightDataset } = this.data();
    if (datasetId === leftDataset.id) {
      return 'left';
    }
    if (datasetId === rightDataset.id) {
      return 'right';
    }
    return undefined;
  }

  private getDatasetNameBySide(side?: ColumnSide): string | undefined {
    if (!side) {
      return undefined;
    }
    const { leftDataset, rightDataset } = this.data();
    return side === 'left' ? leftDataset.name : rightDataset.name;
  }

  private getDatasetIdBySide(side?: ColumnSide): string | undefined {
    if (!side) {
      return undefined;
    }
    const { leftDataset, rightDataset } = this.data();
    return side === 'left' ? leftDataset.id : rightDataset.id;
  }

  private buildPayloadColumn(item: ColumnListItem, index: number): DatasetColumn {
    const column = item.column!;
    const resolvedDatasetId = this.resolveDatasetIdForPayload(item);
    return {
      ...column,
      columnOrder: index + 1,
      dataset: resolvedDatasetId ? { id: resolvedDatasetId } : column.dataset,
    };
  }

  private resolveDatasetIdForPayload(item: ColumnListItem): string | undefined {
    if (!item.column) {
      return undefined;
    }
    const metadataFromAvailable = this.resolveMetadataFromAvailableColumn(item.column);
    const sourceSide = item.sourceSide ?? metadataFromAvailable?.sourceSide;
    return this.getDatasetIdBySide(sourceSide) ?? item.column.dataset?.id;
  }

  private isSameColumn(left?: DatasetColumn, right?: DatasetColumn): boolean {
    const leftIdentity = this.getColumnIdentity(left);
    const rightIdentity = this.getColumnIdentity(right);
    if (!leftIdentity || !rightIdentity) {
      return false;
    }
    return leftIdentity === rightIdentity;
  }

  private getColumnIdentity(column?: DatasetColumn): string | null {
    if (!column) {
      return null;
    }
    if (column.id) {
      return `id:${column.id}`;
    }
    const columnId = column.column?.id;
    if (columnId) {
      return `col-id:${columnId}`;
    }
    const datasetId = column.dataset?.id;
    if (datasetId) {
      return `ds:${datasetId}::name:${column.name}`;
    }
    return `name:${column.name}::display:${column.displayName ?? ''}`;
  }

  private getSelectedItemSourceIdentity(item: ColumnListItem): string | null {
    if (!item.column) {
      return null;
    }
    const sourceContext = this.resolveSelectedSourceContext(item);
    return this.buildSourceIdentity(item.column, sourceContext.datasetId, sourceContext.sourceColumnName);
  }

  private getAvailableItemSourceIdentity(item: AvailableColumnItem): string | null {
    const datasetId =
      this.getDatasetIdBySide(item.metadata.sourceSide as ColumnSide | undefined) ?? item.column.dataset?.id ?? 'no-ds';
    const sourceColumnName = item.metadata.sourceColumnName ?? item.column.name;
    return this.buildSourceIdentity(item.column, datasetId, sourceColumnName);
  }

  private resolveSelectedSourceContext(item: ColumnListItem): { datasetId: string; sourceColumnName?: string } {
    const metadataFromAvailable = this.resolveMetadataFromAvailableColumn(item.column);
    const sourceSide = item.sourceSide ?? metadataFromAvailable?.sourceSide;
    return {
      datasetId: this.getDatasetIdBySide(sourceSide) ?? item.column?.dataset?.id ?? 'no-ds',
      sourceColumnName: item.sourceColumnName ?? metadataFromAvailable?.sourceColumnName ?? item.column?.name,
    };
  }

  private buildSourceIdentity(column: DatasetColumn, datasetId: string, sourceColumnName?: string): string | null {
    if (column.column?.id) {
      return `src:${datasetId}::col-id:${column.column.id}`;
    }
    if (sourceColumnName) {
      return `src:${datasetId}::name:${sourceColumnName}`;
    }
    if (column.id) {
      return `src:${datasetId}::id:${column.id}`;
    }
    return this.getColumnIdentity(column);
  }

  private refreshAvailableColumns(): void {
    const allColumns = this.allAvailableColumns();
    if (!allColumns) {
      return;
    }

    const selectedIdentities = new Set(
      this.allColumnsSelected()
        .map((item) => this.getSelectedItemSourceIdentity(item))
        .filter((identity): identity is string => Boolean(identity)),
    );
    const availableColumns = allColumns.filter((item) => {
      const identity = this.getAvailableItemSourceIdentity(item);
      return !identity || !selectedIdentities.has(identity);
    });
    this.columnsRemovedAll.set(availableColumns);
  }

  private validateSelectedColumns(columns?: DatasetColumn[]) {
    const selected = columns ?? this.columnsSelected();
    const outputNameCounts = new Map<string, number>();
    selected.forEach((col) => {
      const key = resolveDatasetColumnOutputName(col.name, col.alias);
      outputNameCounts.set(key, (outputNameCounts.get(key) || 0) + 1);
    });
    const invalidColumns: DatasetColumn[] = [];
    const processedColumns = new Set<string>();

    for (const [outputName, count] of outputNameCounts) {
      if (count <= 1) continue;

      selected
        .filter((col) => resolveDatasetColumnOutputName(col.name, col.alias) === outputName)
        .forEach((col) => {
          const key = col.id || `${col.name}||${col.displayName}`;
          if (!processedColumns.has(key)) {
            invalidColumns.push(col);
            processedColumns.add(key);
          }
        });
    }

    this.duplicateColumnsInList.set(invalidColumns);
  }

  private updateForwardValidityFromCurrentState(): void {
    this.validateSelectedColumns();
    const hasPendingSelections = this.allColumnsSelected().some((item) => !item.column);
    const hasDuplicateOutputColumns = this.duplicateColumnsInList().length > 0;
    const hasSelectedColumns = this.columnsSelected().length > 0;
    const canProceed =
      this.filterExpressionValid() && hasSelectedColumns && !hasPendingSelections && !hasDuplicateOutputColumns;

    this.previewValidated.set(canProceed);
    this.validationChanged.emit(canProceed);
  }

  isDupplicated(item: ColumnListItem): boolean {
    return this.duplicateColumnsInList().some((col) => this.isSameColumn(col, item.column));
  }

  getSelectedColumns(): DatasetColumn[] {
    return this.columnsSelected();
  }

  getFilterExpression(): string {
    return this.filterExpression();
  }

  isValid(): boolean {
    return this.previewValidated();
  }
}
