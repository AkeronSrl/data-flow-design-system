import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { DatasetColumn } from '@alkyra/dataset/models/dataset-column.model';
import { CommonModule } from '@angular/common';
import { Component, computed, inject, signal, ViewChild } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';

import { WizardJoinStore } from '../+store/wizard-join.store';
import { JoinColumnSelectorCoreComponent, JoinColumnSelectorData } from './join-column-selector-core.component';

@Component({
  selector: 'alk-join-column-selector',
  standalone: true,
  imports: [CommonModule, TiaraSuiteWizardStepComponent, JoinColumnSelectorCoreComponent, TranslatePipe],
  templateUrl: './join-column-selector.component.html',
  styleUrls: ['./join-column-selector.component.scss'],
})
export class JoinColumnSelectorComponent extends WizardStep {
  _wizardJoinStore = inject(WizardJoinStore);

  @ViewChild(JoinColumnSelectorCoreComponent) coreComponent?: JoinColumnSelectorCoreComponent;

  private readonly _isValid = signal<boolean>(false);

  columnSelectorData = computed((): JoinColumnSelectorData => {
    const leftDataset = this._wizardJoinStore.leftDataset();
    const rightDataset = this._wizardJoinStore.rightDataset();
    const keysMapping = this._wizardJoinStore.keysMapping();
    const joinType = this._wizardJoinStore.joinType();

    return {
      leftDataset: {
        id: leftDataset!.id,
        name: leftDataset!.name,
        type: leftDataset!.type,
      },
      rightDataset: {
        id: rightDataset!.id,
        name: rightDataset!.name,
        type: rightDataset!.type,
      },
      keysMapping,
      joinType: joinType || 'INNER',
    };
  });

  override canGoforward = computed((): boolean => {
    return this._isValid();
  });

  onColumnsChanged(columns: DatasetColumn[]) {
    this._wizardJoinStore.setColumns(columns);
  }

  onValidationChanged(isValid: boolean) {
    this._isValid.set(isValid);
  }

  onFilterExpressionChanged(filterExpression: string) {
    this._wizardJoinStore.setFilterExpression(filterExpression);
  }

  override onBackward(): void {}

  override onForward(): void {
    if (this.coreComponent) {
      this._wizardJoinStore.setColumns(this.coreComponent.getSelectedColumns());
      this._wizardJoinStore.setFilterExpression(this.coreComponent.getFilterExpression());
    }
  }
}
