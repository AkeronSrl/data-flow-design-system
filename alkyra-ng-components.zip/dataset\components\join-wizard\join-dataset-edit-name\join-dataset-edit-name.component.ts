import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { ChangeDetectionStrategy, Component, computed, inject, OnInit, Signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { ValueChangedEvent as TextAreaValueChangedEvent } from 'devextreme/ui/text_area';
import { ValueChangedEvent as TextBoxValueChangedEvent } from 'devextreme/ui/text_box';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';

import { WizardJoinStore } from '../+store/wizard-join.store';

@Component({
  selector: 'alk-aggregation-dataset-edit-name',
  templateUrl: './join-dataset-edit-name.component.html',
  styleUrls: ['./join-dataset-edit-name.component.scss'],
  standalone: true,
  imports: [TiaraSuiteWizardStepComponent, DxTextBoxModule, DxTextAreaModule, TranslatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class JoinDatasetEditNameComponent extends WizardStep implements OnInit {
  name: string = '';
  description: string = '';
  private readonly _translateService: TranslateService = inject(TranslateService);
  _wizardJoinStore = inject(WizardJoinStore);

  ngOnInit(): void {
    const sourceName = this._wizardJoinStore.leftDataset()!.name;
    const sourceName2 = this._wizardJoinStore.rightDataset()!.name;
    const join = this._translateService.instant('join');
    this._wizardJoinStore.setName(`${join} - ${sourceName} + ${sourceName2}`);
  }

  onNameChange(value: TextBoxValueChangedEvent) {
    this._wizardJoinStore.setName(value.value);
  }

  onDescriptionChange(value: TextAreaValueChangedEvent) {
    this._wizardJoinStore.setDescription(value.value);
  }

  override canGoforward: Signal<boolean> = computed(() => {
    return this._wizardJoinStore.name().length > 0;
  });
}
