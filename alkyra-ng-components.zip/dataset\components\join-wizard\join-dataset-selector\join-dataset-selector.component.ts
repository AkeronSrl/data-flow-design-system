import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { Dataset } from '@alkyra/dataset/models/dataset.model';
import { DatasetService } from '@alkyra/dataset/services/dataset.service';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { CustomStore } from 'devextreme/common/data';
import { SelectionChangedEvent } from 'devextreme/ui/list';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxListModule } from 'devextreme-angular/ui/list';
import { lastValueFrom, map, Observable } from 'rxjs';

import { WizardJoinStore } from '../+store/wizard-join.store';

@Component({
  selector: 'alk-join-dataset-selector',
  templateUrl: './join-dataset-selector.component.html',
  styleUrls: ['./join-dataset-selector.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    TiaraSuiteWizardStepComponent,
    DxListModule,
    DxDataGridModule,
    TranslatePipe,
    TiaraCircularIllustrationComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class JoinDatasetSelectorComponent extends WizardStep {
  selectedDataset: Dataset[] | null = null;

  readonly _wizardJoinStore = inject(WizardJoinStore);

  private readonly _datasetService = inject(DatasetService);

  datasets: Observable<Dataset[]> = this._datasetService
    .findDatasetsByPipelineId(this._wizardJoinStore.pipelineId()!)
    .pipe(
      map((datasets) =>
        datasets
          .toSorted((a, b) => a.datasetOrder - b.datasetOrder)
          .filter((dataset) => dataset.id !== this._wizardJoinStore.leftDataset()?.id),
      ),
    );

  previewCustomStore = signal<CustomStore | null>(null);

  onDatasetSelected($event: SelectionChangedEvent): void {
    const dataset = $event.addedItems[0];
    const datasetId = dataset.id;
    this.previewCustomStore.set(
      new CustomStore({
        load: () => lastValueFrom(this._datasetService.getPreview(datasetId)),
      }),
    );
    this._wizardJoinStore.setRightDataset(dataset);
  }

  override canGoforward = computed(() => {
    return this._wizardJoinStore.rightDataset() !== null;
  });
}
