import { TiaraSectionPanelComponent } from '@akeron-ng/tiara-ng/tiara-section-panel';
import { DatasetColumn } from '@alkyra/dataset/models/dataset-column.model';
import { DatasetService } from '@alkyra/dataset/services/dataset.service';
import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  computed,
  DestroyRef,
  effect,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { SelectionChangedEvent } from 'devextreme/ui/select_box';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { Subscription } from 'rxjs';

export interface KeyMapping {
  fromColumn: DatasetColumn;
  joinedColumn: DatasetColumn;
}

export interface JoinKeysMappingData {
  leftDatasetId: string;
  rightDatasetId: string;
  initialMappings?: KeyMapping[];
}

@Component({
  selector: 'alk-join-keys-mapping-core',
  templateUrl: './join-keys-mapping-core.component.html',
  styleUrls: ['./join-keys-mapping.component.scss'],
  standalone: true,
  imports: [CommonModule, DxSelectBoxModule, DxTextBoxModule, TranslatePipe, TiaraSectionPanelComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class JoinKeysMappingCoreComponent {
  // Inputs
  data = input.required<JoinKeysMappingData>();
  containerHeight = input<string>('auto'); // Allow customization, default to auto

  // Outputs
  mappingsChanged = output<KeyMapping[]>();

  // Services
  private readonly _datasetService = inject(DatasetService);
  private readonly _destroyRef = inject(DestroyRef);
  private readonly _cdr = inject(ChangeDetectorRef);

  // State
  leftColumns = signal<DatasetColumn[]>([]);
  rightColumns = signal<DatasetColumn[]>([]);
  keysMappings = signal<KeyMapping[]>([]);
  searchQuery = signal<string>('');
  hasMappingCandidates = computed(() => this.leftColumns().length > 0 && this.rightColumns().length > 0);
  filteredLeftColumns = computed(() => {
    const query = this.normalizeValue(this.searchQuery());
    if (!query) {
      return this.leftColumns();
    }

    return this.leftColumns().filter((column) => {
      const displayName = this.normalizeValue(column.displayName);
      if (displayName) {
        return displayName.includes(query);
      }

      return this.normalizeValue(column.name).includes(query);
    });
  });
  hasFilteredResults = computed(() => this.filteredLeftColumns().length > 0);

  // Subscription management
  private _subscriptions: Subscription[] = [];
  private _currentLeftDatasetId: string | null = null;
  private _currentRightDatasetId: string | null = null;

  constructor() {
    // Clean up subscriptions on destroy
    this._destroyRef.onDestroy(() => {
      this._subscriptions.forEach((sub) => sub.unsubscribe());
    });

    // Watch for input changes and trigger data loading
    effect(() => {
      this.data();
      // Just trigger the loading method, don't do subscriptions inside effect
      this.loadDatasetColumns();
    });
  }

  private loadDatasetColumns() {
    const inputData = this.data();

    // Always set initial mappings if provided (works in edit mode)
    if (inputData.initialMappings) {
      this.keysMappings.set(inputData.initialMappings);
      // Emit initial mappings so parent component knows about them
      this.mappingsChanged.emit(inputData.initialMappings);
    }

    // Only reload columns if dataset IDs changed
    if (
      this._currentLeftDatasetId === inputData.leftDatasetId &&
      this._currentRightDatasetId === inputData.rightDatasetId
    ) {
      return;
    }

    // Clear previous subscriptions
    this._subscriptions.forEach((sub) => sub.unsubscribe());
    this._subscriptions = [];

    // Update tracked IDs
    this._currentLeftDatasetId = inputData.leftDatasetId;
    this._currentRightDatasetId = inputData.rightDatasetId;

    // Load left dataset columns
    const leftSub = this._datasetService
      .getDatasetColumns(inputData.leftDatasetId)
      .subscribe((columns) => this.leftColumns.set(columns));
    this._subscriptions.push(leftSub);

    // Load right dataset columns
    const rightSub = this._datasetService
      .getDatasetColumns(inputData.rightDatasetId)
      .subscribe((columns) => this.rightColumns.set(columns));
    this._subscriptions.push(rightSub);
  }

  rightColumnSelectionChanged($event: SelectionChangedEvent, leftColumn: DatasetColumn) {
    const selectedValue = $event.selectedItem as DatasetColumn | null;
    if (selectedValue) {
      this.addKeyMapping(leftColumn, selectedValue);
    } else {
      this.removeKeyMapping(leftColumn);
    }
  }

  trackLeftColumn(index: number, column: DatasetColumn): string {
    return column.id || `${column.name}-${index}`;
  }

  onSearchValueChanged(value: string | null | undefined): void {
    this.searchQuery.set((value ?? '').trim());
  }

  getColumnLabel(column: DatasetColumn): string {
    return column.displayName || column.name;
  }

  displayColumnName = (column?: DatasetColumn): string => {
    if (!column) {
      return '';
    }

    return this.getColumnLabel(column);
  };

  selectValue(column: DatasetColumn): string | undefined {
    return this.keysMappings().find((m) => m.fromColumn.id === column.id)?.joinedColumn.id;
  }

  private addKeyMapping(fromColumn: DatasetColumn, joinedColumn: DatasetColumn) {
    const currentMappings = this.keysMappings();
    const existingIndex = currentMappings.findIndex((m) => m.fromColumn.id === fromColumn.id);

    let updatedMappings: KeyMapping[];
    if (existingIndex > -1) {
      updatedMappings = currentMappings.map((m, i) => (i === existingIndex ? { fromColumn, joinedColumn } : m));
    } else {
      updatedMappings = [...currentMappings, { fromColumn, joinedColumn }];
    }

    this.keysMappings.set(updatedMappings);
    this.mappingsChanged.emit(updatedMappings);
    this._cdr.markForCheck();
  }

  private removeKeyMapping(fromColumn: DatasetColumn) {
    const updatedMappings = this.keysMappings().filter((m) => m.fromColumn.id !== fromColumn.id);

    this.keysMappings.set(updatedMappings);
    this.mappingsChanged.emit(updatedMappings);
    this._cdr.markForCheck();
  }

  getMappings(): KeyMapping[] {
    return this.keysMappings();
  }

  getAllColumns(): DatasetColumn[] {
    return [...this.leftColumns(), ...this.rightColumns()];
  }

  private normalizeValue(value: string | undefined): string {
    return (value ?? '').trim().toLowerCase();
  }
}
