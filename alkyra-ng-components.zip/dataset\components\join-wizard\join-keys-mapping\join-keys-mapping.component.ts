import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { ChangeDetectionStrategy, Component, computed, inject, ViewChild } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';

import { WizardJoinStore } from '../+store/wizard-join.store';
import { JoinKeysMappingCoreComponent, JoinKeysMappingData, KeyMapping } from './join-keys-mapping-core.component';

@Component({
  selector: 'alk-join-keys-mapping',
  templateUrl: './join-keys-mapping.component.html',
  styleUrls: ['./join-keys-mapping.component.scss'],
  standalone: true,
  imports: [TiaraSuiteWizardStepComponent, JoinKeysMappingCoreComponent, TranslatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class JoinKeysMappingComponent extends WizardStep {
  readonly _wizardJoinStore = inject(WizardJoinStore);

  @ViewChild(JoinKeysMappingCoreComponent) coreComponent?: JoinKeysMappingCoreComponent;

  keysMappingData = computed((): JoinKeysMappingData => {
    const leftDataset = this._wizardJoinStore.leftDataset();
    const rightDataset = this._wizardJoinStore.rightDataset();
    const initialMappings = this._wizardJoinStore.keysMapping();

    return {
      leftDatasetId: leftDataset!.id,
      rightDatasetId: rightDataset!.id,
      initialMappings,
    };
  });

  onMappingsChanged(mappings: KeyMapping[]) {
    mappings.forEach((mapping) => {
      this._wizardJoinStore.addKeyMapping(mapping.fromColumn, mapping.joinedColumn);
    });
  }

  override onForward(): void {
    if (this.coreComponent) {
      const allColumns = this.coreComponent.getAllColumns();
      this._wizardJoinStore.setSelectedColumns(allColumns);
    }
  }
}
