import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { DatasetService } from '@alkyra/dataset/services/dataset.service';
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { CustomStore } from 'devextreme/common/data';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { lastValueFrom } from 'rxjs';

import { WizardJoinStore } from '../+store/wizard-join.store';

@Component({
  selector: 'alk-join-preview',
  templateUrl: './join-preview.component.html',
  styleUrls: ['./join-preview.component.scss'],
  standalone: true,
  imports: [TiaraSuiteWizardStepComponent, DxDataGridModule, TranslatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class JoinPreviewComponent extends WizardStep {
  private readonly _datasetService: DatasetService = inject(DatasetService);

  readonly _wizardJoinStore = inject(WizardJoinStore);

  dataSource = new CustomStore({
    load: () => {
      const previewData = this._wizardJoinStore.datasetJoinPreview();
      if (!previewData) {
        return Promise.resolve([]);
      }
      return lastValueFrom(this._datasetService.datasetJoinPreview(previewData));
    },
  });
}
