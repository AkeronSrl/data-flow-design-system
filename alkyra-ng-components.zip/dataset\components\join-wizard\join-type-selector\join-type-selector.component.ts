import {
  OptionButtonItem,
  TiaraSuiteOptionButtonSelectionComponent,
} from '@akeron-ng/tiara-ng-suite/tiara-option-button';
import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { JoinType } from '@alkyra/dataset/models/dataset.model';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';

import { WizardJoinStore } from '../+store/wizard-join.store';

@Component({
  selector: 'alk-join-type-selector',
  templateUrl: './join-type-selector.component.html',
  styleUrls: ['./join-type-selector.component.scss'],
  standalone: true,
  imports: [TiaraSuiteOptionButtonSelectionComponent, TiaraSuiteWizardStepComponent, TranslatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class JoinTypeSelectorComponent extends WizardStep {
  readonly _wizardJoinStore = inject(WizardJoinStore);

  private readonly _translateService: TranslateService = inject(TranslateService);

  options = computed<OptionButtonItem[]>(() => [
    this.createOption('INNER_JOIN', 'Inner Join', 'wizard.inner.join.type.subtitle', 'arrows-left-right-to-line'),
    this.createOption('LEFT_JOIN', 'Left Join', 'wizard.left.join.type.subtitle', 'arrow-right-from-line'),
  ]);

  override canGoforward = computed((): boolean => {
    return this._wizardJoinStore.joinType() !== null;
  });

  private createOption(value: JoinType, title: string, subtitleKey: string, icon: string): OptionButtonItem {
    return {
      title,
      subtitle: this._translateService.instant(subtitleKey),
      icon,
      isSelected: this._wizardJoinStore.joinType() === value,
      onSelect: () => {
        this._wizardJoinStore.setJoinType(value);
      },
      onDeselect: () => {
        if (this._wizardJoinStore.joinType() === value) {
          this._wizardJoinStore.setJoinType(null);
        }
      },
    };
  }
}
