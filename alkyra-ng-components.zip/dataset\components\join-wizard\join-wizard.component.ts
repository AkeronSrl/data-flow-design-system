import { TiaraSuiteWizardComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { Dataset } from '@alkyra/dataset/models/dataset.model';
import { DatasetColumn } from '@alkyra/dataset/models/dataset-column.model';
import { DatasetJoinCreate } from '@alkyra/dataset/models/dataset-join.model';
import { DatasetJoinService } from '@alkyra/dataset/services/dataset-join.service';
import { Id } from '@alkyra/shared-models/id.model';
import { ChangeDetectionStrategy, Component, inject, input, OnInit, output } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';

import { WizardJoinStore } from './+store/wizard-join.store';
import { buildNormalizedJoinColumnsPayload, filterOutRightJoinColumns, JoinKeyMapping } from './join-column-filter';
import { JoinColumnSelectorComponent } from './join-column-selector/join-column-selector.component';
import { JoinDatasetEditNameComponent } from './join-dataset-edit-name/join-dataset-edit-name.component';
import { JoinDatasetSelectorComponent } from './join-dataset-selector/join-dataset-selector.component';
import { JoinKeysMappingComponent } from './join-keys-mapping/join-keys-mapping.component';
import { JoinTypeSelectorComponent } from './join-type-selector/join-type-selector.component';

@Component({
  selector: 'alk-join-wizard',
  templateUrl: './join-wizard.component.html',
  standalone: true,
  imports: [
    TiaraSuiteWizardComponent,
    JoinTypeSelectorComponent,
    JoinDatasetSelectorComponent,
    JoinKeysMappingComponent,
    JoinDatasetEditNameComponent,
    TranslatePipe,
    JoinColumnSelectorComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [WizardJoinStore],
})
export class JoinWizardComponent implements OnInit {
  private readonly _wizardJoinStore = inject(WizardJoinStore);

  onSave = output<Id>();
  onClose = output<void>();

  pipelineId = input<string | null>();

  leftDataset = input<Dataset | null>();

  private readonly _datasetJoinService: DatasetJoinService = inject(DatasetJoinService);

  ngOnInit(): void {
    this._wizardJoinStore.setLeftDataset(this.leftDataset()!);
    this._wizardJoinStore.setPipelineId(this.pipelineId()!);
  }

  complete() {
    const columns = this.getFilteredColumns();
    const datasetJoinCreate: DatasetJoinCreate = {
      name: this._wizardJoinStore.name(),
      desc: this._wizardJoinStore.description(),
      pipelineId: this._wizardJoinStore.pipelineId()!,
      columns: columns,
      joinType: this._wizardJoinStore.joinType()!,
      leftDatasetId: this._wizardJoinStore.leftDataset()?.id!,
      rightDatasetId: this._wizardJoinStore.rightDataset()?.id!,
      joinColumns: buildNormalizedJoinColumnsPayload(this._wizardJoinStore.keysMapping()),
      filterExpression: this._wizardJoinStore.filterExpression() || undefined,
    };
    this._datasetJoinService.addComplexDataset(datasetJoinCreate).subscribe((id: Id) => this.onSave.emit(id));
  }

  private getFilteredColumns(): DatasetColumn[] {
    const columns = this._wizardJoinStore.columns();
    const keyMappings = this._wizardJoinStore.keysMapping() as JoinKeyMapping[];
    const rightDatasetId = this._wizardJoinStore.rightDataset()?.id;

    return filterOutRightJoinColumns(columns, keyMappings, rightDatasetId);
  }

  close() {
    this.onClose.emit();
  }
}
