import { TiaraCollapsableContainerComponent } from '@akeron-ng/tiara-ng/tiara-collapsable-container';
import { ConnectorMetadataColumn } from '@alkyra/connector/models/connector-metadata-column.model';
import { ConnectorMetadataPreviewColumn } from '@alkyra/connector/models/connector-metadata-preview-column.model';
import {
  isMetadataColumnIdentifierValid,
  resolveColumnSuggestedAlias,
  resolveExtractColumnValidationIssues,
  resolveValidationSuggestedAlias,
} from '@alkyra/dataset/components/shared/extract-columns-validation.utils';
import { DatasetColumn, DatasetColumnType } from '@alkyra/dataset/models/dataset-column.model';
import {
  ExtractColumnsInvalidColumn,
  ExtractColumnsValidationIssueCode,
} from '@alkyra/dataset/models/extract-columns-validation.model';
import { CommonModule } from '@angular/common';
import { Component, computed, effect, inject, input, output, signal, ViewChild } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { alert } from 'devextreme/ui/dialog';
import { ItemReorderedEvent } from 'devextreme/ui/list';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxListModule } from 'devextreme-angular/ui/list';
import { DxScrollViewComponent, DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxTooltipModule } from 'devextreme-angular/ui/tooltip';

import { normalizeDatasetColumnAlias, resolveDatasetColumnOutputName } from '../../shared/dataset-column-alias.utils';

type PendingSourceColumnRow = {
  itemId: string;
  columnName?: string;
  alias?: string;
};

type PendingSourceColumnSelection = {
  row: PendingSourceColumnRow;
  columnName: string | null;
};

type PendingSourceColumnAliasUpdate = {
  row: PendingSourceColumnRow;
  alias: string | null;
};

type TooltipTarget = {
  scope: string;
  value: string | null | undefined;
};

@Component({
  selector: 'alk-source-column-selector-core',
  standalone: true,
  imports: [
    CommonModule,
    TiaraCollapsableContainerComponent,
    TranslatePipe,
    DxListModule,
    DxDataGridModule,
    DxTextBoxModule,
    DxButtonModule,
    DxSelectBoxModule,
    DxScrollViewModule,
    DxTooltipModule,
  ],
  templateUrl: './source-column-selector-core.component.html',
  styleUrls: ['./source-column-selector-core.component.scss'],
})
export class SourceColumnSelectorCoreComponent {
  existingColumns = input<DatasetColumn[]>([]);
  availableColumns = input<ConnectorMetadataColumn[]>([]);
  previewRows = input<any[]>([]);
  loadingAvailableColumns = input<boolean>(false);
  previewLoading = input<boolean>(false);
  previewValidated = input<boolean>(false);
  previewErrorMessage = input<string | null>(null);
  validationAttempted = input<boolean>(false);
  invalidColumns = input<ExtractColumnsInvalidColumn[]>([]);
  initialSelection = input<ConnectorMetadataPreviewColumn[]>([]);

  columnsChanged = output<ConnectorMetadataPreviewColumn[]>();
  validationChanged = output<boolean>();
  previewRequested = output<ConnectorMetadataPreviewColumn[]>();

  @ViewChild(DxScrollViewComponent) scrollView?: DxScrollViewComponent;

  pendingRows = signal<PendingSourceColumnRow[]>([]);
  private readonly translateService = inject(TranslateService);

  private nextItemId = 0;
  private initialized = signal(false);

  readonly normalizedExistingColumns = computed(() =>
    this.existingColumns()
      .filter((column) => column.type === DatasetColumnType.SIMPLE)
      .slice()
      .sort((left, right) => (left.columnOrder ?? 0) - (right.columnOrder ?? 0)),
  );

  readonly canAddRow = computed(() => {
    return this.pendingRows().length < this.availableColumns().length;
  });

  readonly selectedColumns = computed(() => {
    const metadataByName = this.availableColumnsByName();
    const existingCount = this.normalizedExistingColumns().length;

    return this.pendingRows()
      .filter((row) => !!row.columnName && metadataByName.has(row.columnName!))
      .map((row, index) => {
        const metadata = metadataByName.get(row.columnName!)!;
        return {
          columnName: metadata.columnName,
          alias: this.normalizeAlias({ alias: row.alias, columnName: row.columnName }),
          type: metadata.dataType,
          length: metadata.length,
          precision: metadata.precision,
          identifierValid: metadata.identifierValid,
          suggestedAlias: metadata.suggestedAlias,
          order: existingCount + index + 1,
        } as ConnectorMetadataPreviewColumn;
      });
  });

  readonly duplicatedRowIds = computed(() => {
    const duplicates = new Set<string>();
    const buckets = new Map<string, string[]>();
    const metadataByName = this.availableColumnsByName();

    for (const row of this.pendingRows()) {
      if (!row.columnName || !metadataByName.has(row.columnName)) {
        continue;
      }
      const outputName = resolveDatasetColumnOutputName(row.columnName, row.alias);
      const current = buckets.get(outputName) ?? [];
      current.push(row.itemId);
      buckets.set(outputName, current);
    }

    for (const rowIds of buckets.values()) {
      if (rowIds.length <= 1) {
        continue;
      }
      rowIds.forEach((rowId) => duplicates.add(rowId));
    }

    return duplicates;
  });

  readonly hasDuplicateOutputNames = computed(() => this.duplicatedRowIds().size > 0);
  readonly validationIssuesByRowId = computed(() => {
    const issuesByRowId = new Map<string, ExtractColumnsValidationIssueCode[]>();
    const currentSelectedColumns = this.selectedColumns();
    for (const row of this.pendingRows()) {
      if (!row.columnName) {
        continue;
      }
      const selectedColumn = currentSelectedColumns.find((column) => column.columnName === row.columnName);
      if (!selectedColumn) {
        continue;
      }
      const issues = resolveExtractColumnValidationIssues(
        selectedColumn,
        currentSelectedColumns,
        this.invalidColumns(),
      );
      if (issues.length > 0) {
        issuesByRowId.set(row.itemId, issues);
      }
    }
    return issuesByRowId;
  });

  readonly canPreview = computed(
    () => this.selectedColumns().length > 0 && !this.previewLoading() && !this.hasDuplicateOutputNames(),
  );

  private readonly availableColumnsByName = computed(() => {
    const map = new Map<string, ConnectorMetadataColumn>();
    for (const column of this.availableColumns()) {
      map.set(column.columnName, column);
    }
    return map;
  });

  constructor() {
    this.setupPendingRowsEffect();
    this.setupSelectionSyncEffect();
    this.setupSuggestedAliasSyncEffect();
  }

  addRow(): void {
    if (!this.canAddRow()) {
      return;
    }
    this.pendingRows.update((rows) => [...rows, { itemId: this.buildItemId() }]);
    this.scrollToEnd();
  }

  private setupPendingRowsEffect(): void {
    effect(() => {
      const available = this.availableColumns();
      const initialSelection = this.initialSelection();
      this.syncPendingRows(available, initialSelection);
    });
  }

  private syncPendingRows(
    availableColumns: ConnectorMetadataColumn[],
    initialSelection: ConnectorMetadataPreviewColumn[],
  ): void {
    if (!this.initialized()) {
      this.initializePendingRows(initialSelection, availableColumns);
      return;
    }

    if (availableColumns.length === 0) {
      this.clearPendingRows();
      return;
    }

    this.ensurePendingRowExists();
  }

  private initializePendingRows(
    initialSelection: ConnectorMetadataPreviewColumn[],
    availableColumns: ConnectorMetadataColumn[],
  ): void {
    this.pendingRows.set(this.buildInitialRows(initialSelection, availableColumns));
    this.initialized.set(true);
  }

  private buildInitialRows(
    initialSelection: ConnectorMetadataPreviewColumn[],
    availableColumns: ConnectorMetadataColumn[],
  ): PendingSourceColumnRow[] {
    if (initialSelection.length > 0) {
      return initialSelection.map((selected) => ({
        itemId: this.buildItemId(),
        columnName: selected.columnName,
        alias: selected.alias,
      }));
    }

    return availableColumns.length > 0 ? [{ itemId: this.buildItemId() }] : [];
  }

  private clearPendingRows(): void {
    if (this.pendingRows().length > 0) {
      this.pendingRows.set([]);
    }
  }

  private ensurePendingRowExists(): void {
    if (this.pendingRows().length === 0) {
      this.pendingRows.set([{ itemId: this.buildItemId() }]);
    }
  }

  private setupSelectionSyncEffect(): void {
    effect(() => {
      const columns = this.selectedColumns();
      this.columnsChanged.emit(columns);
      this.validationChanged.emit(columns.length > 0 && !this.hasDuplicateOutputNames());
    });
  }

  private setupSuggestedAliasSyncEffect(): void {
    effect(() => {
      const metadataByName = this.availableColumnsByName();
      const rows = this.pendingRows();
      if (metadataByName.size === 0 || rows.length === 0) {
        return;
      }

      let changed = false;
      const nextRows = rows.map((row) => {
        const nextRow = this.applySuggestedAliasToRow(row, metadataByName);
        if (nextRow !== row) {
          changed = true;
        }
        return nextRow;
      });

      if (changed) {
        this.pendingRows.set(nextRows);
      }
    });
  }

  private scrollToEnd(): void {
    setTimeout(() => {
      if (this.scrollView) {
        this.scrollView.instance.scrollTo({ top: this.scrollView.instance.scrollHeight() });
      }
    }, 100);
  }

  removeRow(rowToRemove: PendingSourceColumnRow): void {
    this.pendingRows.update((rows) => rows.filter((row) => row.itemId !== rowToRemove.itemId));
  }

  selectColumn(selection: PendingSourceColumnSelection): void {
    const metadataByName = this.availableColumnsByName();
    this.pendingRows.update((rows) =>
      rows.map((row) => {
        if (row.itemId !== selection.row.itemId) {
          return row;
        }
        return this.applySuggestedAliasToRow({ ...row, columnName: selection.columnName ?? undefined }, metadataByName);
      }),
    );
  }

  updateAlias(update: PendingSourceColumnAliasUpdate): void {
    this.pendingRows.update((rows) =>
      rows.map((row) =>
        row.itemId === update.row.itemId
          ? { ...row, alias: this.normalizeAlias({ alias: update.alias, columnName: row.columnName }) }
          : row,
      ),
    );
  }

  getAvailableColumnsForRow(targetRow: PendingSourceColumnRow): ConnectorMetadataColumn[] {
    const selectedByOtherRows = new Set(
      this.pendingRows()
        .filter((row) => row.itemId !== targetRow.itemId && !!row.columnName)
        .map((row) => row.columnName as string),
    );
    return this.availableColumns().filter((column) => !selectedByOtherRows.has(column.columnName));
  }

  showPreview(): void {
    if (!this.canPreview()) {
      return;
    }
    if (this.hasDuplicateOutputNames()) {
      alert(
        this.translateService.instant('join.column.alias.validation.error'),
        this.translateService.instant('error.generic'),
      );
      return;
    }
    this.previewRequested.emit(this.selectedColumns());
  }

  onColumnItemReordered(_event: ItemReorderedEvent): void {
    this.pendingRows.update((rows) => [...rows]);
  }

  isDuplicated(row: PendingSourceColumnRow): boolean {
    return this.duplicatedRowIds().has(row.itemId);
  }

  hasValidationIssues(row: PendingSourceColumnRow): boolean {
    return this.getValidationIssues(row).length > 0;
  }

  getValidationMessage(row: PendingSourceColumnRow): string {
    const issues = this.getValidationIssues(row);
    const selectedColumn = this.getSelectedColumn(row);
    const invalidColumn = selectedColumn
      ? this.invalidColumns().find((column) => column.columnName === selectedColumn.columnName)
      : undefined;
    return issues.map((issue) => this.translateValidationIssue(issue, selectedColumn, invalidColumn)).join('\n');
  }

  isInvalidAvailableColumn(column: ConnectorMetadataColumn | null | undefined): boolean {
    return !!column && !isMetadataColumnIdentifierValid(column);
  }

  getMetadataValidationMessage(column: ConnectorMetadataColumn | null | undefined): string {
    const baseMessage = this.translateService.instant('dataset.columns.validation.issue.sourceNameRequiresAlias');
    return this.withSuggestedAlias({ message: baseMessage, suggestedAlias: resolveColumnSuggestedAlias(column) });
  }

  getTooltipTargetId(target: TooltipTarget): string {
    const sanitized = (target.value ?? 'unknown').replace(/[^A-Za-z0-9_-]/g, '_');
    return `${target.scope}-${sanitized}`;
  }

  private getValidationIssues(row: PendingSourceColumnRow): ExtractColumnsValidationIssueCode[] {
    return this.validationIssuesByRowId().get(row.itemId) ?? [];
  }

  private normalizeAlias({
    alias,
    columnName,
  }: {
    alias: string | null | undefined;
    columnName?: string;
  }): string | undefined {
    return normalizeDatasetColumnAlias(alias, columnName);
  }

  private applySuggestedAliasToRow(
    row: PendingSourceColumnRow,
    metadataByName: Map<string, ConnectorMetadataColumn>,
  ): PendingSourceColumnRow {
    if (!row.columnName || row.alias?.trim()) {
      return row;
    }

    const metadata = metadataByName.get(row.columnName);
    if (!metadata || isMetadataColumnIdentifierValid(metadata)) {
      return row;
    }

    const suggestedAlias = resolveColumnSuggestedAlias(metadata);
    if (!suggestedAlias) {
      return row;
    }

    return {
      ...row,
      alias: suggestedAlias,
    };
  }

  private getSelectedColumn(row: PendingSourceColumnRow): ConnectorMetadataPreviewColumn | undefined {
    if (!row?.columnName) {
      return undefined;
    }
    return this.selectedColumns().find((column) => column.columnName === row.columnName);
  }

  private translateValidationIssue(
    issue: ExtractColumnsValidationIssueCode,
    column?: ConnectorMetadataPreviewColumn,
    invalidColumn?: ExtractColumnsInvalidColumn,
  ): string {
    switch (issue) {
      case 'SOURCE_NAME_INVALID_REQUIRES_ALIAS':
        return this.withSuggestedAlias({
          message: this.translateService.instant('dataset.columns.validation.issue.sourceNameRequiresAlias'),
          suggestedAlias: column
            ? resolveValidationSuggestedAlias(column, this.invalidColumns())
            : (invalidColumn?.suggestedAlias ?? null),
        });
      case 'ALIAS_INVALID':
        return this.withSuggestedAlias({
          message: this.translateService.instant('dataset.columns.validation.issue.aliasInvalid'),
          suggestedAlias: invalidColumn?.suggestedAlias ?? null,
        });
      case 'OUTPUT_NAME_ALREADY_EXISTS':
        return this.translateService.instant('dataset.columns.validation.issue.outputAlreadyExists');
      case 'OUTPUT_NAME_DUPLICATE':
      default:
        return this.translateService.instant('dataset.columns.validation.issue.outputDuplicate');
    }
  }

  private withSuggestedAlias({
    message,
    suggestedAlias,
  }: {
    message: string;
    suggestedAlias: string | null | undefined;
  }): string {
    if (!suggestedAlias) {
      return message;
    }
    return `${message} ${this.translateService.instant('dataset.columns.validation.suggestedAlias', { alias: suggestedAlias })}`;
  }

  private buildItemId(): string {
    return `source-row-${this.nextItemId++}`;
  }
}
