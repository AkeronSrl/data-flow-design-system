import { ConnectorMetadataColumn } from '@alkyra/connector/models/connector-metadata-column.model';
import { ConnectorMetadataPreviewColumn } from '@alkyra/connector/models/connector-metadata-preview-column.model';
import { buildExtractColumnsValidationSignature } from '@alkyra/dataset/components/shared/extract-columns-validation.utils';
import { Dataset } from '@alkyra/dataset/models/dataset.model';
import { DatasetColumnType } from '@alkyra/dataset/models/dataset-column.model';
import {
  ExtractColumnsInvalidColumn,
  ExtractColumnsValidationResponse,
} from '@alkyra/dataset/models/extract-columns-validation.model';
import { DatasetConnectorService } from '@alkyra/dataset/services/dataset-connector.service';
import { ChangeDetectionStrategy, Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import notify from 'devextreme/ui/notify';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxPopupModule } from 'devextreme-angular/ui/popup';
import { finalize } from 'rxjs';

import { SourceColumnSelectorCoreComponent } from './source-column-selector-core/source-column-selector-core.component';

type DatasetWithId = Dataset & { id: string };

type DatasetColumnsRequestContext = {
  dataset: DatasetWithId;
  columns: ConnectorMetadataPreviewColumn[];
  validationSignature: string;
};

type ValidationResponseContext = {
  response: ExtractColumnsValidationResponse;
  validationSignature: string;
};

type ErrorMessageContext = {
  error: any;
  fallbackKey: string;
};

type NotificationType = 'error' | 'success' | 'warning';

type MessageNotification = {
  message: string;
  type: NotificationType;
  displayTime: number;
};

@Component({
  selector: 'alk-source-columns-edit-dialog',
  standalone: true,
  imports: [DxPopupModule, DxButtonModule, TranslatePipe, SourceColumnSelectorCoreComponent],
  templateUrl: './source-columns-edit-dialog.component.html',
  styleUrl: './source-columns-edit-dialog.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SourceColumnsEditDialogComponent {
  private readonly _datasetConnectorService = inject(DatasetConnectorService);
  private readonly _translateService = inject(TranslateService);

  visible = input.required<boolean>();
  dataset = input.required<Dataset | null>();

  saved = output<void>();
  closed = output<void>();

  availableColumns = signal<ConnectorMetadataColumn[]>([]);
  selectedColumns = signal<ConnectorMetadataPreviewColumn[]>([]);
  isSelectionValid = signal(false);
  previewRows = signal<any[]>([]);
  previewValidated = signal(false);
  previewErrorMessage = signal<string | null>(null);
  validationAttempted = signal(false);
  lastSuccessfulValidationSignature = signal<string | null>(null);
  invalidColumns = signal<ExtractColumnsInvalidColumn[]>([]);
  isLoadingColumns = signal(false);
  isPreviewLoading = signal(false);
  isSaving = signal(false);

  readonly existingSimpleColumns = computed(() => {
    const dataset = this.dataset();
    if (!dataset?.columns) {
      return [];
    }
    return dataset.columns
      .filter((column) => column.type === DatasetColumnType.SIMPLE)
      .slice()
      .sort((left, right) => (left.columnOrder ?? 0) - (right.columnOrder ?? 0));
  });

  readonly canSave = computed(
    () => this.selectedColumns().length > 0 && this.isSelectionValid() && this.previewValidated() && !this.isSaving(),
  );

  constructor() {
    effect(() => {
      const isVisible = this.visible();
      const dataset = this.resolveActiveDataset();
      if (!isVisible || !dataset) {
        return;
      }
      this.resetDialogState();
      this.loadAvailableColumns(dataset);
    });
  }

  onColumnsChanged(columns: ConnectorMetadataPreviewColumn[]): void {
    if (this.arePreviewColumnsEqual(this.selectedColumns(), columns)) {
      return;
    }
    this.selectedColumns.set(columns);
    this.previewValidated.set(false);
    this.previewErrorMessage.set(null);
    this.previewRows.set([]);
  }

  onValidationChanged(isValid: boolean): void {
    this.isSelectionValid.set(isValid);
    if (!isValid) {
      this.previewValidated.set(false);
    }
  }

  onPreviewRequested(columns: ConnectorMetadataPreviewColumn[]): void {
    const requestContext = this.buildPreviewRequestContext(columns);
    if (!requestContext) {
      return;
    }
    this.previewErrorMessage.set(null);
    this.isPreviewLoading.set(true);
    this.requestPreviewValidation(requestContext);
  }

  save(): void {
    const requestContext = this.buildSaveRequestContext();
    if (!requestContext) {
      return;
    }

    if (requestContext.validationSignature === this.lastSuccessfulValidationSignature()) {
      this.appendColumns(requestContext);
      return;
    }

    this.isSaving.set(true);
    this._datasetConnectorService.validateExtractColumns(requestContext.columns, requestContext.dataset.id).subscribe({
      next: (response) => {
        if (!this.applyValidationResponse({ response, validationSignature: requestContext.validationSignature })) {
          this.isSaving.set(false);
          this.notifyMessage({
            message: this._translateService.instant('dataset.columns.validation.failed'),
            type: 'warning',
            displayTime: 4000,
          });
          return;
        }
        this.appendColumns(requestContext);
      },
      error: (error) => {
        this.isSaving.set(false);
        this.notifyError({ error, fallbackKey: 'dataset.columns.validation.failed' });
      },
    });
  }

  cancel(): void {
    this.closed.emit();
  }

  private resolveActiveDataset(): DatasetWithId | null {
    const dataset = this.dataset();
    if (!dataset?.id) {
      return null;
    }
    return dataset as DatasetWithId;
  }

  private buildPreviewRequestContext(columns: ConnectorMetadataPreviewColumn[]): DatasetColumnsRequestContext | null {
    if (this.isPreviewLoading()) {
      return null;
    }
    return this.buildRequestContext(columns);
  }

  private buildSaveRequestContext(): DatasetColumnsRequestContext | null {
    if (!this.previewValidated()) {
      this.notifyMessage({
        message: this._translateService.instant('dataset.source.edit.preview.required'),
        type: 'warning',
        displayTime: 4000,
      });
      return null;
    }
    if (!this.canSave()) {
      return null;
    }
    return this.buildRequestContext(this.selectedColumns());
  }

  private buildRequestContext(columns: ConnectorMetadataPreviewColumn[]): DatasetColumnsRequestContext | null {
    const dataset = this.resolveActiveDataset();
    if (!dataset || columns.length === 0) {
      return null;
    }
    return {
      dataset,
      columns,
      validationSignature: buildExtractColumnsValidationSignature(columns),
    };
  }

  private requestPreviewValidation(requestContext: DatasetColumnsRequestContext): void {
    this._datasetConnectorService.validateExtractColumns(requestContext.columns, requestContext.dataset.id).subscribe({
      next: (response) => this.handlePreviewValidationResponse(response, requestContext),
      error: (error) => this.handlePreviewValidationError(error),
    });
  }

  private handlePreviewValidationResponse(
    response: ExtractColumnsValidationResponse,
    requestContext: DatasetColumnsRequestContext,
  ): void {
    if (!this.applyValidationResponse({ response, validationSignature: requestContext.validationSignature })) {
      this.handleRejectedPreviewValidation();
      return;
    }
    this.loadPreviewRows(requestContext);
  }

  private handleRejectedPreviewValidation(): void {
    const message = this._translateService.instant('dataset.columns.validation.failed');
    this.previewRows.set([]);
    this.previewValidated.set(false);
    this.previewErrorMessage.set(message);
    this.isPreviewLoading.set(false);
    this.notifyMessage({ message, type: 'warning', displayTime: 4000 });
  }

  private handlePreviewValidationError(error: any): void {
    this.isPreviewLoading.set(false);
    const message = this.resolveErrorMessage({ error, fallbackKey: 'dataset.columns.validation.failed' });
    this.previewValidated.set(false);
    this.previewRows.set([]);
    this.previewErrorMessage.set(message);
    this.notifyMessage({ message, type: 'error', displayTime: 5000 });
  }

  private loadPreviewRows(requestContext: DatasetColumnsRequestContext): void {
    this._datasetConnectorService
      .previewExtractColumns(requestContext.dataset.id, requestContext.columns)
      .pipe(finalize(() => this.isPreviewLoading.set(false)))
      .subscribe({
        next: (rows) => {
          this.previewRows.set(rows);
          this.previewValidated.set(true);
        },
        error: (error) => {
          this.previewRows.set([]);
          this.previewValidated.set(false);
          const message = this.resolveErrorMessage({ error, fallbackKey: 'dataset.source.edit.preview.error' });
          this.previewErrorMessage.set(message);
          this.notifyMessage({ message, type: 'error', displayTime: 5000 });
        },
      });
  }

  private loadAvailableColumns(dataset: DatasetWithId): void {
    this.isLoadingColumns.set(true);
    this._datasetConnectorService
      .getAvailableExtractColumns(dataset.id)
      .pipe(finalize(() => this.isLoadingColumns.set(false)))
      .subscribe({
        next: (columns) => {
          this.availableColumns.set(columns ?? []);
        },
        error: (error) => {
          this.availableColumns.set([]);
          this.notifyError({ error, fallbackKey: 'dataset.source.edit.load.error' });
        },
      });
  }

  private notifyError(context: ErrorMessageContext): void {
    this.notifyMessage({
      message: this.resolveErrorMessage(context),
      type: 'error',
      displayTime: 5000,
    });
  }

  private resolveErrorMessage({ error, fallbackKey }: ErrorMessageContext): string {
    const message = error?.error?.message ?? error?.error ?? error?.message ?? fallbackKey;
    return this._translateService.instant(message);
  }

  private notifyMessage({ message, type, displayTime }: MessageNotification): void {
    notify(message, type, displayTime);
  }

  private resetDialogState(): void {
    this.availableColumns.set([]);
    this.selectedColumns.set([]);
    this.isSelectionValid.set(false);
    this.previewRows.set([]);
    this.previewValidated.set(false);
    this.previewErrorMessage.set(null);
    this.validationAttempted.set(false);
    this.lastSuccessfulValidationSignature.set(null);
    this.invalidColumns.set([]);
    this.isLoadingColumns.set(false);
    this.isPreviewLoading.set(false);
    this.isSaving.set(false);
  }

  private applyValidationResponse({ response, validationSignature }: ValidationResponseContext): boolean {
    this.validationAttempted.set(true);
    this.invalidColumns.set(response.invalidColumns ?? []);
    if (!response.valid) {
      return false;
    }
    this.lastSuccessfulValidationSignature.set(validationSignature);
    return true;
  }

  private appendColumns(requestContext: DatasetColumnsRequestContext): void {
    this.isSaving.set(true);
    this._datasetConnectorService
      .appendExtractColumns(requestContext.dataset.id, requestContext.columns)
      .pipe(finalize(() => this.isSaving.set(false)))
      .subscribe({
        next: () => {
          notify(this._translateService.instant('dataset.source.edit.save.success'), 'success', 3000);
          this.saved.emit();
        },
        error: (error) => {
          this.notifyError({ error, fallbackKey: 'dataset.source.edit.save.error' });
        },
      });
  }

  private arePreviewColumnsEqual(
    left: ConnectorMetadataPreviewColumn[],
    right: ConnectorMetadataPreviewColumn[],
  ): boolean {
    return buildExtractColumnsValidationSignature(left) === buildExtractColumnsValidationSignature(right);
  }
}
