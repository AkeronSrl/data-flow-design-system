import { TiaraCollapsableContainerComponent } from '@akeron-ng/tiara-ng/tiara-collapsable-container';
import { TiaraSectionPanelComponent } from '@akeron-ng/tiara-ng/tiara-section-panel';
import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { DatasetColumn, DatasetColumnType } from '@alkyra/dataset/models/dataset-column.model';
import { DatasetSubsetPreview } from '@alkyra/dataset/models/dataset-subset.model';
import { DatasetService } from '@alkyra/dataset/services/dataset.service';
import { DatasetColumnFormulaService } from '@alkyra/dataset/services/dataset-column-formula.service';
import {
  ExpressionEditorConfig,
  ExpressionValidationState,
} from '@alkyra/ui/smart-expression-editor/models/expression-editor.model';
import { SmartExpressionEditorComponent } from '@alkyra/ui/smart-expression-editor/smart-expression-editor.component';
import { CommonModule } from '@angular/common';
import { Component, computed, inject, OnInit, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import CustomStore from 'devextreme/data/custom_store';
import { alert } from 'devextreme/ui/dialog';
import { ItemReorderedEvent } from 'devextreme/ui/list';
import { SelectionChangedEvent } from 'devextreme/ui/select_box';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxListModule } from 'devextreme-angular/ui/list';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { catchError, lastValueFrom, Observable, of, take, tap } from 'rxjs';

import { normalizeDatasetColumnAlias, resolveDatasetColumnOutputName } from '../../shared/dataset-column-alias.utils';
import { WizardSubsetStore } from '../+store/wizard-subset.store';
import {
  SubsetCastSavedEvent,
  SubsetChooserChangedEvent,
  SubsetPreviewAreaComponent,
} from './subset-preview-area.component';

interface ColumnListItem {
  column?: DatasetColumn;
}

type FilterValidationResult = {
  isValid: boolean;
  message?: string;
};

type FilterValidationRequest = {
  requestId: number;
  normalizedExpression: string;
};

@Component({
  selector: 'alk-subset-column-selector',
  standalone: true,
  imports: [
    CommonModule,
    TiaraCollapsableContainerComponent,
    TiaraSectionPanelComponent,
    TiaraSuiteWizardStepComponent,
    TranslatePipe,
    DxListModule,
    DxTextBoxModule,
    DxButtonModule,
    DxSelectBoxModule,
    DxScrollViewModule,
    SmartExpressionEditorComponent,
    SubsetPreviewAreaComponent,
  ],
  templateUrl: './subset-column-selector.component.html',
  styleUrls: ['./subset-column-selector.component.scss'],
})
export class SubsetColumnSelectorComponent extends WizardStep implements OnInit {
  private readonly _wizardSubsetStore = inject(WizardSubsetStore);
  private readonly _datasetService = inject(DatasetService);
  private readonly _datasetColumnFormulaService = inject(DatasetColumnFormulaService);
  private readonly _translateService = inject(TranslateService);
  private filterValidationRequestId = 0;

  allColumnsSelected = signal<ColumnListItem[]>([]);
  columnsRemovedAll = signal<DatasetColumn[]>([]);
  duplicateColumnsInList = signal<DatasetColumn[]>([]);

  filterExpression = signal<string>('');
  filterExpressionValid = signal<boolean>(true);
  filterExpressionValidationState = signal<ExpressionValidationState>('none');
  filterExpressionValidationMessage = signal<string>('');

  columnsSelected = computed((): DatasetColumn[] => {
    return this.allColumnsSelected()
      .filter((c) => c.column !== undefined)
      .map((c, index) => ({
        ...c.column!,
        columnOrder: index + 1,
      }));
  });

  previewValidated = signal<boolean>(false);
  previewRows = signal<any[]>([]);

  previewData = signal<CustomStore>(
    new CustomStore({
      load: () => lastValueFrom(of([])),
    }),
  );

  /** Passed to SubsetPreviewAreaComponent: loads preview rows from the backend for given columns. */
  readonly loadPreviewRowsFn = (cols: DatasetColumn[]): Observable<any[]> => {
    const payload = this.buildPreviewPayload(cols);
    if (!payload) {
      return of([]);
    }
    return this._datasetService.datasetSubsetPreview(payload);
  };

  comboDisplayColumnName = (item: DatasetColumn) => item && `${item?.displayName ?? item?.name}`;

  ngOnInit(): void {
    this.filterExpression.set(this._wizardSubsetStore.filterExpression());

    const source = this._wizardSubsetStore.sourceDataset();
    if (!source) {
      this.previewValidated.set(false);
      return;
    }

    this._datasetService
      .getDatasetColumns(source.id)
      .pipe(take(1))
      .subscribe({
        next: (columns) => {
          const sorted = columns.toSorted((a, b) => a.columnOrder - b.columnOrder);
          const selectable = sorted.map((c, index) => ({
            // Use the dataset column displayName (alias if present) as the effective name.
            // This is the name users see and the one that exists in the UNION output parquet.
            name: c.displayName ?? c.name,
            alias: undefined,
            displayName: c.displayName ?? c.name,
            type: DatasetColumnType.SIMPLE,
            columnOrder: index + 1,
            column: c.column,
          }));

          this.allColumnsSelected.set(selectable.map((column) => ({ column })));
          this.columnsRemovedAll.set([]);
          this.previewValidated.set(false);
        },
        error: () => {
          this.previewValidated.set(false);
        },
      });
  }

  addColumn() {
    this.allColumnsSelected.set([...this.allColumnsSelected(), { column: undefined }]);
  }

  columnToAddValueChanged(event: SelectionChangedEvent, col: ColumnListItem) {
    col.column = event.selectedItem as DatasetColumn;
    this.columnsRemovedAll.set(
      this.columnsRemovedAll().filter(
        (c: DatasetColumn) => c.name !== col.column?.name && c.displayName !== col.column?.displayName,
      ),
    );
    this.allColumnsSelected.update((cols: ColumnListItem[]) => {
      const index = cols.indexOf(col);
      cols[index] = col;
      return cols;
    });
    this.previewValidated.set(false);
    this.validateSelectedColumns();
  }

  removeColumn(column: DatasetColumn) {
    const currentCols = this.allColumnsSelected();
    const index = currentCols.findIndex(
      (f) => f.column?.name === column.name && f.column?.displayName === column.displayName,
    );

    if (index > -1) {
      const newCols = currentCols.filter((_, i) => i !== index);
      const colsToRemove = [...this.columnsRemovedAll(), column];

      this.allColumnsSelected.set(newCols);
      this.columnsRemovedAll.set(colsToRemove);
      this.previewValidated.set(false);
      this.validateSelectedColumns();
    }
  }

  removeAllColumns() {
    const colAdded = this.allColumnsSelected()
      .filter((c: ColumnListItem) => c.column !== undefined)
      .map((c: ColumnListItem) => c.column!);
    colAdded.forEach((c: DatasetColumn) => {
      c.alias = undefined;
    });
    const colsToRemove = [...this.columnsRemovedAll(), ...colAdded];
    this.allColumnsSelected.set([]);
    this.columnsRemovedAll.set(colsToRemove);
    this.duplicateColumnsInList.set([]);
    this.previewValidated.set(false);
  }

  onColumnItemReordered(e: ItemReorderedEvent) {
    const fromIndex = e.fromIndex;
    const toIndex = e.toIndex;
    if (fromIndex === undefined) {
      return;
    }

    if (toIndex === undefined) {
      return;
    }

    if (fromIndex === toIndex) {
      return;
    }

    const reordered = [...this.allColumnsSelected()];
    const [moved] = reordered.splice(fromIndex, 1);
    reordered.splice(toIndex, 0, moved);

    this.allColumnsSelected.set(reordered);
    this.previewValidated.set(false);
  }

  canAddColumn = computed((): boolean => {
    return this.columnsRemovedAll().length > 0;
  });

  filterEditorConfig = computed<ExpressionEditorConfig>(() => ({
    dialect: 'formula',
    columns: this.getFilterValidationColumns(),
    warnOnUnknownFunctions: true,
    maxSuggestions: 15,
  }));

  override canGoforward = computed((): boolean => {
    return this.previewValidated();
  });

  override onForward(): void {
    this._wizardSubsetStore.setColumns(this.columnsSelected());
    this._wizardSubsetStore.setFilterExpression(this.normalizeFilterExpression(this.filterExpression()));
  }

  onFilterExpressionChanged(newValue: string): void {
    this.filterValidationRequestId++;
    this.filterExpression.set(newValue ?? '');
    this._wizardSubsetStore.setFilterExpression(this.filterExpression());
    this.filterExpressionValid.set(true);
    this.filterExpressionValidationState.set('none');
    this.filterExpressionValidationMessage.set('');
    this.previewValidated.set(false);
  }

  onFilterExpressionFocusOut(): void {
    void this.validateFilterExpression();
  }

  onColumnNameDragStart(event: DragEvent, columnName: string): void {
    const name = (columnName ?? '').trim();
    if (!name) {
      return;
    }

    const dataTransfer = event.dataTransfer;
    if (!dataTransfer) {
      return;
    }

    this.setSubsetFilterColumnDragData(dataTransfer, name);
  }

  private setSubsetFilterColumnDragData(dataTransfer: DataTransfer, columnName: string): void {
    const entries: Array<[string, string]> = [
      ['text/plain', columnName],
      ['application/x-alkyra-column', columnName],
      ['application/x-alkyra-insert', 'subset-filter'],
      ['application/x-alkyra-origin', 'subset-columns'],
      ['application/x-alkyra-type', 'column'],
      ['application/x-alkyra-value', columnName],
      ['application/x-alkyra-version', '1'],
      ['application/x-alkyra-namespace', 'subset'],
      ['application/x-alkyra-format', 'plain'],
      ['application/x-alkyra-encoding', 'utf-8'],
    ];

    for (const [type, value] of entries) {
      dataTransfer.setData(type, value);
    }

    dataTransfer.effectAllowed = 'copy';
  }

  onFilterDragOver(event: DragEvent): void {
    event.preventDefault();
    if (event.dataTransfer) {
      event.dataTransfer.dropEffect = 'copy';
    }
  }

  onFilterDrop(event: DragEvent): void {
    event.preventDefault();

    const columnName =
      event.dataTransfer?.getData('application/x-alkyra-column') || event.dataTransfer?.getData('text/plain');
    this.insertColumnIntoFilter(columnName);
  }

  private insertColumnIntoFilter(columnName: string | undefined | null): void {
    const name = (columnName ?? '').trim();
    if (!name) {
      return;
    }

    const nextValue = this.buildFilterWithInsertedColumn(this.filterExpression(), name);
    this.filterExpression.set(nextValue);
    this._wizardSubsetStore.setFilterExpression(this.filterExpression());
    this.previewValidated.set(false);
  }

  private buildFilterWithInsertedColumn(existing: string, columnName: string): string {
    const trimmedEnd = (existing ?? '').trimEnd();
    if (!trimmedEnd) {
      return columnName;
    }

    if (this.endsWithLogicalOperator(trimmedEnd)) {
      return `${trimmedEnd} ${columnName}`;
    }

    return `${trimmedEnd} AND ${columnName}`;
  }

  private endsWithLogicalOperator(value: string): boolean {
    return /\b(AND|OR)\s*$/i.test((value ?? '').trimEnd());
  }

  onAliasValueChanged(e: any, item: ColumnListItem) {
    const index = this.allColumnsSelected().findIndex(
      (col: ColumnListItem) =>
        col.column && col.column.name === item.column?.name && col.column?.displayName === item.column?.displayName,
    );
    if (index < 0) {
      return;
    }
    const col = this.allColumnsSelected()[index];
    col.column!.alias = normalizeDatasetColumnAlias(e.value, col.column?.name);
    const cols = this.allColumnsSelected();
    cols[index] = col;
    this.allColumnsSelected.update((cols: ColumnListItem[]) => [...cols]);
    this.previewValidated.set(false);
    this.validateSelectedColumns();
  }

  validateFilterExpressionAsync = (params: { value?: string }): Promise<FilterValidationResult> => {
    return this.validateFilterExpressionValue(params.value ?? '');
  };

  async showPreview(): Promise<void> {
    const validation = await this.validateFilterExpressionValue(this.filterExpression());
    if (!validation.isValid) {
      this.previewValidated.set(false);
      return;
    }

    this.validateSelectedColumns();
    if (this.duplicateColumnsInList().length > 0) {
      this.previewValidated.set(false);
      alert(
        `${this._translateService.instant('join.column.alias.validation.error')}`,
        this._translateService.instant('error.generic'),
      );
      return;
    }

    const filter = this.normalizeFilterExpression(this.filterExpression());

    this.duplicateColumnsInList.set([]);
    this._wizardSubsetStore.setColumns(this.columnsSelected());
    this._wizardSubsetStore.setFilterExpression(filter);

    const payload = this._wizardSubsetStore.datasetSubsetPreview();
    if (!payload) {
      this.previewValidated.set(false);
      return;
    }

    this.previewData.set(
      new CustomStore({
        load: () =>
          lastValueFrom(
            this._datasetService.datasetSubsetPreview(payload).pipe(
              tap((rows) => {
                this.previewRows.set(rows);
                this.previewData.set(new CustomStore({ load: () => lastValueFrom(of(rows)) }));
                this.previewValidated.set(true);
              }),
              catchError(() => {
                this.previewRows.set([]);
                this.previewValidated.set(false);
                return of([]);
              }),
            ),
          ),
      }),
    );
  }

  onCastSaved(event: SubsetCastSavedEvent): void {
    this.applyColumnUpdate(event.column);
    this.previewRows.set(event.rows);
    this.previewData.set(new CustomStore({ load: () => lastValueFrom(of(event.rows)) }));
    this.previewValidated.set(true);
  }

  onColumnRenamed(updatedColumn: DatasetColumn): void {
    this.applyColumnUpdate(updatedColumn);
    this.clearPreview();
    this.validateSelectedColumns();
  }

  onColumnDeleted(column: DatasetColumn): void {
    this.removeColumn(column);
  }

  onChooserChanged(event: SubsetChooserChangedEvent): void {
    const selectedItems = event.selected.map((col) => ({ column: this.cloneDatasetColumn(col) }));
    // Merge removed columns into the pool, deduplicating by name+displayName
    const existingRemovedKeys = new Set(this.columnsRemovedAll().map((c) => `${c.name}||${c.displayName ?? ''}`));
    const newRemoved = event.removed
      .filter((col) => !existingRemovedKeys.has(`${col.name}||${col.displayName ?? ''}`))
      .map((col) => this.cloneDatasetColumn(col));

    this.allColumnsSelected.set(selectedItems);
    this.columnsRemovedAll.update((prev) => [...prev, ...newRemoved]);
    this.previewValidated.set(false);
    this.validateSelectedColumns();
  }

  private buildPreviewPayload(cols: DatasetColumn[]): DatasetSubsetPreview | null {
    const source = this._wizardSubsetStore.sourceDataset();
    if (!source) {
      return null;
    }
    return {
      datasetSourceId: source.id,
      filterExpression: this.normalizeFilterExpression(this.filterExpression()),
      columns: cols,
    };
  }

  private applyColumnUpdate(updatedColumn: DatasetColumn): void {
    this.allColumnsSelected.update((items) =>
      items.map((item) =>
        this.columnMatchesUpdate(item.column, updatedColumn)
          ? { column: this.cloneDatasetColumn(updatedColumn) }
          : item,
      ),
    );
  }

  private columnMatchesUpdate(a: DatasetColumn | undefined, target: DatasetColumn): boolean {
    return !!a && a.name === target.name && a.displayName === target.displayName;
  }

  private clearPreview(): void {
    this.previewRows.set([]);
    this.previewData.set(new CustomStore({ load: () => lastValueFrom(of([])) }));
    this.previewValidated.set(false);
  }

  private cloneDatasetColumn(column: DatasetColumn): DatasetColumn {
    return {
      ...column,
      column: column.column ? { ...column.column } : column.column,
    };
  }

  private validateFilterExpression(): Promise<FilterValidationResult> {
    return this.validateFilterExpressionValue(this.filterExpression());
  }

  private validateFilterExpressionValue(expression: string): Promise<FilterValidationResult> {
    const request = this.createFilterValidationRequest(expression);
    if (!request.normalizedExpression) {
      return Promise.resolve(this.resetFilterValidationState());
    }

    return this.runFilterValidation(request);
  }

  private createFilterValidationRequest(expression: string): FilterValidationRequest {
    return {
      requestId: ++this.filterValidationRequestId,
      normalizedExpression: this.normalizeFilterExpression(expression),
    };
  }

  private resetFilterValidationState(): FilterValidationResult {
    this.filterExpressionValid.set(true);
    this.filterExpressionValidationState.set('none');
    this.filterExpressionValidationMessage.set('');
    return { isValid: true };
  }

  private async runFilterValidation(request: FilterValidationRequest): Promise<FilterValidationResult> {
    try {
      const result = await this.requestFormulaValidation(request);
      return this.applyFilterValidationResult(request, {
        isValid: result.status !== 'error',
        message: result.message ?? undefined,
      });
    } catch (error) {
      return this.applyFilterValidationResult(request, {
        isValid: false,
        message: String(error ?? ''),
      });
    }
  }

  private requestFormulaValidation(request: FilterValidationRequest) {
    return lastValueFrom(
      this._datasetColumnFormulaService.validateFormula({
        expression: request.normalizedExpression,
        columns: this.getFilterValidationColumns(),
      }),
    );
  }

  private applyFilterValidationResult(
    request: FilterValidationRequest,
    result: FilterValidationResult,
  ): FilterValidationResult {
    if (request.requestId !== this.filterValidationRequestId) {
      return result.isValid ? { isValid: true } : result;
    }

    this.filterExpressionValid.set(result.isValid);
    this.filterExpressionValidationState.set(result.isValid ? 'valid' : 'invalid');
    this.filterExpressionValidationMessage.set(result.isValid ? '' : (result.message ?? ''));
    if (!result.isValid) {
      this.previewValidated.set(false);
    }

    return result.isValid ? { isValid: true } : result;
  }

  private validateSelectedColumns() {
    const selected = this.columnsSelected();
    const outputNameCounts = this.countOccurrences(selected, (col) =>
      resolveDatasetColumnOutputName(col.name, col.alias),
    );
    const invalidColumns: DatasetColumn[] = [];
    const processedColumns = new Set<string>();
    for (const [outputName, count] of outputNameCounts) {
      if (count <= 1) {
        continue;
      }

      selected
        .filter((col) => resolveDatasetColumnOutputName(col.name, col.alias) === outputName)
        .forEach((col) => {
          const key = `${col.name}||${col.displayName}`;
          if (!processedColumns.has(key)) {
            invalidColumns.push(col);
            processedColumns.add(key);
          }
        });
    }

    this.duplicateColumnsInList.set(invalidColumns);
  }

  private getFilterValidationColumns(): string[] {
    return this.columnsSelected()
      .map((column) => column.alias || column.displayName || column.name)
      .filter((columnName): columnName is string => !!columnName);
  }

  private normalizeFilterExpression(filterExpression: string): string {
    return (filterExpression ?? '')
      .trim()
      .replace(/^WHERE\b\s*/i, '')
      .trim();
  }

  private countOccurrences<T>(items: T[], keyFn: (item: T) => string): Map<string, number> {
    const counts = new Map<string, number>();
    items.forEach((item) => {
      const key = keyFn(item);
      counts.set(key, (counts.get(key) || 0) + 1);
    });
    return counts;
  }

  isDupplicated(item: ColumnListItem): boolean {
    return this.duplicateColumnsInList().some(
      (col) => col.name === item.column?.name && col.displayName === item.column?.displayName,
    );
  }

  private showErrorPopup(message: string): void {
    alert(message, this._translateService.instant('error.generic'));
  }
}
