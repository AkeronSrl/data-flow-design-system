import { TiaraSuiteListMenuComponent, TiaraSuiteMenuGroup } from '@akeron-ng/tiara-ng-suite/tiara-list-menu';
import { ColumnCastConfig } from '@alkyra/connector/models/column-cast-config.model';
import { ConnectorMetadataPreviewColumn } from '@alkyra/connector/models/connector-metadata-preview-column.model';
import { DataGridColumnTypeMapperService } from '@alkyra/datagrid-column-type-mapper/services/data-grid-column-type-mapper.service';
import { DatasetColumnCastDialogComponent } from '@alkyra/dataset/components/dataset-wizard/dataset-column-selector/dataset-column-cast-dialog/dataset-column-cast-dialog.component';
import { DatasetColumnChooserDialogComponent } from '@alkyra/dataset/components/dataset-wizard/dataset-column-selector/dataset-column-chooser-dialog/dataset-column-chooser-dialog.component';
import {
  buildCastValidationResult,
  buildDatasetColumnActionGroups,
  CastValidationResult,
  ColumnChooserApplyEvent,
  ColumnTypeMeta,
  DATASET_COLUMN_ACTION_CAST,
  DATASET_COLUMN_ACTION_DELETE,
  DATASET_COLUMN_ACTION_RENAME,
  hasCast,
  resolveColumnTypeMeta,
} from '@alkyra/dataset/components/dataset-wizard/dataset-column-selector/dataset-column-selector.models';
import { DatasetColumn, DatasetColumnType } from '@alkyra/dataset/models/dataset-column.model';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject, input, output, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import CustomStore from 'devextreme/data/custom_store';
import notify from 'devextreme/ui/notify';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxPopupModule } from 'devextreme-angular/ui/popup';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { catchError, finalize, forkJoin, Observable, of, take, tap } from 'rxjs';

import { normalizeDatasetColumnAlias, resolveDatasetColumnOutputName } from '../../shared/dataset-column-alias.utils';

export interface SubsetPreviewGridColumn {
  dataField: string;
  caption: string;
  dataType: string;
  column: DatasetColumn;
}

export type SubsetChooserColumn = ConnectorMetadataPreviewColumn & {
  __subsetIdentity: string;
  __displayName: string;
  __datasetColumn: DatasetColumn;
};

export interface SubsetCastSavedEvent {
  column: DatasetColumn;
  rows: any[];
}

export interface SubsetChooserChangedEvent {
  selected: DatasetColumn[];
  removed: DatasetColumn[];
}

@Component({
  selector: 'alk-subset-preview-area',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    DxDataGridModule,
    DxButtonModule,
    DxPopupModule,
    DxTextBoxModule,
    DatasetColumnCastDialogComponent,
    DatasetColumnChooserDialogComponent,
    TiaraSuiteListMenuComponent,
  ],
  templateUrl: './subset-preview-area.component.html',
  styleUrls: ['./subset-preview-area.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SubsetPreviewAreaComponent {
  // --- Inputs ---
  columns = input.required<DatasetColumn[]>();
  removedColumns = input.required<DatasetColumn[]>();
  previewData = input.required<CustomStore>();
  previewRows = input.required<any[]>();
  filterExpressionValid = input<boolean>(true);
  duplicateColumnsInList = input<DatasetColumn[]>([]);
  loadPreviewRowsFn = input.required<(cols: DatasetColumn[]) => Observable<any[]>>();

  // --- Outputs ---
  castSaved = output<SubsetCastSavedEvent>();
  columnRenamed = output<DatasetColumn>();
  columnDeleted = output<DatasetColumn>();
  chooserChanged = output<SubsetChooserChangedEvent>();
  previewRequested = output<void>();

  // --- Services ---
  private readonly _translateService = inject(TranslateService);
  private readonly _dataGridColumnTypeMapper = inject(DataGridColumnTypeMapperService);

  // --- Dialog state ---
  chooserDialogVisible = signal(false);
  renameDialogVisible = signal(false);
  castDialogVisible = signal(false);
  castValidationLoading = signal(false);
  castValidationResult = signal<CastValidationResult | null>(null);
  editingColumnIdentity = signal<string | null>(null);
  castEditingColumn = signal<DatasetColumn | null>(null);
  renameAlias = signal('');

  // --- Computed ---
  readonly columnActionGroups: TiaraSuiteMenuGroup[] = buildDatasetColumnActionGroups((key) =>
    this._translateService.instant(key),
  );
  readonly selectedColumnsCount = computed(() => this.columns().length);
  readonly totalColumnsCount = computed(() => this.columns().length + this.removedColumns().length);
  readonly previewGridColumns = computed((): SubsetPreviewGridColumn[] =>
    this.columns().map((column) => ({
      dataField: this.getColumnOutputName(column),
      caption: this.getColumnOutputName(column),
      dataType: this.getColumnTypeMeta(column).dataType,
      column,
    })),
  );
  readonly chooserSelectedColumns = computed(() => this.columns().map((column) => this.toChooserColumn(column)));
  readonly chooserRemovedColumns = computed(() => this.removedColumns().map((column) => this.toChooserColumn(column)));
  readonly chooserColumnId = (column: ConnectorMetadataPreviewColumn) =>
    (column as SubsetChooserColumn).__subsetIdentity;
  readonly chooserColumnDisplayName = (column: ConnectorMetadataPreviewColumn) =>
    (column as SubsetChooserColumn).__displayName;
  readonly castEditingPreviewColumn = computed((): ConnectorMetadataPreviewColumn | null => {
    const col = this.castEditingColumn();
    return col ? this.toPreviewColumn(col) : null;
  });

  // --- Type/display helpers ---
  getColumnOutputName(column?: DatasetColumn): string {
    return column ? resolveDatasetColumnOutputName(column.name, column.alias) : '';
  }

  getColumnTitle(column?: DatasetColumn): string {
    if (!column) {
      return '';
    }
    if (!column.alias?.trim()) {
      return column.name;
    }
    return `${column.alias} (${column.name})`;
  }

  getEffectiveColumnType(column?: DatasetColumn): string {
    if (!column?.column) {
      return 'Utf8';
    }
    return column.column.typeTargetCol ?? column.column.typeOrigCol ?? 'Utf8';
  }

  getColumnTypeMeta(column?: DatasetColumn): ColumnTypeMeta {
    return resolveColumnTypeMeta(this.getEffectiveColumnType(column), (value) =>
      this._dataGridColumnTypeMapper.mapType(value),
    );
  }

  hasColumnCast(column?: DatasetColumn): boolean {
    return !!column && hasCast(this.toPreviewColumn(column));
  }

  resolvePreviewGridColumn(dataField: string | null | undefined): SubsetPreviewGridColumn | undefined {
    if (!dataField) {
      return undefined;
    }
    return this.previewGridColumns().find((col) => col.dataField === dataField);
  }

  getPreviewColumnActionsButtonIdByDataField(dataField: string | null | undefined): string {
    return `subset-column-actions-${(dataField ?? 'unknown').replace(/[^A-Za-z0-9_-]/g, '_')}`;
  }

  toPreviewColumn(column: DatasetColumn): ConnectorMetadataPreviewColumn {
    return {
      columnName: column.name,
      alias: column.alias,
      order: column.columnOrder,
      type: column.column?.typeOrigCol ?? 'Utf8',
      length: column.column?.length,
      precision: column.column?.precision,
      cast: this.resolveColumnCast(column),
    };
  }

  // --- Dialog controls ---
  openChooserDialog(): void {
    this.chooserDialogVisible.set(true);
  }

  closeRenameDialog(): void {
    this.renameDialogVisible.set(false);
    this.editingColumnIdentity.set(null);
    this.renameAlias.set('');
  }

  closeCastDialog(): void {
    this.castDialogVisible.set(false);
    this.castEditingColumn.set(null);
    this.castValidationResult.set(null);
    this.castValidationLoading.set(false);
  }

  openRenameDialog(column: DatasetColumn): void {
    this.editingColumnIdentity.set(this.getColumnIdentity(column));
    this.renameAlias.set(column.alias ?? '');
    this.renameDialogVisible.set(true);
  }

  openCastDialog(column: DatasetColumn): void {
    if (this.isFormulaColumn(column)) {
      return;
    }
    this.castEditingColumn.set(this.cloneDatasetColumn(column));
    this.castValidationResult.set(null);
    this.castValidationLoading.set(false);
    this.castDialogVisible.set(true);
  }

  onPreviewColumnMenuItemSelected(column: DatasetColumn, actionId: number): void {
    switch (actionId) {
      case DATASET_COLUMN_ACTION_RENAME:
        this.openRenameDialog(column);
        return;
      case DATASET_COLUMN_ACTION_CAST:
        this.openCastDialog(column);
        return;
      case DATASET_COLUMN_ACTION_DELETE:
        this.columnDeleted.emit(column);
        return;
      default:
        return;
    }
  }

  saveRename(): void {
    const column = this.getEditingColumn();
    if (!column) {
      return;
    }

    const normalizedAlias = normalizeDatasetColumnAlias(this.renameAlias(), column.name);
    const nextOutputName = resolveDatasetColumnOutputName(column.name, normalizedAlias);
    const hasDuplicate = this.columns()
      .filter((item) => this.getColumnIdentity(item) !== this.getColumnIdentity(column))
      .some((item) => this.getColumnOutputName(item) === nextOutputName);
    if (hasDuplicate) {
      notify(this._translateService.instant('join.column.alias.validation.error'), 'error', 4000);
      return;
    }

    this.closeRenameDialog();
    this.columnRenamed.emit({ ...column, alias: normalizedAlias });
  }

  applyChooser(event: ColumnChooserApplyEvent): void {
    const selected = event.selectedColumns
      .map((col) => (col as SubsetChooserColumn).__datasetColumn)
      .map((col, index) => ({ ...this.cloneDatasetColumn(col), columnOrder: index + 1 }));
    const removed = event.removedColumns.map((col) => (col as SubsetChooserColumn).__datasetColumn);

    this.chooserDialogVisible.set(false);
    this.chooserChanged.emit({ selected, removed });
  }

  requestColumnCastValidation(cast: ColumnCastConfig): void {
    const column = this.castEditingColumn();
    if (!column) {
      return;
    }

    const sourcePreview$ =
      this.previewRows().length > 0
        ? of(this.previewRows())
        : this.loadPreviewRowsFn()(this.columns()).pipe(catchError(() => of([])));
    const castedColumns = this.buildColumnsWithUpdatedCast(column, cast);
    const castedPreview$ = this.loadPreviewRowsFn()(castedColumns).pipe(
      take(1),
      tap(() => undefined),
      catchError((error) => of([{ __subsetPreviewError: error }] as any[])),
    );

    this.castValidationLoading.set(true);
    this.castValidationResult.set(null);
    forkJoin({ sourceRows: sourcePreview$, castedPreview: castedPreview$ })
      .pipe(finalize(() => this.castValidationLoading.set(false)))
      .subscribe({
        next: ({ sourceRows, castedPreview }) => {
          const previewError = Array.isArray(castedPreview)
            ? castedPreview.find((row) => row?.__subsetPreviewError)?.__subsetPreviewError
            : null;
          if (!previewError) {
            this.castValidationResult.set(
              buildCastValidationResult({
                column: this.toPreviewColumn(column),
                cast,
                sourceRows: this.normalizePreviewRowsForCastValidation(column, sourceRows),
                castedRows: castedPreview,
              }),
            );
            return;
          }
          this.castValidationResult.set(
            buildCastValidationResult({
              column: this.toPreviewColumn(column),
              cast,
              sourceRows: this.normalizePreviewRowsForCastValidation(column, sourceRows),
              castedRows: null,
              fallbackErrorMessage: this.extractErrorMessage(previewError),
            }),
          );
        },
        error: (error) => {
          this.castValidationResult.set({
            valid: false,
            rows: [{ sourceValue: '', castResult: '', status: 'error', message: this.extractErrorMessage(error) }],
            errorCount: 1,
            sampleCount: 0,
          });
        },
      });
  }

  saveEditedColumnCast(cast: ColumnCastConfig | null): void {
    const column = this.castEditingColumn();
    if (!column) {
      return;
    }

    const updatedColumn = this.buildDatasetColumnWithCast(column, cast);
    const nextColumns = this.buildColumnsWithUpdatedCast(column, cast);
    this.castValidationLoading.set(true);
    this.loadPreviewRowsFn()(nextColumns)
      .pipe(
        take(1),
        finalize(() => this.castValidationLoading.set(false)),
      )
      .subscribe({
        next: (rows) => {
          this.closeCastDialog();
          this.castSaved.emit({ column: updatedColumn, rows });
          notify(
            this._translateService.instant(cast ? 'dataset.column.cast.updated' : 'dataset.column.cast.removed'),
            'success',
            3000,
          );
        },
        error: (error) => {
          notify(this.extractErrorMessage(error), 'error', 5000);
        },
      });
  }

  getEditingColumn(): DatasetColumn | undefined {
    const identity = this.editingColumnIdentity();
    if (!identity) {
      return undefined;
    }
    return this.columns().find((column) => this.getColumnIdentity(column) === identity);
  }

  // --- Private helpers ---
  private resolveColumnCast(column: DatasetColumn): ColumnCastConfig | null {
    if (column.column?.cast?.targetType) {
      return column.column.cast;
    }
    if (!column.column?.typeTargetCol) {
      return null;
    }
    return {
      sourceType: column.column.typeOrigCol,
      targetType: column.column.typeTargetCol,
      params: column.column.castParams,
    };
  }

  private toChooserColumn(column: DatasetColumn): SubsetChooserColumn {
    return {
      columnName: column.name,
      alias: column.alias,
      order: column.columnOrder,
      type: this.getEffectiveColumnType(column),
      length: column.column?.length,
      precision: column.column?.precision,
      cast: this.resolveColumnCast(column),
      __subsetIdentity: this.getColumnIdentity(column) ?? column.name,
      __displayName: column.alias ?? column.displayName ?? column.name,
      __datasetColumn: this.cloneDatasetColumn(column),
    };
  }

  private normalizePreviewRowsForCastValidation(column: DatasetColumn, rows: any[]): any[] {
    const outputName = this.getColumnOutputName(column);
    return rows.map((row) => ({
      ...row,
      [column.name]: row?.[column.name] ?? row?.[outputName],
    }));
  }

  private buildColumnsWithUpdatedCast(column: DatasetColumn, cast: ColumnCastConfig | null): DatasetColumn[] {
    const updatedColumn = this.buildDatasetColumnWithCast(column, cast);
    const updatedIdentity = this.getColumnIdentity(updatedColumn);
    return this.columns().map((item) =>
      this.getColumnIdentity(item) === updatedIdentity
        ? this.cloneDatasetColumn(updatedColumn)
        : this.cloneDatasetColumn(item),
    );
  }

  private buildDatasetColumnWithCast(column: DatasetColumn, cast: ColumnCastConfig | null): DatasetColumn {
    return {
      ...this.cloneDatasetColumn(column),
      column: {
        ...(column.column ?? { typeOrigCol: 'Utf8' }),
        typeOrigCol: column.column?.typeOrigCol ?? 'Utf8',
        typeTargetCol: cast?.targetType ?? null,
        castParams: cast?.params ?? undefined,
        cast,
      },
    };
  }

  private getColumnIdentity(column?: DatasetColumn): string | null {
    if (!column) {
      return null;
    }
    if (column.id) {
      return `id:${column.id}`;
    }
    const columnId = column.column?.id;
    if (columnId) {
      return `col-id:${columnId}`;
    }
    return `name:${column.name}::display:${column.displayName ?? ''}`;
  }

  private cloneDatasetColumn(column: DatasetColumn): DatasetColumn {
    return {
      ...column,
      column: column.column ? { ...column.column } : column.column,
    };
  }

  private isFormulaColumn(column: DatasetColumn): boolean {
    return `${column.type ?? ''}`.toUpperCase() === DatasetColumnType.FORMULA;
  }

  private extractErrorMessage(error: unknown): string {
    const maybeError = error as { error?: { message?: string }; message?: string } | null | undefined;
    return maybeError?.error?.message ?? maybeError?.message ?? this._translateService.instant('error.generic');
  }
}
