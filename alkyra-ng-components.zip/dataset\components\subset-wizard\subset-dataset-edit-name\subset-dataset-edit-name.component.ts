import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { ChangeDetectionStrategy, Component, computed, inject, OnInit, Signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { ValueChangedEvent as TextAreaValueChangedEvent } from 'devextreme/ui/text_area';
import { ValueChangedEvent as TextBoxValueChangedEvent } from 'devextreme/ui/text_box';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';

import { WizardSubsetStore } from '../+store/wizard-subset.store';

@Component({
  selector: 'alk-subset-dataset-edit-name',
  templateUrl: './subset-dataset-edit-name.component.html',
  styleUrls: ['./subset-dataset-edit-name.component.scss'],
  standalone: true,
  imports: [TiaraSuiteWizardStepComponent, DxTextBoxModule, DxTextAreaModule, TranslatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SubsetDatasetEditNameComponent extends WizardStep implements OnInit {
  private readonly _translateService: TranslateService = inject(TranslateService);
  readonly _wizardSubsetStore = inject(WizardSubsetStore);

  ngOnInit(): void {
    const sourceName = this._wizardSubsetStore.sourceDataset()?.name ?? '';
    const subset = this._translateService.instant('subset');
    this._wizardSubsetStore.setName(`${subset} ${sourceName}`.trim());
  }

  onNameChange(value: TextBoxValueChangedEvent): void {
    this._wizardSubsetStore.setName(value.value);
  }

  onDescriptionChange(value: TextAreaValueChangedEvent): void {
    this._wizardSubsetStore.setDescription(value.value);
  }

  override canGoforward: Signal<boolean> = computed(() => {
    return this._wizardSubsetStore.name().length > 0;
  });
}
