import { TiaraSuiteWizardComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { Dataset } from '@alkyra/dataset/models/dataset.model';
import { DatasetSubsetCreate } from '@alkyra/dataset/models/dataset-subset.model';
import { DatasetSubsetService } from '@alkyra/dataset/services/dataset-subset.service';
import { Id } from '@alkyra/shared-models/id.model';
import { ChangeDetectionStrategy, Component, inject, input, OnInit, output } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';

import { WizardSubsetStore } from './+store/wizard-subset.store';
import { SubsetColumnSelectorComponent } from './subset-column-selector/subset-column-selector.component';
import { SubsetDatasetEditNameComponent } from './subset-dataset-edit-name/subset-dataset-edit-name.component';

@Component({
  selector: 'alk-subset-wizard',
  templateUrl: './subset-wizard.component.html',
  standalone: true,
  imports: [TiaraSuiteWizardComponent, SubsetColumnSelectorComponent, SubsetDatasetEditNameComponent, TranslatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [WizardSubsetStore],
})
export class SubsetWizardComponent implements OnInit {
  private readonly _wizardSubsetStore = inject(WizardSubsetStore);
  private readonly _datasetSubsetService = inject(DatasetSubsetService);

  saved = output<Id>();
  closed = output<void>();

  pipelineId = input<string | null>();
  sourceDataset = input<Dataset | null>();

  ngOnInit(): void {
    this._wizardSubsetStore.setSourceDataset(this.sourceDataset()!);
    this._wizardSubsetStore.setPipelineId(this.pipelineId()!);
  }

  complete(): void {
    const source = this._wizardSubsetStore.sourceDataset();
    if (!source) {
      return;
    }

    const datasetSubsetCreate: DatasetSubsetCreate = {
      name: this._wizardSubsetStore.name(),
      desc: this._wizardSubsetStore.description(),
      pipelineId: this._wizardSubsetStore.pipelineId()!,
      columns: this._wizardSubsetStore.columns(),
      datasetSourceId: source.id,
      filterExpression: this._wizardSubsetStore.filterExpression(),
    };

    this._datasetSubsetService.addComplexDataset(datasetSubsetCreate).subscribe((id: Id) => this.saved.emit(id));
  }

  requestClose(): void {
    this.closed.emit();
  }
}
