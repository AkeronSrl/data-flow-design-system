import { TiaraSectionPanelComponent } from '@akeron-ng/tiara-ng/tiara-section-panel';
import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { DatasetColumn } from '@alkyra/dataset/models/dataset-column.model';
import { DatasetUnionColumnMapping } from '@alkyra/dataset/models/dataset-union.model';
import { DatasetService } from '@alkyra/dataset/services/dataset.service';
import { CommonModule } from '@angular/common';
import { Component, computed, inject, OnInit, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import notify from 'devextreme/ui/notify';
import { SelectionChangedEvent } from 'devextreme/ui/select_box';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { catchError, combineLatest, of, take } from 'rxjs';

import { resolveDatasetColumnOutputName } from '../../shared/dataset-column-alias.utils';
import { WizardUnionStore } from '../+store/wizard-union.store';

interface UnionMappingRow {
  rowId: string;
  leftColumn: DatasetColumn;
  rightColumn?: DatasetColumn;
}

@Component({
  selector: 'alk-union-column-mapping',
  standalone: true,
  imports: [
    CommonModule,
    TiaraSuiteWizardStepComponent,
    TiaraSectionPanelComponent,
    DxSelectBoxModule,
    DxScrollViewModule,
    TranslatePipe,
  ],
  templateUrl: './union-column-mapping.component.html',
  styleUrls: ['./union-column-mapping.component.scss'],
})
export class UnionColumnMappingComponent extends WizardStep implements OnInit {
  private readonly _wizardUnionStore = inject(WizardUnionStore);
  private readonly _datasetService = inject(DatasetService);
  private readonly _translateService = inject(TranslateService);

  private _rowSequence = 0;

  leftColumns = signal<DatasetColumn[]>([]);
  rightColumns = signal<DatasetColumn[]>([]);
  rows = signal<UnionMappingRow[]>([]);
  invalidRowIds = signal<string[]>([]);
  validationMessages = signal<string[]>([]);

  leftRows = computed(() => this.rows());

  override canGoforward = computed(() => {
    return this.leftRows().length > 0 && this.validationMessages().length === 0;
  });

  ngOnInit(): void {
    this.loadSourceColumns();
  }

  override onBackward(): void {}

  override onForward(): void {
    const existingMappingsBySourceId = new Map(
      this._wizardUnionStore.columnMappings().map((mapping) => [mapping.outputSourceColumnId, mapping] as const),
    );

    const columnMappings: DatasetUnionColumnMapping[] = [];

    this.leftRows()
      .filter((row) => !!row.leftColumn.id)
      .forEach((row) => {
        const sourceId = row.leftColumn.id!;
        const existing = existingMappingsBySourceId.get(sourceId);
        columnMappings.push({
          outputSourceColumnId: sourceId,
          leftColumnId: sourceId,
          rightColumnId: row.rightColumn?.id,
          outputAlias: existing?.outputAlias,
          columnOrder: columnMappings.length + 1,
        });
      });

    const usedRightIds = new Set(
      this.leftRows()
        .map((row) => row.rightColumn?.id)
        .filter((id): id is string => !!id),
    );
    this.rightColumns()
      .filter((rightColumn) => !!rightColumn.id && !usedRightIds.has(rightColumn.id))
      .forEach((rightColumn) => {
        const sourceId = rightColumn.id!;
        const existing = existingMappingsBySourceId.get(sourceId);
        columnMappings.push({
          outputSourceColumnId: sourceId,
          rightColumnId: sourceId,
          outputAlias: existing?.outputAlias,
          columnOrder: columnMappings.length + 1,
        });
      });

    this._wizardUnionStore.setColumnMappings(columnMappings);
  }

  loadSourceColumns(): void {
    const left = this._wizardUnionStore.leftDataset();
    const right = this._wizardUnionStore.rightDataset();
    if (!left || !right) {
      return;
    }

    combineLatest([this._datasetService.getDatasetColumns(left.id), this._datasetService.getDatasetColumns(right.id)])
      .pipe(
        take(1),
        catchError(() => {
          this.notifyError(this._translateService.instant('union.preview.load.columns.error'));
          return of([[], []] as [DatasetColumn[], DatasetColumn[]]);
        }),
      )
      .subscribe(([leftCols, rightCols]) => {
        const sortedLeft = this.sortColumnsByOrder(leftCols);
        const sortedRight = this.sortColumnsByOrder(rightCols);
        this.leftColumns.set(sortedLeft);
        this.rightColumns.set(sortedRight);
        this.rows.set(this.buildRows(sortedLeft, sortedRight, this._wizardUnionStore.columnMappings()));
        this.validateMappings();
      });
  }

  buildRows(
    leftCols: DatasetColumn[],
    rightCols: DatasetColumn[],
    existingMappings: DatasetUnionColumnMapping[],
  ): UnionMappingRow[] {
    const rows: UnionMappingRow[] = [];
    const usedRightIds = new Set<string>();
    const mappingsByLeftId = new Map(
      existingMappings
        .filter((mapping) => !!mapping.leftColumnId)
        .map((mapping) => [mapping.leftColumnId as string, mapping] as const),
    );

    for (const leftColumn of leftCols) {
      const existing = leftColumn.id ? mappingsByLeftId.get(leftColumn.id) : undefined;
      let rightColumn = existing?.rightColumnId
        ? rightCols.find((column) => column.id === existing.rightColumnId)
        : undefined;

      if (!rightColumn) {
        rightColumn = this.findRightMatch(leftColumn, rightCols, usedRightIds);
      }

      if (rightColumn?.id) {
        usedRightIds.add(rightColumn.id);
      }

      rows.push({
        rowId: this.nextRowId(),
        leftColumn,
        rightColumn,
      });
    }

    return rows;
  }

  onRightColumnSelectionChanged(event: SelectionChangedEvent, row: UnionMappingRow): void {
    const selected = (event.selectedItem as DatasetColumn | null) ?? undefined;
    this.rows.set(
      this.rows().map((item) =>
        item.rowId === row.rowId
          ? {
              ...item,
              rightColumn: selected,
            }
          : item,
      ),
    );
    this.validateMappings();
  }

  validateMappings(): boolean {
    const invalidRowIds = new Set<string>();
    const validationMessages: string[] = [];
    const usedRightColumns = this.rows()
      .filter((row) => !!row.rightColumn?.id)
      .map((row) => row.rightColumn!.id!)
      .filter((id): id is string => !!id);

    const rightUsageCounts = this.countOccurrences(usedRightColumns, (id) => id);
    for (const row of this.rows()) {
      const rightId = row.rightColumn?.id;
      if (!rightId) {
        continue;
      }

      if ((rightUsageCounts.get(rightId) || 0) > 1) {
        invalidRowIds.add(row.rowId);
      }
    }

    if (Array.from(rightUsageCounts.values()).some((count) => count > 1)) {
      validationMessages.push(this._translateService.instant('union.mapping.step.validation.right.duplicate'));
    }

    this.invalidRowIds.set(Array.from(invalidRowIds));
    this.validationMessages.set(validationMessages);
    return validationMessages.length === 0;
  }

  isInvalidRow(row: UnionMappingRow): boolean {
    return this.invalidRowIds().includes(row.rowId);
  }

  getLeftColumnLabel(row: UnionMappingRow): string {
    return this.getColumnOutputName(row.leftColumn);
  }

  displayColumnName = (column?: DatasetColumn): string => {
    if (!column) {
      return '';
    }

    const outputName = this.getColumnOutputName(column);
    return `${outputName} (${column.displayName ?? column.name})`;
  };

  trackRow(index: number, row: UnionMappingRow): string {
    return row.rowId || `${index}`;
  }

  private findRightMatch(
    leftColumn: DatasetColumn,
    rightCols: DatasetColumn[],
    usedRightIds: Set<string>,
  ): DatasetColumn | undefined {
    const leftOutputName = this.normalizeName(this.getColumnOutputName(leftColumn));
    for (const rightColumn of rightCols) {
      if (rightColumn.id && usedRightIds.has(rightColumn.id)) {
        continue;
      }

      const rightOutputName = this.normalizeName(this.getColumnOutputName(rightColumn));
      if (rightOutputName === leftOutputName) {
        return rightColumn;
      }
    }

    return undefined;
  }

  private sortColumnsByOrder(columns: DatasetColumn[]): DatasetColumn[] {
    return [...columns].sort((a, b) => a.columnOrder - b.columnOrder);
  }

  private countOccurrences<T>(items: T[], keyFn: (item: T) => string): Map<string, number> {
    const counts = new Map<string, number>();
    for (const item of items) {
      const key = keyFn(item);
      counts.set(key, (counts.get(key) || 0) + 1);
    }
    return counts;
  }

  private nextRowId(): string {
    this._rowSequence += 1;
    return `union-mapping-row-${this._rowSequence}`;
  }

  private normalizeName(value: string): string {
    return (value ?? '').trim().toLowerCase().replace(/\s+/g, '_');
  }

  private notifyError(message: string): void {
    notify(message, 'error', 4000);
  }

  private getColumnOutputName(column: DatasetColumn): string {
    return resolveDatasetColumnOutputName(column.name, column.alias);
  }
}
