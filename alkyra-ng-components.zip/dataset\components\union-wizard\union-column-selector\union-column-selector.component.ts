import { TiaraSuiteListMenuComponent, TiaraSuiteMenuGroup } from '@akeron-ng/tiara-ng-suite/tiara-list-menu';
import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { ConnectorMetadataPreviewColumn } from '@alkyra/connector/models/connector-metadata-preview-column.model';
import { DataGridDataType } from '@alkyra/datagrid-column-type-mapper/models/data-grid-type-mapper.types';
import { DataGridColumnTypeMapperService } from '@alkyra/datagrid-column-type-mapper/services/data-grid-column-type-mapper.service';
import { DatasetColumnChooserDialogComponent } from '@alkyra/dataset/components/dataset-wizard/dataset-column-selector/dataset-column-chooser-dialog/dataset-column-chooser-dialog.component';
import { DatasetColumn, DatasetColumnType } from '@alkyra/dataset/models/dataset-column.model';
import { DatasetUnionColumnMapping } from '@alkyra/dataset/models/dataset-union.model';
import { DatasetService } from '@alkyra/dataset/services/dataset.service';
import { CommonModule } from '@angular/common';
import { Component, computed, inject, OnInit, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import CustomStore from 'devextreme/data/custom_store';
import { alert } from 'devextreme/ui/dialog';
import notify from 'devextreme/ui/notify';
import { ValueChangedEvent as TextBoxValueChangedEvent } from 'devextreme/ui/text_box';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxPopupModule } from 'devextreme-angular/ui/popup';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { combineLatest, finalize, lastValueFrom, of, take } from 'rxjs';
import {
  ColumnChooserApplyEvent,
  ColumnTypeMeta,
  resolveColumnTypeMeta,
} from '../../dataset-wizard/dataset-column-selector/dataset-column-selector.models';
import { normalizeDatasetColumnAlias, resolveDatasetColumnOutputName } from '../../shared/dataset-column-alias.utils';
import { WizardUnionStore } from '../+store/wizard-union.store';

interface UnionOutputRow {
  rowId: string;
  leftColumn?: DatasetColumn;
  rightColumn?: DatasetColumn;
  outputSourceColumn: DatasetColumn | null;
  outputAlias?: string;
  columnOrder: number;
}

interface UnionPreviewGridColumn {
  dataField: string;
  caption: string;
  dataType: DataGridDataType;
  column: ConnectorMetadataPreviewColumn;
  row: UnionOutputRow;
}

const UNION_COLUMN_ACTION_RENAME = 1;
const UNION_COLUMN_ACTION_DELETE = 2;

@Component({
  selector: 'alk-union-column-selector',
  standalone: true,
  imports: [
    CommonModule,
    TiaraSuiteWizardStepComponent,
    TiaraSuiteListMenuComponent,
    TranslatePipe,
    DxDataGridModule,
    DxTextBoxModule,
    DxButtonModule,
    DxLoadIndicatorModule,
    DxPopupModule,
    DatasetColumnChooserDialogComponent,
  ],
  templateUrl: './union-column-selector.component.html',
  styleUrls: ['./union-column-selector.component.scss'],
})
export class UnionColumnSelectorComponent extends WizardStep implements OnInit {
  private readonly _wizardUnionStore = inject(WizardUnionStore);
  private readonly _datasetService = inject(DatasetService);
  private readonly _translateService = inject(TranslateService);
  private readonly _dataGridColumnTypeMapper = inject(DataGridColumnTypeMapperService);

  private _rowSequence = 0;

  leftColumns = signal<DatasetColumn[]>([]);
  rightColumns = signal<DatasetColumn[]>([]);
  rows = signal<UnionOutputRow[]>([]);
  removedRows = signal<UnionOutputRow[]>([]);
  invalidRowIds = signal<string[]>([]);
  validationMessages = signal<string[]>([]);

  renameDialogVisible = signal(false);
  chooserDialogVisible = signal(false);
  editingRowId = signal<string | null>(null);
  renameAlias = signal('');
  previewLoading = signal<boolean>(false);
  previewValidated = signal<boolean>(false);
  previewData = signal<CustomStore>(
    new CustomStore({
      load: () => lastValueFrom(of([])),
    }),
  );
  readonly columnActionGroups: TiaraSuiteMenuGroup[] = [
    {
      items: [
        {
          id: UNION_COLUMN_ACTION_RENAME,
          name: this._translateService.instant('dataset.column.rename.action'),
          tiaraIcon: 'edit',
        },
        {
          id: UNION_COLUMN_ACTION_DELETE,
          name: this._translateService.instant('dataset.column.delete.action'),
          tiaraIcon: 'trash',
        },
      ],
    },
  ];
  readonly selectedColumnsCount = computed(() => this.rows().length);
  readonly totalColumnsCount = computed(() => this.rows().length + this.removedRows().length);
  readonly chooserSelectedColumns = computed(() => this.rows().map((row) => this.toChooserColumn(row)));
  readonly chooserRemovedColumns = computed(() => this.removedRows().map((row) => this.toChooserColumn(row)));
  readonly previewGridColumns = computed((): UnionPreviewGridColumn[] =>
    this.rows()
      .filter((row) => row.outputSourceColumn)
      .map((row) => {
        const column = this.toChooserColumn(row);
        return {
          dataField: this.resolveRowOutputName(row),
          caption: this.resolveRowOutputName(row),
          dataType: this.getColumnTypeMeta(column).dataType,
          column,
          row,
        };
      }),
  );

  override canGoforward = computed((): boolean => {
    return !this.previewLoading() && this.previewValidated() && this.validationMessages().length === 0;
  });

  ngOnInit(): void {
    this.loadSourceColumns();
  }

  override onBackward(): void {}

  override onForward(): void {
    const normalizedRows = this.withReorderedRows(this.rows());
    this.rows.set(normalizedRows);
    this._wizardUnionStore.setColumns(this.toDatasetColumns(normalizedRows));
    this._wizardUnionStore.setColumnMappings(this.toColumnMappings(normalizedRows));
  }

  loadSourceColumns(): void {
    const left = this._wizardUnionStore.leftDataset();
    const right = this._wizardUnionStore.rightDataset();
    if (!left || !right) {
      this.previewValidated.set(false);
      return;
    }

    combineLatest([this._datasetService.getDatasetColumns(left.id), this._datasetService.getDatasetColumns(right.id)])
      .pipe(take(1))
      .subscribe({
        next: ([leftCols, rightCols]) => {
          this.leftColumns.set(this.sortColumnsByOrder(leftCols));
          this.rightColumns.set(this.sortColumnsByOrder(rightCols));
          const rows = this.buildRows(this.leftColumns(), this.rightColumns(), this._wizardUnionStore.columnMappings());
          this.rows.set(rows);
          this.removedRows.set([]);
          this.previewValidated.set(false);
          this.validateRows();
        },
        error: () => {
          this.previewValidated.set(false);
          this.notifyError(this._translateService.instant('union.preview.load.columns.error'));
        },
      });
  }

  buildRows(
    leftCols: DatasetColumn[],
    rightCols: DatasetColumn[],
    mappings: DatasetUnionColumnMapping[],
  ): UnionOutputRow[] {
    const rows: UnionOutputRow[] = [];
    const usedRightIds = new Set<string>();
    const sortedMappings = [...mappings].sort((a, b) => a.columnOrder - b.columnOrder);
    const leftMappings = sortedMappings.filter((mapping) => !!mapping.leftColumnId);
    const rightMappings = sortedMappings.filter((mapping) => !mapping.leftColumnId && !!mapping.rightColumnId);

    const leftMappingsById = new Map(leftMappings.map((mapping) => [mapping.leftColumnId as string, mapping] as const));

    for (const leftColumn of leftCols) {
      const mapping = leftColumn.id ? leftMappingsById.get(leftColumn.id) : undefined;
      let rightColumn = mapping?.rightColumnId
        ? rightCols.find((column) => column.id === mapping.rightColumnId)
        : undefined;

      if (!rightColumn) {
        rightColumn = this.findRightMatch(leftColumn, rightCols, usedRightIds);
      }

      if (rightColumn?.id) {
        usedRightIds.add(rightColumn.id);
      }

      rows.push({
        rowId: this.nextRowId(),
        leftColumn,
        rightColumn,
        outputSourceColumn: leftColumn,
        outputAlias: normalizeDatasetColumnAlias(mapping?.outputAlias ?? leftColumn.alias, leftColumn.name),
        columnOrder: rows.length + 1,
      });
    }

    for (const mapping of rightMappings) {
      const rightColumn = rightCols.find((column) => column.id === mapping.rightColumnId);
      if (!rightColumn || !rightColumn.id || usedRightIds.has(rightColumn.id)) {
        continue;
      }

      usedRightIds.add(rightColumn.id);
      rows.push({
        rowId: this.nextRowId(),
        rightColumn,
        outputSourceColumn: rightColumn,
        outputAlias: normalizeDatasetColumnAlias(mapping.outputAlias ?? rightColumn.alias, rightColumn.name),
        columnOrder: rows.length + 1,
      });
    }

    return rows;
  }

  onOutputAliasChanged(event: TextBoxValueChangedEvent, row: UnionOutputRow): void {
    const sourceColumnName = row.outputSourceColumn?.name;
    const outputAlias = normalizeDatasetColumnAlias(event.value, sourceColumnName);

    this.rows.set(
      this.rows().map((item) =>
        item.rowId === row.rowId
          ? {
              ...item,
              outputAlias,
            }
          : item,
      ),
    );
    this.previewValidated.set(false);
    this.validateRows();
  }

  removeRow(row: UnionOutputRow): void {
    this.rows.set(this.withReorderedRows(this.rows().filter((item) => item.rowId !== row.rowId)));
    this.removedRows.update((rows) => (rows.some((item) => item.rowId === row.rowId) ? rows : [...rows, row]));
    this.previewValidated.set(false);
    this.validateRows();
  }

  openRenameDialog(column: ConnectorMetadataPreviewColumn): void {
    const row = this.findRowByChooserColumn(column);
    if (!row) {
      return;
    }
    this.editingRowId.set(row.rowId);
    this.renameAlias.set(row.outputAlias ?? '');
    this.renameDialogVisible.set(true);
  }

  saveRename(): void {
    const rowId = this.editingRowId();
    if (!rowId) {
      return;
    }

    this.rows.set(
      this.rows().map((row) =>
        row.rowId === rowId
          ? {
              ...row,
              outputAlias: normalizeDatasetColumnAlias(this.renameAlias(), row.outputSourceColumn?.name),
            }
          : row,
      ),
    );
    this.closeRenameDialog();
    this.previewValidated.set(false);
    this.validateRows();
  }

  closeRenameDialog(): void {
    this.renameDialogVisible.set(false);
    this.editingRowId.set(null);
  }

  openChooserDialog(): void {
    this.chooserDialogVisible.set(true);
  }

  applyChooser(event: ColumnChooserApplyEvent): void {
    const rowsById = this.buildRowsById([...this.rows(), ...this.removedRows()]);
    const selectedRows = event.selectedColumns
      .map((column) => rowsById.get(column.columnName))
      .filter((row): row is UnionOutputRow => !!row);
    const removedRows = event.removedColumns
      .map((column) => rowsById.get(column.columnName))
      .filter((row): row is UnionOutputRow => !!row);

    this.rows.set(this.withReorderedRows(selectedRows));
    this.removedRows.set(removedRows);
    this.chooserDialogVisible.set(false);
    this.previewValidated.set(false);
    this.validateRows();
  }

  toDatasetColumns(rows: UnionOutputRow[]): DatasetColumn[] {
    return this.withReorderedRows(rows)
      .filter((row) => row.outputSourceColumn)
      .map((row, index) => {
        const sourceColumn = row.outputSourceColumn!;
        return {
          name: sourceColumn.displayName ?? this.getColumnOutputName(sourceColumn),
          alias: row.outputAlias,
          type: DatasetColumnType.SIMPLE,
          columnOrder: index + 1,
          column: sourceColumn.column,
          sourceDatasetColumnId: sourceColumn.id,
        };
      });
  }

  toColumnMappings(rows: UnionOutputRow[]): DatasetUnionColumnMapping[] {
    return this.withReorderedRows(rows)
      .filter((row) => row.outputSourceColumn?.id)
      .map((row, index) => ({
        outputSourceColumnId: row.outputSourceColumn!.id!,
        leftColumnId: row.leftColumn?.id,
        rightColumnId: row.rightColumn?.id,
        outputAlias: row.outputAlias,
        columnOrder: index + 1,
      }));
  }

  validateRows(): boolean {
    const invalidRowIds = new Set<string>();
    const validationMessages: string[] = [];
    const rows = this.withReorderedRows(this.rows());

    if (rows.length === 0) {
      validationMessages.push(this._translateService.instant('union.mapping.validation.incomplete.row'));
    }

    if (rows.some((row) => !row.outputSourceColumn)) {
      rows.filter((row) => !row.outputSourceColumn).forEach((row) => invalidRowIds.add(row.rowId));
      validationMessages.push(this._translateService.instant('union.mapping.validation.incomplete.row'));
    }

    const outputRows = rows.filter((row) => row.outputSourceColumn);
    const outputCounts = this.countOccurrences(outputRows, (row) => this.resolveRowOutputName(row));
    for (const [outputName, count] of outputCounts) {
      if (count <= 1) {
        continue;
      }

      outputRows
        .filter((row) => this.resolveRowOutputName(row) === outputName)
        .forEach((row) => invalidRowIds.add(row.rowId));
    }
    if (Array.from(outputCounts.values()).some((count) => count > 1)) {
      validationMessages.push(this._translateService.instant('union.mapping.validation.output.duplicate'));
    }

    this.rows.set(rows);
    this.invalidRowIds.set(Array.from(invalidRowIds));
    this.validationMessages.set(validationMessages);

    return validationMessages.length === 0;
  }

  showPreview(): void {
    if (!this.validateRows()) {
      this.previewValidated.set(false);
      alert(this.validationMessages().join('\n'), this._translateService.instant('error.generic'));
      return;
    }

    const rows = this.rows();
    this._wizardUnionStore.setColumns(this.toDatasetColumns(rows));
    this._wizardUnionStore.setColumnMappings(this.toColumnMappings(rows));

    const payload = this._wizardUnionStore.datasetUnionPreview();
    if (!payload) {
      this.previewValidated.set(false);
      this.previewLoading.set(false);
      return;
    }

    this.previewLoading.set(true);
    this._datasetService
      .datasetUnionPreview(payload)
      .pipe(
        take(1),
        finalize(() => this.previewLoading.set(false)),
      )
      .subscribe({
        next: (rows) => {
          this.previewValidated.set(true);
          this.previewData.set(
            new CustomStore({
              load: () => lastValueFrom(of(rows)),
            }),
          );
        },
        error: (err) => {
          this.previewValidated.set(false);
          this.notifyError(err?.error?.message ?? err?.message ?? this._translateService.instant('error.generic'));
        },
      });
  }

  isInvalidRow(row: UnionOutputRow): boolean {
    return this.invalidRowIds().includes(row.rowId);
  }

  getRowLabel(row: UnionOutputRow): string {
    if (!row.outputSourceColumn) {
      return '';
    }

    return this.resolveRowOutputName(row);
  }

  columnChooserId = (column: ConnectorMetadataPreviewColumn): string => column.columnName;

  columnChooserDisplayName = (column: ConnectorMetadataPreviewColumn | null | undefined): string => {
    if (!column) {
      return '';
    }
    const row = this.findRowByChooserColumn(column);
    return row ? this.getRowTitle(row) : column.columnName;
  };

  resolvePreviewGridColumn(dataField: string | null | undefined): UnionPreviewGridColumn | undefined {
    if (!dataField) {
      return undefined;
    }
    return this.previewGridColumns().find((column) => column.dataField === dataField);
  }

  getPreviewColumnActionsButtonIdByDataField(dataField: string | null | undefined): string {
    return `union-column-actions-${(dataField ?? 'unknown').replace(/[^A-Za-z0-9_-]/g, '_')}`;
  }

  onPreviewColumnMenuItemSelected(column: ConnectorMetadataPreviewColumn, actionId: number): void {
    switch (actionId) {
      case UNION_COLUMN_ACTION_RENAME:
        this.openRenameDialog(column);
        return;
      case UNION_COLUMN_ACTION_DELETE: {
        const row = this.findRowByChooserColumn(column);
        if (row) {
          this.removeRow(row);
        }
        return;
      }
      default:
        return;
    }
  }

  getColumnTypeMeta(column: ConnectorMetadataPreviewColumn | null | undefined): ColumnTypeMeta {
    return resolveColumnTypeMeta(column?.type ?? 'Utf8', (value) => this._dataGridColumnTypeMapper.mapType(value));
  }

  getEditingRowLabel(): string {
    const rowId = this.editingRowId();
    const row = rowId ? this.rows().find((item) => item.rowId === rowId) : undefined;
    return row ? this.getRowTitle(row) : '';
  }

  displayColumnName = (column?: DatasetColumn): string => {
    if (!column) {
      return '';
    }

    const outputName = this.getColumnOutputName(column);
    return `${outputName} (${column.displayName ?? column.name})`;
  };

  trackRow(index: number, row: UnionOutputRow): string {
    return row.rowId || `${index}`;
  }

  private findRightMatch(
    leftColumn: DatasetColumn,
    rightCols: DatasetColumn[],
    usedRightIds: Set<string>,
  ): DatasetColumn | undefined {
    const leftOutputName = this.normalizeName(this.getColumnOutputName(leftColumn));
    for (const rightColumn of rightCols) {
      if (rightColumn.id && usedRightIds.has(rightColumn.id)) {
        continue;
      }

      const rightOutputName = this.normalizeName(this.getColumnOutputName(rightColumn));
      if (rightOutputName === leftOutputName) {
        return rightColumn;
      }
    }

    return undefined;
  }

  private resolveRowOutputName(row: UnionOutputRow): string {
    const sourceColumn = row.outputSourceColumn;
    if (!sourceColumn) {
      return '';
    }

    const sourceOutputName = sourceColumn.displayName ?? this.getColumnOutputName(sourceColumn);
    return resolveDatasetColumnOutputName(sourceOutputName, row.outputAlias);
  }

  private getRowTitle(row: UnionOutputRow): string {
    const sourceColumn = row.outputSourceColumn;
    if (!sourceColumn) {
      return '';
    }

    const sourceOutputName = sourceColumn.displayName ?? this.getColumnOutputName(sourceColumn);
    if (!row.outputAlias?.trim()) {
      return sourceOutputName;
    }
    return `${row.outputAlias} (${sourceOutputName})`;
  }

  private toChooserColumn(row: UnionOutputRow): ConnectorMetadataPreviewColumn {
    const sourceColumn = row.outputSourceColumn;
    return {
      columnName: row.rowId,
      alias: row.outputAlias,
      type: this.getRowColumnType(row),
      length: sourceColumn?.column.length,
      precision: sourceColumn?.column.precision,
    };
  }

  private getRowColumnType(row: UnionOutputRow): string {
    const column = row.outputSourceColumn?.column;
    return column?.typeTargetCol ?? column?.typeOrigCol ?? 'Utf8';
  }

  private findRowByChooserColumn(column: ConnectorMetadataPreviewColumn): UnionOutputRow | undefined {
    return [...this.rows(), ...this.removedRows()].find((row) => row.rowId === column.columnName);
  }

  private buildRowsById(rows: UnionOutputRow[]): Map<string, UnionOutputRow> {
    return new Map(rows.map((row) => [row.rowId, row] as const));
  }

  private withReorderedRows(rows: UnionOutputRow[]): UnionOutputRow[] {
    return rows.map((row, index) => ({
      ...row,
      columnOrder: index + 1,
    }));
  }

  private countOccurrences<T>(items: T[], keyFn: (item: T) => string): Map<string, number> {
    const counts = new Map<string, number>();
    for (const item of items) {
      const key = keyFn(item);
      counts.set(key, (counts.get(key) || 0) + 1);
    }
    return counts;
  }

  private sortColumnsByOrder(columns: DatasetColumn[]): DatasetColumn[] {
    return [...columns].sort((a, b) => a.columnOrder - b.columnOrder);
  }

  private normalizeName(value: string): string {
    return (value ?? '').trim().toLowerCase().replace(/\s+/g, '_');
  }

  private nextRowId(): string {
    this._rowSequence += 1;
    return `union-output-row-${this._rowSequence}`;
  }

  private notifyError(message: string): void {
    notify(message, 'error', 4000);
  }

  private getColumnOutputName(column: DatasetColumn): string {
    return resolveDatasetColumnOutputName(column.name, column.alias);
  }
}
