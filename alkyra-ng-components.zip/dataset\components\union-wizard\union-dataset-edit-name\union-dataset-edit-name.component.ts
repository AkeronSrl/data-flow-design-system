import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { ChangeDetectionStrategy, Component, computed, inject, OnInit, Signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { ValueChangedEvent as TextAreaValueChangedEvent } from 'devextreme/ui/text_area';
import { ValueChangedEvent as TextBoxValueChangedEvent } from 'devextreme/ui/text_box';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';

import { WizardUnionStore } from '../+store/wizard-union.store';

@Component({
  selector: 'alk-union-dataset-edit-name',
  templateUrl: './union-dataset-edit-name.component.html',
  styleUrls: ['./union-dataset-edit-name.component.scss'],
  standalone: true,
  imports: [TiaraSuiteWizardStepComponent, DxTextBoxModule, DxTextAreaModule, TranslatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UnionDatasetEditNameComponent extends WizardStep implements OnInit {
  private readonly _translateService: TranslateService = inject(TranslateService);
  readonly _wizardUnionStore = inject(WizardUnionStore);

  ngOnInit(): void {
    const leftName = this._wizardUnionStore.leftDataset()!.name;
    const rightName = this._wizardUnionStore.rightDataset()!.name;
    const union = this._translateService.instant('union');
    this._wizardUnionStore.setName(`${union} - ${leftName} + ${rightName}`);
  }

  onNameChange(value: TextBoxValueChangedEvent): void {
    this._wizardUnionStore.setName(value.value);
  }

  onDescriptionChange(value: TextAreaValueChangedEvent): void {
    this._wizardUnionStore.setDescription(value.value);
  }

  override canGoforward: Signal<boolean> = computed(() => {
    return this._wizardUnionStore.name().length > 0;
  });
}
