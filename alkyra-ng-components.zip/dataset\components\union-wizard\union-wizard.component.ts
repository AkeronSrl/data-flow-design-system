import { TiaraSuiteWizardComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { Dataset } from '@alkyra/dataset/models/dataset.model';
import { DatasetUnionCreate } from '@alkyra/dataset/models/dataset-union.model';
import { DatasetUnionService } from '@alkyra/dataset/services/dataset-union.service';
import { Id } from '@alkyra/shared-models/id.model';
import { ChangeDetectionStrategy, Component, inject, input, OnInit, output } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';

import { WizardUnionStore } from './+store/wizard-union.store';
import { UnionColumnMappingComponent } from './union-column-mapping/union-column-mapping.component';
import { UnionColumnSelectorComponent } from './union-column-selector/union-column-selector.component';
import { UnionDatasetEditNameComponent } from './union-dataset-edit-name/union-dataset-edit-name.component';
import { UnionDatasetSelectorComponent } from './union-dataset-selector/union-dataset-selector.component';

@Component({
  selector: 'alk-union-wizard',
  templateUrl: './union-wizard.component.html',
  standalone: true,
  imports: [
    TiaraSuiteWizardComponent,
    UnionDatasetSelectorComponent,
    UnionColumnMappingComponent,
    UnionColumnSelectorComponent,
    UnionDatasetEditNameComponent,
    TranslatePipe,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [WizardUnionStore],
})
export class UnionWizardComponent implements OnInit {
  private readonly _wizardUnionStore = inject(WizardUnionStore);
  private readonly _datasetUnionService = inject(DatasetUnionService);

  onSave = output<Id>();
  onClose = output<void>();

  pipelineId = input<string | null>();
  leftDataset = input<Dataset | null>();

  ngOnInit(): void {
    this._wizardUnionStore.setLeftDataset(this.leftDataset()!);
    this._wizardUnionStore.setPipelineId(this.pipelineId()!);
  }

  complete(): void {
    const datasetUnionCreate: DatasetUnionCreate = {
      name: this._wizardUnionStore.name(),
      desc: this._wizardUnionStore.description(),
      pipelineId: this._wizardUnionStore.pipelineId()!,
      columns: this._wizardUnionStore.columns(),
      columnMappings: this._wizardUnionStore.columnMappings(),
      leftDatasetId: this._wizardUnionStore.leftDataset()!.id,
      rightDatasetId: this._wizardUnionStore.rightDataset()!.id,
    };

    this._datasetUnionService.addComplexDataset(datasetUnionCreate).subscribe((id: Id) => this.onSave.emit(id));
  }

  close(): void {
    this.onClose.emit();
  }
}
