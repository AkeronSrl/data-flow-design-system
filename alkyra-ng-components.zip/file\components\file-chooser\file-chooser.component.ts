import { TiaraSuiteSwitchBoxComponent } from '@akeron-ng/tiara-ng-suite/tiara-switch-box';
import { ScreenLockStore } from '@alkyra/screen-lock/+store/screen-lock.store';
import { UploadedFile } from '@alkyra/shared-models/uploaded-file.model';
import {
  ChangeDetectionStrategy,
  Component,
  inject,
  input,
  OnChanges,
  output,
  SimpleChanges,
  signal,
} from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import notify from 'devextreme/ui/notify';
import { ValueChangedEvent } from 'devextreme/ui/text_box';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxFileUploaderModule } from 'devextreme-angular/ui/file-uploader';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxValidatorModule } from 'devextreme-angular/ui/validator';
import { catchError, firstValueFrom, Observable, tap, throwError } from 'rxjs';

export type FileChooserMode = 'edit' | 'create';

export interface YesNoModel {
  id: string;
  caption: string;
}

export enum YesNoEnum {
  YES = 'YES',
  NO = 'NO',
}

export const YesNoElements: YesNoModel[] = [
  { id: YesNoEnum.YES, caption: 'yes' },
  { id: YesNoEnum.NO, caption: 'no' },
];

@Component({
  selector: 'alk-file-chooser',
  standalone: true,
  templateUrl: './file-chooser.component.html',
  imports: [
    TiaraSuiteSwitchBoxComponent,
    TranslatePipe,
    DxTextBoxModule,
    DxFileUploaderModule,
    DxValidatorModule,
    DxButtonModule,
  ],
  styleUrls: ['./file-chooser.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FileChooserComponent implements OnChanges {
  private readonly _screenLockStore = inject(ScreenLockStore);

  mode = input<FileChooserMode>('create');
  allowedFileExtensions = input<string>();
  value = input<string>();
  uploadLocalFileFn = input<(f: File) => Observable<UploadedFile>>();
  addFileVisible = signal<boolean>(false);

  fileUploaderIsOpen = signal(true);
  fileNameIsOpen = signal(false);
  uploadedFile = signal<UploadedFile | undefined>(undefined);

  valueHasBeenInitialized: boolean = false;

  internalValue = signal<string | undefined>(undefined);

  onFileUploaded = output<UploadedFile | undefined>();
  onFileNameChanged = output<string | undefined>();

  yesCaption: string = YesNoElements.filter((element) => element.id === YesNoEnum.YES)[0].caption;
  noCaption: string = YesNoElements.filter((element) => element.id === YesNoEnum.NO)[0].caption;

  constructor() {
    this.uploadLocalFile = this.uploadLocalFile.bind(this);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['value']?.currentValue && !this.valueHasBeenInitialized) {
      this.valueHasBeenInitialized = true;
      this.internalValue.set(changes['value'].currentValue);
      this.fileNameIsOpen.set(true);
    }
  }

  onFileNameSwitchChanged(e: boolean) {
    this.fileUploaderIsOpen.set(!e);
    if (e) {
      if (this.uploadedFile()) {
        this.onFileUploaded.emit(undefined);
        this.uploadedFile.set(undefined);
      }
    }
  }

  onFileUploaderSwitchChanged(e: boolean) {
    this.fileNameIsOpen.set(!e);
    if (e) {
      this.internalValue.set(undefined);
      this.onFileNameChanged.emit(undefined);
    }
  }

  uploadLocalFile(file: File): Promise<UploadedFile> {
    this._screenLockStore.lockScreen();
    return firstValueFrom(
      this.uploadLocalFileFn()!(file).pipe(
        tap((uploadedFile: UploadedFile) => {
          this.valueHasBeenInitialized = true;
          this.onFileUploaded.emit(uploadedFile);
          this.uploadedFile.set(uploadedFile);
          this._screenLockStore.unlockScreen();
        }),
        catchError((error) => {
          this._screenLockStore.unlockScreen();
          const errorMessage = error?.error?.message ?? error?.message ?? 'File upload failed';
          this.notifyMex(String(errorMessage), 'error', 5000);
          return throwError(() => error);
        }),
      ),
    );
  }

  fileNameChanged(e: ValueChangedEvent) {
    this.valueHasBeenInitialized = true;
    this.onFileNameChanged.emit(e.value);
  }

  fileUploadValidationCallback(e: { value: File[] }): boolean {
    if (e.value.length > 0) {
      return true;
    }
    return false;
  }

  notifyMex(message: string | undefined, type: string, displayTime: number): void {
    notify(message, type, displayTime);
  }
}
