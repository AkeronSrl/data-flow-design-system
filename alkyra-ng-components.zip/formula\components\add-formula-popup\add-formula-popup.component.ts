import { Dataset } from '@alkyra/dataset/models/dataset.model';
import {
  DatasetColumnFormula,
  DatasetColumnFormulaCreate,
  DatasetColumnFormulaUpdate,
} from '@alkyra/dataset/models/dataset-column-formula.model';
import { DatasetColumnService } from '@alkyra/dataset/services/dataset-column.service';
import { DatasetColumnFormulaService } from '@alkyra/dataset/services/dataset-column-formula.service';
import { FormulaFormModel } from '@alkyra/formula/models/formula.model';
import { Id } from '@alkyra/shared-models/id.model';
import { FailViewerComponent } from '@alkyra/ui/fail-viewer/fail-viewer.component';
import { ExpressionEditorConfig } from '@alkyra/ui/smart-expression-editor/models/expression-editor.model';
import { SmartExpressionEditorComponent } from '@alkyra/ui/smart-expression-editor/smart-expression-editor.component';
import { Component, computed, inject, input, OnInit, output, signal } from '@angular/core';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { confirm } from 'devextreme/ui/dialog';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxFormModule } from 'devextreme-angular/ui/form';
import { DxPopupModule } from 'devextreme-angular/ui/popup';
import { catchError, EMPTY, finalize, Observable, switchMap } from 'rxjs';

import { normalizeDatasetColumnAlias } from '../../../dataset/components/shared/dataset-column-alias.utils';
import { FormulaToBeValidated } from '../../models/formula-validation.model';

type FormulaPopupFormModel = FormulaFormModel & {
  originalFormulaValue?: string;
};

@Component({
  selector: 'add-formula-popup',
  standalone: true,
  imports: [
    DxButtonModule,
    DxPopupModule,
    DxFormModule,
    FailViewerComponent,
    TranslateModule,
    SmartExpressionEditorComponent,
  ],
  templateUrl: './add-formula-popup.component.html',
  styleUrl: './add-formula-popup.component.scss',
})
export class AddFormulaPopupComponent implements OnInit {
  dataset = input<Dataset | null>(null);
  columns = input<string[]>();
  existingFormula = input<DatasetColumnFormula>();
  onSavedFormula = output<void>();
  onHiddenFormula = output<void>();

  errors = signal<string[]>([]);
  isSaving = signal<boolean>(false);
  isDeleting = signal<boolean>(false);
  readonly aliasIdentifierPattern = /^[A-Za-z_]\w*$/;

  datasetColumnFormulaService = inject(DatasetColumnFormulaService);
  datasetColumnService = inject(DatasetColumnService);
  private readonly _translateService: TranslateService = inject(TranslateService);

  formula: FormulaPopupFormModel = {
    description: '',
    formulaValue: '',
  };

  formulaEditorConfig = computed<ExpressionEditorConfig>(() => ({
    dialect: 'formula',
    columns: this.columns() ?? [],
    warnOnUnknownFunctions: true,
    maxSuggestions: 20,
  }));

  ngOnInit(): void {
    const existingFormulaInput = this.existingFormula();

    if (existingFormulaInput) {
      this.formula = {
        description: existingFormulaInput.column.displayName!,
        formulaValue: existingFormulaInput.formulaValue,
        originalFormulaValue: existingFormulaInput.formulaValue,
      };
    }
  }

  saveFormula() {
    this.errors.set([]);

    const description = this.resolveFormulaDescription();
    if (!description) {
      this.errors.set([this._translateService.instant('validation.required')]);
      return;
    }
    if (!this.aliasIdentifierPattern.test(description)) {
      this.errors.set([this._translateService.instant('error.dataset.column.alias.invalid')]);
      return;
    }
    if (this.hasDuplicateDescription(description)) {
      this.errors.set([this._translateService.instant('join.column.alias.validation.error')]);
      return;
    }

    this.formula.description = description;
    const order = (this.dataset()?.columns?.length ?? 0) + 1;
    const formulaCreate: DatasetColumnFormulaCreate = <DatasetColumnFormulaCreate>{
      datasetId: this.dataset()?.id,
      description,
      transformationOrder: order,
      formulaValue: this.formula.formulaValue,
    };
    const formulaToBeValidated: FormulaToBeValidated = <FormulaToBeValidated>{
      description,
      expression: this.formula.formulaValue,
      columns: this.columns() ?? [],
    };
    this.isSaving.set(true);
    this.datasetColumnFormulaService
      .validateFormula(formulaToBeValidated)
      .pipe(
        switchMap((result) => {
          if (result.status === 'error') {
            this.errors.set([result.message]);
            return EMPTY;
          }

          return this.createOrUpdateFormula(formulaCreate);
        }),
        finalize(() => this.isSaving.set(false)),
        catchError((error) => {
          this.errors.set([this.extractErrorMessage(error)]);
          return EMPTY;
        }),
      )
      .subscribe(() => {
        this.onSavedFormula.emit();
      });
  }

  deleteFormulaColumn(): void {
    const existingFormulaInput = this.existingFormula();
    const columnId = existingFormulaInput?.column?.id;
    if (!columnId || this.isDeleting()) {
      return;
    }

    const result = confirm(this._translateService.instant('dataset.delete.confirmation'), '');
    result.then((dialogResult) => {
      if (!dialogResult) {
        return;
      }

      this.isDeleting.set(true);
      this.datasetColumnService
        .deleteDatasetColumn(columnId)
        .pipe(
          finalize(() => this.isDeleting.set(false)),
          catchError((error) => {
            this.errors.set([this.extractErrorMessage(error)]);
            return EMPTY;
          }),
        )
        .subscribe(() => {
          this.onSavedFormula.emit();
        });
    });
  }

  hiddenFormula() {
    this.onHiddenFormula.emit();
  }

  onFormulaValueChanged(newValue: string): void {
    this.formula.formulaValue = newValue ?? '';
  }

  private resolveFormulaDescription(): string | undefined {
    const normalized = normalizeDatasetColumnAlias(this.formula.description);
    if (normalized) {
      return normalized;
    }

    const existingFormulaInput = this.existingFormula();
    if (existingFormulaInput) {
      return existingFormulaInput.column.displayName ?? existingFormulaInput.column.name;
    }

    return undefined;
  }

  private hasDuplicateDescription(description: string): boolean {
    const currentName = this.existingFormula()?.column.displayName ?? this.existingFormula()?.column.name;

    return (this.columns() ?? [])
      .filter((columnName) => columnName !== currentName)
      .some((columnName) => columnName === description);
  }

  private createOrUpdateFormula(formulaCreate: DatasetColumnFormulaCreate): Observable<Id | void> {
    const existingFormulaInput = this.existingFormula();
    if (existingFormulaInput) {
      return this.updateFormula(existingFormulaInput);
    } else {
      return this.createFormula(formulaCreate);
    }
  }

  private createFormula(formulaCreate: DatasetColumnFormulaCreate): Observable<Id> {
    return this.datasetColumnFormulaService.addFormula(formulaCreate);
  }

  private updateFormula(existingTransformation: DatasetColumnFormula): Observable<void> {
    const formulaUpdate: DatasetColumnFormulaUpdate = <DatasetColumnFormulaUpdate>{
      id: existingTransformation.id,
      description: this.formula.description,
      formulaValue: this.formula.formulaValue,
    };
    return this.datasetColumnFormulaService.updateFormula(formulaUpdate);
  }

  private extractErrorMessage(error: any): string {
    const message =
      error?.error?.errorMessage ?? error?.error?.message ?? error?.error ?? error?.message ?? 'error.generic';
    return this._translateService.instant(message);
  }
}
