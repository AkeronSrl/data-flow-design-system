import { TiaraListComponent, TiaraListItemComponent, TiaraListItemSectionComponent } from '@akeron-ng/tiara-ng';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { DatasourceConnector } from '@alkyra/connector/models/datasource-connector.model';
import { RabbitMqInitializerService } from '@alkyra/infrastructure-services/rabbitmq-initializer.service';
import { Component, inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { confirm } from 'devextreme/ui/dialog';
import notify from 'devextreme/ui/notify';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxPopupModule } from 'devextreme-angular/ui/popup';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';

import { AkeronDataSourceDetailComponent } from '../datasources/data-source-wizard/data-source-edit-panel/akeron-data-source-detail/akeron-data-source-detail.component';
import { DataSourceWizardComponent } from '../datasources/data-source-wizard/data-source-wizard.component';
import { ConnectorsStore } from './+store/connectors.store';
import { EditListAdapterComponentPanel } from './edit-adapter/edit-adapter.component';

@Component({
  selector: 'app-edit-datasource',
  templateUrl: './connectors-list.component.html',
  styleUrl: './connectors-list.component.scss',
  standalone: true,
  imports: [
    DxButtonModule,
    DxPopupModule,
    TiaraListComponent,
    TiaraListItemComponent,
    TiaraListItemSectionComponent,
    TranslatePipe,
    DataSourceWizardComponent,
    EditListAdapterComponentPanel,
    AkeronDataSourceDetailComponent,
    DxScrollViewModule,
  ],
})
export class ConnectorsListComponent implements OnInit {
  _store = inject(ConnectorsStore);

  private readonly _router = inject(Router);
  private readonly _rabbitmqInitializer = inject(RabbitMqInitializerService);
  private readonly _translateService: TranslateService = inject(TranslateService);

  private readonly confirmCancellation = this._translateService.instant('confirm.cancellation');
  private readonly deleteConnection = this._translateService.instant('connection.delete');
  private readonly connectionDeletedSuccessfully = this._translateService.instant('connection.deleted.successfully');

  ngOnInit(): void {
    this._store.loadDatasource();
  }

  deleteConnector(id: string) {
    // Guard: Akeron connectors are read-only and cannot be deleted from the UI. (NAU-439)
    const connector = this._store.datasourceConnector().find((c) => c.id === id);
    if (connector && this.isAkeronConnector(connector)) {
      return;
    }
    const result = confirm(this.confirmCancellation, this.deleteConnection);
    result.then((dialogResult) => {
      if (dialogResult) {
        this._store.deleteConnection(id).subscribe({
          next: () => {
            this.notify(this.connectionDeletedSuccessfully, 'success', 4000);
          },
        });
      }
    });
  }

  isDBSelecion(): boolean {
    return this._store.datasourceIdSelected() !== undefined && this._store.datasourceIdSelected() !== '';
  }

  // ── NAU-439 helpers ──────────────────────────────────────────────────────────

  /**
   * Returns true for Akeron-provisioned connectors (read-only, opens detail popup).
   * The eye icon is shown exclusively for these rows.
   */
  isAkeronConnector(connector: DatasourceConnector): boolean {
    return connector.connectorType === ConnectorType.AKERON;
  }

  /**
   * Returns true for any connector that has been marked deprecated by the BE.
   * Covers Vulki, CSV, Excel and any future connector type that exposes deprecated via ConnectionDto base.
   * NAU-440 t65e602cb: removed the ConnectorType.VULKI constraint — now generic.
   */
  isDeprecatedVulki(connector: DatasourceConnector): boolean {
    return connector.deprecated === true;
  }

  /**
   * Opens the read-only Akeron detail popup.
   * Uses a dedicated popup separate from the generic edit popup so that no Save/Delete
   * toolbar items appear. (NAU-439)
   */
  openAkeronDetail(id: string): void {
    this._store.setDatasourceIdSelected(id);
    this._store.openAkeronDetailPopup();
  }

  closeAkeronDetailPopup(): void {
    this._store.closeAkeronDetailPopup();
    this._store.setDatasourceIdSelected(undefined);
  }

  notify(message: string | undefined, type: string, displayTime: number): void {
    notify(message, type, displayTime);
  }

  addConnector() {
    this._store.openWizard();
  }

  closeEditPopup() {
    this._store.closeEditPopup();
    this._store.loadDatasource();
  }
  closeWizard() {
    this._store.closeWizard();
    this._store.loadDatasource();
  }

  editConnector(id: string) {
    // Guard: Akeron connectors are read-only and must not be opened via the edit path. (NAU-439)
    const connector = this._store.datasourceConnector().find((c) => c.id === id);
    if (connector && this.isAkeronConnector(connector)) {
      return;
    }
    this._store.setDatasourceIdSelected(id);
    this._store.openEditPopup();
  }

  openQueryAnalyzer(id: string) {
    if (!this._rabbitmqInitializer.isConnected()) {
      this.notify(this._translateService.instant('query.analyzer.rabbitmq.unavailable'), 'error', 5000);
      return;
    }
    this._router.navigate(['/connections', id, 'query-analyzer']);
  }

  isQueryAnalyzerAvailable(connectorType: ConnectorType): boolean {
    return connectorType === ConnectorType.DATABASE || connectorType === ConnectorType.SALESFORCE;
  }

  dataSourceEdited() {
    this._store.closeEditPopup();
    this._store.loadDatasource();
    this._store.setDatasourceIdSelected(undefined);
  }
}
