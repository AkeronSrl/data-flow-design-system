import { DatasourceConnector } from '@alkyra/connector/models/datasource-connector.model';
import { ConnectorService } from '@alkyra/connector/services/connector.service';
import { DatasourceWizardStore } from '@alkyra/pages/datasources/data-source-wizard/+store/data-source-wizard.store';
import { DataSourceEditComponentInterface } from '@alkyra/pages/datasources/data-source-wizard/data-source-edit-panel/data-source-edit-component-interface';
import { DataSourceEditComponentRegistry } from '@alkyra/pages/datasources/data-source-wizard/data-source-edit-panel/datasource-edit-component-registry';
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  inject,
  OnInit,
  output,
  ViewContainerRef,
  viewChild,
} from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import notify from 'devextreme/ui/notify';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxPopupModule } from 'devextreme-angular/ui/popup';

import { ConnectorsStore } from '../+store/connectors.store';

@Component({
  selector: 'alk-edit-adapter',
  templateUrl: './edit-adapter.component.html',
  standalone: true,
  styleUrl: './edit-adapter.component.scss',
  imports: [DxPopupModule, TranslatePipe, DxButtonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [DatasourceWizardStore],
})
export class EditListAdapterComponentPanel implements OnInit, AfterViewInit {
  _storeWizard = inject(DatasourceWizardStore);
  _storeConnect = inject(ConnectorsStore);

  private readonly registry = inject(DataSourceEditComponentRegistry);
  container = viewChild('editConnectorComponentContainer', {
    read: ViewContainerRef,
  });

  private readonly _translateService: TranslateService = inject(TranslateService);
  connectorService = inject(ConnectorService);
  datasourceEditComponent: DataSourceEditComponentInterface | null = null;

  onClose = output<void>();

  ngOnInit(): void {
    this._storeWizard.resetInitialState();
    this._storeWizard.operationEdit();

    let datasourceConnectionArray: DatasourceConnector[] = this._storeConnect.datasourceConnector();
    let datasourceConnection: DatasourceConnector | undefined = datasourceConnectionArray.find(
      (item) => item.id === this._storeConnect.datasourceIdSelected(),
    );

    if (!datasourceConnection) {
      //ERRORE SOLO SE LO CANCELLANO SOTTO AL CULO?! IMPOSSIBILE?!
      alert(this._translateService.instant('datasource.list.edit.error'));
      return;
    }

    this.initDataSource(datasourceConnection);
  }

  initDataSource(datasourceConnection: DatasourceConnector) {
    this._storeWizard.setDatasourceType(datasourceConnection.type || null);

    this.connectorService
      .findConnector(datasourceConnection.id!, datasourceConnection.connectorType)
      .subscribe((connector) => {
        this._storeWizard.setConnectorWorkaround(connector);
      });
  }

  ngAfterViewInit(): void {
    const dsType = this._storeWizard.datasourceType()!;
    const componentType = this.registry.getComponent(dsType);
    if (!componentType) {
      return;
    }

    let containerComponent = this.container();
    if (!containerComponent) {
      return;
    }

    containerComponent.clear();
    const cmpRef = containerComponent.createComponent<DataSourceEditComponentInterface>(componentType);
    this.datasourceEditComponent = cmpRef.instance;
  }

  close() {
    this.onClose.emit();
  }

  complete() {
    this.connectorService.updateConnector(this.datasourceEditComponent!.getConnector()()!).subscribe({
      next: () => {
        this.onClose.emit();
        notify({
          message: this._translateService.instant('connection.saved.successfully'),
          type: 'success',
          displayTime: 3000,
        });
      },
      error: (err) => notify({ message: err.message ?? err, type: 'error', displayTime: 3000 }),
    });
  }
}
