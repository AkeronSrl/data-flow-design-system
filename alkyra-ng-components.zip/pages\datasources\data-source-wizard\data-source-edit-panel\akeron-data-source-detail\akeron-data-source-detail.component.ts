import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import {
  AkeronConnectionTestResult,
  AkeronConnector,
  AkeronSchemaDiscoveryResponse,
} from '@alkyra/akeron-connector/models/akeron-connector.model';
import { AkeronConnectorService } from '@alkyra/akeron-connector/services/akeron-connector.service';
import { ConnectorUnionType } from '@alkyra/connector/models/connector-type.model';
import { ScreenLockStore } from '@alkyra/screen-lock/+store/screen-lock.store';
import { mapAkeronExportDiscoveryToNodes } from '@alkyra/ui/schema-discovery/mappers/akeron-export-schema-discovery.mapper';
import { SchemaDiscoveryNode } from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import { ChangeDetectionStrategy, Component, computed, inject, OnInit, Signal, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxFormModule } from 'devextreme-angular/ui/form';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { catchError, of, switchMap, tap } from 'rxjs';

import { ConnectorsStore } from '../../../../connectors-list/+store/connectors.store';
import { DataSourceEditComponentInterface } from '../data-source-edit-component-interface';

/**
 * Read-only detail popup for an Akeron-provisioned connector.
 *
 * Layout (NAU-439 mockup REV — homogeneous with VulkiDataSourceEditComponent):
 *   Two-panel layout (.vulki-editor flex row):
 *     LEFT  — dx-form (readOnly:true), tiara-name-description-label labels,
 *              single "Test connessione" toolbar button.
 *     RIGHT — tiara-circular-illustration empty state → global test result banner +
 *              alk-schema-discovery tree (after the single button run).
 *
 * The single "Test connessione" button runs the connection test first; on success it also
 * triggers schema discovery and shows both results together in the right panel.
 *
 * Implements DataSourceEditComponentInterface as a sibling of VulkiDataSourceEditComponent.
 * No editable fields, no Save/Delete.
 *
 * CONTRACT NOTE — "Database Name" (mockup field absent from real API):
 *   The live backend DTO (verified against masterdata :8085, NAU-440) does NOT expose
 *   low-level db-config fields (host/port/user/name).
 *   Only description / apiEndpoint / username / dbId are available.
 *   `dbId` (logical Vulki database id) is shown as read-only "Environment" field (NAU-440 tef563fbf).
 *   Product field removed from UI (NAU-439 UI fix).
 */
@Component({
  selector: 'alk-akeron-data-source-detail',
  templateUrl: './akeron-data-source-detail.component.html',
  styleUrl: './akeron-data-source-detail.component.scss',
  standalone: true,
  imports: [
    DxFormModule,
    DxButtonModule,
    DxScrollViewModule,
    DxLoadIndicatorModule,
    TiaraCircularIllustrationComponent,
    TiaraNameDescriptionLabelComponent,
    SchemaDiscoveryComponent,
    TranslatePipe,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AkeronDataSourceDetailComponent implements OnInit, DataSourceEditComponentInterface {
  private readonly _akeronService = inject(AkeronConnectorService);
  private readonly _connectorsStore = inject(ConnectorsStore);
  private readonly _screenLockStore = inject(ScreenLockStore);
  private readonly _translateService = inject(TranslateService);

  // ── State ───────────────────────────────────────────────────────────────────

  readonly connector = signal<AkeronConnector | null>(null);
  readonly isLoading = signal(false);
  readonly loadError = signal<string | null>(null);

  // Test connection state
  readonly isTestLoading = signal(false);
  readonly testResult = signal<AkeronConnectionTestResult | null>(null);
  readonly testHasRun = signal(false);

  // Schema Discovery state (shown inline below test results after a successful test)
  readonly isDiscoveryLoading = signal(false);
  readonly discoveryNodes = signal<SchemaDiscoveryNode[]>([]);

  readonly isTestSuccess = computed(() => this.testHasRun() && this.testResult()?.status === 'SUCCESS');
  readonly isTestFailed = computed(() => this.testHasRun() && this.testResult()?.status !== 'SUCCESS');

  // ── Lifecycle ───────────────────────────────────────────────────────────────

  ngOnInit(): void {
    const id = this._connectorsStore.datasourceIdSelected();
    if (!id) {
      this.loadError.set('Nessun connettore selezionato.');
      return;
    }

    this.isLoading.set(true);
    this._akeronService
      .findConnector(id)
      .pipe(
        catchError(() => {
          this.loadError.set('Impossibile caricare i dettagli del connettore.');
          this.isLoading.set(false);
          return of(null);
        }),
      )
      .subscribe((conn) => {
        this.connector.set(conn);
        this.isLoading.set(false);
      });
  }

  // ── Actions ─────────────────────────────────────────────────────────────────

  /**
   * Single entry-point: runs the connection test then, on SUCCESS, triggers schema discovery.
   * Both results are shown together in the right panel.
   */
  runTestAndDiscovery(): void {
    const id = this._connectorsStore.datasourceIdSelected();
    if (!id) return;

    // Reset state for a fresh run
    this.isTestLoading.set(true);
    this.testHasRun.set(false);
    this.testResult.set(null);
    this.discoveryNodes.set([]);

    this._akeronService
      .testConnection(id)
      .pipe(
        catchError(() =>
          of({
            status: 'UNKNOWN_ERROR' as const,
            message: this._translateService.instant('connection.test.failed'),
            serviceResults: [],
          }),
        ),
        tap((result) => {
          this.testResult.set(result);
          this.testHasRun.set(true);
          this.isTestLoading.set(false);

          if (result.status === 'SUCCESS') {
            this._screenLockStore.unlockScreen({
              message: this._translateService.instant('connection.test.success'),
              status: 'success',
            });
          } else {
            this._screenLockStore.unlockScreen({
              message: result.message ?? this._translateService.instant('connection.test.failed'),
              status: 'error',
            });
          }
        }),
        switchMap((result) => {
          if (result.status !== 'SUCCESS') {
            return of<AkeronSchemaDiscoveryResponse>({ services: [] });
          }
          // Run discovery only on successful test
          this.isDiscoveryLoading.set(true);
          return this._akeronService.exportDiscovery(id).pipe(
            catchError(() => {
              this.isDiscoveryLoading.set(false);
              return of<AkeronSchemaDiscoveryResponse>({ services: [] });
            }),
          );
        }),
      )
      .subscribe((response) => {
        if (response) {
          const nodes = mapAkeronExportDiscoveryToNodes(response);
          this.discoveryNodes.set(nodes);
          this.isDiscoveryLoading.set(false);
        }
      });
  }

  // ── DataSourceEditComponentInterface ────────────────────────────────────────

  /**
   * Returns null — Akeron connectors are read-only; there is nothing to save.
   * The caller (EditListAdapterComponentPanel) must not invoke updateConnector for AKERON.
   */
  getConnector(): Signal<ConnectorUnionType | null> {
    return signal(null);
  }
}
