import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import { AmazonSqsConnector } from '@alkyra/amazon-sqs-connector/models/amazon-sqs-connector.model';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { Component, inject, OnInit, Signal, signal } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxFormModule } from 'devextreme-angular/ui/form';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';

import { DatasourceWizardStore } from '../../+store/data-source-wizard.store';
import { DataSourceEditComponentInterface } from '../data-source-edit-component-interface';
import { AmazonSqsEditStore } from './+store/amazon-sqs-edit.store';

@Component({
  selector: 'alk-amazon-sqs-edit',
  templateUrl: './amazon-sqs-edit.component.html',
  styleUrls: ['./amazon-sqs-edit.component.scss'],
  standalone: true,
  imports: [
    DxScrollViewModule,
    DxFormModule,
    DxButtonModule,
    DxLoadIndicatorModule,
    TranslatePipe,
    DxTextAreaModule,
    TiaraNameDescriptionLabelComponent,
  ],
  providers: [AmazonSqsEditStore],
})
export class AmazonSqsEditComponent implements OnInit, DataSourceEditComponentInterface {
  readonly _dsWizardStore = inject(DatasourceWizardStore);
  readonly _store = inject(AmazonSqsEditStore);
  readonly activeEditor = signal<'sample' | 'schema'>('sample');
  private readonly previewInvalidatingFields = ['awsRegion', 'accessKey', 'secretKey', 'queueUrl'] as const;
  private connectionFieldCache: Record<string, string> = {
    awsRegion: '',
    accessKey: '',
    secretKey: '',
    queueUrl: '',
  };

  amazonConnector = this._dsWizardStore.amazonSqsConnector;

  get preview() {
    return this._store.preview();
  }

  get isGeneratingSchema() {
    return this._store.isGeneratingSchema();
  }

  get isButtonPreviewEnabled() {
    const conn = this.amazonConnector();
    if (!conn) return false;

    const requiredFields = [conn.awsRegion, conn.accessKey, conn.secretKey, conn.queueUrl];

    return requiredFields.every((field) => !!field && field.trim() !== '');
  }

  ngOnInit(): void {
    if (this._dsWizardStore.operazione() === 'CREATE') {
      let amazonSqsConnector: AmazonSqsConnector = {
        connectorType: ConnectorType.AMAZON_SQS,
        description: '',
        awsRegion: '',
        accessKey: '',
        secretKey: '',
        queueUrl: '',
        payloadSchema: '',
        payloadSample: '',
      };
      this._dsWizardStore.setAmazonConnector(amazonSqsConnector);
    }

    this.syncConnectionFieldCache();
  }

  onTestConnection(): void {
    this._store.testPreviewConnection(this.amazonConnector()!);
  }

  onFieldDataChanged(event: any) {
    const field = event?.dataField as (typeof this.previewInvalidatingFields)[number] | undefined;
    if (!field || !this.previewInvalidatingFields.includes(field)) return;

    const newValue = (event?.value ?? '') as string;
    const previousValue = this.connectionFieldCache[field];
    const hasChanged = previousValue !== newValue;

    this.connectionFieldCache[field] = newValue;

    if (hasChanged) {
      this._store.clearPreview();
    }
  }

  getConnector(): Signal<AmazonSqsConnector | null> {
    return this._dsWizardStore.amazonSqsConnector;
  }

  onPayloadSampleChanged(payloadSample: string) {
    this._dsWizardStore.setAmazonConnector({
      ...this.amazonConnector()!,
      payloadSample: payloadSample,
    });
  }

  onPayloadSchemaChanged(payloadSchema: string) {
    this._dsWizardStore.setAmazonConnector({
      ...this.amazonConnector()!,
      payloadSchema: payloadSchema,
    });
  }

  copyPreviewToSample(): void {
    if (!this.preview) {
      return;
    }

    const connector = this.amazonConnector();
    if (!connector) {
      return;
    }

    this.syncConnectionFieldCache();

    this._dsWizardStore.setAmazonConnector({
      ...connector,
      payloadSample: this.preview,
    });

    this.activeEditor.set('sample');
  }

  generateSchemaFromSample(): void {
    const connector = this.amazonConnector();
    if (!connector) return;

    const payloadSample = connector.payloadSample ?? '';
    if (!payloadSample.trim()) return;

    this._store.generateSchemaFromSample(payloadSample).subscribe({
      next: (payloadSchema) => {
        const updatedConnector = this.amazonConnector();
        if (!updatedConnector) return;

        this._dsWizardStore.setAmazonConnector({
          ...updatedConnector,
          payloadSchema,
        });

        this.activeEditor.set('schema');
      },
      error: (error) => console.error('Error generating schema from sample', error),
    });
  }

  switchEditor(tab: 'sample' | 'schema') {
    this.activeEditor.set(tab);
  }

  private syncConnectionFieldCache() {
    const connector = this.amazonConnector();
    if (!connector) return;

    this.previewInvalidatingFields.forEach((field) => {
      this.connectionFieldCache[field] = (connector as any)[field] ?? '';
    });
  }
}
