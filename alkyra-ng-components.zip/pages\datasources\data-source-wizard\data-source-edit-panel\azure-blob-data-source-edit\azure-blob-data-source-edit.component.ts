import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import { TiaraSuiteTreeNode } from '@akeron-ng/tiara-ng-suite/tiara-tree-view';
import { AzureBlobAuthMode, AzureBlobConnector } from '@alkyra/azure-blob-connector/models/azure-blob-connector.model';
import { AzureBlobConnectorService } from '@alkyra/azure-blob-connector/services/azure-blob-connector.service';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { ConnectorUnionType } from '@alkyra/connector/models/connector-type.model';
import { buildSupportedCloudFileTreeNodes } from '@alkyra/dataset/components/dataset-wizard/dataset-cloud-source/cloud-supported-tree.utils';
import { FileExplorerItem } from '@alkyra/file-explorer/models/file-explorer-item.model';
import { mapCloudTreeNodesToSchemaDiscoveryNodes } from '@alkyra/ui/schema-discovery/mappers/cloud-file-schema-discovery.mapper';
import {
  SchemaDiscoveryHeaderMeta,
  SchemaDiscoveryNode,
} from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import { ChangeDetectionStrategy, Component, computed, inject, OnInit, Signal, signal } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxFormModule } from 'devextreme-angular/ui/form';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';

import { DatasourceWizardStore } from '../../+store/data-source-wizard.store';
import { DataSourceEditComponentInterface } from '../data-source-edit-component-interface';

@Component({
  selector: 'alk-azure-blob-data-source-edit',
  templateUrl: './azure-blob-data-source-edit.component.html',
  styleUrl: './azure-blob-data-source-edit.component.scss',
  standalone: true,
  imports: [
    DxFormModule,
    DxButtonModule,
    DxLoadIndicatorModule,
    DxScrollViewModule,
    TranslatePipe,
    TiaraCircularIllustrationComponent,
    TiaraNameDescriptionLabelComponent,
    SchemaDiscoveryComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AzureBlobDataSourceEditComponent implements OnInit, DataSourceEditComponentInterface {
  private static readonly DEFAULT_ENDPOINT_SUFFIX = 'core.windows.net';

  readonly _wizardStore = inject(DatasourceWizardStore);
  readonly _azureBlobConnectorService = inject(AzureBlobConnectorService);

  readonly authModes: AzureBlobAuthMode[] = ['SAS_TOKEN', 'ACCOUNT_KEY', 'CONNECTION_STRING'];
  readonly authModeEditorOptions: { items: AzureBlobAuthMode[] } = {
    items: this.authModes,
  };

  readonly azureBlobConnector = this._wizardStore.azureBlobConnector;
  readonly selectedAuthMode = signal<AzureBlobAuthMode>('SAS_TOKEN');
  readonly previewItems = signal<TiaraSuiteTreeNode<FileExplorerItem, FileExplorerItem>[]>([]);
  readonly isPreviewLoading = signal(false);
  readonly previewDisabled = signal(true);
  readonly hasPreview = computed(() => this.previewItems().length > 0);
  readonly schemaNodes = computed<SchemaDiscoveryNode[]>(() =>
    mapCloudTreeNodesToSchemaDiscoveryNodes(this.previewItems()),
  );
  readonly headerMeta = computed<SchemaDiscoveryHeaderMeta[]>(() => {
    const connector = this.azureBlobConnector();
    if (!connector) {
      return [];
    }

    return [
      { label: 'type', value: ConnectorType.AZURE_BLOB },
      ...(connector.containerName?.trim()
        ? [{ label: 'azure.blob.field.container.label', value: connector.containerName.trim() }]
        : []),
      ...(connector.description?.trim() ? [{ label: 'description', value: connector.description.trim() }] : []),
    ];
  });
  private lastSuggestedEndpoint = '';

  ngOnInit(): void {
    if (this._wizardStore.operazione() === 'CREATE' || !this._wizardStore.azureBlobConnector()) {
      const connector: AzureBlobConnector = {
        description: '',
        connectorType: ConnectorType.AZURE_BLOB,
        type: ConnectorType.AZURE_BLOB,
        authMode: 'SAS_TOKEN',
        containerName: '',
        accountName: '',
        endpointSuffix: AzureBlobDataSourceEditComponent.DEFAULT_ENDPOINT_SUFFIX,
        sasToken: '',
        accountKey: '',
        connectionString: '',
      };
      this._wizardStore.setAzureBlobConnector(connector);
    }

    const connector = this.azureBlobConnector();
    if (connector) {
      this.selectedAuthMode.set(connector.authMode);
    }
    this.updatePreviewAvailability(connector);
  }

  showPreview(): void {
    const connector = this.azureBlobConnector();

    this.isPreviewLoading.set(true);
    this._azureBlobConnectorService.connectionPreview(connector!).subscribe({
      next: (fileItems) => {
        this.previewItems.set(buildSupportedCloudFileTreeNodes(fileItems ?? []));
      },
      error: () => {
        this.previewItems.set([]);
        this.isPreviewLoading.set(false);
      },
      complete: () => {
        this.isPreviewLoading.set(false);
      },
    });
  }

  onFieldChange(event: any): void {
    const connector = this.azureBlobConnector();
    if (!connector) {
      this.previewDisabled.set(true);
      return;
    }

    if (event.dataField === 'authMode') {
      const nextMode = event.value as AzureBlobAuthMode;
      if (nextMode !== this.selectedAuthMode()) {
        connector.authMode = nextMode;
        this.selectedAuthMode.set(nextMode);
        this.resetCredentialFields(connector, nextMode);
      }
    }
    if (event.dataField === 'accountName') {
      this.autoSuggestEndpoint(connector, event.value as string);
    }

    this.updatePreviewAvailability(connector);
  }

  getConnector(): Signal<ConnectorUnionType | null> {
    return this._wizardStore.azureBlobConnector;
  }

  private resetCredentialFields(connector: AzureBlobConnector, authMode: AzureBlobAuthMode): void {
    switch (authMode) {
      case 'SAS_TOKEN':
        connector.accountKey = '';
        connector.connectionString = '';
        break;
      case 'ACCOUNT_KEY':
        connector.sasToken = '';
        connector.connectionString = '';
        break;
      case 'CONNECTION_STRING':
        connector.accountName = '';
        connector.sasToken = '';
        connector.accountKey = '';
        break;
    }
  }

  private autoSuggestEndpoint(connector: AzureBlobConnector, rawAccountName: string): void {
    const accountName = rawAccountName?.trim() ?? '';
    const endpointValue = connector.endpointSuffix?.trim() ?? '';
    const canSuggest =
      endpointValue.length === 0 ||
      endpointValue === AzureBlobDataSourceEditComponent.DEFAULT_ENDPOINT_SUFFIX ||
      endpointValue === this.lastSuggestedEndpoint;

    if (!accountName) {
      if (canSuggest) {
        connector.endpointSuffix = AzureBlobDataSourceEditComponent.DEFAULT_ENDPOINT_SUFFIX;
        this.lastSuggestedEndpoint = '';
      }
      return;
    }

    if (!canSuggest) {
      return;
    }

    const suggestedEndpoint = `https://${accountName}.blob.core.windows.net`;
    connector.endpointSuffix = suggestedEndpoint;
    this.lastSuggestedEndpoint = suggestedEndpoint;
  }

  private updatePreviewAvailability(connector: AzureBlobConnector | null = this.azureBlobConnector()): void {
    if (!connector) {
      this.previewDisabled.set(true);
      return;
    }

    const requiredFields = this.getRequiredFields(connector.authMode);
    const canPreview = requiredFields.every((field) => {
      const value = connector[field];
      return typeof value === 'string' && value.trim().length > 0;
    });
    this.previewDisabled.set(!canPreview);
  }

  private getRequiredFields(mode: AzureBlobAuthMode): Array<keyof AzureBlobConnector> {
    switch (mode) {
      case 'SAS_TOKEN':
        return ['accountName', 'containerName', 'sasToken'];
      case 'ACCOUNT_KEY':
        return ['accountName', 'containerName', 'accountKey'];
      case 'CONNECTION_STRING':
        return ['containerName', 'connectionString'];
    }
  }
}
