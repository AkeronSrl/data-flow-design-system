import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import { BusinessCentralConnectionTestResult } from '@alkyra/business-central-connector/models/business-central-connection-test-result.model';
import { BusinessCentralConnector } from '@alkyra/business-central-connector/models/business-central-connector.model';
import { BusinessCentralConnectorService } from '@alkyra/business-central-connector/services/business-central-connector.service';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { ConnectorUnionType } from '@alkyra/connector/models/connector-type.model';
import {
  mapRestApiResourcesToPreviewItems,
  mapRestApiResourcesToSchemaDiscoveryNodes,
} from '@alkyra/ui/schema-discovery/mappers/rest-api-schema-discovery.mapper';
import {
  SchemaDiscoveryHeaderMeta,
  SchemaDiscoveryNode,
} from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import { ChangeDetectionStrategy, Component, computed, inject, OnInit, Signal, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import notify from 'devextreme/ui/notify';
import { DxAccordionModule } from 'devextreme-angular/ui/accordion';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxFormModule } from 'devextreme-angular/ui/form';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';

import { DatasourceWizardStore } from '../../+store/data-source-wizard.store';
import { DataSourceEditComponentInterface } from '../data-source-edit-component-interface';

@Component({
  selector: 'alk-business-central-data-source-edit',
  templateUrl: './business-central-data-source-edit.component.html',
  styleUrl: './business-central-data-source-edit.component.scss',
  standalone: true,
  imports: [
    DxFormModule,
    DxButtonModule,
    DxScrollViewModule,
    DxLoadIndicatorModule,
    DxAccordionModule,
    DxTextBoxModule,
    TranslatePipe,
    TiaraCircularIllustrationComponent,
    TiaraNameDescriptionLabelComponent,
    SchemaDiscoveryComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BusinessCentralDataSourceEditComponent implements OnInit, DataSourceEditComponentInterface {
  private readonly _wizardStore = inject(DatasourceWizardStore);
  private readonly _businessCentralConnectorService = inject(BusinessCentralConnectorService);
  private readonly _translateService = inject(TranslateService);

  readonly businessCentralConnector = this._wizardStore.businessCentralConnector;
  readonly isTestLoading = signal(false);
  readonly testHasRun = signal(false);
  readonly testResult = signal<BusinessCentralConnectionTestResult | null>(null);
  readonly testDisabled = computed(() => !this.canTestConnection(this.businessCentralConnector()));
  readonly schemaNodes = computed<SchemaDiscoveryNode[]>(() =>
    mapRestApiResourcesToSchemaDiscoveryNodes(this.testResult()?.resources ?? []),
  );
  readonly previewItems = computed(() => mapRestApiResourcesToPreviewItems(this.testResult()?.resources ?? []));
  readonly headerMeta = computed<SchemaDiscoveryHeaderMeta[]>(() => {
    const connector = this.businessCentralConnector();
    if (!connector) {
      return [];
    }

    return [
      { label: this._translateService.instant('type'), value: ConnectorType.BUSINESS_CENTRAL },
      ...(connector.description?.trim()
        ? [{ label: this._translateService.instant('description'), value: connector.description.trim() }]
        : []),
    ];
  });
  private ignoreFieldChanges = false;

  ngOnInit(): void {
    if (this._wizardStore.operazione() === 'CREATE') {
      const connector: BusinessCentralConnector = {
        description: '',
        connectorType: ConnectorType.BUSINESS_CENTRAL,
        type: ConnectorType.BUSINESS_CENTRAL,
        tenantId: '',
        environmentName: '',
        clientId: '',
        clientSecret: '',
        apiRoute: 'api/v2.0',
      };
      this._wizardStore.setBusinessCentralConnector(connector);
    }
  }

  testConnection(): void {
    const connector = this.businessCentralConnector();
    if (!connector || this.isTestLoading()) return;

    this.isTestLoading.set(true);
    this.testHasRun.set(false);
    this.testResult.set(null);
    this._businessCentralConnectorService.testConnection(connector).subscribe({
      next: (result) => {
        this.testHasRun.set(true);
        this.testResult.set(result);
        const failureMessage = !result.authenticationSuccess
          ? result.authenticationMessage
          : !result.connectionSuccess
            ? result.connectionMessage
            : result.resourceDiscoverySuccess === false
              ? result.resourceDiscoveryMessage
              : null;

        if (failureMessage) {
          notify(failureMessage, 'error', 5000);
          return;
        }
        notify(this._translateService.instant('connection.test.success'), 'success', 3000);
      },
      error: () => {
        this.testHasRun.set(true);
        this.testResult.set(null);
        notify(this._translateService.instant('connection.test.failed'), 'error', 5000);
      },
      complete: () => {
        this.isTestLoading.set(false);
      },
    });
  }

  onFieldChange(event: any): void {
    if (this.ignoreFieldChanges) {
      return;
    }

    const fieldName = event?.dataField as keyof BusinessCentralConnector | undefined;
    if (!fieldName) {
      return;
    }

    const connector = this.businessCentralConnector();
    if (!connector) {
      return;
    }

    this.ignoreFieldChanges = true;
    const updatedConnector: BusinessCentralConnector = {
      ...connector,
      [fieldName]: event.value,
    };
    if (fieldName === 'companyId') {
      updatedConnector.companyName = undefined;
    }

    this._wizardStore.setBusinessCentralConnector(updatedConnector);
    queueMicrotask(() => {
      this.ignoreFieldChanges = false;
    });

    if (fieldName !== 'description') {
      this.clearTestResult();
    }
  }

  onManualFieldChange(field: keyof BusinessCentralConnector, value: unknown): void {
    const connector = this.businessCentralConnector();
    if (!connector) return;

    const updatedConnector: BusinessCentralConnector = {
      ...connector,
      [field]: value as never,
    };
    if (field === 'companyId') {
      updatedConnector.companyName = undefined;
    }

    this._wizardStore.setBusinessCentralConnector(updatedConnector);

    if (field !== 'description') {
      this.clearTestResult();
    }
  }

  getConnector(): Signal<ConnectorUnionType | null> {
    return this._wizardStore.businessCentralConnector as Signal<ConnectorUnionType | null>;
  }

  private clearTestResult(): void {
    this.testHasRun.set(false);
    this.testResult.set(null);
  }

  private canTestConnection(connector: BusinessCentralConnector | null): boolean {
    return (
      !!connector &&
      this.hasAllValues(
        connector.tenantId,
        connector.environmentName,
        connector.clientId,
        connector.clientSecret,
        connector.companyId,
        connector.apiRoute,
      )
    );
  }

  private hasAllValues(...values: unknown[]): boolean {
    return values.every((value) => this.hasValue(value));
  }

  private hasValue(value: unknown): boolean {
    if (typeof value !== 'string') {
      return false;
    }
    return value.trim().length > 0;
  }
}
