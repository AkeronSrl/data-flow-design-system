import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { CsvConnector } from '@alkyra/csv-connector/models/csv-connector.model';
import { CsvConnectorService } from '@alkyra/csv-connector/services/csv-connector.service';
import { FileChooserComponent, FileChooserMode } from '@alkyra/file/components/file-chooser/file-chooser.component';
import { UploadedFile } from '@alkyra/shared-models/uploaded-file.model';
import { ChangeDetectionStrategy, Component, inject, OnInit, Signal } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import notify from 'devextreme/ui/notify';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxCheckBoxModule } from 'devextreme-angular/ui/check-box';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxFormModule } from 'devextreme-angular/ui/form';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTreeViewModule } from 'devextreme-angular/ui/tree-view';

import { DatasourceWizardStore } from '../../+store/data-source-wizard.store';
import { DataSourceEditComponentInterface } from '../data-source-edit-component-interface';
import { CsvDatasourceStore } from './+store/csv-data-source-edit.store';

@Component({
  selector: 'alk-csv-data-source-edit',
  templateUrl: './csv-data-source-edit.component.html',
  standalone: true,
  styleUrl: './csv-data-source-edit.component.scss',
  imports: [
    DxFormModule,
    DxButtonModule,
    DxSelectBoxModule,
    DxTreeViewModule,
    DxCheckBoxModule,
    TranslatePipe,
    DxTreeViewModule,
    TiaraCircularIllustrationComponent,
    DxScrollViewModule,
    FileChooserComponent,
    DxDataGridModule,
    TiaraNameDescriptionLabelComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CsvDataSourceEditComponent implements OnInit, DataSourceEditComponentInterface {
  _wizardStore = inject(DatasourceWizardStore);
  _store = inject(CsvDatasourceStore);

  csvConnectorService: CsvConnectorService = inject(CsvConnectorService);

  uploadLocalFileFn = (file: File) => this.csvConnectorService.uploadFile(file);

  allowedFileExtensions = ['.txt', '.csv'].join(',');

  csvConnector = this._wizardStore.csvConnector;

  filechooserMode: FileChooserMode = 'edit';

  previewDisabled = this._store.previewDisabled;
  isShowingPreview = false;
  previewData = this._store.preview;

  ngOnInit() {
    this._store.resetInitialState();

    if (this._wizardStore.operazione() === 'CREATE') {
      // SONO IN CREAZIONE E TUTTE LE VOLTE NE VOLGIO PARTIRE DA PULITO
      let conn: CsvConnector = <CsvConnector>{
        description: '',
        fileName: '',
        hasHeader: false,
        separator: ',',
        textQualifier: '"',
        connectorType: ConnectorType.CSV,
      };
      this._wizardStore.setCsvConnector(conn);
      this.filechooserMode = 'create';
    } else {
      this._store.clearPreview(this._wizardStore.csvConnector());
      this._store.setIsPreviewExecuted(false);
    }
  }

  showPreview() {
    if (this.isShowingPreview) return;
    this.isShowingPreview = true;
    this._store.loadPreview(this._wizardStore.csvConnector(), this._store.fileUploaded());
    this.isShowingPreview = false;
  }

  notifyMex(message: string | undefined, type: string, displayTime: number): void {
    notify(message, type, displayTime);
  }

  onFieldChange(event: any) {
    if (event.dataField !== 'description') {
      this._store.clearPreview(this._wizardStore.csvConnector());
      this._store.setIsPreviewExecuted(false);
    }
  }

  onFileNameChanged(fileName: string | undefined) {
    this._store.setFileUploaded(false);
    this.updateFileName(fileName!);
  }

  onFileUploaded(uploadedFile: UploadedFile | undefined) {
    this._store.setFileUploaded(true);
    this.updateFileName(uploadedFile!.fileName);
  }

  updateFileName(fileName: string) {
    const csvConnector = this._wizardStore.csvConnector();
    csvConnector!.fileName = fileName;
    this._wizardStore.setCsvConnector(csvConnector!);
    this._store.clearPreview(csvConnector);
    this._store.setIsPreviewExecuted(false);
  }

  getConnector(): Signal<CsvConnector | null> {
    return this._wizardStore.csvConnector;
  }
}
