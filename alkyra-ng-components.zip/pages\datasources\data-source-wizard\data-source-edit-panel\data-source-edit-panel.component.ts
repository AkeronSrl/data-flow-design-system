import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  ViewContainerRef,
  viewChild,
} from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxFormModule } from 'devextreme-angular/ui/form';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTreeViewModule } from 'devextreme-angular/ui/tree-view';

import { DatasourceWizardStore } from '../+store/data-source-wizard.store';
import { DataSourceEditComponentInterface } from './data-source-edit-component-interface';
import { DataSourceEditComponentRegistry } from './datasource-edit-component-registry';

@Component({
  selector: 'alk-data-source-edit-step',
  templateUrl: './data-source-edit-panel.component.html',
  standalone: true,
  styleUrl: './data-source-edit-panel.component.scss',
  imports: [DxFormModule, DxButtonModule, DxSelectBoxModule, DxTreeViewModule, TiaraSuiteWizardStepComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DataSourceEditComponentPanel extends WizardStep implements AfterViewInit {
  _store = inject(DatasourceWizardStore);

  private readonly registry = inject(DataSourceEditComponentRegistry);
  container = viewChild('editConnectorComponentContainer', {
    read: ViewContainerRef,
  });

  datasourceEditComponent: DataSourceEditComponentInterface | null = null;

  private readonly _translateService: TranslateService = inject(TranslateService);

  title = computed(() => {
    switch (this._store.datasourceType()) {
      case 'CSV':
        return this._translateService.instant('file.create.title');
      case 'EXCEL':
        return this._translateService.instant('file.create.title');
      case 'S3_BUCKET':
        return this._translateService.instant('datasource.amazon.s3.create.title');
      case 'AZURE_BLOB':
        return this._translateService.instant('datasource.azure.blob.create.title');
      case 'AMAZON_SQS':
        return this._translateService.instant('datasource.amazon.sqs.create.title');
      default:
        return this._translateService.instant('connection.create.title');
    }
  });

  subTitle = computed(() => {
    switch (this._store.datasourceType()) {
      case 'CSV':
        return this._translateService.instant('file.create.subtitle');
      case 'EXCEL':
        return this._translateService.instant('file.create.subtitle');
      case 'S3_BUCKET':
        return this._translateService.instant('datasource.amazon.s3.create.subtitle');
      case 'AZURE_BLOB':
        return this._translateService.instant('datasource.azure.blob.create.subtitle');
      case 'AMAZON_SQS':
        return this._translateService.instant('datasource.amazon.sqs.create.subtitle');
      default:
        return this._translateService.instant('connection.create.subtitle');
    }
  });

  ngAfterViewInit(): void {
    const dsType = this._store.datasourceType()!;
    const componentType = this.registry.getComponent(dsType);
    if (!componentType) {
      return;
    }

    let containerComponent = this.container();
    if (!containerComponent) {
      return;
    }

    containerComponent.clear();
    const cmpRef = containerComponent.createComponent<DataSourceEditComponentInterface>(componentType);
    this.datasourceEditComponent = cmpRef.instance;
  }

  override onForward(): void {
    if (this.datasourceEditComponent) {
      const connector = this.datasourceEditComponent.getConnector();
      this._store.setConnector(connector()!);
    }
  }
}
