import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { ConnectorMetadataColumn } from '@alkyra/connector/models/connector-metadata-column.model';
import { DBMSType } from '@alkyra/connector/models/dbms-type.model';
import { DatabaseConnector } from '@alkyra/database-connector/models/database-connector.model';
import { DatabaseSourceMetadata } from '@alkyra/database-connector/models/database-source-metadata.model';
import { DatabaseConnectorService } from '@alkyra/database-connector/services/database-connector.service';
import {
  DatabaseSchemaDiscoveryLabels,
  DatabaseSchemaState,
  mapDatabaseStatesToSchemaDiscoveryNodes,
} from '@alkyra/ui/schema-discovery/mappers/database-schema-discovery.mapper';
import {
  SchemaDiscoveryHeaderMeta,
  SchemaDiscoveryNode,
} from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import { ChangeDetectionStrategy, Component, computed, inject, OnInit, Signal, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import notify from 'devextreme/ui/notify';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxFormModule } from 'devextreme-angular/ui/form';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { catchError, of, switchMap } from 'rxjs';

import { DatasourceWizardStore } from '../../+store/data-source-wizard.store';
import { DataSourceEditComponentInterface } from '../data-source-edit-component-interface';
import { DatabaseDatasourceStore } from './+store/database-data-source-edit.store';

@Component({
  selector: 'alk-data-source-edit',
  templateUrl: './database-data-source-edit.component.html',
  standalone: true,
  styleUrl: './database-data-source-edit.component.scss',
  imports: [
    DxFormModule,
    DxButtonModule,
    DxSelectBoxModule,
    TranslatePipe,
    TiaraCircularIllustrationComponent,
    DxScrollViewModule,
    SchemaDiscoveryComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [DatabaseDatasourceStore],
})
export class DatabaseDataSourceEditComponent implements OnInit, DataSourceEditComponentInterface {
  _wizardStore = inject(DatasourceWizardStore);
  _store = inject(DatabaseDatasourceStore);

  connection = this._wizardStore.databaseConnector;
  testConnectionDisabled = this._store.testConnectionDisabled;
  databaseConnectorService: DatabaseConnectorService = inject(DatabaseConnectorService);
  private readonly _translateService: TranslateService = inject(TranslateService);
  readonly metadataStates = signal<DatabaseSchemaState[]>([]);
  readonly schemaLabels = computed<DatabaseSchemaDiscoveryLabels>(() => ({
    tables: this._translateService.instant('query.analyzer.schema.tables'),
    views: this._translateService.instant('query.analyzer.schema.views'),
  }));
  readonly schemaNodes = computed<SchemaDiscoveryNode[]>(() =>
    mapDatabaseStatesToSchemaDiscoveryNodes(this.metadataStates(), this.schemaLabels()),
  );
  readonly headerMeta = computed<SchemaDiscoveryHeaderMeta[]>(() => {
    const connector = this.connection();
    if (!connector) {
      return [];
    }

    return [
      { label: this._translateService.instant('type'), value: ConnectorType.DATABASE },
      ...(connector.dbname?.trim()
        ? [{ label: this._translateService.instant('database.name'), value: connector.dbname.trim() }]
        : []),
      ...(connector.description?.trim()
        ? [{ label: this._translateService.instant('description'), value: connector.description.trim() }]
        : []),
    ];
  });
  isTestingConnection = false;

  ngOnInit() {
    const dbmsType = this._wizardStore.datasourceType() as DBMSType | null;
    let defaultPort: number | null = null;

    switch (dbmsType) {
      case 'POSTGRES':
        defaultPort = 5432;
        break;
      case 'SQLSERVER':
        defaultPort = 1433;
        break;
      case 'ORACLE':
        defaultPort = 1521;
        break;
      case 'SAPHANA':
        defaultPort = 39015;
        break;
    }

    if (this._wizardStore.operazione() === 'CREATE') {
      // SONO IN CREAZINE E TUTTE LE VOLTE NE VOLGIO PARTIRE DA PULITO
      let conn: DatabaseConnector = {
        host: '',
        port: defaultPort ?? 0,
        dbname: '',
        username: '',
        password: '',
        description: '',
        dbmsType: dbmsType!,
        schemaName: null,
        connectorType: ConnectorType.DATABASE,
      };
      this._wizardStore.setDatabaseConnector(conn);
    }
  }

  testConnection() {
    if (this.isTestingConnection) return;
    this.isTestingConnection = true;
    this.metadataStates.set([]);
    this._store.setIsTestingExecute(true);
    const connection = this.connection();
    if (!connection) {
      this.isTestingConnection = false;
      this._store.setIsTestingExecute(false);
      return;
    }

    this.databaseConnectorService
      .testConnection(connection)
      .pipe(switchMap(() => this._store.loadMetadata(connection)))
      .subscribe({
        next: (metadata) => {
          this.metadataStates.set(this.toSchemaStates(metadata));
          this._store.setIsTestingExecute(true);
          this.notifyMex(this._translateService.instant('datasource.test.connection.success'), 'success', 5000);
        },
        error: () => {
          this.isTestingConnection = false;
          this._store.setIsTestingExecute(false);
          this.metadataStates.set([]);
          this.notifyMex(this._translateService.instant('show.preview.error'), 'error', 5000);
        },
        complete: () => {
          this.isTestingConnection = false;
        },
      });
  }

  onNodeExpanded(event: { node: SchemaDiscoveryNode }): void {
    const resource = event.node.data;
    if (!this.isDatabaseMetadata(resource)) {
      return;
    }

    const connection = this.connection();
    if (!connection) {
      return;
    }

    const state = this.getMetadataState(resource.tableName);
    if (!state) {
      return;
    }

    this.updateMetadataState(resource.tableName, { expanded: true });

    if (state.columnsLoading || state.columnsLoaded) {
      return;
    }

    this.updateMetadataState(resource.tableName, {
      expanded: true,
      columnsLoading: true,
    });

    this.loadColumns(connection, resource.tableName).subscribe((columns) => {
      this.updateMetadataState(resource.tableName, {
        columns,
        columnsLoaded: true,
        columnsLoading: false,
        expanded: true,
      });
    });
  }

  onNodeCollapsed(event: { node: SchemaDiscoveryNode }): void {
    const resource = event.node.data;
    if (!this.isDatabaseMetadata(resource)) {
      return;
    }

    this.updateMetadataState(resource.tableName, { expanded: false });
  }

  notifyMex(message: string | undefined, type: string, displayTime: number): void {
    notify(message, type, displayTime);
  }

  onFieldChange(event: any) {
    if (event.dataField !== 'description' && event.dataField !== 'schemaName') {
      //RESETTO SOLO IN CASO DI MODIFICA DI CAMPI IMPORTANTI
      this._store.reloadConnectionTest(this._wizardStore.databaseConnector()!);
      this._store.setIsTestingExecute(false);
      this.metadataStates.set([]);
    }
  }

  getConnector(): Signal<DatabaseConnector | null> {
    return this._wizardStore.databaseConnector;
  }

  private toSchemaStates(metadata: DatabaseSourceMetadata[]): DatabaseSchemaState[] {
    return metadata.map((item) => ({
      resource: item,
      columnsLoaded: false,
      columnsLoading: false,
      expanded: false,
    }));
  }

  private getMetadataState(tableName: string): DatabaseSchemaState | undefined {
    return this.metadataStates().find((state) => state.resource.tableName === tableName);
  }

  private updateMetadataState(tableName: string, patch: Partial<DatabaseSchemaState>): void {
    this.metadataStates.update((states) =>
      states.map((state) =>
        state.resource.tableName === tableName
          ? {
              ...state,
              ...patch,
            }
          : state,
      ),
    );
  }

  private loadColumns(connection: DatabaseConnector, tableName: string) {
    const request$ = connection.id
      ? this.databaseConnectorService.columns(connection.id, tableName)
      : this.databaseConnectorService.columnsFromConnection(connection, tableName);

    return request$.pipe(catchError(() => of([] as ConnectorMetadataColumn[])));
  }

  private isDatabaseMetadata(value: unknown): value is DatabaseSourceMetadata {
    return !!value && typeof value === 'object' && 'tableName' in value;
  }
}
