import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { ExcelConnector } from '@alkyra/excel-connector/models/excel-connector.model';
import { ExcelConnectorService } from '@alkyra/excel-connector/services/excel-connector.service';
import { FileChooserComponent, FileChooserMode } from '@alkyra/file/components/file-chooser/file-chooser.component';
import { UploadedFile } from '@alkyra/shared-models/uploaded-file.model';
import { ChangeDetectionStrategy, Component, computed, inject, OnInit, Signal, signal } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import notify from 'devextreme/ui/notify';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxCheckBoxModule } from 'devextreme-angular/ui/check-box';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxFormModule } from 'devextreme-angular/ui/form';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTreeViewModule } from 'devextreme-angular/ui/tree-view';

import { DatasourceWizardStore } from '../../+store/data-source-wizard.store';
import { DataSourceEditComponentInterface } from '../data-source-edit-component-interface';
import { ExcelDatasourceStore } from './+store/excel-data-source-edit.store';

@Component({
  selector: 'alk-excel-data-source-edit',
  templateUrl: './excel-data-source-edit.component.html',
  standalone: true,
  styleUrl: './excel-data-source-edit.component.scss',
  imports: [
    DxFormModule,
    DxButtonModule,
    DxSelectBoxModule,
    DxTreeViewModule,
    DxCheckBoxModule,
    TranslatePipe,
    DxTreeViewModule,
    TiaraCircularIllustrationComponent,
    DxScrollViewModule,
    FileChooserComponent,
    DxDataGridModule,
    TiaraNameDescriptionLabelComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExcelDataSourceEditComponent implements OnInit, DataSourceEditComponentInterface {
  _wizardStore = inject(DatasourceWizardStore);
  _store = inject(ExcelDatasourceStore);

  excelConnectorService: ExcelConnectorService = inject(ExcelConnectorService);

  uploadLocalFileFn = (file: File) => this.excelConnectorService.uploadFile(file);

  allowedFileExtensions = ['.xlsx'].join(',');

  selectedSheet = signal<string | undefined>(undefined);

  filechooserMode: FileChooserMode = 'edit';

  excelConnector = this._wizardStore.excelConnector;

  previewDisabled = this._store.previewDisabled;
  isShowingPreview = false;
  previewData = this._store.preview;

  selectSheetBoxDisabled = computed(() => {
    return this._store.sheets() === null || this._store.sheets().length <= 0;
  });

  ngOnInit() {
    this._store.resetInitialState();

    if (this._wizardStore.operazione() === 'CREATE') {
      // SONO IN CREAZIONE E TUTTE LE VOLTE NE VOLGIO PARTIRE DA PULITO
      let conn: ExcelConnector = <ExcelConnector>{
        description: '',
        fileName: '',
        connectorType: ConnectorType.EXCEL,
      };
      this._wizardStore.setExcelConnector(conn);
      this.filechooserMode = 'create';
    } else {
      this._store.clearPreview(this._wizardStore.excelConnector());
      this._store.setIsPreviewExecuted(false);
    }
  }

  showPreview() {
    if (this.isShowingPreview) return;
    this.isShowingPreview = true;
    this._store.loadPreview(this._wizardStore.excelConnector(), this._store.fileUploaded());
    this.isShowingPreview = false;
  }

  notifyMex(message: string | undefined, type: string, displayTime: number): void {
    notify(message, type, displayTime);
  }

  onFieldChange(event: any) {
    if (event.dataField !== 'description') {
      this._store.clearPreview(this._wizardStore.excelConnector());
      this._store.setIsPreviewExecuted(false);
    }
  }

  onFileNameChanged(fileName: string | undefined) {
    this._store.setFileUploaded(false);
    this.updateFileName(fileName);
  }

  onFileUploaded(uploadedFile: UploadedFile | undefined) {
    this._store.setFileUploaded(true);
    this.updateFileName(uploadedFile ? uploadedFile.fileName : undefined);
  }

  updateFileName(fileName: string | undefined) {
    this.selectedSheet.set(undefined);
    const excelconnector = this._wizardStore.excelConnector();
    excelconnector!.fileName = fileName || '';
    this._wizardStore.setExcelConnector(excelconnector!);
    this._store.loadSheets(excelconnector);
    this._store.clearPreview(excelconnector);
    this._store.setIsPreviewExecuted(false);
  }

  onSheetChange(event: any) {
    this._store.setSelectedSheet(event.value);
    this._store.clearPreview(this._wizardStore.excelConnector());
    this._store.setIsPreviewExecuted(false);
  }

  getConnector(): Signal<ExcelConnector | null> {
    return this._wizardStore.excelConnector;
  }
}
