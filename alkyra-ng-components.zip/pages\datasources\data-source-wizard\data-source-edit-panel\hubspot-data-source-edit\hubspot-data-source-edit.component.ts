import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { ConnectorUnionType } from '@alkyra/connector/models/connector-type.model';
import {
  HubSpotAuthMode,
  HubSpotConnector,
  HubSpotConnectorReferenceRequest,
  HubSpotConnectorStatus,
  HubSpotOAuthCallbackResponse,
  HubSpotObjectDetailed,
} from '@alkyra/hubspot-connector/models/hubspot-connector.model';
import { HubSpotConnectorService } from '@alkyra/hubspot-connector/services/hubspot-connector.service';
import {
  HubSpotSchemaDiscoveryLabels,
  HubSpotSchemaState,
  mapHubSpotStatesToSchemaDiscoveryNodes,
} from '@alkyra/ui/schema-discovery/mappers/hubspot-schema-discovery.mapper';
import {
  SchemaDiscoveryHeaderMeta,
  SchemaDiscoveryNode,
} from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  inject,
  OnInit,
  Signal,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import notify from 'devextreme/ui/notify';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { filter, finalize, fromEvent, map, Observable, of, switchMap, tap, throwError } from 'rxjs';

import { DatasourceWizardStore } from '../../+store/data-source-wizard.store';
import { DataSourceEditComponentInterface } from '../data-source-edit-component-interface';

type HubSpotOauthMessage =
  | { type: 'hubspot-oauth-complete'; payload: HubSpotOAuthCallbackResponse }
  | { type: 'hubspot-oauth-error'; message: string };

const DEFAULT_OAUTH_SCOPES =
  'oauth crm.objects.contacts.read crm.objects.companies.read crm.objects.deals.read crm.objects.tickets.read crm.schemas.contacts.read crm.schemas.companies.read crm.schemas.deals.read crm.schemas.tickets.read crm.objects.custom.read crm.schemas.custom.read';

@Component({
  selector: 'alk-hubspot-data-source-edit',
  templateUrl: './hubspot-data-source-edit.component.html',
  styleUrl: './hubspot-data-source-edit.component.scss',
  standalone: true,
  imports: [
    DxButtonModule,
    DxLoadIndicatorModule,
    DxScrollViewModule,
    DxSelectBoxModule,
    DxTextAreaModule,
    DxTextBoxModule,
    TranslatePipe,
    TiaraCircularIllustrationComponent,
    TiaraNameDescriptionLabelComponent,
    SchemaDiscoveryComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HubSpotDataSourceEditComponent implements OnInit, DataSourceEditComponentInterface {
  private readonly _wizardStore = inject(DatasourceWizardStore);
  private readonly _hubSpotConnectorService = inject(HubSpotConnectorService);
  private readonly _translateService = inject(TranslateService);
  private readonly _destroyRef = inject(DestroyRef);

  readonly connection = this._wizardStore.hubspotConnector;
  readonly isPersisting = signal(false);
  readonly isTestingConnection = signal(false);
  readonly isOauthConnecting = signal(false);
  readonly isPreviewLoading = signal(false);
  readonly testHasRun = signal(false);
  readonly objects = signal<HubSpotSchemaState[]>([]);
  private oauthPopupPollHandle: ReturnType<typeof setInterval> | null = null;

  readonly authModeOptions = computed(() => [
    {
      value: HubSpotAuthMode.PRIVATE_APP_TOKEN,
      label: this._translateService.instant('hubspot.auth.mode.private.app.token'),
    },
    {
      value: HubSpotAuthMode.OAUTH_AUTHORIZATION_CODE,
      label: this._translateService.instant('hubspot.auth.mode.oauth'),
    },
  ]);

  readonly showPrivateTokenField = computed(() => this.connection()?.authMode === HubSpotAuthMode.PRIVATE_APP_TOKEN);
  readonly showOauthFields = computed(() => this.connection()?.authMode === HubSpotAuthMode.OAUTH_AUTHORIZATION_CODE);
  readonly isBusy = computed(
    () => this.isPersisting() || this.isTestingConnection() || this.isOauthConnecting() || this.isPreviewLoading(),
  );
  readonly previewEmptyMessageKey = computed(() => (this.testHasRun() ? 'no.data.message' : 'hubspot.preview.empty'));
  readonly hasPreview = computed(() => this.testHasRun() || this.isTestingConnection() || this.isPreviewLoading());
  readonly testConnectionDisabled = computed(
    () => this.isBusy() || !this._hubSpotConnectorService.isConnectionTestable(this.connection()),
  );
  readonly oauthConnectDisabled = computed(() => this.isBusy() || !this.canStartOauth(this.connection()));
  readonly oauthDisconnectDisabled = computed(
    () => this.isBusy() || !this._hubSpotConnectorService.isOauthConnected(this.connection()),
  );
  readonly oauthActionLabel = computed(() =>
    this._hubSpotConnectorService.isOauthConnected(this.connection())
      ? this._translateService.instant('hubspot.oauth.actions.reconnect')
      : this._translateService.instant('hubspot.oauth.actions.connect'),
  );
  readonly currentStatusLabel = computed(() => {
    const status = this.connection()?.status ?? HubSpotConnectorStatus.DRAFT;
    return this._translateService.instant(this.toStatusTranslationKey(status));
  });
  readonly currentAccountLabel = computed(() => {
    const connector = this.connection();
    if (!connector) {
      return '';
    }

    if (connector.hubDomain && connector.hubId) {
      return `${connector.hubDomain} (Hub ID ${connector.hubId})`;
    }
    if (connector.hubDomain) {
      return connector.hubDomain;
    }
    if (connector.hubId) {
      return `Hub ID ${connector.hubId}`;
    }
    return this._translateService.instant('hubspot.oauth.status.not.connected');
  });
  readonly grantedScopesLabel = computed(() => (this.connection()?.grantedScopes ?? []).join(', '));
  readonly schemaLabels = computed<HubSpotSchemaDiscoveryLabels>(() => ({
    standardObjects: this._translateService.instant('hubspot.preview.standard.objects'),
    customObjects: this._translateService.instant('hubspot.preview.custom.objects'),
    customBadge: this._translateService.instant('hubspot.preview.custom'),
  }));
  readonly schemaNodes = computed<SchemaDiscoveryNode[]>(() =>
    mapHubSpotStatesToSchemaDiscoveryNodes(this.objects(), this.schemaLabels()),
  );
  readonly headerMeta = computed<SchemaDiscoveryHeaderMeta[]>(() => {
    const connector = this.connection();
    if (!connector) {
      return [];
    }

    return [
      { label: this._translateService.instant('type'), value: ConnectorType.HUBSPOT },
      { label: this._translateService.instant('hubspot.oauth.status.label'), value: this.currentStatusLabel() },
      ...(connector.description?.trim()
        ? [{ label: this._translateService.instant('description'), value: connector.description.trim() }]
        : []),
    ];
  });

  ngOnInit(): void {
    if (this._wizardStore.operazione() === 'CREATE' || !this.connection()) {
      this._wizardStore.setHubSpotConnector(this.createDefaultConnector());
    }

    if (typeof window !== 'undefined') {
      fromEvent<MessageEvent<HubSpotOauthMessage>>(window, 'message')
        .pipe(
          filter((event) => event.origin === window.location.origin),
          filter(
            (event) => event.data?.type === 'hubspot-oauth-complete' || event.data?.type === 'hubspot-oauth-error',
          ),
          takeUntilDestroyed(this._destroyRef),
        )
        .subscribe((event) => this.handleOauthMessage(event.data));
    }
  }

  getConnector(): Signal<ConnectorUnionType | null> {
    return this._wizardStore.hubspotConnector as Signal<ConnectorUnionType | null>;
  }

  onDescriptionValueChanged(value: string | null | undefined): void {
    this.onManualFieldChange('description', value ?? '', false);
  }

  onAuthModeChange(authMode: HubSpotAuthMode | null | undefined): void {
    const connector = this.connection();
    if (!connector) {
      return;
    }

    if (!authMode) {
      return;
    }

    if (connector.authMode === authMode) {
      return;
    }

    this.applyConnectorUpdate(
      this.resetRuntimeStateForAuthChange(this.buildConnectorForAuthMode(connector, authMode)),
      true,
    );
  }

  onManualFieldChange(field: keyof HubSpotConnector, value: unknown, authRelevant = true): void {
    const connector = this.connection();
    if (!connector) {
      return;
    }

    const nextConnector: HubSpotConnector = {
      ...connector,
      [field]: value as never,
    };
    this.applyConnectorUpdate(
      authRelevant ? this.resetRuntimeStateForAuthChange(nextConnector) : nextConnector,
      authRelevant,
    );
  }

  testConnection(): void {
    if (this.testConnectionDisabled()) {
      return;
    }

    const connector = this.connection();
    if (!connector) {
      return;
    }

    this.clearPreview();
    this.testHasRun.set(false);
    this.isTestingConnection.set(true);

    this.executeTestConnection(connector)
      .pipe(finalize(() => this.isTestingConnection.set(false)))
      .subscribe({
        next: ({ result, objects }) => {
          this.testHasRun.set(true);
          this.objects.set(this.mapObjectsToSchemaState(objects));

          if (result.success) {
            notify(this._translateService.instant('hubspot.test.connection.success'), 'success', 3000);
            return;
          }

          notify(result.message, 'error', 5000);
        },
        error: (error) => {
          this.testHasRun.set(true);
          this.clearPreview();
          notify(this.resolveErrorMessage(error, 'connection.test.failed'), 'error', 5000);
        },
      });
  }

  connectOauth(): void {
    if (this.oauthConnectDisabled()) {
      return;
    }

    this.clearPreview();
    this.testHasRun.set(false);
    this.isOauthConnecting.set(true);
    this.persistConnector()
      .pipe(
        switchMap((connector) =>
          this._hubSpotConnectorService.authorize(this.toConnectorReferenceRequest(connector.id!)),
        ),
      )
      .subscribe({
        next: (response) => this.openAuthorizationPopup(response.authorizationUrl),
        error: (error) => {
          this.isOauthConnecting.set(false);
          notify(this.resolveErrorMessage(error, 'connection.test.failed'), 'error', 5000);
        },
      });
  }

  disconnectOauth(): void {
    const connector = this.connection();
    if (!connector?.id || this.oauthDisconnectDisabled()) {
      return;
    }

    this.isPersisting.set(true);
    this._hubSpotConnectorService
      .disconnect(this.toConnectorReferenceRequest(connector.id))
      .pipe(
        switchMap(() => this.refreshConnector(connector.id!)),
        finalize(() => this.isPersisting.set(false)),
      )
      .subscribe({
        next: () => {
          this.clearPreview();
          this.testHasRun.set(false);
          notify(this._translateService.instant('hubspot.oauth.disconnected.success'), 'success', 3000);
        },
        error: (error) => {
          notify(this.resolveErrorMessage(error, 'connection.test.failed'), 'error', 5000);
        },
      });
  }

  private createDefaultConnector(): HubSpotConnector {
    return {
      description: '',
      connectorType: ConnectorType.HUBSPOT,
      authMode: HubSpotAuthMode.PRIVATE_APP_TOKEN,
      privateAppToken: '',
      oauthClientId: '',
      oauthClientSecret: '',
      status: HubSpotConnectorStatus.DRAFT,
    };
  }

  private applyConnectorUpdate(connector: HubSpotConnector, clearValidationState: boolean): void {
    this._wizardStore.setHubSpotConnector({ ...connector });
    if (clearValidationState) {
      this.clearPreview();
      this.testHasRun.set(false);
    }
  }

  private resetRuntimeStateForAuthChange(connector: HubSpotConnector): HubSpotConnector {
    const nextStatus =
      connector.authMode === HubSpotAuthMode.OAUTH_AUTHORIZATION_CODE
        ? HubSpotConnectorStatus.DRAFT
        : connector.id
          ? HubSpotConnectorStatus.REQUIRES_REVALIDATION
          : HubSpotConnectorStatus.DRAFT;

    return {
      ...connector,
      hubId: undefined,
      hubDomain: undefined,
      grantedScopes: [],
      lastValidatedAt: undefined,
      lastValidationMessage: undefined,
      status: nextStatus,
    };
  }

  private persistConnector(): Observable<HubSpotConnector> {
    const connector = this.connection();
    if (!connector) {
      return throwError(() => new Error('HubSpot connector is not initialized.'));
    }

    this.isPersisting.set(true);

    const persist$ = connector.id
      ? this._hubSpotConnectorService.updateConnector(connector).pipe(map(() => connector.id!))
      : this._hubSpotConnectorService.saveConnector(connector).pipe(map((response) => response.id));

    return persist$.pipe(
      switchMap((connectorId) => this.refreshConnector(connectorId)),
      finalize(() => this.isPersisting.set(false)),
    );
  }

  private refreshConnector(connectorId: string): Observable<HubSpotConnector> {
    return this._hubSpotConnectorService
      .findConnector(connectorId)
      .pipe(tap((connector) => this._wizardStore.setHubSpotConnector(connector)));
  }

  private loadDetailedObjectsForConnector(connectorId: string): Observable<HubSpotObjectDetailed[]> {
    this.isPreviewLoading.set(true);
    return this._hubSpotConnectorService.getObjectsDetailed(this.toConnectorReferenceRequest(connectorId)).pipe(
      map((objects) => objects ?? []),
      finalize(() => this.isPreviewLoading.set(false)),
    );
  }

  private handleOauthMessage(message: HubSpotOauthMessage): void {
    this.clearOauthPopupWatcher();
    this.isOauthConnecting.set(false);

    if (message.type === 'hubspot-oauth-error') {
      notify(message.message, 'error', 5000);
      return;
    }

    this.refreshConnector(message.payload.connectorId)
      .pipe(takeUntilDestroyed(this._destroyRef))
      .subscribe({
        next: () => {
          this.clearPreview();
          this.testHasRun.set(false);
          if (message.payload.status === HubSpotConnectorStatus.INVALID) {
            notify(message.payload.message ?? this._translateService.instant('connection.test.failed'), 'error', 5000);
            return;
          }

          notify(this._translateService.instant('hubspot.oauth.connected.success'), 'success', 3000);
        },
        error: (error) => {
          notify(this.resolveErrorMessage(error, 'connection.test.failed'), 'error', 5000);
        },
      });
  }

  private openAuthorizationPopup(authorizationUrl: string): void {
    if (typeof window === 'undefined') {
      this.isOauthConnecting.set(false);
      return;
    }

    const popup = window.open(
      authorizationUrl,
      'hubspot-oauth',
      'popup=yes,width=720,height=760,resizable=yes,scrollbars=yes',
    );

    if (!popup) {
      this.isOauthConnecting.set(false);
      notify(this._translateService.instant('hubspot.oauth.popup.blocked'), 'error', 5000);
      return;
    }

    this.startOauthPopupWatcher(popup);
  }

  private clearPreview(): void {
    this.objects.set([]);
  }

  private mapObjectsToSchemaState(objects: HubSpotObjectDetailed[]): HubSpotSchemaState[] {
    return objects.map((object) => ({
      resource: object,
    }));
  }

  private executeTestConnection(
    connector: HubSpotConnector,
  ): Observable<{ result: { success: boolean; message: string }; objects: HubSpotObjectDetailed[] }> {
    if (this.shouldUseDirectConnectionCalls(connector)) {
      return this._hubSpotConnectorService.testConnection(connector).pipe(
        switchMap((result) =>
          result.success
            ? this._hubSpotConnectorService
                .getObjectsDetailedFromConnection(connector)
                .pipe(map((objects) => ({ result, objects: objects ?? [] })))
            : of({ result, objects: [] as HubSpotObjectDetailed[] }),
        ),
        switchMap((payload) =>
          connector.id ? this.refreshConnector(connector.id).pipe(map(() => payload)) : of(payload),
        ),
      );
    }

    return this.persistConnector().pipe(
      switchMap((savedConnector) =>
        this._hubSpotConnectorService
          .testConnection(savedConnector)
          .pipe(map((result) => ({ savedConnector, result }))),
      ),
      switchMap(({ savedConnector, result }) =>
        this.refreshConnector(savedConnector.id!).pipe(map((connectorState) => ({ connectorState, result }))),
      ),
      switchMap(({ connectorState, result }) =>
        result.success && connectorState.id
          ? this.loadDetailedObjectsForConnector(connectorState.id).pipe(map((objects) => ({ result, objects })))
          : of({ result, objects: [] as HubSpotObjectDetailed[] }),
      ),
    );
  }

  private canStartOauth(connector: HubSpotConnector | null): boolean {
    if (!connector || connector.authMode !== HubSpotAuthMode.OAUTH_AUTHORIZATION_CODE) {
      return false;
    }

    return (
      this.hasValue(connector.oauthRedirectUri) &&
      this.hasValue(connector.oauthClientId) &&
      this.hasValue(connector.oauthClientSecret) &&
      this.hasValue(connector.oauthScopes)
    );
  }

  private buildConnectorForAuthMode(connector: HubSpotConnector, authMode: HubSpotAuthMode): HubSpotConnector {
    const oauthRedirectUri =
      connector.oauthRedirectUri && connector.oauthRedirectUri.trim().length > 0
        ? connector.oauthRedirectUri
        : this.getDefaultOauthRedirectUri();
    const oauthScopes =
      connector.oauthScopes && connector.oauthScopes.trim().length > 0 ? connector.oauthScopes : DEFAULT_OAUTH_SCOPES;

    return {
      ...connector,
      authMode,
      privateAppToken: authMode === HubSpotAuthMode.PRIVATE_APP_TOKEN ? '' : undefined,
      oauthRedirectUri: authMode === HubSpotAuthMode.OAUTH_AUTHORIZATION_CODE ? oauthRedirectUri : undefined,
      oauthScopes: authMode === HubSpotAuthMode.OAUTH_AUTHORIZATION_CODE ? oauthScopes : undefined,
      oauthClientId:
        authMode === HubSpotAuthMode.OAUTH_AUTHORIZATION_CODE ? (connector.oauthClientId ?? '') : undefined,
      oauthClientSecret:
        authMode === HubSpotAuthMode.OAUTH_AUTHORIZATION_CODE ? (connector.oauthClientSecret ?? '') : undefined,
    };
  }

  private getDefaultOauthRedirectUri(): string {
    if (typeof window === 'undefined') {
      return '';
    }

    return `${window.location.origin}/hubspot/oauth/callback`;
  }

  private toConnectorReferenceRequest(connectorId: string): HubSpotConnectorReferenceRequest {
    return { connectorId };
  }

  private hasValue(value: unknown): boolean {
    if (typeof value !== 'string') {
      return false;
    }

    return value.trim().length > 0;
  }

  private shouldUseDirectConnectionCalls(connector: HubSpotConnector): boolean {
    return connector.authMode === HubSpotAuthMode.PRIVATE_APP_TOKEN;
  }

  private toStatusTranslationKey(status: HubSpotConnectorStatus): string {
    switch (status) {
      case HubSpotConnectorStatus.CONNECTED_NOT_VALIDATED:
        return 'hubspot.status.connected.not.validated';
      case HubSpotConnectorStatus.VALID:
        return 'hubspot.status.valid';
      case HubSpotConnectorStatus.REQUIRES_REVALIDATION:
        return 'hubspot.status.requires.revalidation';
      case HubSpotConnectorStatus.INVALID:
        return 'hubspot.status.invalid';
      case HubSpotConnectorStatus.DRAFT:
      default:
        return 'hubspot.status.draft';
    }
  }

  private resolveErrorMessage(error: unknown, fallbackTranslationKey: string): string {
    const detail = (error as any)?.error?.detail;
    const message = (error as any)?.error?.message ?? (error as any)?.message;
    return detail ?? message ?? this._translateService.instant(fallbackTranslationKey);
  }

  private startOauthPopupWatcher(popup: Window): void {
    this.clearOauthPopupWatcher();
    this.oauthPopupPollHandle = setInterval(() => {
      if (!popup.closed) {
        return;
      }

      this.clearOauthPopupWatcher();
      this.isOauthConnecting.set(false);
    }, 500);
    this._destroyRef.onDestroy(() => this.clearOauthPopupWatcher());
  }

  private clearOauthPopupWatcher(): void {
    if (!this.oauthPopupPollHandle) {
      return;
    }

    clearInterval(this.oauthPopupPollHandle);
    this.oauthPopupPollHandle = null;
  }
}
