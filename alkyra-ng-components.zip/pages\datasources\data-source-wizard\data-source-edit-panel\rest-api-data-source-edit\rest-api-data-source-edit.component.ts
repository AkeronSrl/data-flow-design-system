import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { ConnectorUnionType } from '@alkyra/connector/models/connector-type.model';
import { RestApiConnectionTestResult } from '@alkyra/rest-api-connector/models/rest-api-connection-test-result.model';
import { RestApiAuthType, RestApiConnector } from '@alkyra/rest-api-connector/models/rest-api-connector.model';
import { RestApiConnectorService } from '@alkyra/rest-api-connector/services/rest-api-connector.service';
import {
  mapRestApiResourcesToPreviewItems,
  mapRestApiResourcesToSchemaDiscoveryNodes,
} from '@alkyra/ui/schema-discovery/mappers/rest-api-schema-discovery.mapper';
import {
  SchemaDiscoveryHeaderMeta,
  SchemaDiscoveryNode,
} from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import { ChangeDetectionStrategy, Component, computed, inject, OnInit, Signal, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import notify from 'devextreme/ui/notify';
import { DxAccordionModule } from 'devextreme-angular/ui/accordion';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxFormModule } from 'devextreme-angular/ui/form';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';

import { DatasourceWizardStore } from '../../+store/data-source-wizard.store';
import { DataSourceEditComponentInterface } from '../data-source-edit-component-interface';

type RestApiAuthMode = 'REST' | 'OAUTH';

@Component({
  selector: 'alk-rest-api-data-source-edit',
  templateUrl: './rest-api-data-source-edit.component.html',
  styleUrl: './rest-api-data-source-edit.component.scss',
  standalone: true,
  imports: [
    DxFormModule,
    DxButtonModule,
    DxScrollViewModule,
    DxLoadIndicatorModule,
    DxAccordionModule,
    DxSelectBoxModule,
    DxTextBoxModule,
    TranslatePipe,
    TiaraCircularIllustrationComponent,
    TiaraNameDescriptionLabelComponent,
    SchemaDiscoveryComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RestApiDataSourceEditComponent implements OnInit, DataSourceEditComponentInterface {
  readonly _wizardStore = inject(DatasourceWizardStore);
  readonly _restApiConnectorService = inject(RestApiConnectorService);
  readonly _translateService = inject(TranslateService);
  readonly RestApiAuthType = RestApiAuthType;

  readonly restApiConnector = this._wizardStore.restApiConnector;
  readonly isTestLoading = signal(false);
  readonly testDisabled = signal(true);
  readonly testResult = signal<RestApiConnectionTestResult | null>(null);
  readonly testHasRun = signal(false);
  private lastAuthType: RestApiAuthType | null = null;
  private ignoreFieldChanges = false;

  readonly authModeOptions = computed(() => [
    { value: 'REST', label: this._translateService.instant('rest.api.auth.mode.rest') },
    { value: 'OAUTH', label: this._translateService.instant('rest.api.auth.mode.oauth') },
  ]);

  readonly restAuthTypeOptions = computed(() => [
    { value: RestApiAuthType.NO_AUTH, label: this._translateService.instant('rest.api.auth.type.no.auth') },
    { value: RestApiAuthType.BEARER_TOKEN, label: this._translateService.instant('rest.api.auth.type.bearer') },
    { value: RestApiAuthType.API_KEY, label: this._translateService.instant('rest.api.auth.type.api.key') },
    { value: RestApiAuthType.BASIC, label: this._translateService.instant('rest.api.auth.type.basic') },
  ]);
  readonly selectedAuthMode = computed<RestApiAuthMode>(() =>
    this.restApiConnector()?.authType === RestApiAuthType.OAUTH2_CLIENT_CREDENTIALS ? 'OAUTH' : 'REST',
  );

  readonly schemaNodes = computed<SchemaDiscoveryNode[]>(() =>
    mapRestApiResourcesToSchemaDiscoveryNodes(this.testResult()?.resources ?? []),
  );
  readonly previewItems = computed(() => mapRestApiResourcesToPreviewItems(this.testResult()?.resources ?? []));
  readonly headerMeta = computed<SchemaDiscoveryHeaderMeta[]>(() => {
    const connector = this.restApiConnector();
    if (!connector) {
      return [];
    }

    return [
      { label: this._translateService.instant('type'), value: ConnectorType.REST_API },
      ...(connector.description?.trim()
        ? [{ label: this._translateService.instant('description'), value: connector.description.trim() }]
        : []),
    ];
  });
  ngOnInit(): void {
    if (this._wizardStore.operazione() === 'CREATE') {
      const connector: RestApiConnector = {
        description: '',
        connectorType: ConnectorType.REST_API,
        type: ConnectorType.REST_API,
        endpoint: '',
        authType: RestApiAuthType.NO_AUTH,
      };
      this._wizardStore.setRestApiConnector(connector);
    }

    this.lastAuthType = this.restApiConnector()?.authType ?? null;

    this.updateTestAvailability();
  }

  testConnection(): void {
    const connector = this.restApiConnector();
    if (!connector) return;

    this.isTestLoading.set(true);
    this.testHasRun.set(false);
    this.testResult.set(null);
    this._restApiConnectorService.testConnection(connector).subscribe({
      next: (result) => {
        this.testResult.set(result);
        this.testHasRun.set(true);
        this.isTestLoading.set(false);
        const firstFailure = !result.connectionSuccess
          ? result.connectionMessage
          : !result.authenticationSuccess
            ? result.authenticationMessage
            : null;
        if (firstFailure) {
          notify(firstFailure, 'error', 5000);
        } else {
          notify(this._translateService.instant('connection.test.success'), 'success', 3000);
        }
      },
      error: () => {
        this.testResult.set(null);
        this.testHasRun.set(true);
        this.isTestLoading.set(false);
        notify(this._translateService.instant('connection.test.failed'), 'error', 5000);
      },
      complete: () => {
        this.isTestLoading.set(false);
      },
    });
  }

  onFieldChange(event: any): void {
    if (this.ignoreFieldChanges) {
      return;
    }

    const fieldName = this.resolveChangedField(event);
    if (!fieldName) {
      return;
    }

    const hasActualChange = this.hasActualFieldChange(fieldName, event);

    if (this.shouldClearTestResult(fieldName, hasActualChange)) {
      this.clearTestResult();
    }
    this.persistConnectorSnapshot(hasActualChange);
    this.updateTestAvailability();
  }

  onManualFieldChange(field: keyof RestApiConnector, value: unknown): void {
    const connector = this.restApiConnector();
    if (!connector) return;

    const updatedConnector: RestApiConnector = {
      ...connector,
      [field]: value as never,
    };
    this._wizardStore.setRestApiConnector(updatedConnector);
    this.testHasRun.set(false);
    this.testResult.set(null);
    this.updateTestAvailability();
  }

  onAuthModeChange(mode: RestApiAuthMode | null | undefined): void {
    if (mode === 'OAUTH') {
      this.setAuthType(RestApiAuthType.OAUTH2_CLIENT_CREDENTIALS);
      return;
    }

    if (mode === 'REST') {
      const currentAuthType = this.restApiConnector()?.authType;
      if (currentAuthType === RestApiAuthType.OAUTH2_CLIENT_CREDENTIALS || !currentAuthType) {
        this.setAuthType(RestApiAuthType.NO_AUTH);
      }
    }
  }

  onRestAuthTypeChange(authType: RestApiAuthType | null | undefined): void {
    if (!authType || authType === RestApiAuthType.OAUTH2_CLIENT_CREDENTIALS) {
      return;
    }
    this.setAuthType(authType);
  }

  isAuthType(type: RestApiAuthType): boolean {
    return this.restApiConnector()?.authType === type;
  }

  getConnector(): Signal<ConnectorUnionType | null> {
    return this._wizardStore.restApiConnector as Signal<ConnectorUnionType | null>;
  }

  private buildConnectorForAuthType(connector: RestApiConnector): RestApiConnector {
    const normalizedConnector: RestApiConnector = {
      ...connector,
      bearerToken: undefined,
      basicUsername: undefined,
      basicPassword: undefined,
      oauthTokenUrl: undefined,
      oauthClientId: undefined,
      oauthClientSecret: undefined,
      apiKeyUsername: undefined,
      apiKeyValue: undefined,
      apiKeyAuthEndpoint: undefined,
    };

    switch (normalizedConnector.authType) {
      case RestApiAuthType.NO_AUTH:
        break;
      case RestApiAuthType.BEARER_TOKEN:
        normalizedConnector.bearerToken = '';
        break;
      case RestApiAuthType.BASIC:
        normalizedConnector.basicUsername = '';
        normalizedConnector.basicPassword = '';
        break;
      case RestApiAuthType.OAUTH2_CLIENT_CREDENTIALS:
        normalizedConnector.oauthTokenUrl = '';
        normalizedConnector.oauthClientId = '';
        normalizedConnector.oauthClientSecret = '';
        break;
      case RestApiAuthType.API_KEY:
        normalizedConnector.apiKeyUsername = '';
        normalizedConnector.apiKeyValue = '';
        normalizedConnector.apiKeyAuthEndpoint = '';
        break;
      default:
        break;
    }

    return normalizedConnector;
  }

  private setAuthType(authType: RestApiAuthType): void {
    const connector = this.restApiConnector();
    if (!connector || connector.authType === authType) {
      return;
    }

    this._wizardStore.setRestApiConnector(this.buildConnectorForAuthType({ ...connector, authType }));
    this.lastAuthType = authType;
    this.testHasRun.set(false);
    this.testResult.set(null);
    this.updateTestAvailability();
  }

  private resolveChangedField(event: any): keyof RestApiConnector | undefined {
    return event?.dataField as keyof RestApiConnector | undefined;
  }

  private hasActualFieldChange(fieldName: keyof RestApiConnector, event: any): boolean {
    if (fieldName === 'authType') {
      return this.handleAuthTypeChangeFromForm();
    }
    return this.hasDevExtremeValueChange(event);
  }

  private handleAuthTypeChangeFromForm(): boolean {
    const currentAuthType = this.restApiConnector()?.authType ?? null;
    const hasActualChange = currentAuthType !== this.lastAuthType;

    if (this.shouldRebuildConnectorForAuthType(currentAuthType)) {
      this._wizardStore.setRestApiConnector(
        this.buildConnectorForAuthType({ ...this.restApiConnector()!, authType: currentAuthType }),
      );
    }

    this.lastAuthType = currentAuthType;
    return hasActualChange;
  }

  private shouldRebuildConnectorForAuthType(authType: RestApiAuthType | null): authType is RestApiAuthType {
    return this.lastAuthType !== null && !!authType && authType !== this.lastAuthType;
  }

  private hasDevExtremeValueChange(event: any): boolean {
    if (!this.hasDevExtremeValuePayload(event)) {
      return true;
    }
    return event.previousValue !== event.value;
  }

  private hasDevExtremeValuePayload(event: any): boolean {
    if (!event) {
      return false;
    }
    return ['previousValue', 'value'].some((property) => this.hasEventProperty(event, property));
  }

  private hasEventProperty(event: any, property: string): boolean {
    return property in event;
  }

  private shouldClearTestResult(fieldName: keyof RestApiConnector, hasActualChange: boolean): boolean {
    return fieldName !== 'description' && hasActualChange;
  }

  private clearTestResult(): void {
    this.testHasRun.set(false);
    this.testResult.set(null);
  }

  private persistConnectorSnapshot(hasActualChange: boolean): void {
    const connector = this.restApiConnector();
    if (!connector || !hasActualChange) {
      return;
    }

    this.ignoreFieldChanges = true;
    this._wizardStore.setRestApiConnector({ ...connector });
    queueMicrotask(() => {
      this.ignoreFieldChanges = false;
    });
  }

  private updateTestAvailability(): void {
    const connector = this.restApiConnector();
    this.testDisabled.set(!this.canTestConnection(connector));
  }

  private canTestConnection(connector: RestApiConnector | null): boolean {
    return !!connector && this.hasValue(connector.endpoint) && this.hasValidAuthConfig(connector);
  }

  private hasValidAuthConfig(connector: RestApiConnector): boolean {
    switch (connector.authType) {
      case RestApiAuthType.NO_AUTH:
        return true;
      case RestApiAuthType.BEARER_TOKEN:
        return this.hasValue(connector.bearerToken);
      case RestApiAuthType.BASIC:
        return this.hasAllValues(connector.basicUsername, connector.basicPassword);
      case RestApiAuthType.OAUTH2_CLIENT_CREDENTIALS:
        return this.hasAllValues(connector.oauthTokenUrl, connector.oauthClientId, connector.oauthClientSecret);
      case RestApiAuthType.API_KEY:
        return this.hasAllValues(connector.apiKeyUsername, connector.apiKeyValue);
      default:
        return false;
    }
  }

  private hasAllValues(...values: unknown[]): boolean {
    return values.every((value) => this.hasValue(value));
  }

  private hasValue(value: unknown): boolean {
    if (typeof value !== 'string') {
      return false;
    }
    return value.trim().length > 0;
  }
}
