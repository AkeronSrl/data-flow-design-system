import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import { TiaraSuiteTreeNode } from '@akeron-ng/tiara-ng-suite/tiara-tree-view';
import { S3BucketConnector } from '@alkyra/amazon-s3-connector/models/s3-bucket-connector.model';
import { S3BucketConnectorService } from '@alkyra/amazon-s3-connector/services/s3-bucket-connector.service';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { ConnectorUnionType } from '@alkyra/connector/models/connector-type.model';
import { buildSupportedCloudFileTreeNodes } from '@alkyra/dataset/components/dataset-wizard/dataset-cloud-source/cloud-supported-tree.utils';
import { FileExplorerItem } from '@alkyra/file-explorer/models/file-explorer-item.model';
import { mapCloudTreeNodesToSchemaDiscoveryNodes } from '@alkyra/ui/schema-discovery/mappers/cloud-file-schema-discovery.mapper';
import {
  SchemaDiscoveryHeaderMeta,
  SchemaDiscoveryNode,
} from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import { ChangeDetectionStrategy, Component, computed, inject, OnInit, Signal, signal } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxFormModule } from 'devextreme-angular/ui/form';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';

import { DatasourceWizardStore } from '../../+store/data-source-wizard.store';
import { DataSourceEditComponentInterface } from '../data-source-edit-component-interface';

@Component({
  selector: 'alk-s3-data-source-edit',
  templateUrl: './s3-data-source-edit.component.html',
  styleUrl: './s3-data-source-edit.component.scss',
  standalone: true,
  imports: [
    DxFormModule,
    DxButtonModule,
    DxScrollViewModule,
    TranslatePipe,
    TiaraCircularIllustrationComponent,
    TiaraNameDescriptionLabelComponent,
    SchemaDiscoveryComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class S3DataSourceEditComponent implements OnInit, DataSourceEditComponentInterface {
  readonly _wizardStore = inject(DatasourceWizardStore);
  readonly _s3BucketConnectorService = inject(S3BucketConnectorService);

  readonly s3Connector = this._wizardStore.s3BucketConnector;
  readonly previewItems = signal<TiaraSuiteTreeNode<FileExplorerItem, FileExplorerItem>[]>([]);
  readonly isPreviewLoading = signal(false);
  readonly previewDisabled = signal(true);
  readonly hasPreview = computed(() => this.previewItems().length > 0);
  readonly schemaNodes = computed<SchemaDiscoveryNode[]>(() =>
    mapCloudTreeNodesToSchemaDiscoveryNodes(this.previewItems()),
  );
  readonly headerMeta = computed<SchemaDiscoveryHeaderMeta[]>(() => {
    const connector = this.s3Connector();
    if (!connector) {
      return [];
    }

    return [
      { label: 'type', value: ConnectorType.S3_BUCKET },
      ...(connector.bucketName?.trim()
        ? [{ label: 'amazon.s3.field.bucket.label', value: connector.bucketName.trim() }]
        : []),
      ...(connector.description?.trim() ? [{ label: 'description', value: connector.description.trim() }] : []),
    ];
  });

  ngOnInit(): void {
    if (this._wizardStore.operazione() === 'CREATE' || !this._wizardStore.s3BucketConnector()) {
      const connector: S3BucketConnector = {
        description: '',
        connectorType: ConnectorType.S3_BUCKET,
        type: ConnectorType.S3_BUCKET,
        accessKeyId: '',
        secretAccessKey: '',
        region: '',
        bucketName: '',
      };
      this._wizardStore.setS3Connector(connector);
    }

    this.updatePreviewAvailability();
  }

  showPreview(): void {
    const connector = this.s3Connector();

    this.isPreviewLoading.set(true);
    this._s3BucketConnectorService.connectionPreview(connector!).subscribe({
      next: (fileItems) => {
        this.previewItems.set(buildSupportedCloudFileTreeNodes(fileItems ?? []));
      },
      error: () => {
        this.previewItems.set([]);
        this.isPreviewLoading.set(false);
      },
      complete: () => {
        this.isPreviewLoading.set(false);
      },
    });
  }

  onFieldChange(event: any): void {
    if (event.dataField !== 'description') {
      this.updatePreviewAvailability();
    }
  }

  getConnector(): Signal<ConnectorUnionType | null> {
    return this._wizardStore.s3BucketConnector;
  }

  private updatePreviewAvailability(): void {
    const requiredFields: Array<keyof S3BucketConnector> = ['accessKeyId', 'secretAccessKey', 'region', 'bucketName'];
    const connector = this.s3Connector();
    if (!connector) {
      this.previewDisabled.set(true);
      return;
    }
    const canPreview = requiredFields.every((field) => {
      const value = connector[field];
      return typeof value === 'string' && value.trim().length > 0;
    });

    this.previewDisabled.set(!canPreview);
  }
}
