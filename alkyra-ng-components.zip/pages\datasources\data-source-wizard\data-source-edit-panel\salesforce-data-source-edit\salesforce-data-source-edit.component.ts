import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { SalesforceConnector } from '@alkyra/salesforce-connector/models/salesforce-connector.model';
import { SalesforceField } from '@alkyra/salesforce-connector/models/salesforce-field.model';
import { SalesforceConnectorService } from '@alkyra/salesforce-connector/services/salesforce-connector.service';
import {
  mapSalesforceStatesToSchemaDiscoveryNodes,
  SalesforceSchemaState,
} from '@alkyra/ui/schema-discovery/mappers/salesforce-schema-discovery.mapper';
import {
  SchemaDiscoveryHeaderMeta,
  SchemaDiscoveryNode,
} from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import { ChangeDetectionStrategy, Component, computed, inject, OnInit, Signal, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import notify from 'devextreme/ui/notify';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxFormModule } from 'devextreme-angular/ui/form';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { catchError, map, of } from 'rxjs';

import { DatasourceWizardStore } from '../../+store/data-source-wizard.store';
import { DataSourceEditComponentInterface } from '../data-source-edit-component-interface';

@Component({
  selector: 'alk-salesforce-data-source-edit',
  templateUrl: './salesforce-data-source-edit.component.html',
  standalone: true,
  styleUrl: './salesforce-data-source-edit.component.scss',
  imports: [
    DxFormModule,
    DxButtonModule,
    DxLoadIndicatorModule,
    DxScrollViewModule,
    TranslatePipe,
    TiaraCircularIllustrationComponent,
    SchemaDiscoveryComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SalesforceDataSourceEditComponent implements OnInit, DataSourceEditComponentInterface {
  private readonly _wizardStore = inject(DatasourceWizardStore);
  private readonly _salesforceConnectorService = inject(SalesforceConnectorService);
  private readonly _translateService: TranslateService = inject(TranslateService);

  connection = this._wizardStore.salesforceConnector;
  objects = signal<SalesforceSchemaState[]>([]);
  isTestingConnection = signal<boolean>(false);
  readonly schemaNodes = computed<SchemaDiscoveryNode[]>(() =>
    mapSalesforceStatesToSchemaDiscoveryNodes(this.objects()),
  );
  readonly headerMeta = computed<SchemaDiscoveryHeaderMeta[]>(() => {
    const connector = this.connection();
    if (!connector) {
      return [];
    }

    return [
      { label: this._translateService.instant('type'), value: ConnectorType.SALESFORCE },
      ...(connector.description?.trim()
        ? [{ label: this._translateService.instant('description'), value: connector.description.trim() }]
        : []),
    ];
  });
  readonly hasPreview = computed(() => this.isTestingConnection() || this.schemaNodes().length > 0);

  testConnectionDisabled = computed(() => !this._salesforceConnectorService.isConnectionTestable(this.connection()));
  private _ignoreFieldChanges = false;

  ngOnInit() {
    if (this._wizardStore.operazione() === 'CREATE') {
      const connector: SalesforceConnector = {
        description: '',
        username: '',
        password: '',
        securityToken: '',
        loginUrl: '',
        connectorType: ConnectorType.SALESFORCE,
      };
      this._wizardStore.setSalesforceConnector(connector);
    }
  }

  testConnection() {
    if (this.isTestingConnection()) return;
    const connector = this.connection();
    if (!connector) return;

    this.isTestingConnection.set(true);
    this._salesforceConnectorService.getObjectsFromConnection(connector).subscribe({
      next: (objects) => {
        this.objects.set(
          objects.map((resource) => ({
            resource,
            fieldStatus: 'idle',
            expanded: false,
          })),
        );
        this.notifyMex(this._translateService.instant('datasource.test.connection.success'), 'success', 5000);
      },
      error: () => {
        this.notifyMex(this._translateService.instant('connection.test.failed'), 'error', 5000);
      },
      complete: () => {
        this.isTestingConnection.set(false);
      },
    });
  }

  onNodeExpanded(event: { node: SchemaDiscoveryNode }): void {
    const resource = event.node.data;
    if (!this.isSalesforceObject(resource)) {
      return;
    }

    const connector = this.connection();
    if (!connector) {
      return;
    }

    const state = this.getObjectState(resource.name);
    if (!state) {
      return;
    }

    this.updateObjectState(resource.name, {
      expanded: true,
    });

    if (!this.shouldLoadFields(state)) {
      return;
    }

    this.updateObjectState(resource.name, {
      expanded: true,
      fieldStatus: 'loading',
    });

    this._salesforceConnectorService
      .describeWithConnection(connector, resource.name)
      .pipe(
        map((fields) => ({ fields, fieldStatus: 'loaded' as const })),
        catchError(() => of({ fields: [] as SalesforceField[], fieldStatus: 'error' as const })),
      )
      .subscribe((patch) => {
        this.updateObjectState(resource.name, patch);
      });
  }

  onNodeCollapsed(event: { node: SchemaDiscoveryNode }): void {
    const resource = event.node.data;
    if (!this.isSalesforceObject(resource)) {
      return;
    }

    this.updateObjectState(resource.name, {
      expanded: false,
    });
  }

  private getObjectState(objectName: string): SalesforceSchemaState | undefined {
    return this.objects().find((item) => item.resource.name === objectName);
  }

  private shouldLoadFields(state: SalesforceSchemaState | undefined): state is SalesforceSchemaState {
    return !!state && state.fieldStatus !== 'loading' && state.fieldStatus !== 'loaded';
  }

  private updateObjectState(objectName: string, patch: Partial<SalesforceSchemaState>): void {
    this.objects.update((states) =>
      states.map((state) =>
        state.resource.name === objectName
          ? {
              ...state,
              ...patch,
            }
          : state,
      ),
    );
  }

  private isSalesforceObject(value: unknown): value is SalesforceSchemaState['resource'] {
    return !!value && typeof value === 'object' && 'name' in value;
  }

  onFieldChange(event: any) {
    if (this._ignoreFieldChanges) return;

    const current = this.connection();
    if (current && event?.dataField) {
      this._ignoreFieldChanges = true;
      const updated = { ...current, [event.dataField]: event.value };
      this._wizardStore.setSalesforceConnector(updated);
      queueMicrotask(() => {
        this._ignoreFieldChanges = false;
      });
    }

    if (event.dataField !== 'description') {
      this.objects.set([]);
    }
  }

  notifyMex(message: string | undefined, type: string, displayTime: number): void {
    notify(message, type, displayTime);
  }
  getConnector(): Signal<SalesforceConnector | null> {
    return this._wizardStore.salesforceConnector;
  }
}
