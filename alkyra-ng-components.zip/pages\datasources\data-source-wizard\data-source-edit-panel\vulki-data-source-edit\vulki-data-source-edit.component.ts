import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { ConnectorUnionType } from '@alkyra/connector/models/connector-type.model';
import { ScreenLockStore } from '@alkyra/screen-lock/+store/screen-lock.store';
import { VulkiPreviewTreeComponent } from '@alkyra/vulki/vulki-preview-tree/vulki-preview-tree.component';
import { DataloaderDiscoveryResponse } from '@alkyra/vulki-connector/models/dataloader-discovery.model';
import {
  VulkiSwaggerFieldDetail,
  VulkiSwaggerResponse,
  VulkiSwaggerTagGroup,
} from '@alkyra/vulki-connector/models/vulki-connection-test-result.model';
import { VulkiConnector } from '@alkyra/vulki-connector/models/vulki-connector.model';
import { VulkiConnectorService } from '@alkyra/vulki-connector/services/vulki-connector.service';
import {
  resolveDataloaderColumnLabel,
  resolveDataloaderColumnType,
} from '@alkyra/vulki-connector/utils/dataloader.utils';
import { ChangeDetectionStrategy, Component, computed, inject, OnInit, Signal, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { DxAccordionModule } from 'devextreme-angular/ui/accordion';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxFormModule } from 'devextreme-angular/ui/form';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { of, switchMap } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { DatasourceWizardStore } from '../../+store/data-source-wizard.store';
import { DataSourceEditComponentInterface } from '../data-source-edit-component-interface';

@Component({
  selector: 'alk-vulki-data-source-edit',
  templateUrl: './vulki-data-source-edit.component.html',
  styleUrl: './vulki-data-source-edit.component.scss',
  standalone: true,
  imports: [
    DxFormModule,
    DxButtonModule,
    DxScrollViewModule,
    DxLoadIndicatorModule,
    TranslatePipe,
    TiaraCircularIllustrationComponent,
    TiaraNameDescriptionLabelComponent,
    DxAccordionModule,
    DxTextBoxModule,
    VulkiPreviewTreeComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class VulkiDataSourceEditComponent implements OnInit, DataSourceEditComponentInterface {
  readonly _wizardStore = inject(DatasourceWizardStore);
  readonly _vulkiConnectorService = inject(VulkiConnectorService);
  readonly _screenLockStore = inject(ScreenLockStore);
  readonly translateService = inject(TranslateService);

  readonly vulkiConnector = this._wizardStore.vulkiConnector;
  readonly previewItems = signal<VulkiSwaggerTagGroup[]>([]);
  readonly isTestLoading = signal(false);
  readonly testDisabled = signal(true);
  readonly testErrorMessage = signal('');
  readonly testHasRun = signal(false);

  readonly hasPreview = computed(() => this.previewItems().length > 0);
  readonly isTestSuccess = computed(() => this.testHasRun() && this.testErrorMessage() === '');
  readonly isTestFailed = computed(() => {
    return this.testHasRun() && this.testErrorMessage() !== '';
  });

  ngOnInit(): void {
    if (this._wizardStore.operazione() === 'CREATE') {
      const connector: VulkiConnector = {
        description: '',
        connectorType: ConnectorType.VULKI,
        type: ConnectorType.VULKI,
        endpoint: '',
        username: '',
        apiKey: '',
      };
      this._wizardStore.setVulkiConnector(connector);
    }

    this.updateTestAvailability();
  }

  testConnection(): void {
    const connector = this.vulkiConnector();
    if (!connector) return;

    this.isTestLoading.set(true);
    this.testHasRun.set(false);
    this.testErrorMessage.set('');
    this.previewItems.set([]);

    this._vulkiConnectorService
      .testConnection(connector)
      .pipe(
        catchError(() => of({ tags: [], hasDataloader: false } as VulkiSwaggerResponse)),
        switchMap((swaggerResponse) => {
          const swaggerTags = swaggerResponse.tags ?? [];
          if (swaggerResponse.hasDataloader) {
            return this._vulkiConnectorService.dataloaderDiscoveryAll(connector).pipe(
              catchError(() => of({ definitions: [] } as DataloaderDiscoveryResponse)),
              switchMap((dataloaderResponse) => of({ swaggerTags, dataloaderResponse })),
            );
          }
          return of({ swaggerTags, dataloaderResponse: { definitions: [] } as DataloaderDiscoveryResponse });
        }),
      )
      .subscribe({
        next: ({ swaggerTags, dataloaderResponse }) => {
          const bulkTags = this.buildBulkTagGroups(dataloaderResponse.definitions ?? []);
          const lineByLineTags = this.buildLineByLineTags(swaggerTags ?? []);
          this.previewItems.set([...bulkTags, ...lineByLineTags]);
          this.testHasRun.set(true);
          this.isTestLoading.set(false);
          this._screenLockStore.unlockScreen({
            message: this.translateService.instant('connection.test.success'),
            status: 'success',
          });
        },
        error: () => {
          this.previewItems.set([]);
          this.testHasRun.set(true);
          this.isTestLoading.set(false);
          this._screenLockStore.unlockScreen({
            message: this.translateService.instant('connection.test.failed'),
            status: 'error',
          });
        },
      });
  }

  onFieldChange(event: any): void {
    if (event.dataField !== 'description') {
      this.updateTestAvailability();
      // Reset test result when credentials change
      this.testHasRun.set(false);
      this.testErrorMessage.set('');
      this.previewItems.set([]);
    }
    // Update store with current connector state
    const connector = this.vulkiConnector();
    if (connector) {
      this._wizardStore.setVulkiConnector(connector);
    }
  }

  onAuthEndpointChange(event: any): void {
    const connector = this.vulkiConnector();
    if (connector) {
      connector.authEndpoint = event.value;
      this._wizardStore.setVulkiConnector(connector);
    }
  }

  getConnector(): Signal<ConnectorUnionType | null> {
    return this._wizardStore.vulkiConnector as Signal<ConnectorUnionType | null>;
  }

  private buildBulkTagGroups(
    definitions: import('@alkyra/vulki-connector/models/dataloader-discovery.model').DataloaderDefinition[],
  ): VulkiSwaggerTagGroup[] {
    const lang = this.translateService.currentLang || 'en';
    return definitions.map((def) => {
      const columns = def.entities?.[0]?.columns ?? [];
      const fields: VulkiSwaggerFieldDetail[] = columns.map((col) => {
        const label = resolveDataloaderColumnLabel(col, lang);
        const labelSuffix = label ? ` — ${label}` : '';
        return {
          name: col.name,
          type: `${resolveDataloaderColumnType(col)}${labelSuffix}`,
          required: col.required,
        };
      });

      return {
        name: `${def.name} (bulk)`,
        description: undefined,
        tagKind: 'bulk' as const,
        dataloaderColumns: columns,
        dataloaderSupportedStrategies: def.supportedStrategies ?? [],
        dataloaderDefinitionId: def.name,
        versions: [
          {
            version: 'bulk',
            operations: [{ path: '', fields }],
          },
        ],
      };
    });
  }

  private buildLineByLineTags(swaggerTags: VulkiSwaggerTagGroup[]): VulkiSwaggerTagGroup[] {
    return swaggerTags.map((tag) => ({
      ...tag,
      name: `${tag.name} (line by line)`,
      tagKind: 'lineByLine' as const,
    }));
  }

  private updateTestAvailability(): void {
    const connector = this.vulkiConnector();
    const requiredFields: Array<keyof VulkiConnector> = ['endpoint', 'username', 'apiKey'];

    const allFieldsFilled = requiredFields.every((field) => {
      const value = connector?.[field];
      return value !== undefined && value !== null && value !== '';
    });

    this.testDisabled.set(!allFieldsFilled);
  }
}
