import {
  OptionButtonItem,
  TiaraSuiteOptionButtonSelectionComponent,
} from '@akeron-ng/tiara-ng-suite/tiara-option-button';
import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { DatasourceType } from '@alkyra/connector/models/datasource-type.model';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';

import { DatasourceWizardStore } from '../+store/data-source-wizard.store';

type DataSourceOptionConfig = {
  value: DatasourceType;
  titleKey: string;
  imgAlt: string;
  imgSource: string;
};

@Component({
  selector: 'alk-data-source-type-selector',
  templateUrl: './data-source-type-selector.component.html',
  styleUrls: ['./data-source-type-selector.component.scss'],
  standalone: true,
  imports: [TiaraSuiteOptionButtonSelectionComponent, TiaraSuiteWizardStepComponent, TranslatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DataSourceTypeSelectorComponent extends WizardStep {
  readonly _dsWizardStore = inject(DatasourceWizardStore);

  private readonly _translateService: TranslateService = inject(TranslateService);

  private readonly _optionConfigs: readonly DataSourceOptionConfig[] = [
    {
      value: 'POSTGRES',
      titleKey: 'datasource.postgresql',
      imgAlt: 'Postgress SQL Database',
      imgSource: 'assets/db-icon/pg.png',
    },
    {
      value: 'SQLSERVER',
      titleKey: 'datasource.ms',
      imgAlt: 'Microsoft SQL Server',
      imgSource: 'assets/db-icon/mssql.png',
    },
    {
      value: 'ORACLE',
      titleKey: 'datasource.oracle',
      imgAlt: 'Oracle SQL Database',
      imgSource: 'assets/db-icon/oracle.png',
    },
    {
      value: 'SAPHANA',
      titleKey: 'datasource.sap',
      imgAlt: 'SAP SQL Database',
      imgSource: 'assets/db-icon/sap.png',
    },
    {
      value: 'CSV',
      titleKey: 'datasource.csv',
      imgAlt: 'CSV File',
      imgSource: 'assets/file-icon/csv.png',
    },
    {
      value: 'EXCEL',
      titleKey: 'datasource.excel',
      imgAlt: 'Excel File',
      imgSource: 'assets/file-icon/excel.png',
    },
    {
      value: 'AMAZON_SQS',
      titleKey: 'datasource.amazon.sqs',
      imgAlt: 'Amazon SQS',
      imgSource: 'assets/cloud-icon/aws.png',
    },
    {
      value: 'S3_BUCKET',
      titleKey: 'datasource.amazon.s3',
      imgAlt: 'Amazon S3',
      imgSource: 'assets/cloud-icon/s3.png',
    },
    {
      value: 'AZURE_BLOB',
      titleKey: 'datasource.azure.blob',
      imgAlt: 'Azure Blob Storage',
      imgSource: 'assets/cloud-icon/azure.png',
    },
    {
      value: 'SALESFORCE',
      titleKey: 'datasource.salesforce',
      imgAlt: 'Salesforce',
      imgSource: 'assets/cloud-icon/salesforce.png',
    },
    {
      value: 'HUBSPOT',
      titleKey: 'datasource.hubspot',
      imgAlt: 'HubSpot',
      imgSource: 'assets/cloud-icon/hubspot.svg',
    },
    // Note: VULKI tile removed (NAU-439). Legacy Vulki connections remain editable from the list;
    // new Vulki connections can no longer be created manually. Akeron connections are provisioned
    // via YAML/BE and do not appear here.
    {
      value: 'BUSINESS_CENTRAL',
      titleKey: 'datasource.business.central',
      imgAlt: 'Business Central',
      imgSource: 'assets/cloud-icon/business-central.png',
    },
    {
      value: 'REST_API',
      titleKey: 'datasource.rest.api',
      imgAlt: 'REST API',
      imgSource: 'assets/cloud-icon/rest-api.png',
    },
  ];

  options = computed<OptionButtonItem[]>(() => this._optionConfigs.map((option) => this.createOption(option)));

  override canGoforward = computed((): boolean => {
    return this._dsWizardStore.datasourceType() !== null && this._dsWizardStore.datasourceType() !== undefined;
  });

  override onForward(): void {
    this._dsWizardStore.operationCreate();
  }

  private createOption(option: DataSourceOptionConfig): OptionButtonItem {
    return {
      title: this._translateService.instant(option.titleKey),
      subtitle: '',
      icon: '',
      imgAlt: option.imgAlt,
      imgSource: option.imgSource,
      isSelected: this._dsWizardStore.datasourceType() === option.value,
      onSelect: () => {
        this._dsWizardStore.setDatasourceType(option.value);
      },
      onDeselect: () => {
        if (this._dsWizardStore.datasourceType() === option.value) {
          this._dsWizardStore.setDatasourceType(null);
        }
      },
    };
  }
}
