import { TiaraSuiteWizardComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { ConnectorService } from '@alkyra/connector/services/connector.service';
import { Id } from '@alkyra/shared-models/id.model';
import { ChangeDetectionStrategy, Component, inject, input, OnInit, output } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import notify from 'devextreme/ui/notify';

import { DatasourceWizardStore } from './+store/data-source-wizard.store';
import { DataSourceEditComponentPanel } from './data-source-edit-panel/data-source-edit-panel.component';
import { DataSourceTypeSelectorComponent } from './data-source-type-selector/data-source-type-selector.component';

@Component({
  selector: 'alk-datasource-wizard',
  standalone: true,
  imports: [TranslatePipe, TiaraSuiteWizardComponent, DataSourceTypeSelectorComponent, DataSourceEditComponentPanel],
  templateUrl: './data-source-wizard.component.html',
  styleUrl: './data-source-wizard.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [DatasourceWizardStore],
})
export class DataSourceWizardComponent implements OnInit {
  onClose = output<void>();
  onSavedDataset = output<Id>();
  pipelineId = input<string | null>();

  readonly _dsWizardStore = inject(DatasourceWizardStore);
  readonly _translateService = inject(TranslateService);

  connectorService = inject(ConnectorService);

  ngOnInit(): void {
    this._dsWizardStore.resetInitialState();
  }

  close() {
    this.onClose.emit();
  }

  complete() {
    const connector = this._dsWizardStore.connector()!;
    const request$ = connector.id
      ? this.connectorService.updateConnector(connector)
      : this.connectorService.saveConnector(connector);

    request$.subscribe({
      next: () => {
        this.onClose.emit();
        notify({
          message: this._translateService.instant('connection.saved.successfully'),
          type: 'success',
          displayTime: 3000,
        });
      },
      error: (err) => notify({ message: err.message ?? err, type: 'error', displayTime: 3000 }),
    });
  }
}
