import { HubSpotConnectorStatus } from '@alkyra/hubspot-connector/models/hubspot-connector.model';
import { HubSpotConnectorService } from '@alkyra/hubspot-connector/services/hubspot-connector.service';
import { ChangeDetectionStrategy, Component, computed, inject, OnInit, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';

type HubSpotOauthMessage =
  | { type: 'hubspot-oauth-complete'; payload: unknown }
  | { type: 'hubspot-oauth-error'; message: string };

@Component({
  selector: 'alk-hubspot-oauth-callback',
  standalone: true,
  templateUrl: './hubspot-oauth-callback.component.html',
  styleUrl: './hubspot-oauth-callback.component.scss',
  imports: [TranslatePipe, DxLoadIndicatorModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HubSpotOauthCallbackComponent implements OnInit {
  private readonly _route = inject(ActivatedRoute);
  private readonly _hubSpotConnectorService = inject(HubSpotConnectorService);
  private readonly _translateService = inject(TranslateService);

  readonly isLoading = signal(true);
  readonly isError = signal(false);
  readonly message = signal('');
  readonly titleKey = computed(() => {
    if (this.isLoading()) {
      return 'hubspot.oauth.callback.loading';
    }
    return this.isError() ? 'hubspot.oauth.callback.error' : 'hubspot.oauth.callback.completed';
  });

  ngOnInit(): void {
    const params = this._route.snapshot.queryParamMap;
    this.message.set(this._translateService.instant('hubspot.oauth.callback.loading'));

    this._hubSpotConnectorService
      .oauthCallback({
        code: params.get('code'),
        state: params.get('state'),
        error: params.get('error'),
        error_description: params.get('error_description'),
      })
      .subscribe({
        next: (response) => {
          const isInvalid = response.status === HubSpotConnectorStatus.INVALID;
          this.isLoading.set(false);
          this.isError.set(isInvalid);
          this.message.set(
            isInvalid
              ? (response.message ?? this._translateService.instant('hubspot.oauth.callback.error'))
              : this._translateService.instant('hubspot.oauth.connected.success'),
          );
          this.postToOpener({ type: 'hubspot-oauth-complete', payload: response });
          this.closePopupSoon();
        },
        error: (error) => {
          const message =
            error?.error?.detail ??
            error?.error?.message ??
            error?.message ??
            this._translateService.instant('hubspot.oauth.callback.error');
          this.isLoading.set(false);
          this.isError.set(true);
          this.message.set(message);
          this.postToOpener({ type: 'hubspot-oauth-error', message });
          this.closePopupSoon();
        },
      });
  }

  private postToOpener(message: HubSpotOauthMessage): void {
    if (typeof window === 'undefined') {
      return;
    }

    if (window.opener && !window.opener.closed) {
      window.opener.postMessage(message, window.location.origin);
    }
  }

  private closePopupSoon(): void {
    if (typeof window === 'undefined' || !window.opener) {
      return;
    }

    setTimeout(() => window.close(), 800);
  }
}
