﻿import { TiaraNavBarUiComponent } from '@akeron-ng/tiara-ng/tiara-nav-bar-ui';
import { DataGridDataType } from '@alkyra/datagrid-column-type-mapper/models/data-grid-type-mapper.types';
import { DataGridColumnTypeMapperService } from '@alkyra/datagrid-column-type-mapper/services/data-grid-column-type-mapper.service';
import { Dataset, DatasetType } from '@alkyra/dataset/models/dataset.model';
import { DatasetAggregationRelation } from '@alkyra/dataset/models/dataset-aggregation.model';
import { DatasetConnector } from '@alkyra/dataset/models/dataset-connector.model';
import { DatasetJoinRelation } from '@alkyra/dataset/models/dataset-join.model';
import { DatasetSubsetRelation } from '@alkyra/dataset/models/dataset-subset.model';
import { DatasetUnionRelation } from '@alkyra/dataset/models/dataset-union.model';
import {
  AuditDatasetAggregationDto,
  AuditDatasetColumnDto,
  AuditDatasetDto,
  AuditDatasetJoinColumnsDto,
  AuditDatasetSubsetPreviewDto,
  AuditDatasetUnionRelationDto,
  AuditParquetPreviewDto,
  PipelineAuditExecutionDto,
} from '@alkyra/logs/models/data-audit.model';
import { DataAuditService } from '@alkyra/logs/services/data-audit.service';
import { PipelineFlowComponent } from '@alkyra/pages/pipeline/components/pipeline-flow/pipeline-flow.component';
import { Pipeline, PipelineType } from '@alkyra/pipeline/models/pipeline.model';
import { CommonModule } from '@angular/common';
import { Component, computed, inject, OnInit, signal, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { CustomStore } from 'devextreme/common/data';
import { confirm } from 'devextreme/ui/dialog';
import notify from 'devextreme/ui/notify';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxDataGridComponent, DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxSplitterModule } from 'devextreme-angular/ui/splitter';
import { catchError, forkJoin, lastValueFrom, map, of } from 'rxjs';

interface ExecutionOption extends PipelineAuditExecutionDto {
  label: string;
}

interface AuditColumnView {
  datasetId: string;
  name: string;
  alias?: string;
  typeOriginal?: string;
}

interface AuditColumnGridView {
  dataField: string;
  caption: string;
  dataType: DataGridDataType;
}

type JoinSide = 'left' | 'right';

interface JoinDefinition {
  leftId?: string;
  rightId?: string;
  joinType?: string;
}

@Component({
  selector: 'alk-data-audit',
  standalone: true,
  imports: [
    CommonModule,
    TiaraNavBarUiComponent,
    TranslatePipe,
    DxSelectBoxModule,
    DxDataGridModule,
    DxButtonModule,
    DxLoadIndicatorModule,
    DxSplitterModule,
    PipelineFlowComponent,
  ],
  templateUrl: './data-audit.component.html',
  styleUrl: './data-audit.component.scss',
})
export class DataAuditComponent implements OnInit {
  private readonly _route = inject(ActivatedRoute);
  private readonly _router = inject(Router);
  private readonly _dataAuditService = inject(DataAuditService);
  private readonly _dataGridColumnTypeMapper = inject(DataGridColumnTypeMapperService);
  private readonly _translateService = inject(TranslateService);

  @ViewChild(DxDataGridComponent) previewGrid?: DxDataGridComponent;

  pipelineId = '';
  correlationId: string | null = null;
  outcome: string | null = null;
  source: string | null = null;
  workspaceId: string | null = null;

  auditExecutions = signal<PipelineAuditExecutionDto[]>([]);
  selectedExecutionId = signal<string | null>(null);

  datasets = signal<Dataset[]>([]);
  datasetJoins = signal<DatasetJoinRelation[]>([]);
  datasetUnions = signal<DatasetUnionRelation[]>([]);
  datasetSubsets = signal<DatasetSubsetRelation[]>([]);
  datasetAggregations = signal<DatasetAggregationRelation[]>([]);

  columns = signal<AuditColumnView[]>([]);
  selectedDataset = signal<Dataset | null>(null);

  previewCustomStore = signal<CustomStore>(
    new CustomStore({
      load: () => Promise.resolve([]),
    }),
  );
  previewMeta = signal<AuditParquetPreviewDto | null>(null);
  isDownloading = signal(false);
  private lastLoadOptions: Record<string, unknown> | null = null;

  hasExecutions = computed(() => this.auditExecutions().length > 0);
  selectedExecution = computed(() => this.auditExecutions().find((ex) => ex.id === this.selectedExecutionId()) || null);
  executionOptions = computed<ExecutionOption[]>(() =>
    this.auditExecutions().map((ex, index) => ({
      ...ex,
      label: this.buildExecutionLabel(ex, index),
    })),
  );

  previewColumns = computed<AuditColumnGridView[]>(() => {
    const previewMeta = this.previewMeta();
    const sample = previewMeta?.data?.[0];
    const previewKeys = new Set(sample ? Object.keys(sample) : []);
    const previewColumns = previewMeta?.columns ?? [];

    if (previewColumns.length) {
      return previewColumns
        .map((column) => {
          const alias = column.alias?.trim();
          const name = column.name?.trim();
          const dataField =
            (alias && previewKeys.has(alias) && alias) ||
            (name && previewKeys.has(name) && name) ||
            alias ||
            name ||
            '';
          const dataType = this._dataGridColumnTypeMapper.mapType(column.column?.typeOrigCol);
          return {
            dataField,
            caption: alias || name || dataField,
            dataType,
          };
        })
        .filter((column) => !!column.dataField);
    }

    if (!sample) {
      return [];
    }

    return Object.keys(sample).map((key) => ({
      dataField: key,
      caption: key,
      dataType: this._dataGridColumnTypeMapper.mapType(undefined),
    }));
  });

  selectedColumns = computed<AuditColumnGridView[]>(() => {
    const previewColumns = this.previewColumns();
    if (previewColumns.length) {
      return previewColumns;
    }

    const datasetId = this.selectedDataset()?.id;
    if (!datasetId) {
      return [];
    }
    const sample = this.previewMeta()?.data?.[0];
    const previewKeys = new Set(sample ? Object.keys(sample) : []);
    const datasetColumns = this.columns()
      .filter((column) => column.datasetId === datasetId)
      .map((column) => {
        const alias = column.alias?.trim();
        const name = column.name?.trim();
        const dataField =
          (alias && previewKeys.has(alias) && alias) || (name && previewKeys.has(name) && name) || alias || name || '';
        const dataType = this._dataGridColumnTypeMapper.mapType(column.typeOriginal);
        return {
          dataField,
          caption: alias || name || dataField,
          dataType,
        };
      })
      .filter((column) => !!column.dataField);

    if (!datasetColumns.length) {
      return [];
    }
    if (previewKeys.size === 0) {
      return datasetColumns;
    }
    const matchingColumns = datasetColumns.filter((column) => previewKeys.has(column.dataField));
    return matchingColumns.length ? matchingColumns : datasetColumns;
  });

  ngOnInit(): void {
    this.pipelineId = this._route.snapshot.paramMap.get('pipelineId') || '';
    this.correlationId = this._route.snapshot.queryParamMap.get('correlationId');
    this.outcome = this._route.snapshot.queryParamMap.get('outcome');
    this.source = this._route.snapshot.queryParamMap.get('source');
    this.workspaceId = this._route.snapshot.queryParamMap.get('workspaceId');

    if (!this.pipelineId) {
      return;
    }

    this.loadSnapshots();
  }

  onBackClick() {
    if (this.source !== 'pipeline') {
      this._router.navigate(['/logs']);
      return;
    }
    if (!this.workspaceId) {
      this._router.navigate(['/logs']);
      return;
    }
    this._router.navigate(['/workspaces', this.workspaceId, 'pipelines']);
  }

  getBackTitleKey(): string {
    return this.source === 'pipeline' ? 'pipeline.list.header.title' : 'log.header.title';
  }

  onExecutionChanged(executionId: string) {
    this.selectedExecutionId.set(executionId);
    if (!executionId) {
      return;
    }
    this.loadSnapshotDetails(executionId);
  }

  selectDataset(dataset: Dataset) {
    this.selectedDataset.set(dataset);
    this.previewMeta.set(null);
    this.lastLoadOptions = null;
    this.previewCustomStore.set(this.createPreviewStore(dataset));
  }

  async onDownload(): Promise<void> {
    const dataset = this.selectedDataset();
    const execution = this.selectedExecution();
    const correlationId = execution?.correlationId;
    if (!dataset || !correlationId) {
      return;
    }

    this.isDownloading.set(true);
    const loadOptions = this.buildDownloadLoadOptions();
    if (!this.hasActiveFilter(loadOptions)) {
      const confirmMessage = this._translateService.instant('data.audit.download.confirm', { name: dataset.name });
      const confirmTitle = this._translateService.instant('data.audit.download.title');
      const confirmed = await confirm(confirmMessage, confirmTitle);
      if (!confirmed) {
        this.isDownloading.set(false);
        return;
      }
    }
    const visibleColumns = this.getVisibleColumnFields();

    try {
      const response = await lastValueFrom(
        this._dataAuditService.downloadAuditCsv(this.pipelineId, correlationId, dataset.id, {
          loadOptions,
          visibleColumns,
        }),
      );
      const fileName =
        this.extractFileName(response.headers.get('content-disposition')) ||
        `audit_${this.pipelineId}_${dataset.id}.csv`;
      this.downloadBlob(response.body, fileName);
    } catch {
      notify(this._translateService.instant('data.audit.download.error'), 'error', 4000);
    } finally {
      this.isDownloading.set(false);
    }
  }

  isPartialOutcome(): boolean {
    return this.outcome === 'KO';
  }

  private loadSnapshots() {
    this._dataAuditService.geAuditExecutions(this.pipelineId).subscribe((executions) => {
      const sorted = [...executions].sort(
        (a, b) => new Date(b.executionStartTime).getTime() - new Date(a.executionStartTime).getTime(),
      );
      this.auditExecutions.set(sorted);

      if (!sorted.length) {
        return;
      }

      const selected =
        (this.correlationId && sorted.find((exec) => exec.correlationId === this.correlationId)) || sorted[0];
      this.selectedExecutionId.set(selected.id);
      this.loadSnapshotDetails(selected.id);
    });
  }

  private loadSnapshotDetails(executionId: string) {
    const execution = this.auditExecutions().find((ex) => ex.id === executionId);
    if (!execution) {
      return;
    }
    const snapshotId = execution.snapshotId;
    forkJoin({
      datasets: this._dataAuditService.getDatasets(snapshotId).pipe(catchError(() => of([]))),
      datasetColumns: this._dataAuditService.getDatasetColumns(snapshotId).pipe(catchError(() => of([]))),
      joinColumns: this._dataAuditService.getDatasetJoinColumns(snapshotId).pipe(catchError(() => of([]))),
      unions: this._dataAuditService.getDatasetUnions(snapshotId).pipe(catchError(() => of([]))),
      subsets: this._dataAuditService.getDatasetSubsets(snapshotId).pipe(catchError(() => of([]))),
      aggregations: this._dataAuditService.getDatasetAggregations(snapshotId).pipe(catchError(() => of([]))),
    }).subscribe(({ datasets, datasetColumns, joinColumns, unions, subsets, aggregations }) => {
      const mappedDatasets = this.mapDatasets(datasets);
      this.datasets.set(mappedDatasets);
      this.columns.set(this.mapColumns(datasetColumns));
      this.datasetUnions.set(this.mapUnionRelations(unions));
      this.datasetAggregations.set(this.mapAggregationRelations(aggregations));
      this.datasetSubsets.set(this.mapSubsetRelations(mappedDatasets, subsets));
      this.datasetJoins.set(this.mapJoinRelations(mappedDatasets, datasetColumns, joinColumns));

      const initialDataset = mappedDatasets.toSorted((a, b) => a.datasetOrder - b.datasetOrder)[0] || null;
      if (initialDataset) {
        this.selectDataset(initialDataset);
      } else {
        this.selectedDataset.set(null);
        this.previewCustomStore.set(
          new CustomStore({
            load: () => Promise.resolve([]),
          }),
        );
      }
    });
  }

  private createPreviewStore(dataset: Dataset) {
    const datasetId = dataset.id;
    const execution = this.selectedExecution();
    const correlationId = execution?.correlationId;

    if (!correlationId) {
      return new CustomStore({
        load: () => Promise.resolve([]),
      });
    }

    return new CustomStore({
      load: (loadOptions) => {
        const normalizedLoadOptions = {
          ...(loadOptions ?? {}),
          requireTotalCount: true,
        } as Record<string, unknown>;
        this.lastLoadOptions = normalizedLoadOptions;

        return lastValueFrom(
          this._dataAuditService.getAuditPreview(this.pipelineId, correlationId, datasetId, normalizedLoadOptions).pipe(
            map((preview) => {
              const totalCount =
                typeof preview.totalCount === 'number' ? preview.totalCount : (preview.data?.length ?? 0);
              const normalizedPreview = {
                ...preview,
                data: preview.data ?? [],
                totalCount,
              };
              this.previewMeta.set(normalizedPreview);
              return { data: normalizedPreview.data, totalCount: normalizedPreview.totalCount };
            }),
            catchError(() => {
              this.previewMeta.set({
                data: [],
                totalCount: 0,
                status: 'ERROR',
                note: 'Preview unavailable',
              });
              return of({ data: [], totalCount: 0 });
            }),
          ),
        );
      },
    });
  }

  private mapDatasets(datasets: AuditDatasetDto[]): Dataset[] {
    const pipelineStub: Pipeline = {
      id: this.pipelineId,
      name: '',
      description: '',
      workspace: undefined,
      pipelineParams: [],
      pipelineType: PipelineType.BATCH,
    };

    return datasets.map((dataset) => ({
      id: dataset.id,
      name: dataset.name,
      description: dataset.description,
      type: this.normalizeDatasetType(dataset.type),
      datasetOrder: dataset.datasetOrder,
      exportable: false,
      datasetConnector: (dataset.datasetConnector ?? {}) as DatasetConnector,
      exportDatasetConnectors: (dataset.exportDatasetConnectors ?? []) as DatasetConnector[],
      columns: [],
      pipeline: pipelineStub,
    }));
  }

  private mapColumns(columns: AuditDatasetColumnDto[]): AuditColumnView[] {
    return columns
      .map((column) => ({
        datasetId: column.dataset?.id || '',
        name: column.name,
        alias: column.alias ?? undefined,
        typeOriginal: column.column?.typeOrigCol ?? undefined,
      }))
      .filter((column) => !!column.datasetId);
  }

  private mapUnionRelations(relations: AuditDatasetUnionRelationDto[]): DatasetUnionRelation[] {
    return relations.map((relation) => ({
      datasetId: relation.datasetId,
      leftDatasetId: relation.leftDatasetId,
      rightDatasetId: relation.rightDatasetId,
    }));
  }

  private mapAggregationRelations(relations: AuditDatasetAggregationDto[]): DatasetAggregationRelation[] {
    return relations
      .map((relation) => ({
        datasetId: relation.dataset?.id || '',
        datasetSourceId: relation.datasetSource?.id || '',
      }))
      .filter((relation) => relation.datasetId && relation.datasetSourceId);
  }

  private mapSubsetRelations(datasets: Dataset[], relations: AuditDatasetSubsetPreviewDto[]): DatasetSubsetRelation[] {
    const subsetDatasets = datasets
      .filter((dataset) => dataset.type === DatasetType.SUBSET)
      .sort((a, b) => a.datasetOrder - b.datasetOrder);
    const datasetOrder = new Map(datasets.map((dataset) => [dataset.id, dataset.datasetOrder]));
    const used = new Set<number>();

    return subsetDatasets
      .map((dataset) => {
        const candidateIndex = this.findBestRelationIndex(
          relations,
          used,
          dataset.datasetOrder,
          datasetOrder,
          'datasetSourceId',
        );
        if (candidateIndex === -1) {
          return null;
        }
        used.add(candidateIndex);
        const relation = relations[candidateIndex];
        return { datasetId: dataset.id, datasetSourceId: relation.datasetSourceId } as DatasetSubsetRelation;
      })
      .filter((relation): relation is DatasetSubsetRelation => !!relation);
  }

  private mapJoinRelations(
    datasets: Dataset[],
    columns: AuditDatasetColumnDto[],
    joinColumns: AuditDatasetJoinColumnsDto[],
  ): DatasetJoinRelation[] {
    const joinDatasets = datasets
      .filter((dataset) => dataset.type === DatasetType.JOIN)
      .sort((a, b) => a.datasetOrder - b.datasetOrder);
    const datasetOrder = new Map(datasets.map((dataset) => [dataset.id, dataset.datasetOrder]));
    const columnDatasetMap = this.buildColumnDatasetMap(columns);
    const joinDefinitions = this.buildJoinDefinitions(joinColumns, columnDatasetMap);
    const joinList = Array.from(joinDefinitions.values()).filter((item) => item.leftId && item.rightId);
    const used = new Set<number>();

    return joinDatasets
      .map((dataset) => {
        const candidateIndex = this.findBestJoinIndex(joinList, used, dataset.datasetOrder, datasetOrder);
        if (candidateIndex === -1) {
          return null;
        }
        used.add(candidateIndex);
        const relation = joinList[candidateIndex];
        return {
          datasetId: dataset.id,
          leftDatasetId: relation.leftId!,
          rightDatasetId: relation.rightId!,
          joinType: relation.joinType,
        } as DatasetJoinRelation;
      })
      .filter((relation): relation is DatasetJoinRelation => !!relation);
  }

  private buildColumnDatasetMap(columns: AuditDatasetColumnDto[]): Map<string, string> {
    const columnDatasetMap = new Map<string, string>();
    columns.forEach((column) => {
      const columnId = column.column?.id;
      if (columnId && column.dataset?.id) {
        columnDatasetMap.set(columnId, column.dataset.id);
      }
    });
    return columnDatasetMap;
  }

  private buildJoinDefinitions(
    joinColumns: AuditDatasetJoinColumnsDto[],
    columnDatasetMap: Map<string, string>,
  ): Map<string, JoinDefinition> {
    const joinDefinitions = new Map<string, JoinDefinition>();
    joinColumns.forEach((joinColumn) => {
      const joinId = this.getJoinId(joinColumn);
      if (!joinId) {
        return;
      }
      const existing = joinDefinitions.get(joinId) || {};
      const leftId = existing.leftId || this.resolveJoinDatasetId(joinColumn, columnDatasetMap, 'left');
      const rightId = existing.rightId || this.resolveJoinDatasetId(joinColumn, columnDatasetMap, 'right');
      const joinType = existing.joinType || joinColumn.datasetJoinId?.joinType;
      joinDefinitions.set(joinId, { leftId, rightId, joinType });
    });
    return joinDefinitions;
  }

  private getJoinId(joinColumn: AuditDatasetJoinColumnsDto): string | null {
    return joinColumn.datasetJoinId?.id || joinColumn.id || null;
  }

  private resolveJoinDatasetId(
    joinColumn: AuditDatasetJoinColumnsDto,
    columnDatasetMap: Map<string, string>,
    side: JoinSide,
  ): string | undefined {
    const fromJoin = this.getJoinDatasetIdFromRelation(joinColumn, side);
    if (fromJoin) {
      return fromJoin;
    }
    const columnId = this.getJoinColumnId(joinColumn, side);
    if (!columnId) {
      return undefined;
    }
    return columnDatasetMap.get(columnId);
  }

  private getJoinDatasetIdFromRelation(joinColumn: AuditDatasetJoinColumnsDto, side: JoinSide): string | undefined {
    if (side === 'left') {
      return joinColumn.datasetJoinId?.datasetIdLeft?.id;
    }
    return joinColumn.datasetJoinId?.datasetIdRight?.id;
  }

  private getJoinColumnId(joinColumn: AuditDatasetJoinColumnsDto, side: JoinSide): string | undefined {
    if (side === 'left') {
      return joinColumn.columnLeft?.id;
    }
    return joinColumn.columnRight?.id;
  }

  private findBestRelationIndex<T extends { datasetSourceId: string }>(
    relations: T[],
    used: Set<number>,
    targetOrder: number,
    datasetOrder: Map<string, number>,
    sourceKey: keyof T,
  ): number {
    let bestIndex = -1;
    let bestOrder = -Infinity;

    relations.forEach((relation, index) => {
      if (used.has(index)) {
        return;
      }
      const sourceId = relation[sourceKey] as unknown as string;
      const sourceOrder = datasetOrder.get(sourceId);
      if (sourceOrder === undefined) {
        return;
      }
      if (sourceOrder < targetOrder && sourceOrder > bestOrder) {
        bestOrder = sourceOrder;
        bestIndex = index;
      }
    });

    if (bestIndex !== -1) {
      return bestIndex;
    }

    return relations.findIndex((_, index) => !used.has(index));
  }

  private findBestJoinIndex(
    relations: Array<{ leftId?: string; rightId?: string }>,
    used: Set<number>,
    targetOrder: number,
    datasetOrder: Map<string, number>,
  ): number {
    let bestIndex = -1;
    let bestScore = -Infinity;

    relations.forEach((relation, index) => {
      if (used.has(index)) {
        return;
      }
      const score = this.getJoinRelationScore(relation, datasetOrder);
      if (score === null) {
        return;
      }
      if (score < targetOrder && score > bestScore) {
        bestScore = score;
        bestIndex = index;
      }
    });

    if (bestIndex !== -1) {
      return bestIndex;
    }

    return relations.findIndex((_, index) => !used.has(index));
  }

  private getJoinRelationScore(
    relation: { leftId?: string; rightId?: string },
    datasetOrder: Map<string, number>,
  ): number | null {
    const leftOrder = this.getDatasetOrder(datasetOrder, relation.leftId);
    const rightOrder = this.getDatasetOrder(datasetOrder, relation.rightId);
    if (leftOrder === null || rightOrder === null) {
      return null;
    }
    return Math.max(leftOrder, rightOrder);
  }

  private getDatasetOrder(datasetOrder: Map<string, number>, datasetId?: string): number | null {
    if (!datasetId) {
      return null;
    }
    const order = datasetOrder.get(datasetId);
    return order === undefined ? null : order;
  }

  private normalizeDatasetType(type: string): DatasetType {
    const normalized = type?.toUpperCase() as DatasetType;
    return Object.values(DatasetType).includes(normalized) ? normalized : DatasetType.SIMPLE;
  }

  private buildExecutionLabel(execution: PipelineAuditExecutionDto, index: number): string {
    const date = new Date(execution.executionStartTime);
    const dateLabel = Number.isNaN(date.getTime()) ? execution.executionStartTime : date.toLocaleString();
    const executionLabel =
      this._translateService.instant('data.audit.execution.index', { index: index + 1 }) || `Execution #${index + 1}`;
    return `${dateLabel} • ${executionLabel}`;
  }

  private buildDownloadLoadOptions(): Record<string, unknown> {
    const source = this.lastLoadOptions ?? {};
    const downloadOptions: Record<string, unknown> = {};
    if (source['filter']) {
      downloadOptions['filter'] = source['filter'];
    }
    if (source['sort']) {
      downloadOptions['sort'] = source['sort'];
    }
    return downloadOptions;
  }

  private hasActiveFilter(loadOptions: Record<string, unknown>): boolean {
    const filter = loadOptions['filter'];
    if (filter === null || filter === undefined) {
      return false;
    }
    if (typeof filter === 'string') {
      return filter.trim().length > 0;
    }
    if (Array.isArray(filter)) {
      return filter.length > 0;
    }
    return true;
  }

  private getVisibleColumnFields(): string[] {
    const grid = this.previewGrid?.instance;
    if (grid) {
      return grid
        .getVisibleColumns()
        .filter((column) => !!column.dataField)
        .sort((a, b) => (a.visibleIndex ?? 0) - (b.visibleIndex ?? 0))
        .map((column) => String(column.dataField));
    }
    return this.selectedColumns().map((column) => column.dataField);
  }

  private extractFileName(contentDisposition: string | null): string | null {
    if (!contentDisposition) {
      return null;
    }
    const utf8Match = /filename\*=UTF-8''([^;]+)/i.exec(contentDisposition);
    if (utf8Match?.[1]) {
      return decodeURIComponent(utf8Match[1]);
    }
    const asciiMatch = /filename="?([^\";]+)\"?/i.exec(contentDisposition);
    return asciiMatch?.[1] ?? null;
  }

  private downloadBlob(blob: Blob | null, fileName: string): void {
    if (!blob) {
      return;
    }
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = fileName;
    anchor.click();
    URL.revokeObjectURL(url);
  }
}
