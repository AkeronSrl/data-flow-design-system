import {
  TiaraCircularIllustrationComponent,
  TiaraExpandableListItemComponent,
  TiaraListItemComponent,
  TiaraListItemSectionComponent,
} from '@akeron-ng/tiara-ng';
import {
  ExportErrorStoreItemDto,
  ExportErrorStoreQueryDto,
  PipelineAuditExecutionDto,
  PipelineExecutionDetailLogDto,
} from '@alkyra/logs/models/data-audit.model';
import { LogDetail } from '@alkyra/logs/models/log.model';
import { DataAuditService } from '@alkyra/logs/services/data-audit.service';
import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  EventEmitter,
  Input,
  inject,
  OnChanges,
  Output,
  SimpleChanges,
  signal,
} from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxPopupModule } from 'devextreme-angular/ui/popup';
import { lastValueFrom } from 'rxjs';

interface FlatCellView {
  key: string;
  label: string;
  value: string;
}

interface CellViewInput {
  key: string;
  label: string;
  value: string;
  isTranslationKey?: boolean;
}

interface PopupLoadContext {
  pipelineId: string;
  correlationId: string;
  detail: LogDetail;
}

interface ExportErrorDetailCardView {
  id: string;
  fields: FlatCellView[];
  columnsNumber: number;
}

interface ExportErrorRowView {
  id: string;
  columnsNumber: number;
  errorType: FlatCellView;
  errorDescription: FlatCellView;
  payloadFields: FlatCellView[];
  detailCards: ExportErrorDetailCardView[];
}

@Component({
  selector: 'alk-log-error-popup',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    DxPopupModule,
    DxButtonModule,
    DxLoadIndicatorModule,
    TiaraCircularIllustrationComponent,
    TiaraExpandableListItemComponent,
    TiaraListItemComponent,
    TiaraListItemSectionComponent,
  ],
  templateUrl: './log-error-popup.component.html',
  styleUrl: './log-error-popup.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LogErrorPopupComponent implements OnChanges {
  private readonly _dataAuditService = inject(DataAuditService);
  private readonly _pageSize = 10;

  @Input() visible = false;
  @Input() pipelineId: string | null = null;
  @Input() correlationId: string | null = null;
  @Input() detail: LogDetail | null = null;

  @Output() onClosePopup = new EventEmitter<void>();

  protected readonly isLoading = signal(false);
  protected readonly isLoadingErrors = signal(false);
  protected readonly loadFailed = signal(false);
  protected readonly executionDetail = signal<PipelineExecutionDetailLogDto | null>(null);
  protected readonly exportErrors = signal<ExportErrorStoreItemDto[]>([]);
  protected readonly currentPage = signal(0);
  protected readonly totalCount = signal(0);
  protected readonly expandedErrorRows = signal<Record<string, boolean>>({});

  protected readonly errorSummary = computed(
    () => this.executionDetail()?.errorSummary || this.detail?.description || '-',
  );
  protected readonly detailPayload = computed<Record<string, unknown>>(
    () => this.executionDetail()?.detailPayload || {},
  );
  protected readonly errorCount = computed(() => this.readNumericField('unmanageableErrorCount'));
  protected readonly warningCount = computed(() => this.readNumericField('manageableErrorCount'));
  protected readonly classificationEntries = computed(() =>
    Object.entries(this.readRecordField('classificationCounts')).map(([key, value]) => ({
      key,
      value: typeof value === 'number' ? value : Number(value ?? 0),
    })),
  );
  protected readonly firstUnmanageableError = computed(() => {
    const field = this.detailPayload()['firstUnmanageableError'];
    return this.isRecord(field) ? field : null;
  });
  protected readonly firstUnmanageableMessage = computed(() => {
    const message = this.firstUnmanageableError()?.['message'];
    return typeof message === 'string' || typeof message === 'number' ? message : '-';
  });
  protected readonly firstUnmanageableType = computed(() => {
    const classification = this.firstUnmanageableError()?.['classification'];
    if (typeof classification === 'string' || typeof classification === 'number') {
      return classification;
    }
    return this.firstUnmanageableMessage();
  });
  protected readonly payloadColumnKeys = computed(() => this.collectPayloadColumnKeys(this.exportErrors()));
  protected readonly exportErrorRows = computed(() =>
    this.exportErrors().map((row) => this.buildExportErrorRowView(row, this.payloadColumnKeys())),
  );
  protected readonly hasExportErrors = computed(() => this.exportErrors().length > 0);
  protected readonly pageInfo = computed(() => {
    const total = this.totalCount();
    const page = this.currentPage();
    const start = total === 0 ? 0 : page * this._pageSize + 1;
    const end = total === 0 ? 0 : Math.min((page + 1) * this._pageSize, total);
    return { start, end, total };
  });
  protected readonly canGoPrevious = computed(() => this.currentPage() > 0);
  protected readonly canGoNext = computed(() => (this.currentPage() + 1) * this._pageSize < this.totalCount());

  ngOnChanges(changes: SimpleChanges): void {
    if (!this.shouldLoadPopupData(changes)) {
      return;
    }
    void this.loadPopupData();
  }

  protected closePopup(): void {
    this.onClosePopup.emit();
  }

  protected isExportDetail(): boolean {
    return this.detail?.detailType === 'EXPORT';
  }

  protected async goToPreviousPage(): Promise<void> {
    if (!this.canGoPrevious()) {
      return;
    }
    await this.loadExportErrors(this.currentPage() - 1);
  }

  protected async goToNextPage(): Promise<void> {
    if (!this.canGoNext()) {
      return;
    }
    await this.loadExportErrors(this.currentPage() + 1);
  }

  protected isErrorRowExpanded(rowId: string): boolean {
    return !!this.expandedErrorRows()[rowId];
  }

  protected onErrorRowExpandedChange(rowId: string, expanded: boolean): void {
    this.expandedErrorRows.update((state) => ({ ...state, [rowId]: expanded }));
  }

  private async loadPopupData(): Promise<void> {
    this.executionDetail.set(null);
    this.exportErrors.set([]);
    this.totalCount.set(0);
    this.currentPage.set(0);
    this.expandedErrorRows.set({});
    this.loadFailed.set(false);

    const context = this.getPopupLoadContext();
    if (!context) {
      return;
    }

    this.isLoading.set(true);

    try {
      const executions = await lastValueFrom(this._dataAuditService.geAuditExecutions(context.pipelineId));
      const matchedDetail = this.findMatchingExecutionDetail(executions, context.correlationId, context.detail);
      this.executionDetail.set(matchedDetail);

      if (this.shouldLoadExportErrors(context.detail)) {
        await this.loadExportErrors(0);
      }
    } catch {
      this.loadFailed.set(true);
    } finally {
      this.isLoading.set(false);
    }
  }

  private findMatchingExecutionDetail(
    executions: PipelineAuditExecutionDto[],
    correlationId: string,
    detail: LogDetail,
  ): PipelineExecutionDetailLogDto | null {
    const execution = executions.find((item) => item.correlationId === correlationId);
    if (!execution?.details?.length) {
      return null;
    }

    const normalizedType = detail.detailType?.toUpperCase();
    const matches = execution.details.filter((candidate) =>
      this.matchesExecutionDetail(candidate, detail, normalizedType),
    );

    return matches[0] ?? null;
  }

  private async loadExportErrors(page: number): Promise<void> {
    const query = this.buildExportErrorsQuery(page);
    if (!query) {
      return;
    }

    this.isLoadingErrors.set(true);
    try {
      const result = await lastValueFrom(this._dataAuditService.getExportErrors(query));
      this.exportErrors.set(result.items ?? []);
      this.currentPage.set(result.page ?? page);
      this.totalCount.set(result.totalCount ?? 0);
      this.expandedErrorRows.set({});
    } catch {
      this.loadFailed.set(true);
    } finally {
      this.isLoadingErrors.set(false);
    }
  }

  private collectPayloadColumnKeys(rows: ExportErrorStoreItemDto[]): string[] {
    const keys = new Set<string>();
    for (const row of rows) {
      for (const key of Object.keys(this.flattenRecord(row.payload))) {
        keys.add(key);
      }
    }
    return [...keys];
  }

  private buildExportErrorRowView(row: ExportErrorStoreItemDto, payloadColumnKeys: string[]): ExportErrorRowView {
    const flattenedPayload = this.flattenRecord(row.payload);
    const payloadFields = payloadColumnKeys.map((key) =>
      this.createCellView({
        key: `payload-${key}`,
        label: key,
        value: flattenedPayload[key] ?? '-',
      }),
    );
    const detailCards = row.errorDetails.map((detail, index) => this.buildErrorDetailCardView(row.id, detail, index));

    return {
      id: row.id,
      columnsNumber: payloadFields.length + 3,
      errorType: this.createCellView({
        key: 'error-type',
        label: 'log.error.popup.row.error.type',
        value: row.errorClassification || '-',
        isTranslationKey: true,
      }),
      errorDescription: this.createCellView({
        key: 'error-description',
        label: 'log.error.popup.row.error.description',
        value: row.errorMessage || '-',
        isTranslationKey: true,
      }),
      payloadFields,
      detailCards,
    };
  }

  private buildErrorDetailCardView(
    rowId: string,
    detail: Record<string, unknown>,
    index: number,
  ): ExportErrorDetailCardView {
    const flattened = this.flattenRecord(detail);
    const fields = Object.entries(flattened).map(([key, value]) =>
      this.createCellView({
        key: `detail-${index}-${key}`,
        label: key,
        value,
      }),
    );

    return {
      id: `${rowId}-detail-${index}`,
      fields,
      columnsNumber: Math.max(fields.length, 1),
    };
  }

  private createCellView({ key, label, value, isTranslationKey = false }: CellViewInput): FlatCellView {
    return {
      key,
      label: isTranslationKey ? label : this.formatFlattenedKey(label),
      value,
    };
  }

  private flattenRecord(record: Record<string, unknown>): Record<string, string> {
    const output: Record<string, string> = {};
    this.flattenValue(record, '', output);
    return output;
  }

  private flattenValue(value: unknown, prefix: string, output: Record<string, string>): void {
    if (Array.isArray(value)) {
      this.flattenArray(value, prefix, output);
      return;
    }

    if (this.isRecord(value)) {
      this.flattenObject(value, prefix, output);
      return;
    }

    this.flattenScalar(value, prefix, output);
  }

  private stringifyValue(value: unknown): string {
    if (value === null || value === undefined) {
      return '-';
    }
    if (typeof value === 'string') {
      return value;
    }
    if (typeof value === 'number' || typeof value === 'boolean') {
      return String(value);
    }
    return JSON.stringify(value);
  }

  private formatFlattenedKey(key: string): string {
    return key;
  }

  private readRecordField(fieldName: string): Record<string, unknown> {
    const value = this.detailPayload()[fieldName];
    return this.isRecord(value) ? value : {};
  }

  private readNumericField(fieldName: string): number {
    const value = this.detailPayload()[fieldName];
    return typeof value === 'number' ? value : Number(value ?? 0);
  }

  private shouldLoadPopupData(changes: SimpleChanges): boolean {
    if (!this.visible) {
      return false;
    }

    return !!(changes['visible'] || changes['pipelineId'] || changes['correlationId'] || changes['detail']);
  }

  private shouldLoadExportErrors(detail: LogDetail): boolean {
    return detail.detailType === 'EXPORT' && !!detail.detailKey;
  }

  private matchesExecutionDetail(
    candidate: PipelineExecutionDetailLogDto,
    detail: LogDetail,
    normalizedType?: string,
  ): boolean {
    if (normalizedType && candidate.detailType?.toUpperCase() !== normalizedType) {
      return false;
    }

    if (detail.detailKey) {
      return candidate.detailKey === detail.detailKey;
    }

    if (detail.detailLabel) {
      return candidate.detailLabel === detail.detailLabel;
    }

    return true;
  }

  private buildExportErrorsQuery(page: number): ExportErrorStoreQueryDto | null {
    const context = this.getPopupLoadContext();
    const datasetId = context?.detail.detailKey;
    if (!context || !datasetId) {
      return null;
    }

    return {
      pipelineId: context.pipelineId,
      correlationId: context.correlationId,
      datasetId,
      page,
      size: this._pageSize,
    };
  }

  private getPopupLoadContext(): PopupLoadContext | null {
    if (!this.pipelineId) {
      return null;
    }

    if (!this.correlationId) {
      return null;
    }

    if (!this.detail) {
      return null;
    }

    return {
      pipelineId: this.pipelineId,
      correlationId: this.correlationId,
      detail: this.detail,
    };
  }

  private flattenArray(value: unknown[], prefix: string, output: Record<string, string>): void {
    if (this.isEmptyContainer(value.length, prefix)) {
      output[prefix] = '[]';
      return;
    }

    value.forEach((item, index) => {
      this.flattenValue(item, this.buildArrayPrefix(prefix, index), output);
    });
  }

  private flattenObject(value: Record<string, unknown>, prefix: string, output: Record<string, string>): void {
    const entries = Object.entries(value);
    if (this.isEmptyContainer(entries.length, prefix)) {
      output[prefix] = '{}';
      return;
    }

    for (const [key, child] of entries) {
      this.flattenValue(child, this.buildObjectPrefix(prefix, key), output);
    }
  }

  private flattenScalar(value: unknown, prefix: string, output: Record<string, string>): void {
    if (!prefix) {
      return;
    }

    output[prefix] = this.stringifyValue(value);
  }

  private isEmptyContainer(length: number, prefix: string): boolean {
    return length === 0 && prefix.length > 0;
  }

  private buildArrayPrefix(prefix: string, index: number): string {
    return prefix ? `${prefix}[${index}]` : `[${index}]`;
  }

  private buildObjectPrefix(prefix: string, key: string): string {
    return prefix ? `${prefix}.${key}` : key;
  }

  private isRecord(value: unknown): value is Record<string, unknown> {
    return !!value && typeof value === 'object' && !Array.isArray(value);
  }
}
