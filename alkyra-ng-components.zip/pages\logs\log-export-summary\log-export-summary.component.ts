import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';

import { ExportSummaryView } from '../models/export-summary-view.model';

@Component({
  selector: 'alk-log-export-summary',
  templateUrl: './log-export-summary.component.html',
  styleUrl: './log-export-summary.component.scss',
  standalone: true,
  imports: [CommonModule, TranslatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LogExportSummaryComponent {
  @Input({ required: true })
  summary!: ExportSummaryView;
}
