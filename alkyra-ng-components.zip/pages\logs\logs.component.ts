import {
  TiaraCircularIllustrationComponent,
  TiaraExpandableListItemComponent,
  TiaraListComponent,
  TiaraListItemSectionComponent,
} from '@akeron-ng/tiara-ng';
import { TiaraSuiteFilterRecapItemComponent } from '@akeron-ng/tiara-ng-suite';
import { Log, LogDetail, LogOutcome, LogsFilter } from '@alkyra/logs/models/log.model';
import { MsFormatPipe } from '@alkyra/ms-format-pipe/ms-format.pipe';
import { CommonModule } from '@angular/common';
import { Component, computed, effect, inject, OnInit, signal, untracked } from '@angular/core';
import { Router } from '@angular/router';
import { TranslatePipe } from '@ngx-translate/core';
import { ValueChangedEvent as CheckBoxValueChangedEvent } from 'devextreme/ui/check_box';
import { ValueChangedEvent as DateRangeBoxValueChangedEvent } from 'devextreme/ui/date_range_box';
import { ValueChangedEvent as TextBoxValueChangedEvent } from 'devextreme/ui/text_box';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxCheckBoxModule } from 'devextreme-angular/ui/check-box';
import { DxDateRangeBoxModule } from 'devextreme-angular/ui/date-range-box';
import { DxListModule } from 'devextreme-angular/ui/list';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxTooltipModule } from 'devextreme-angular/ui/tooltip';
import { DxValidatorModule } from 'devextreme-angular/ui/validator';

import { LogsStore } from './+store/logs.store';
import { LogErrorPopupComponent } from './log-error-popup/log-error-popup.component';
import { LogExportSummaryComponent } from './log-export-summary/log-export-summary.component';
import {
  EntityResultView,
  ExportSummaryView,
  ExportViewType,
  PhaseTimingView,
} from './models/export-summary-view.model';

@Component({
  selector: 'alk-logs',
  templateUrl: './logs.component.html',
  styleUrls: ['./logs.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    TiaraExpandableListItemComponent,
    TiaraListComponent,
    TiaraListItemSectionComponent,
    TranslatePipe,
    DxTextBoxModule,
    DxListModule,
    TiaraCircularIllustrationComponent,
    DxButtonModule,
    MsFormatPipe,
    DxDateRangeBoxModule,
    DxValidatorModule,
    TiaraSuiteFilterRecapItemComponent,
    DxCheckBoxModule,
    DxTooltipModule,
    LogErrorPopupComponent,
    LogExportSummaryComponent,
  ],
})
export class LogsComponent implements OnInit {
  _searchValue = signal<string>('');
  _outcomeValue = signal<string[]>(['OK', 'KO', 'WARNING']);
  _detailOutcomeValue = signal<LogOutcome[]>(['OK', 'KO', 'WARNING']);
  _startDate = signal<Date | null>(null);
  _endDate = signal<Date | null>(null);
  _expandedLogId = signal<string | null>(null);
  _expandedDetailId = signal<string | null>(null);
  _selectedErrorLog = signal<Log | null>(null);
  _selectedErrorDetail = signal<LogDetail | null>(null);

  _store = inject(LogsStore);
  private readonly _router = inject(Router);

  hasLogs = computed(() => this.filteredLogs().length > 0);

  readonly outcomeList: Array<{ id: LogOutcome; label: string; value: boolean; icon: string }> = [
    {
      id: 'OK',
      label: 'Success',
      value: true,
      icon: 'fa-regular fa-circle-check success-icon',
    },
    {
      id: 'KO',
      label: 'Error',
      value: true,
      icon: 'fa-regular fa-circle-xmark error-icon',
    },
    {
      id: 'WARNING',
      label: 'Warning',
      value: true,
      icon: 'fa-regular fa-circle-exclamation warning-icon',
    },
  ];

  // Computed list filtered by search term
  filteredLogs = computed(() => {
    const term = this._searchValue().trim().toLowerCase();
    let logs = this._store.logs();

    // Filter by search term (client-side only)
    if (term) {
      logs = logs.filter(
        (l) =>
          l.pipeline?.toLowerCase().includes(term) ||
          l.workspace?.toLowerCase().includes(term) ||
          l.description?.toLowerCase().includes(term),
      );
    }

    const sortedLogs = this.sortByStartTimeDesc(logs);
    return sortedLogs;
  });

  // BE filters: outcome, startDate, endDate
  beFilter = computed<LogsFilter>(() => {
    const outcome = this._outcomeValue();
    const startDate = this._startDate();
    const endDate = this._endDate();

    const filter: LogsFilter = {
      topic: 'execution',
      subject: 'pipeline',
    };

    // Send outcome values as-is (OK, KO, WARNING match payload status)
    // Support multiple outcome selection
    if (outcome.length > 0 && outcome.length < 3) {
      // If all selected or none, don't filter by outcome
      filter.outcome = outcome; // Send full array for multiple outcome filter
    }

    if (startDate) {
      filter.startDate = startDate.toISOString();
    }

    if (endDate) {
      filter.endDate = endDate.toISOString();
    }

    return filter;
  });

  logsDataSource = this._store.createLogsDataSource(() => this.filteredLogs());

  rowsRange = computed(() => {
    const count = this._store.loadedCount();
    return {
      from: count > 0 ? 1 : 0,
      to: count,
    };
  });

  constructor() {
    // Effect che reagisce ai cambi di beFilter
    effect(() => {
      const filter = this.beFilter();
      this._store.setFilter(filter);
      this._store.resetLogs();
      // Forza reload del dataSource
      untracked(() => {
        this.logsDataSource.pageIndex(0);
        this.logsDataSource.reload();
      });
    });
  }

  ngOnInit() {
    // Effect gestisce il caricamento automatico
  }

  searchValueChanged(e: TextBoxValueChangedEvent) {
    this._searchValue.set(e.value ?? '');
    // Client-side filter: reload without resetting BE state
    this.logsDataSource.pageIndex(0);
    this.logsDataSource.reload();
  }

  onDateRangeChanged(e: DateRangeBoxValueChangedEvent) {
    const [nextStart, nextEnd] = this.coerceDateRange(e.value);

    if (!this.isStrictDateRange(nextStart, nextEnd)) {
      return;
    }

    const startUnchanged = this.isSameDate(this._startDate(), nextStart);
    const endUnchanged = this.isSameDate(this._endDate(), nextEnd);
    if (startUnchanged && endUnchanged) {
      return;
    }

    this._startDate.set(nextStart);
    this._endDate.set(nextEnd);
  }

  validateStrictDateRange(params: { value?: Array<Date | string | number | null> | null }) {
    const [startDate, endDate] = this.coerceDateRange(params?.value);
    return this.isStrictDateRange(startDate, endDate);
  }

  clearDateFilters() {
    this._startDate.set(null);
    this._endDate.set(null);
  }

  private coerceDate(value: Date | string | null): Date | null {
    if (!value) {
      return null;
    }
    if (value instanceof Date) {
      return Number.isNaN(value.getTime()) ? null : value;
    }
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? null : parsed;
  }

  private coerceDateRange(value: unknown): [Date | null, Date | null] {
    if (!Array.isArray(value)) {
      return [null, null];
    }

    const [startRaw, endRaw] = value;
    const startDate = this.coerceDate(
      typeof startRaw === 'number' ? new Date(startRaw) : (startRaw as Date | string | null),
    );
    const endDate = this.coerceDate(typeof endRaw === 'number' ? new Date(endRaw) : (endRaw as Date | string | null));
    return [startDate, endDate];
  }

  private isStrictDateRange(startDate: Date | null, endDate: Date | null): boolean {
    if (!startDate || !endDate) {
      return true;
    }

    return startDate.getTime() < endDate.getTime();
  }

  private isSameDate(left: Date | null, right: Date | null): boolean {
    if (!left && !right) {
      return true;
    }
    if (!left || !right) {
      return false;
    }
    return left.getTime() === right.getTime();
  }

  getEsitoIcon(esito: string): string {
    switch (esito) {
      case 'OK':
        return 'fa-regular fa-circle-check success-icon';
      case 'KO':
        return 'fa-regular fa-circle-xmark error-icon';
      case 'WARNING':
        return 'fa-regular fa-circle-exclamation warning-icon';
      default:
        return 'akn-icon akn-icon-info-circle info-icon';
    }
  }

  getLogIcon(log: Log): string {
    if (log.outcome === 'KO') {
      return 'fa-regular fa-circle-xmark error-icon';
    }
    if (log.isCompleted) {
      return 'fa-regular fa-circle-check success-icon';
    }
    return 'fa-regular fa-clock in-progress-icon';
  }

  onOutcomeCheckboxChanged(outcome: string, e: CheckBoxValueChangedEvent) {
    if (!e.event) {
      return;
    }

    const selected = new Set(this._outcomeValue());
    if (e.value) {
      selected.add(outcome);
    } else {
      selected.delete(outcome);
    }

    const ordered = this.outcomeList.map((item) => item.id).filter((id) => selected.has(id));
    this._outcomeValue.set(ordered);
  }

  refreshLogs() {
    // Azzera tutti i filtri
    this._searchValue.set('');
    this._outcomeValue.set(['OK', 'KO', 'WARNING']);
    this._detailOutcomeValue.set(['OK', 'KO', 'WARNING']);
    this._startDate.set(null);
    this._endDate.set(null);
    this._expandedLogId.set(null);
    this._clearCaches();
    // Forza DevExtreme a tornare alla prima pagina
    this.logsDataSource.pageIndex(0);
    // Reset e reload vengono triggerati automaticamente dall'effect
  }

  toggleLogDetails(log: Log): void {
    const nextId = this.getLogStableId(log);
    this._expandedLogId.set(this._expandedLogId() === nextId ? null : nextId);
  }

  onLogExpandedChange(log: Log, expanded: boolean): void {
    this._expandedLogId.set(expanded ? this.getLogStableId(log) : null);
  }

  isLogExpanded(log: Log): boolean {
    return this._expandedLogId() === this.getLogStableId(log);
  }

  private _visibleDetailsCache = new Map<string, LogDetail[]>();
  private _lastDetailFilterKey = '';

  getVisibleDetails(log: Log): LogDetail[] {
    const filterKey = this._detailOutcomeValue().join(',');
    const logId = this.getLogStableId(log);
    const key = `${logId}::${filterKey}`;

    // If filter changed, clear ALL cached entries
    if (filterKey !== this._lastDetailFilterKey) {
      this._visibleDetailsCache.clear();
      this._lastDetailFilterKey = filterKey;
    }

    const cached = this._visibleDetailsCache.get(key);
    if (cached) return cached;

    const selected = new Set(this._detailOutcomeValue());
    const selectedOrder = this._detailOutcomeValue();
    const result = [...log.details]
      .filter((detail) => selected.has(detail.outcome))
      .sort((left, right) => selectedOrder.indexOf(left.outcome) - selectedOrder.indexOf(right.outcome));
    this._visibleDetailsCache.set(key, result);
    return result;
  }

  onDetailOutcomeCheckboxChanged(outcome: LogOutcome, e: CheckBoxValueChangedEvent): void {
    if (!e.event) {
      return;
    }

    const selected = new Set(this._detailOutcomeValue());
    if (e.value) {
      selected.add(outcome);
    } else {
      selected.delete(outcome);
    }

    const ordered = this.outcomeList.map((item) => item.id).filter((id) => selected.has(id));
    this._detailOutcomeValue.set(ordered);
  }

  getDetailToggleLabel(log: Log): string {
    return this.isLogExpanded(log) ? 'log.detail.hide' : 'log.detail.show';
  }

  hasDetails(log: Log): boolean {
    return log.details.length > 0;
  }

  private getLogStableId(log: Log): string {
    return log.correlationId ?? `${log.pipelineId ?? 'pipeline'}-${log.startTime.getTime()}`;
  }

  openDataAudit(log: Log) {
    if (!this.canOpenDataAudit(log)) {
      return;
    }

    this._router.navigate(['/logs/data-audit', log.pipelineId], {
      queryParams: { correlationId: log.correlationId, outcome: log.outcome },
    });
  }

  getAuditButtonId(log: Log): string {
    const base = log.correlationId || log.pipelineId || 'unknown';
    return `audit-btn-${base.replace(/[^a-zA-Z0-9_-]/g, '')}`;
  }

  private sortByStartTimeDesc(logs: Log[]): Log[] {
    return [...logs].sort((a, b) => {
      const left = a.startTime?.getTime?.() ?? Number.NEGATIVE_INFINITY;
      const right = b.startTime?.getTime?.() ?? Number.NEGATIVE_INFINITY;
      return right - left;
    });
  }

  private canOpenDataAudit(log: Log): log is Log & { pipelineId: string; correlationId: string; hasDataAudit: true } {
    return !!log.hasDataAudit && !!log.pipelineId && !!log.correlationId;
  }

  canOpenErrorDetails(detail: LogDetail): boolean {
    return (
      this.isExportDetail(detail) &&
      !!detail.detailKey &&
      this.isErrorStoreEnabled(detail) &&
      this.hasExportErrors(detail)
    );
  }

  private hasExportErrors(detail: LogDetail): boolean {
    const p = detail.detailPayload;
    if (!p) return false;
    const outcome = p['outcome'];
    if (outcome === 'FAILED' || outcome === 'PARTIAL') return true;
    const errorCount = p['validationErrorCount'] ?? p['manageableErrorCount'] ?? p['unmanageableErrorCount'];
    return typeof errorCount === 'number' && errorCount > 0;
  }

  isExportDetail(detail: LogDetail): boolean {
    return detail.detailType === 'EXPORT';
  }

  isErrorStoreEnabled(detail: LogDetail): boolean {
    return detail.detailPayload?.['errorStoreEnabled'] === true;
  }

  getDetailError(detail: LogDetail): string | null {
    const error = detail.detailPayload?.['error'];
    return typeof error === 'string' && error.length > 0 ? error : null;
  }

  isDetailExpanded(detail: LogDetail): boolean {
    return this._expandedDetailId() === detail.id;
  }

  onDetailExpandedChange(detail: LogDetail, expanded: boolean): void {
    this._expandedDetailId.set(expanded ? detail.id : null);
  }

  getValidationSummaryFromPayload(detail: LogDetail): Array<{ message: string; count: number }> {
    const payload = detail.detailPayload;
    if (!payload) return [];
    const summary = payload['validationErrorsSummary'];
    if (!Array.isArray(summary)) return [];
    return summary.filter(
      (item): item is { message: string; count: number } =>
        typeof item === 'object' && item !== null && 'message' in item && 'count' in item,
    );
  }

  openErrorDetails(log: Log, detail: LogDetail): void {
    if (!this.canOpenErrorDetails(detail)) {
      return;
    }

    this._selectedErrorLog.set(log);
    this._selectedErrorDetail.set(detail);
  }

  closeErrorDetailsPopup(): void {
    this._selectedErrorLog.set(null);
    this._selectedErrorDetail.set(null);
  }

  private readonly _exportSummaryCache = new Map<string, ExportSummaryView | null>();
  private readonly _payloadFieldsCache = new Map<string, Array<{ key: string; value: string }>>();

  private _clearCaches(): void {
    this._visibleDetailsCache.clear();
    this._exportSummaryCache.clear();
    this._payloadFieldsCache.clear();
  }

  getExportSummary(detail: LogDetail): ExportSummaryView | null {
    const cached = this._exportSummaryCache.get(detail.id);
    if (cached !== undefined) return cached;
    const result = this._buildExportSummary(detail);
    this._exportSummaryCache.set(detail.id, result);
    return result;
  }

  private _buildExportSummary(detail: LogDetail): ExportSummaryView | null {
    const p = detail.detailPayload;
    if (!p) return null;
    const totalInserted = this.num(p, 'totalInserted');
    const totalDeleted = this.num(p, 'totalDeleted');
    const outcome = this.str(p, 'outcome');
    const totalExported = this.computeTotalExported(totalInserted, totalDeleted, outcome);
    return {
      datasetId: this.str(p, 'datasetId') || this.str(p, 'dataset_id'),
      datasetDescription: this.str(p, 'datasetDescription'),
      exportTarget: this.str(p, 'exportTarget') || this.str(p, 'export_target'),
      exportType: this.str(p, 'exportType') || this.str(p, 'export_type'),
      exportMode: this.str(p, 'exportMode') || this.str(p, 'export_mode'),
      exportViewType: this.resolveExportViewType(p),
      outcome,
      totalRows: this.num(p, 'totalRows'),
      totalValid: this.num(p, 'totalValid'),
      totalInserted,
      totalDeleted,
      totalRejected: this.num(p, 'totalRejected'),
      totalProjected: this.num(p, 'totalProjected'),
      totalExported,
      validationErrorCount: this.num(p, 'validationErrorCount'),
      validationErrors: this.getValidationSummaryFromPayload(detail),
      entityResults: this.extractEntityResults(p),
      phaseTimings: this.extractPhaseTimings(p),
      extraFields: this.extractExportTypeFields(p),
      errorMessage: this.extractErrorMessage(p),
      firstUnmanageableError: this.extractFirstUnmanageableError(p),
      classificationCounts: this.extractClassificationCounts(p),
      manageableErrorCount: this.num(p, 'manageableErrorCount'),
      unmanageableErrorCount: this.num(p, 'unmanageableErrorCount'),
      dataloaderStatus: this.str(p, 'dataloaderStatus'),
    };
  }

  private computeTotalExported(
    totalInserted: number | null,
    totalDeleted: number | null,
    outcome: string,
  ): number | null {
    if (outcome !== 'SUCCESS' && outcome !== 'PARTIAL') return null;
    const inserted = totalInserted ?? 0;
    const deleted = totalDeleted ?? 0;
    const sum = inserted + deleted;
    return sum > 0 ? sum : null;
  }

  private resolveExportViewType(p: Record<string, any>): ExportViewType {
    const exportType = (this.str(p, 'exportType') || this.str(p, 'export_type')).toUpperCase();
    if (exportType === 'DATABASE') return 'DATABASE';
    if (exportType === 'FILE') return 'FILE';
    if (exportType === 'WEB_API') {
      return p['dataloaderDefinitionId'] || p['dataloaderStatus'] ? 'VULKI_BULK' : 'REST_API';
    }
    return 'REST_API';
  }

  getDisplayablePayloadFields(detail: LogDetail): Array<{ key: string; value: string }> {
    const cached = this._payloadFieldsCache.get(detail.id);
    if (cached !== undefined) return cached;
    const result = this._buildDisplayablePayloadFields(detail);
    this._payloadFieldsCache.set(detail.id, result);
    return result;
  }

  private _buildDisplayablePayloadFields(detail: LogDetail): Array<{ key: string; value: string }> {
    const payload = detail.detailPayload;
    if (!payload) return [];
    const skip = new Set([
      'phase',
      'pipeline_id',
      'workspace_id',
      'detail_label',
      'detail_key',
      'duration_seconds',
      'memory_delta_mb',
      'status',
      'event_type',
      'registryLifeCycle',
      'regsitryLifeCycle',
      'error',
      'validationErrorsSummary',
      'entityResults',
      'phaseTimings',
      'datasetId',
      'dataset_id',
      'datasetDescription',
      'exportTarget',
      'export_target',
      'exportType',
      'export_type',
      'exportMode',
      'export_mode',
      'outcome',
      'totalRows',
      'totalValid',
      'totalInserted',
      'totalDeleted',
      'totalRejected',
      'totalProjected',
      'validationErrorCount',
      'persistedManageableErrors',
      'errorStoreEnabled',
      'manageableErrorCount',
      'unmanageableErrorCount',
      'classificationCounts',
      'firstUnmanageableError',
      'firstManageableError',
      'attemptedRows',
      'successRows',
      'dataloaderStatus',
      'httpVersion',
      'duration',
    ]);
    return Object.entries(payload)
      .filter(([key]) => !skip.has(key))
      .filter(([, value]) => value !== null && value !== undefined && value !== '')
      .map(([key, value]) => ({
        key,
        value: typeof value === 'object' ? JSON.stringify(value) : String(value),
      }));
  }

  private str(p: Record<string, any>, key: string): string {
    const v = p[key];
    return v != null ? String(v) : '';
  }

  private num(p: Record<string, any>, key: string): number | null {
    const v = p[key];
    return typeof v === 'number' ? v : null;
  }

  private extractEntityResults(p: Record<string, any>): EntityResultView[] {
    const arr = p['entityResults'];
    if (!Array.isArray(arr)) return [];
    return arr.map((e: any) => ({
      entityName: String(e['entityName'] ?? ''),
      projectedRows: e['projectedRows'] ?? 0,
      validRows: e['validRows'] ?? 0,
      insertedRows: e['insertedRows'] ?? 0,
      deletedRows: e['deletedRows'] ?? 0,
      rejectedRows: e['rejectedRows'] ?? 0,
    }));
  }

  private extractPhaseTimings(p: Record<string, any>): PhaseTimingView[] {
    const arr = p['phaseTimings'];
    if (!Array.isArray(arr)) return [];
    return arr.map((t: any) => ({
      phaseName: String(t['phaseName'] ?? ''),
      duration: this.formatIsoDuration(String(t['duration'] ?? '')),
    }));
  }

  private formatIsoDuration(iso: string): string {
    const match = iso.match(/^PT(?:(\d+)H)?(?:(\d+)M)?(?:([\d.]+)S)?$/);
    if (!match) return iso;
    const hours = parseInt(match[1] || '0', 10);
    const minutes = parseInt(match[2] || '0', 10);
    const seconds = Math.round(parseFloat(match[3] || '0'));
    return [String(hours).padStart(2, '0'), String(minutes).padStart(2, '0'), String(seconds).padStart(2, '0')].join(
      ':',
    );
  }

  private extractErrorMessage(p: Record<string, any>): string | null {
    const error = p['error'];
    if (typeof error === 'string' && error.length > 0) return error;
    const firstMessage = this.extractFirstUnmanageableError(p)?.message;
    return firstMessage || null;
  }

  private extractFirstUnmanageableError(p: Record<string, any>): { classification: string; message: string } | null {
    const first = p['firstUnmanageableError'];
    if (typeof first !== 'object' || first === null) return null;
    return {
      classification: String(first['classification'] ?? ''),
      message: String(first['message'] ?? ''),
    };
  }

  private extractClassificationCounts(p: Record<string, any>): Array<{ key: string; value: number }> {
    const counts = p['classificationCounts'];
    if (typeof counts !== 'object' || counts === null) return [];
    return Object.entries(counts)
      .filter((entry): entry is [string, number] => typeof entry[1] === 'number')
      .map(([key, value]) => ({ key, value }));
  }

  private extractExportTypeFields(p: Record<string, any>): Array<{ key: string; value: string }> {
    const viewType = this.resolveExportViewType(p);
    const fields: Array<{ key: string; value: string }> = [];
    const addIfPresent = (key: string, label: string): void => {
      const v = p[key];
      if (v != null && v !== '') fields.push({ key: label, value: String(v) });
    };

    switch (viewType) {
      case 'VULKI_BULK':
        addIfPresent('dataloaderDefinitionId', 'Dataloader ID');
        addIfPresent('dataloaderStrategy', 'Strategy');
        addIfPresent('httpVersion', 'HTTP Version');
        break;
      case 'REST_API':
        addIfPresent('httpMethod', 'HTTP Method');
        addIfPresent('httpVersion', 'HTTP Version');
        addIfPresent('requestUrl', 'URL');
        break;
      case 'FILE':
        addIfPresent('fileType', 'File Type');
        addIfPresent('destinationType', 'Destination');
        addIfPresent('writeStrategy', 'Write Strategy');
        addIfPresent('targetLocation', 'Location');
        addIfPresent('sheetName', 'Sheet');
        addIfPresent('encoding', 'Encoding');
        break;
      case 'DATABASE':
        addIfPresent('dbmsType', 'DBMS');
        addIfPresent('tableName', 'Table');
        addIfPresent('schemaName', 'Schema');
        break;
    }
    return fields;
  }
}

export {
  EntityResultView,
  ExportSummaryView,
  ExportViewType,
  PhaseTimingView,
} from './models/export-summary-view.model';
