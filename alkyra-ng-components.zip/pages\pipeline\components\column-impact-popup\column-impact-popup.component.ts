import { DatasetColumnRenameImpactItem } from '@alkyra/dataset/models/dataset-column-rename-impact.model';
import { Component, input, output } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxPopupModule } from 'devextreme-angular/ui/popup';

@Component({
  selector: 'alk-column-impact-popup',
  standalone: true,
  imports: [DxPopupModule, DxButtonModule, TranslatePipe],
  templateUrl: './column-impact-popup.component.html',
})
export class ColumnImpactPopupComponent {
  visible = input(false);
  titleKey = input.required<string>();
  messageKey = input.required<string>();
  impacts = input<DatasetColumnRenameImpactItem[]>([]);

  closed = output<void>();

  onClose(): void {
    this.closed.emit();
  }
}
