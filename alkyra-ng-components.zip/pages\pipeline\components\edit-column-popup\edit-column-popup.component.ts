import { DatasetColumn } from '@alkyra/dataset/models/dataset-column.model';
import { DatasetColumnRenameImpactItem } from '@alkyra/dataset/models/dataset-column-rename-impact.model';
import { Component, input, output } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxPopupModule } from 'devextreme-angular/ui/popup';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';

@Component({
  selector: 'alk-edit-column-popup',
  standalone: true,
  imports: [DxPopupModule, DxTextBoxModule, DxButtonModule, TranslatePipe],
  templateUrl: './edit-column-popup.component.html',
  styleUrl: './edit-column-popup.component.scss',
})
export class EditColumnPopupComponent {
  visible = input<boolean>(false);
  column = input<DatasetColumn | null>(null);
  alias = input<string>('');
  validationMessage = input<string | null>(null);
  impacts = input<DatasetColumnRenameImpactItem[]>([]);
  isSaving = input<boolean>(false);

  aliasChange = output<string>();
  save = output<void>();
  closed = output<void>();

  onAliasValueChanged(event: { value?: string | null }): void {
    this.aliasChange.emit(event?.value ?? '');
  }

  onSave(): void {
    this.save.emit();
  }

  onClose(): void {
    this.closed.emit();
  }
}
