import { DatasourceConnector } from '@alkyra/connector/models/datasource-connector.model';
import { Dataset, DatasetType } from '@alkyra/dataset/models/dataset.model';
import { DatasetAggregationRelation } from '@alkyra/dataset/models/dataset-aggregation.model';
import { DatasetJoinRelation } from '@alkyra/dataset/models/dataset-join.model';
import { DatasetSubsetRelation } from '@alkyra/dataset/models/dataset-subset.model';
import { DatasetUnionRelation } from '@alkyra/dataset/models/dataset-union.model';
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  computed,
  ElementRef,
  effect,
  input,
  OnDestroy,
  output,
  QueryList,
  signal,
  ViewChild,
  ViewChildren,
} from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxContextMenuModule } from 'devextreme-angular/ui/context-menu';
import { DxTooltipModule } from 'devextreme-angular/ui/tooltip';

import {
  computePipelineDatasetBadgeLabelMap,
  computePipelineDatasetRoleMap,
  PipelineDatasetBadgeLabelKey,
  PipelineDatasetRole,
} from '../../utils/pipeline-dataset-role.utils';
import { computeColumnLayout } from './pipeline-flow-layout.utils';

type FlowOperationKey =
  | 'pipeline.flow.operation.join'
  | 'pipeline.flow.operation.innerJoin'
  | 'pipeline.flow.operation.leftJoin'
  | 'pipeline.flow.operation.union'
  | 'pipeline.flow.operation.subset'
  | 'pipeline.flow.operation.aggregation'
  | 'pipeline.flow.operation.transformation';

type FlowOperationLabelKey =
  | 'pipeline.flow.operation.join'
  | 'pipeline.flow.operation.union'
  | 'pipeline.flow.operation.subset'
  | 'pipeline.flow.operation.aggregation'
  | 'pipeline.flow.operation.transformation';

type FlowSideKey = 'pipeline.flow.detail.side.left' | 'pipeline.flow.detail.side.right';

type FlowConnection = {
  id: string;
  fromId: string;
  toId: string;
  fromLabel: string;
  toLabel: string;
  fromOrder: number;
  toOrder: number;
  operationKey: FlowOperationKey;
  operationLabelKey: FlowOperationLabelKey;
  joinTypeKey?: FlowOperationKey;
  sideKey?: FlowSideKey;
};

type FlowNode = {
  dataset: Dataset;
  level: number;
  icon?: string;
  connectorLabel?: string;
  isSource: boolean;
  isJoin: boolean;
  isDerived: boolean;
  badgeLabelKey: PipelineDatasetBadgeLabelKey;
};

type FlowColumn = {
  level: number;
  nodes: FlowNode[];
};

type FlowViewModel = {
  columns: FlowColumn[];
  connections: FlowConnection[];
};

type FlowPath = {
  id: string;
  d: string;
  labelX: number;
  labelY: number;
  connection: FlowConnection;
};

@Component({
  selector: 'alk-pipeline-flow',
  standalone: true,
  imports: [DxTooltipModule, DxContextMenuModule, TranslatePipe],
  templateUrl: './pipeline-flow.component.html',
  styleUrl: './pipeline-flow.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PipelineFlowComponent implements AfterViewInit, OnDestroy {
  private readonly minNodeGap = 24;
  private flowNodeResizeObserver?: ResizeObserver;

  private static readonly CONNECTOR_TYPE_ICONS: Record<string, string> = {
    CSV: 'assets/file-icon/csv.png',
    EXCEL: 'assets/file-icon/excel.png',
    AMAZON_SQS: 'assets/cloud-icon/aws.png',
    S3_BUCKET: 'assets/cloud-icon/s3.png',
  };

  private static readonly DBMS_TYPE_ICONS: Record<string, string> = {
    POSTGRES: 'assets/db-icon/pg.png',
    SQLSERVER: 'assets/db-icon/mssql.png',
    ORACLE: 'assets/db-icon/oracle.png',
    SAPHANA: 'assets/db-icon/sap.png',
  };

  private static readonly JOIN_TYPE_KEYS: Record<string, FlowOperationKey> = {
    INNER_JOIN: 'pipeline.flow.operation.innerJoin',
    LEFT_JOIN: 'pipeline.flow.operation.leftJoin',
  };

  datasets = input<Dataset[]>([]);
  connectors = input<DatasourceConnector[]>([]);
  joinRelations = input<DatasetJoinRelation[]>([]);
  unionRelations = input<DatasetUnionRelation[]>([]);
  aggregationRelations = input<DatasetAggregationRelation[]>([]);
  subsetRelations = input<DatasetSubsetRelation[]>([]);
  focusedDatasetId = input<string | null>(null);
  datasetSelected = output<Dataset>();
  datasetDuplicateRequested = output<Dataset>();
  datasetDeleteRequested = output<Dataset>();

  @ViewChild('flowCanvas') flowCanvasRef?: ElementRef<HTMLDivElement>;
  @ViewChildren('flowNode') flowNodeRefs?: QueryList<ElementRef<HTMLDivElement>>;

  private readonly flowResizeHandler = () => this.scheduleFlowUpdate();

  flowCanvasSize = signal({ width: 0, height: 0 });
  connectionPaths = signal<FlowPath[]>([]);
  hoveredConnectionId = signal<string | null>(null);

  readonly flowViewModel = computed(() =>
    this.buildFlowViewModel(
      this.datasets(),
      this.connectors(),
      this.joinRelations(),
      this.unionRelations(),
      this.aggregationRelations(),
      this.subsetRelations(),
    ),
  );

  constructor() {
    effect(() => {
      this.flowViewModel();
      this.scheduleFlowUpdate();
    });
  }

  ngAfterViewInit(): void {
    window.addEventListener('resize', this.flowResizeHandler);
    this.flowNodeRefs?.changes.subscribe(() => {
      this.observeFlowNodes();
      this.scheduleFlowUpdate();
    });
    this.observeFlowNodes();
    this.scheduleFlowUpdate();
  }

  ngOnDestroy(): void {
    window.removeEventListener('resize', this.flowResizeHandler);
    this.flowNodeResizeObserver?.disconnect();
  }

  onDatasetSelected(dataset: Dataset): void {
    this.datasetSelected.emit(dataset);
  }

  onConnectionLabelEnter(connectionId: string): void {
    this.hoveredConnectionId.set(connectionId);
  }

  onConnectionLabelLeave(): void {
    this.hoveredConnectionId.set(null);
  }

  private scheduleFlowUpdate(): void {
    requestAnimationFrame(() => this.updateConnectionPaths());
  }

  private updateConnectionPaths(): void {
    const canvas = this.flowCanvasRef?.nativeElement;
    const nodeRefs = this.flowNodeRefs?.toArray() ?? [];

    if (!this.canUpdatePaths(canvas, nodeRefs)) {
      this.connectionPaths.set([]);
      return;
    }

    const canvasRect = canvas.getBoundingClientRect();
    this.updateCanvasSize(canvas, canvasRect);
    const nodeElements = this.buildNodeElementsMap(nodeRefs);
    const nodeRects = this.buildNodeRectsMap(nodeRefs);
    this.applyNodeLayout(nodeElements, nodeRects, canvasRect);
    const paths = this.buildConnectionPaths(canvasRect, nodeRects);
    this.connectionPaths.set(paths);
  }

  private canUpdatePaths(
    canvas: HTMLDivElement | undefined,
    nodeRefs: ElementRef<HTMLDivElement>[],
  ): canvas is HTMLDivElement {
    return !!canvas && nodeRefs.length > 0;
  }

  private updateCanvasSize(canvas: HTMLDivElement, canvasRect: DOMRect): void {
    this.flowCanvasSize.set({
      width: Math.max(canvas.scrollWidth, canvasRect.width),
      height: Math.max(canvas.scrollHeight, canvasRect.height),
    });
  }

  private buildNodeRectsMap(nodeRefs: ElementRef<HTMLDivElement>[]): Map<string, DOMRect> {
    return this.buildNodeMap(nodeRefs, (element) => element.getBoundingClientRect());
  }

  private buildNodeElementsMap(nodeRefs: ElementRef<HTMLDivElement>[]): Map<string, HTMLDivElement> {
    return this.buildNodeMap(nodeRefs, (element) => element);
  }

  private buildNodeMap<T>(
    nodeRefs: ElementRef<HTMLDivElement>[],
    mapFn: (element: HTMLDivElement) => T,
  ): Map<string, T> {
    const nodeMap = new Map<string, T>();
    for (const nodeRef of nodeRefs) {
      const nodeElement = nodeRef.nativeElement;
      const datasetId = nodeElement.dataset['id'];
      if (datasetId) {
        nodeMap.set(datasetId, mapFn(nodeElement));
      }
    }
    return nodeMap;
  }

  private applyNodeLayout(
    nodeElements: Map<string, HTMLDivElement>,
    nodeRects: Map<string, DOMRect>,
    canvasRect: DOMRect,
  ): void {
    const { columns, connections } = this.flowViewModel();
    if (!columns.length) {
      return;
    }

    const incomingMap = this.buildIncomingConnectionsMap(connections);

    for (const column of columns) {
      this.applyColumnLayout(column, nodeElements, nodeRects, canvasRect, incomingMap);
    }
  }

  private buildIncomingConnectionsMap(connections: FlowConnection[]): Map<string, string[]> {
    const incomingMap = new Map<string, string[]>();
    for (const connection of connections) {
      if (!incomingMap.has(connection.toId)) {
        incomingMap.set(connection.toId, []);
      }
      incomingMap.get(connection.toId)!.push(connection.fromId);
    }
    return incomingMap;
  }

  private applyColumnLayout(
    column: FlowColumn,
    nodeElements: Map<string, HTMLDivElement>,
    nodeRects: Map<string, DOMRect>,
    canvasRect: DOMRect,
    incomingMap: Map<string, string[]>,
  ): void {
    const layouts = this.buildNodeLayouts(column.nodes, nodeElements, nodeRects, incomingMap);
    if (layouts.length === 0) {
      return;
    }

    const columnLayout = this.computeLayoutForColumn(layouts, canvasRect);
    const layoutMap = new Map(columnLayout.map((layout) => [layout.id, layout]));
    this.applyLayoutTransforms(layouts, layoutMap, nodeRects);
  }

  private computeLayoutForColumn(
    layouts: Array<{ id: string; desiredCenter: number; rect: DOMRect }>,
    canvasRect: DOMRect,
  ) {
    return computeColumnLayout(
      layouts.map((layout) => ({
        id: layout.id,
        desiredCenter: layout.desiredCenter,
        height: layout.rect.height,
        currentTop: layout.rect.top,
        currentBottom: layout.rect.bottom,
      })),
      this.minNodeGap,
      canvasRect.top,
    );
  }

  private buildNodeLayouts(
    nodes: FlowNode[],
    nodeElements: Map<string, HTMLDivElement>,
    nodeRects: Map<string, DOMRect>,
    incomingMap: Map<string, string[]>,
  ) {
    return nodes
      .map((node) => this.createNodeLayout(node, nodeElements, nodeRects, incomingMap))
      .filter((layout): layout is NonNullable<typeof layout> => !!layout);
  }

  private createNodeLayout(
    node: FlowNode,
    nodeElements: Map<string, HTMLDivElement>,
    nodeRects: Map<string, DOMRect>,
    incomingMap: Map<string, string[]>,
  ) {
    const nodeId = node.dataset.id;
    const element = nodeElements.get(nodeId);
    const rect = nodeRects.get(nodeId);
    if (!element || !rect) {
      return null;
    }

    const desiredCenter = this.calculateDesiredCenter(nodeId, rect, nodeRects, incomingMap);
    return { id: nodeId, element, rect, desiredCenter };
  }

  private calculateDesiredCenter(
    nodeId: string,
    rect: DOMRect,
    nodeRects: Map<string, DOMRect>,
    incomingMap: Map<string, string[]>,
  ): number {
    const sourceIds = incomingMap.get(nodeId) ?? [];
    const sourceCenters = this.getSourceCenters(sourceIds, nodeRects);

    if (sourceCenters.length === 0) {
      return this.getRectCenter(rect);
    }

    return this.calculateAverage(sourceCenters);
  }

  private getSourceCenters(sourceIds: string[], nodeRects: Map<string, DOMRect>): number[] {
    return sourceIds
      .map((sourceId) => nodeRects.get(sourceId))
      .filter((sourceRect): sourceRect is DOMRect => !!sourceRect)
      .map((sourceRect) => this.getRectCenter(sourceRect));
  }

  private getRectCenter(rect: DOMRect): number {
    return rect.top + rect.height / 2;
  }

  private calculateAverage(values: number[]): number {
    return values.reduce((sum, value) => sum + value, 0) / values.length;
  }

  private applyLayoutTransforms(
    layouts: Array<{ id: string; element: HTMLDivElement; rect: DOMRect; desiredCenter: number }>,
    layoutMap: Map<string, { deltaY: number }>,
    nodeRects: Map<string, DOMRect>,
  ): void {
    for (const layout of layouts) {
      const target = layoutMap.get(layout.id);
      if (target) {
        this.applyTransform(layout.element, target.deltaY);
        nodeRects.set(layout.id, layout.element.getBoundingClientRect());
      }
    }
  }

  private applyTransform(element: HTMLDivElement, deltaY: number): void {
    element.style.transform = Math.abs(deltaY) < 0.5 ? '' : `translateY(${deltaY}px)`;
  }

  private buildConnectionPaths(canvasRect: DOMRect, nodeRects: Map<string, DOMRect>): FlowPath[] {
    return this.flowViewModel()
      .connections.map((connection) => this.createFlowPath(connection, canvasRect, nodeRects))
      .filter((path): path is FlowPath => !!path);
  }

  private createFlowPath(
    connection: FlowConnection,
    canvasRect: DOMRect,
    nodeRects: Map<string, DOMRect>,
  ): FlowPath | null {
    const fromRect = nodeRects.get(connection.fromId);
    const toRect = nodeRects.get(connection.toId);
    if (!fromRect || !toRect) {
      return null;
    }

    const { startX, startY, endX, endY } = this.calculatePathPoints(fromRect, toRect, canvasRect);
    const controlX = startX + (endX - startX) / 2;
    const { labelX, labelY } = this.calculateLabelPosition(startX, startY, endX, endY, controlX);

    return {
      id: connection.id,
      d: `M ${startX} ${startY} C ${controlX} ${startY}, ${controlX} ${endY}, ${endX} ${endY}`,
      labelX,
      labelY,
      connection,
    };
  }

  private calculatePathPoints(
    fromRect: DOMRect,
    toRect: DOMRect,
    canvasRect: DOMRect,
  ): { startX: number; startY: number; endX: number; endY: number } {
    return {
      startX: fromRect.right - canvasRect.left,
      startY: this.getRectCenter(fromRect) - canvasRect.top,
      endX: toRect.left - canvasRect.left,
      endY: this.getRectCenter(toRect) - canvasRect.top,
    };
  }

  private calculateLabelPosition(
    startX: number,
    startY: number,
    endX: number,
    endY: number,
    controlX: number,
  ): { labelX: number; labelY: number } {
    return {
      labelX: (startX + 6 * controlX + endX) / 8,
      labelY: (startY + endY) / 2,
    };
  }

  private buildFlowViewModel(
    datasets: Dataset[],
    connectors: DatasourceConnector[],
    joinRelations: DatasetJoinRelation[],
    unionRelations: DatasetUnionRelation[],
    aggregationRelations: DatasetAggregationRelation[],
    subsetRelations: DatasetSubsetRelation[],
  ): FlowViewModel {
    if (!datasets.length) {
      return { columns: [], connections: [] };
    }

    const sortedDatasets = [...datasets].sort((a, b) => a.datasetOrder - b.datasetOrder);
    const datasetMap = new Map(sortedDatasets.map((dataset) => [dataset.id, dataset]));
    const connectorMap = new Map(
      connectors.filter((connector) => connector.id).map((connector) => [connector.id!, connector]),
    );

    const relationMaps = this.buildAllRelationMaps({
      joinRelations,
      unionRelations,
      aggregationRelations,
      subsetRelations,
    });

    const { incomingMap, joinTypeMap, aggregationMap } = this.buildDatasetMaps(
      sortedDatasets,
      datasetMap,
      relationMaps,
    );

    const connections = this.buildConnections({
      sortedDatasets,
      datasetMap,
      incomingMap,
      joinTypeMap,
      aggregationMap,
      joinRelationMap: relationMaps.joinRelationMap,
      unionRelationMap: relationMaps.unionRelationMap,
    });

    const levels = this.calculateDatasetLevels(sortedDatasets, incomingMap, datasetMap);
    const roleMap = computePipelineDatasetRoleMap(
      sortedDatasets,
      joinRelations,
      unionRelations,
      aggregationRelations,
      subsetRelations,
    );
    const badgeLabelMap = computePipelineDatasetBadgeLabelMap(
      sortedDatasets,
      joinRelations,
      unionRelations,
      aggregationRelations,
      subsetRelations,
    );
    const nodes = this.buildFlowNodes({ sortedDatasets, levels, connectorMap, roleMap, badgeLabelMap });
    const columns = this.groupNodesIntoColumns(nodes);

    return { columns, connections };
  }

  private buildAllRelationMaps(params: {
    joinRelations: DatasetJoinRelation[];
    unionRelations: DatasetUnionRelation[];
    aggregationRelations: DatasetAggregationRelation[];
    subsetRelations: DatasetSubsetRelation[];
  }) {
    return {
      joinRelationMap: this.buildJoinRelationMap(params.joinRelations),
      unionRelationMap: this.buildUnionRelationMap(params.unionRelations),
      aggregationRelationMap: this.buildAggregationRelationMap(params.aggregationRelations),
      subsetRelationMap: this.buildSubsetRelationMap(params.subsetRelations),
    };
  }

  private buildDatasetMaps(
    sortedDatasets: Dataset[],
    datasetMap: Map<string, Dataset>,
    relationMaps: {
      joinRelationMap: Map<string, DatasetJoinRelation>;
      unionRelationMap: Map<string, DatasetUnionRelation>;
      aggregationRelationMap: Map<string, DatasetAggregationRelation>;
      subsetRelationMap: Map<string, DatasetSubsetRelation>;
    },
  ): {
    incomingMap: Map<string, string[]>;
    joinTypeMap: Map<string, string | null>;
    aggregationMap: Map<string, boolean>;
  } {
    const incomingMap = new Map<string, string[]>();
    const joinTypeMap = new Map<string, string | null>();
    const aggregationMap = new Map<string, boolean>();

    for (const dataset of sortedDatasets) {
      const { sourceIds, joinType, hasAggregation } = this.getDatasetSources(
        dataset,
        sortedDatasets,
        datasetMap,
        relationMaps,
      );
      incomingMap.set(dataset.id, sourceIds);
      if (joinType) {
        joinTypeMap.set(dataset.id, joinType);
      }
      if (hasAggregation) {
        aggregationMap.set(dataset.id, true);
      }
    }

    return { incomingMap, joinTypeMap, aggregationMap };
  }

  private buildConnections(params: {
    sortedDatasets: Dataset[];
    datasetMap: Map<string, Dataset>;
    incomingMap: Map<string, string[]>;
    joinTypeMap: Map<string, string | null>;
    aggregationMap: Map<string, boolean>;
    joinRelationMap: Map<string, DatasetJoinRelation>;
    unionRelationMap: Map<string, DatasetUnionRelation>;
  }): FlowConnection[] {
    return params.sortedDatasets.flatMap((dataset) =>
      this.buildDatasetConnections({
        dataset,
        datasetMap: params.datasetMap,
        incomingMap: params.incomingMap,
        joinTypeMap: params.joinTypeMap,
        aggregationMap: params.aggregationMap,
        joinRelationMap: params.joinRelationMap,
        unionRelationMap: params.unionRelationMap,
      }),
    );
  }

  private buildDatasetConnections(params: {
    dataset: Dataset;
    datasetMap: Map<string, Dataset>;
    incomingMap: Map<string, string[]>;
    joinTypeMap: Map<string, string | null>;
    aggregationMap: Map<string, boolean>;
    joinRelationMap: Map<string, DatasetJoinRelation>;
    unionRelationMap: Map<string, DatasetUnionRelation>;
  }): FlowConnection[] {
    const { dataset, datasetMap, incomingMap, joinTypeMap, aggregationMap, joinRelationMap, unionRelationMap } = params;
    const sourceIds = incomingMap.get(dataset.id) ?? [];
    if (!sourceIds.length) {
      return [];
    }

    const joinType = joinTypeMap.get(dataset.id) ?? undefined;
    const hasAggregation = aggregationMap.get(dataset.id) ?? false;
    const operationKey = this.getOperationKey(dataset, joinType, hasAggregation);
    const operationLabelKey = this.getOperationLabelKey(dataset, joinType, hasAggregation);

    return this.createConnectionsForSources({
      dataset,
      sourceIds,
      datasetMap,
      operationKey,
      operationLabelKey,
      joinType,
      joinRelationMap,
      unionRelationMap,
    });
  }

  private createConnectionsForSources(params: {
    dataset: Dataset;
    sourceIds: string[];
    datasetMap: Map<string, Dataset>;
    operationKey: FlowOperationKey;
    operationLabelKey: FlowOperationLabelKey;
    joinType: string | undefined;
    joinRelationMap: Map<string, DatasetJoinRelation>;
    unionRelationMap: Map<string, DatasetUnionRelation>;
  }): FlowConnection[] {
    const {
      dataset,
      sourceIds,
      datasetMap,
      operationKey,
      operationLabelKey,
      joinType,
      joinRelationMap,
      unionRelationMap,
    } = params;
    const joinTypeKey = this.mapJoinTypeToKey(joinType);

    return sourceIds
      .map((sourceId) =>
        this.createConnection({
          sourceId,
          dataset,
          datasetMap,
          operationKey,
          operationLabelKey,
          joinTypeKey,
          joinRelationMap,
          unionRelationMap,
        }),
      )
      .filter((connection): connection is FlowConnection => !!connection);
  }

  private createConnection(params: {
    sourceId: string;
    dataset: Dataset;
    datasetMap: Map<string, Dataset>;
    operationKey: FlowOperationKey;
    operationLabelKey: FlowOperationLabelKey;
    joinTypeKey: FlowOperationKey | undefined;
    joinRelationMap: Map<string, DatasetJoinRelation>;
    unionRelationMap: Map<string, DatasetUnionRelation>;
  }): FlowConnection | null {
    const {
      sourceId,
      dataset,
      datasetMap,
      operationKey,
      operationLabelKey,
      joinTypeKey,
      joinRelationMap,
      unionRelationMap,
    } = params;
    const sourceDataset = datasetMap.get(sourceId);
    if (!sourceDataset) {
      return null;
    }

    const sideKey = this.resolveSideKey(dataset.id, sourceId, joinRelationMap, unionRelationMap);
    return {
      id: `${sourceId}-${dataset.id}`,
      fromId: sourceId,
      toId: dataset.id,
      fromLabel: sourceDataset.name,
      toLabel: dataset.name,
      fromOrder: sourceDataset.datasetOrder,
      toOrder: dataset.datasetOrder,
      operationKey,
      operationLabelKey,
      joinTypeKey,
      sideKey,
    };
  }

  private calculateDatasetLevels(
    sortedDatasets: Dataset[],
    incomingMap: Map<string, string[]>,
    datasetMap: Map<string, Dataset>,
  ): Map<string, number> {
    const levels = new Map<string, number>();
    const visiting = new Set<string>();

    for (const dataset of sortedDatasets) {
      this.resolveDatasetLevel(dataset.id, levels, visiting, incomingMap, datasetMap);
    }

    return levels;
  }

  private resolveDatasetLevel(
    datasetId: string,
    levels: Map<string, number>,
    visiting: Set<string>,
    incomingMap: Map<string, string[]>,
    datasetMap: Map<string, Dataset>,
  ): number {
    if (levels.has(datasetId)) {
      return levels.get(datasetId)!;
    }
    if (visiting.has(datasetId)) {
      return 0;
    }

    visiting.add(datasetId);
    const sources = (incomingMap.get(datasetId) ?? []).filter((sourceId) => datasetMap.has(sourceId));

    if (!sources.length) {
      levels.set(datasetId, 0);
      visiting.delete(datasetId);
      return 0;
    }

    const sourceLevels = sources.map((sourceId) =>
      this.resolveDatasetLevel(sourceId, levels, visiting, incomingMap, datasetMap),
    );
    const level = Math.max(...sourceLevels) + 1;
    levels.set(datasetId, level);
    visiting.delete(datasetId);
    return level;
  }

  private buildFlowNodes(params: {
    sortedDatasets: Dataset[];
    levels: Map<string, number>;
    connectorMap: Map<string, DatasourceConnector>;
    roleMap: Map<string, PipelineDatasetRole>;
    badgeLabelMap: Map<string, PipelineDatasetBadgeLabelKey>;
  }): FlowNode[] {
    const { sortedDatasets, levels, connectorMap, roleMap, badgeLabelMap } = params;
    return sortedDatasets.map((dataset) => this.createFlowNode(dataset, levels, connectorMap, roleMap, badgeLabelMap));
  }

  private createFlowNode(
    dataset: Dataset,
    levels: Map<string, number>,
    connectorMap: Map<string, DatasourceConnector>,
    roleMap: Map<string, PipelineDatasetRole>,
    badgeLabelMap: Map<string, PipelineDatasetBadgeLabelKey>,
  ): FlowNode {
    const role = roleMap.get(dataset.id) ?? 'derived';
    const isSource = role === 'source';
    const isJoin = role === 'join';
    const isDerived = !isSource && !isJoin;
    const icon = isSource ? this.resolveConnectorIcon(dataset, connectorMap) : undefined;
    const connectorLabel = isSource ? this.resolveConnectorLabel(dataset, connectorMap) : undefined;

    return {
      dataset,
      level: levels.get(dataset.id) ?? 0,
      icon,
      connectorLabel,
      isSource,
      isJoin,
      isDerived,
      badgeLabelKey: badgeLabelMap.get(dataset.id) ?? 'pipeline.flow.operation.transformation',
    };
  }

  private groupNodesIntoColumns(nodes: FlowNode[]): FlowColumn[] {
    const columnsMap = new Map<number, FlowNode[]>();
    for (const node of nodes) {
      if (!columnsMap.has(node.level)) {
        columnsMap.set(node.level, []);
      }
      columnsMap.get(node.level)!.push(node);
    }

    return [...columnsMap.entries()]
      .sort(([levelA], [levelB]) => levelA - levelB)
      .map(([level, levelNodes]) => ({
        level,
        nodes: levelNodes.toSorted((a, b) => a.dataset.datasetOrder - b.dataset.datasetOrder),
      }));
  }

  private getDatasetSources(
    dataset: Dataset,
    sortedDatasets: Dataset[],
    datasetMap: Map<string, Dataset>,
    relationMaps: {
      joinRelationMap: Map<string, DatasetJoinRelation>;
      unionRelationMap: Map<string, DatasetUnionRelation>;
      aggregationRelationMap: Map<string, DatasetAggregationRelation>;
      subsetRelationMap: Map<string, DatasetSubsetRelation>;
    },
  ): { sourceIds: string[]; joinType?: string; hasAggregation: boolean } {
    const datasetAny = dataset as Dataset & {
      leftDatasetId?: string;
      rightDatasetId?: string;
      joinType?: string;
      datasetSourceId?: string;
      sourceDatasetId?: string;
      parentDatasetId?: string;
      derivedFromDatasetId?: string;
      aggregationColumns?: unknown[];
      aggregationFunctions?: unknown[];
    };

    const joinRelation = relationMaps.joinRelationMap.get(dataset.id);
    const unionRelation = relationMaps.unionRelationMap.get(dataset.id);
    const aggregationRelation = relationMaps.aggregationRelationMap.get(dataset.id);
    const subsetRelation = relationMaps.subsetRelationMap.get(dataset.id);

    const sourceIds = this.extractSourceIds(
      datasetAny,
      dataset,
      sortedDatasets,
      joinRelation,
      unionRelation,
      aggregationRelation,
      subsetRelation,
    );
    const hasAggregation = aggregationRelation ? true : this.checkHasAggregation(datasetAny);
    const joinType = joinRelation?.joinType ?? this.determineJoinType(datasetAny.joinType, dataset);
    const validSourceIds = this.filterValidSourceIds(sourceIds, datasetMap);

    return {
      sourceIds: validSourceIds,
      joinType,
      hasAggregation,
    };
  }

  private extractSourceIds(
    datasetAny: any,
    dataset: Dataset,
    sortedDatasets: Dataset[],
    joinRelation?: DatasetJoinRelation,
    unionRelation?: DatasetUnionRelation,
    aggregationRelation?: DatasetAggregationRelation,
    subsetRelation?: DatasetSubsetRelation,
  ): string[] {
    const sourceIds = this.extractRelationSourceIds(unionRelation, joinRelation, subsetRelation, aggregationRelation);
    if (sourceIds.length > 0) {
      return sourceIds;
    }

    const datasetSourceIds = this.extractDatasetPropertySourceIds(datasetAny);
    if (datasetSourceIds.length > 0) {
      return datasetSourceIds;
    }

    return this.extractFallbackSourceIds(dataset, sortedDatasets);
  }

  private extractRelationSourceIds(
    unionRelation?: DatasetUnionRelation,
    joinRelation?: DatasetJoinRelation,
    subsetRelation?: DatasetSubsetRelation,
    aggregationRelation?: DatasetAggregationRelation,
  ): string[] {
    if (unionRelation?.leftDatasetId && unionRelation?.rightDatasetId) {
      return [unionRelation.leftDatasetId, unionRelation.rightDatasetId];
    }
    if (joinRelation?.leftDatasetId && joinRelation?.rightDatasetId) {
      return [joinRelation.leftDatasetId, joinRelation.rightDatasetId];
    }
    if (subsetRelation?.datasetSourceId) {
      return [subsetRelation.datasetSourceId];
    }
    if (aggregationRelation?.datasetSourceId) {
      return [aggregationRelation.datasetSourceId];
    }
    return [];
  }

  private extractDatasetPropertySourceIds(datasetAny: any): string[] {
    if (datasetAny.leftDatasetId && datasetAny.rightDatasetId) {
      return [datasetAny.leftDatasetId, datasetAny.rightDatasetId];
    }
    if (datasetAny.datasetSourceId) {
      return [datasetAny.datasetSourceId];
    }
    if (datasetAny.sourceDatasetId) {
      return [datasetAny.sourceDatasetId];
    }
    if (datasetAny.parentDatasetId) {
      return [datasetAny.parentDatasetId];
    }
    if (datasetAny.derivedFromDatasetId) {
      return [datasetAny.derivedFromDatasetId];
    }
    return [];
  }

  private buildJoinRelationMap(joinRelations: DatasetJoinRelation[]): Map<string, DatasetJoinRelation> {
    return this.buildRelationMap(joinRelations);
  }

  private buildUnionRelationMap(unionRelations: DatasetUnionRelation[]): Map<string, DatasetUnionRelation> {
    return this.buildRelationMap(unionRelations);
  }

  private buildAggregationRelationMap(
    aggregationRelations: DatasetAggregationRelation[],
  ): Map<string, DatasetAggregationRelation> {
    return this.buildRelationMap(aggregationRelations);
  }

  private buildSubsetRelationMap(subsetRelations: DatasetSubsetRelation[]): Map<string, DatasetSubsetRelation> {
    return this.buildRelationMap(subsetRelations);
  }

  private buildRelationMap<T extends { datasetId?: string }>(relations: T[]): Map<string, T> {
    const relationMap = new Map<string, T>();
    for (const relation of relations) {
      if (relation.datasetId) {
        relationMap.set(relation.datasetId, relation);
      }
    }
    return relationMap;
  }

  private extractFallbackSourceIds(dataset: Dataset, sortedDatasets: Dataset[]): string[] {
    const index = sortedDatasets.findIndex((item) => item.id === dataset.id);
    const sourceIds: string[] = [];

    if (dataset.type === DatasetType.JOIN) {
      if (index > 0) sourceIds.push(sortedDatasets[index - 1].id);
      if (index > 1) sourceIds.push(sortedDatasets[index - 2].id);
    } else if (!dataset.datasetConnector?.connector?.id && index > 0) {
      sourceIds.push(sortedDatasets[index - 1].id);
    }

    return sourceIds;
  }

  private checkHasAggregation(datasetAny: any): boolean {
    return (
      Array.isArray(datasetAny.aggregationColumns) ||
      Array.isArray(datasetAny.aggregationFunctions) ||
      !!datasetAny.datasetSourceId
    );
  }

  private determineJoinType(explicitJoinType: string | undefined, dataset: Dataset): string | undefined {
    if (explicitJoinType) {
      return explicitJoinType;
    }
    return dataset.type === DatasetType.JOIN ? 'JOIN' : undefined;
  }

  private filterValidSourceIds(sourceIds: string[], datasetMap: Map<string, Dataset>): string[] {
    const uniqueSourceIds = sourceIds.filter((sourceId, idx) => sourceId && sourceIds.indexOf(sourceId) === idx);
    return uniqueSourceIds.filter((sourceId) => datasetMap.has(sourceId));
  }

  private isSubsetDataset(dataset: Dataset): boolean {
    const datasetAny = dataset as Dataset & { filterExpression?: string };
    return dataset.type === DatasetType.SUBSET || Boolean(datasetAny.filterExpression);
  }

  private getOperationKey(dataset: Dataset, joinType?: string, hasAggregation?: boolean): FlowOperationKey {
    if (dataset.type === DatasetType.UNION) {
      return 'pipeline.flow.operation.union';
    }

    if (this.isSubsetDataset(dataset)) {
      return 'pipeline.flow.operation.subset';
    }

    if (dataset.type === DatasetType.JOIN || joinType) {
      return this.getJoinOperationKey(joinType);
    }

    if (hasAggregation) {
      return 'pipeline.flow.operation.aggregation';
    }

    return 'pipeline.flow.operation.transformation';
  }

  private getJoinOperationKey(joinType?: string): FlowOperationKey {
    return PipelineFlowComponent.JOIN_TYPE_KEYS[joinType ?? ''] ?? 'pipeline.flow.operation.join';
  }

  private getOperationLabelKey(dataset: Dataset, joinType?: string, hasAggregation?: boolean): FlowOperationLabelKey {
    if (dataset.type === DatasetType.UNION) {
      return 'pipeline.flow.operation.union';
    }

    if (this.isSubsetDataset(dataset)) {
      return 'pipeline.flow.operation.subset';
    }

    if (dataset.type === DatasetType.JOIN || joinType) {
      return 'pipeline.flow.operation.join';
    }

    if (hasAggregation) {
      return 'pipeline.flow.operation.aggregation';
    }

    return 'pipeline.flow.operation.transformation';
  }

  private mapJoinTypeToKey(joinType?: string): FlowOperationKey | undefined {
    return joinType ? PipelineFlowComponent.JOIN_TYPE_KEYS[joinType] : undefined;
  }

  private resolveSideKey(
    datasetId: string,
    sourceId: string,
    joinRelationMap: Map<string, DatasetJoinRelation>,
    unionRelationMap: Map<string, DatasetUnionRelation>,
  ): FlowSideKey | undefined {
    const joinRelation = joinRelationMap.get(datasetId);
    if (joinRelation) {
      if (joinRelation.leftDatasetId === sourceId) {
        return 'pipeline.flow.detail.side.left';
      }
      if (joinRelation.rightDatasetId === sourceId) {
        return 'pipeline.flow.detail.side.right';
      }
    }

    const unionRelation = unionRelationMap.get(datasetId);
    if (unionRelation) {
      if (unionRelation.leftDatasetId === sourceId) {
        return 'pipeline.flow.detail.side.left';
      }
      if (unionRelation.rightDatasetId === sourceId) {
        return 'pipeline.flow.detail.side.right';
      }
    }

    return undefined;
  }

  private resolveConnectorIcon(dataset: Dataset, connectorMap: Map<string, DatasourceConnector>): string | undefined {
    const iconFromMap = this.getIconFromConnectorMap(dataset, connectorMap);
    if (iconFromMap) {
      return iconFromMap;
    }

    return this.getIconFromConnectorProperties(dataset);
  }

  private getIconFromConnectorMap(
    dataset: Dataset,
    connectorMap: Map<string, DatasourceConnector>,
  ): string | undefined {
    const connectorId = dataset.datasetConnector?.connector?.id;
    return connectorId ? connectorMap.get(connectorId)?.icon : undefined;
  }

  private getIconFromConnectorProperties(dataset: Dataset): string | undefined {
    const connectorAny = dataset.datasetConnector?.connector as {
      connectorType?: string;
      dbmsType?: string;
    };

    if (connectorAny?.dbmsType) {
      return this.resolveDbmsIcon(connectorAny.dbmsType);
    }

    return this.resolveConnectorTypeIcon(connectorAny?.connectorType);
  }

  private resolveConnectorTypeIcon(connectorType?: string): string | undefined {
    return connectorType ? PipelineFlowComponent.CONNECTOR_TYPE_ICONS[connectorType] : undefined;
  }

  private resolveConnectorLabel(dataset: Dataset, connectorMap: Map<string, DatasourceConnector>): string | undefined {
    const connectorDescription = this.getConnectorDescription(dataset, connectorMap);
    const connectorEntity = dataset.datasetConnector?.connectorEntity;
    return this.formatConnectorLabel(connectorDescription, connectorEntity);
  }

  private getConnectorDescription(
    dataset: Dataset,
    connectorMap: Map<string, DatasourceConnector>,
  ): string | undefined {
    const connectorId = dataset.datasetConnector?.connector?.id;
    return connectorId ? connectorMap.get(connectorId)?.description : dataset.datasetConnector?.connector?.description;
  }

  private formatConnectorLabel(description: string | undefined, entity: string | undefined): string | undefined {
    if (description && entity) {
      return `${description} - ${entity}`;
    }
    return description ?? entity;
  }

  private resolveDbmsIcon(dbmsType: string): string | undefined {
    return PipelineFlowComponent.DBMS_TYPE_ICONS[dbmsType] ?? 'assets/db-icon/db.png';
  }

  private observeFlowNodes(): void {
    if (typeof ResizeObserver === 'undefined') {
      return;
    }

    this.flowNodeResizeObserver ??= new ResizeObserver(() => this.scheduleFlowUpdate());

    this.flowNodeResizeObserver.disconnect();
    const nodes = this.flowNodeRefs?.toArray() ?? [];
    for (const node of nodes) {
      this.flowNodeResizeObserver.observe(node.nativeElement);
    }
  }
}
