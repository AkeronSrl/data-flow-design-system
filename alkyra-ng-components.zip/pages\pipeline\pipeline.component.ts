import { TiaraCollapsableContainerComponent } from '@akeron-ng/tiara-ng/tiara-collapsable-container';
import { TiaraNavBarUiComponent } from '@akeron-ng/tiara-ng/tiara-nav-bar-ui';
import { TiaraToggleComponent } from '@akeron-ng/tiara-ng/tiara-toggle';
import { TiaraSuiteListMenuComponent, TiaraSuiteMenuGroup } from '@akeron-ng/tiara-ng-suite/tiara-list-menu';
import {
  TiaraSuiteTreeNode,
  TiaraSuiteTreeSelectionEvent,
  TiaraSuiteTreeViewComponent,
} from '@akeron-ng/tiara-ng-suite/tiara-tree-view';
import { S3BucketConnectorService } from '@alkyra/amazon-s3-connector/services/s3-bucket-connector.service';
import { AzureBlobConnectorService } from '@alkyra/azure-blob-connector/services/azure-blob-connector.service';
import { ColumnCastConfig } from '@alkyra/connector/models/column-cast-config.model';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { ConnectorMetadataPreviewColumn } from '@alkyra/connector/models/connector-metadata-preview-column.model';
import { DataGridDataType } from '@alkyra/datagrid-column-type-mapper/models/data-grid-type-mapper.types';
import { DataGridColumnTypeMapperService } from '@alkyra/datagrid-column-type-mapper/services/data-grid-column-type-mapper.service';
import { AggregationWizardComponent } from '@alkyra/dataset/components/aggregation-wizard/aggregation-wizard.component';
import { DatasetEditPopupComponent } from '@alkyra/dataset/components/dataset-edit-popup/dataset-edit-popup.component';
import { ApiStepStore } from '@alkyra/dataset/components/dataset-wizard/+store/api-step.store';
import { SqsStepStore } from '@alkyra/dataset/components/dataset-wizard/+store/sqs-step.store';
import { resolveCloudFileType } from '@alkyra/dataset/components/dataset-wizard/dataset-cloud-source/cloud-file-tree.utils';
import { DatasetColumnCastDialogComponent } from '@alkyra/dataset/components/dataset-wizard/dataset-column-selector/dataset-column-cast-dialog/dataset-column-cast-dialog.component';
import {
  buildCastValidationResult,
  CastValidationResult,
  normalizeCastTypeOption,
  resolveColumnTypeMeta,
} from '@alkyra/dataset/components/dataset-wizard/dataset-column-selector/dataset-column-selector.models';
import { DatasetWizardComponent } from '@alkyra/dataset/components/dataset-wizard/dataset-wizard.component';
import { ExportDatasetWizardComponent } from '@alkyra/dataset/components/export-dataset-wizard/export-dataset-wizard.component';
import {
  composeCloudConnectorEntity,
  directoryPathFromItemPath,
  fileNameWithoutExtension,
  parseCloudConnectorEntity,
} from '@alkyra/dataset/components/export-dataset-wizard/utils/cloud-export-path.utils';
import { buildExportCloudFileTreeNodes } from '@alkyra/dataset/components/export-dataset-wizard/utils/cloud-export-tree.utils';
import { JoinEditDialogComponent } from '@alkyra/dataset/components/join-edit-dialog/join-edit-dialog.component';
import { JoinWizardComponent } from '@alkyra/dataset/components/join-wizard/join-wizard.component';
import { SourceColumnsEditDialogComponent } from '@alkyra/dataset/components/source-columns-edit-dialog/source-columns-edit-dialog.component';
import { SubsetWizardComponent } from '@alkyra/dataset/components/subset-wizard/subset-wizard.component';
import { UnionWizardComponent } from '@alkyra/dataset/components/union-wizard/union-wizard.component';
import { Dataset, DatasetMetadataUpdate } from '@alkyra/dataset/models/dataset.model';
import { DatasetColumn } from '@alkyra/dataset/models/dataset-column.model';
import { DatasetColumnFormula } from '@alkyra/dataset/models/dataset-column-formula.model';
import {
  DatasetColumnRenameImpactItem,
  DatasetColumnRenameImpactPreview,
} from '@alkyra/dataset/models/dataset-column-rename-impact.model';
import { DatasetConnector } from '@alkyra/dataset/models/dataset-connector.model';
import { DatasetExportType } from '@alkyra/dataset/models/dataset-connector-export.model';
import { DatasetService } from '@alkyra/dataset/services/dataset.service';
import { DatasetColumnService } from '@alkyra/dataset/services/dataset-column.service';
import { DatasetColumnFormulaService } from '@alkyra/dataset/services/dataset-column-formula.service';
import { DatasetConnectorService } from '@alkyra/dataset/services/dataset-connector.service';
import { FileExplorerItem } from '@alkyra/file-explorer/models/file-explorer-item.model';
import { PipelineAuditStatusComponent } from '@alkyra/pipeline/components/pipeline-audit-status/pipeline-audit-status.component';
import { ExportType, Pipeline, PipelineAuditParams, PipelineType } from '@alkyra/pipeline/models/pipeline.model';
import { PipelineService } from '@alkyra/pipeline/services/pipeline.service';
import { ScreenLockStore } from '@alkyra/screen-lock/+store/screen-lock.store';
import { Id } from '@alkyra/shared-models/id.model';
import { LowerCasePipe, NgTemplateOutlet } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  inject,
  OnDestroy,
  OnInit,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { confirm } from 'devextreme/ui/dialog';
import notify from 'devextreme/ui/notify';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxDropDownBoxModule } from 'devextreme-angular/ui/drop-down-box';
import { DxPopupModule } from 'devextreme-angular/ui/popup';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxSplitterModule } from 'devextreme-angular/ui/splitter';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxTreeViewModule } from 'devextreme-angular/ui/tree-view';
import { DxValidatorModule } from 'devextreme-angular/ui/validator';
import { catchError, concat, EMPTY, finalize, Observable, of, switchMap, take, throwError } from 'rxjs';

import { DatasetListComponent } from '../../dataset/components/dataset-list/dataset-list.component';
import {
  normalizeDatasetColumnAlias,
  resolveDatasetColumnOutputName,
} from '../../dataset/components/shared/dataset-column-alias.utils';
import { AddFormulaPopupComponent } from '../../formula/components/add-formula-popup/add-formula-popup.component';
import { PipelineStore } from './+store/pipeline.store';
import { ColumnImpactPopupComponent } from './components/column-impact-popup/column-impact-popup.component';
import { EditColumnPopupComponent } from './components/edit-column-popup/edit-column-popup.component';
import { PipelineFlowComponent } from './components/pipeline-flow/pipeline-flow.component';
import {
  ColumnActionPrecheckConfig,
  ColumnMutationConfig,
  ColumnTypeMeta,
  DatasetColumnCastPayload,
  DatasetColumnRenamePayload,
  ImpactPopupState,
} from './models/pipeline.model';

@Component({
  selector: 'alk-pipeline',
  standalone: true,
  imports: [
    DxButtonModule,
    DxPopupModule,
    DxTextBoxModule,
    DxSelectBoxModule,
    DxValidatorModule,
    DxDataGridModule,
    DxDropDownBoxModule,
    DxTreeViewModule,
    AddFormulaPopupComponent,
    DatasetWizardComponent,
    DatasetEditPopupComponent,
    DatasetListComponent,
    JoinWizardComponent,
    JoinEditDialogComponent,
    SourceColumnsEditDialogComponent,
    UnionWizardComponent,
    SubsetWizardComponent,
    TranslatePipe,
    AggregationWizardComponent,
    TiaraCollapsableContainerComponent,
    TiaraNavBarUiComponent,
    TiaraToggleComponent,
    DxScrollViewModule,
    DxSplitterModule,
    PipelineFlowComponent,
    PipelineAuditStatusComponent,
    NgTemplateOutlet,
    LowerCasePipe,
    ExportDatasetWizardComponent,
    EditColumnPopupComponent,
    DatasetColumnCastDialogComponent,
    ColumnImpactPopupComponent,
    TiaraSuiteListMenuComponent,
    TiaraSuiteTreeViewComponent,
  ],
  providers: [PipelineStore, SqsStepStore, ApiStepStore],
  templateUrl: './pipeline.component.html',
  styleUrl: './pipeline.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PipelineComponent implements OnInit, OnDestroy {
  private static readonly COLUMN_ACTION_RENAME = 1;
  private static readonly COLUMN_ACTION_EDIT_FORMULA = 2;
  private static readonly COLUMN_ACTION_DELETE = 3;
  private static readonly COLUMN_ACTION_CAST = 4;
  _store = inject(PipelineStore);
  _screenLockStore = inject(ScreenLockStore);
  _activatedRoute = inject(ActivatedRoute);
  _router = inject(Router);
  pipelineService = inject(PipelineService);
  trasformationService = inject(DatasetColumnFormulaService);
  datasetColumnService = inject(DatasetColumnService);
  datasetConnectorService = inject(DatasetConnectorService);
  datasetService = inject(DatasetService);
  private readonly _translateService: TranslateService = inject(TranslateService);
  private readonly _dataGridColumnTypeMapper = inject(DataGridColumnTypeMapperService);
  private readonly _s3BucketConnectorService = inject(S3BucketConnectorService);
  private readonly _azureBlobConnectorService = inject(AzureBlobConnectorService);
  private readonly _destroyRef = inject(DestroyRef);
  readonly _sqsStore = inject(SqsStepStore);
  readonly _apiStepStore = inject(ApiStepStore);

  workspaceId!: string;
  pipelineId!: string;

  pipelineDescription: string = '';
  auditEnabled = signal<boolean>(false);
  auditMaxCopies = signal<number>(1);

  formula: DatasetColumnFormula | undefined;
  selectedExportType: ExportType | null = null;
  readonly PipelineType = PipelineType;
  pipelineType = signal<PipelineType | null>(null);
  editingExportId: string | null = null;
  exportWizardDatasetId: string | null = null;

  editExportPopupVisible = signal<boolean>(false);
  editingExport = signal<DatasetConnector | null>(null);
  editConnectorEntity: string = '';
  readonly fileNameNoDotsPattern = /^[^.]+$/;
  editCloudDirectoryPath = signal<string>('');
  editCloudFileName = signal<string>('');
  editCloudSelectedItemPath = signal<string | null>(null);
  editCloudTreeNodes = signal<TiaraSuiteTreeNode<FileExplorerItem, FileExplorerItem>[]>([]);
  isEditCloudTreeLoading = signal<boolean>(false);
  editDatasetPopupVisible = signal<boolean>(false);
  editingDataset = signal<Dataset | null>(null);
  editColumnPopupVisible = signal<boolean>(false);
  editingColumn = signal<DatasetColumn | null>(null);
  editColumnAlias: string = '';
  editColumnImpacts = signal<DatasetColumnRenameImpactItem[]>([]);
  editColumnValidationMessage = signal<string | null>(null);
  isSavingColumnRename = signal<boolean>(false);
  renameImpactPopupVisible = signal<boolean>(false);
  renameBlockedImpacts = signal<DatasetColumnRenameImpactItem[]>([]);
  deleteImpactPopupVisible = signal<boolean>(false);
  deleteBlockedImpacts = signal<DatasetColumnRenameImpactItem[]>([]);
  castColumnDialogVisible = signal<boolean>(false);
  castImpactPopupVisible = signal<boolean>(false);
  castEditingColumn = signal<DatasetColumn | null>(null);
  castValidationResult = signal<CastValidationResult | null>(null);
  castValidationLoading = signal<boolean>(false);
  castBlockedImpacts = signal<DatasetColumnRenameImpactItem[]>([]);
  isSavingColumnCast = signal<boolean>(false);
  previewGridVisible = signal<boolean>(true);
  readonly castEditingPreviewColumn = computed(() => {
    const column = this.castEditingColumn();
    return column ? this.toPreviewColumn(column) : null;
  });
  readonly aliasIdentifierPattern = /^[A-Za-z_]\w*$/;
  readonly simpleColumnActionGroups: TiaraSuiteMenuGroup[] = [
    {
      items: [
        {
          id: PipelineComponent.COLUMN_ACTION_RENAME,
          name: this._translateService.instant('actions.rename'),
          tiaraIcon: 'edit',
        },
        {
          id: PipelineComponent.COLUMN_ACTION_CAST,
          name: this._translateService.instant('dataset.column.cast.changeType.action'),
          tiaraIcon: 'shuffle',
        },
        {
          id: PipelineComponent.COLUMN_ACTION_DELETE,
          name: this._translateService.instant('dataset.column.delete.action'),
          tiaraIcon: 'trash',
        },
      ],
    },
  ];
  readonly formulaColumnActionGroups: TiaraSuiteMenuGroup[] = [
    {
      items: [
        {
          id: PipelineComponent.COLUMN_ACTION_RENAME,
          name: this._translateService.instant('actions.rename'),
          tiaraIcon: 'edit',
        },
        {
          id: PipelineComponent.COLUMN_ACTION_EDIT_FORMULA,
          name: this._translateService.instant('dataset.formula.edit'),
          tiaraIcon: 'formula',
        },
        {
          id: PipelineComponent.COLUMN_ACTION_DELETE,
          name: this._translateService.instant('actions.delete'),
          tiaraIcon: 'trash',
        },
      ],
    },
  ];

  // NAU-241/NAU-242: Edit Join Dialog state
  editJoinDialogVisible = signal<boolean>(false);
  editingJoinDataset = signal<Dataset | null>(null);
  editJoinMode = signal<'mappings' | 'columns'>('mappings');
  editSourceColumnsDialogVisible = signal<boolean>(false);
  editingSourceDataset = signal<Dataset | null>(null);

  viewMode: 'list' | 'flow' = 'list';
  private readonly viewModeStorageKey = 'pipeline.viewMode';

  ngOnInit(): void {
    this.initializePipelinePageState();
    this.loadPipelineContext();
    this.loadPipelineDataSequence();
  }

  private initializePipelinePageState(): void {
    this.restoreViewMode();
    this.workspaceId = this._activatedRoute.snapshot.paramMap.get('workspaceId')!;
    this.pipelineId = this._activatedRoute.snapshot.paramMap.get('id')!;
    this._store.clearPreview();
    this._screenLockStore.setAutoUnlock(false); // Disabilita unlock automatico
  }

  private loadPipelineContext(): void {
    this.pipelineService
      .findPipelineById(this.pipelineId)
      .pipe(take(1))
      .subscribe({
        next: (pipeline) => this.applyPipelineContext(pipeline),
      });
  }

  private applyPipelineContext(pipeline: Pipeline): void {
    this._sqsStore.setSelectedPipeline(pipeline);
    this._apiStepStore.setSelectedPipeline(pipeline);
    this.pipelineType.set(pipeline.pipelineType);
    this.auditEnabled.set(this.readAuditEnabled(pipeline));
    this.auditMaxCopies.set(this.readAuditMaxCopies(pipeline));
  }

  private readAuditEnabled(pipeline: Pipeline): boolean {
    return (
      pipeline.pipelineParams?.find((param) => param.codParametro === PipelineAuditParams.ENABLED)?.valoreBooleano ??
      false
    );
  }

  private readAuditMaxCopies(pipeline: Pipeline): number {
    return (
      pipeline.pipelineParams?.find((param) => param.codParametro === PipelineAuditParams.MAX_COPIES)?.valoreNumerico ??
      1
    );
  }

  private loadPipelineDataSequence(): void {
    concat(...this.createPipelineLoadSteps()).subscribe({
      complete: () => {
        this._screenLockStore.unlockScreen();
      },
    });
  }

  private createPipelineLoadSteps(): Observable<unknown>[] {
    return [
      this.wrapLoadStep(this._store.loadSources(), 'Errore nel caricamento delle sorgenti'),
      this.wrapLoadStep(this._store.loadDatasets(this.pipelineId), 'Errore nel caricamento dei passi'),
      this.wrapLoadStep(this._store.loadDatasetJoins(this.pipelineId), 'Errore nel caricamento delle join'),
      this.wrapLoadStep(this._store.loadDatasetUnions(this.pipelineId), 'Errore nel caricamento delle union'),
      this.wrapLoadStep(
        this._store.loadDatasetAggregations(this.pipelineId),
        'Errore nel caricamento delle aggregazioni',
      ),
      this.wrapLoadStep(this._store.loadDatasetSubsets(this.pipelineId), 'Errore nel caricamento delle subset'),
      this.wrapLoadStep(
        this.pipelineService.preparePreviewPipelineParquets(this.pipelineId),
        'Errore nella preparazione dei parquet',
      ),
    ];
  }

  private wrapLoadStep(loadStep$: Observable<unknown>, errorMessage: string): Observable<unknown> {
    return loadStep$.pipe(
      catchError((err) => {
        this.handleError(errorMessage);
        return throwError(() => err);
      }),
    );
  }

  private handleError(message: string): void {
    this._screenLockStore.unlockScreen({ message, status: 'error' });
  }

  ngOnDestroy(): void {
    this.pipelineService.deletePipelineParquets(this.pipelineId).subscribe();
  }

  onAddClick() {
    this._store.setDatasetPopupVisible(true);
  }

  onBackClick() {
    this._router.navigate(['/workspaces', this.workspaceId, 'pipelines']);
  }

  setViewMode(mode: 'list' | 'flow') {
    this.viewMode = mode;
    sessionStorage.setItem(this.viewModeStorageKey, mode);
  }

  onViewModeChanged(mode: string): void {
    if (mode === 'list' || mode === 'flow') {
      this.setViewMode(mode);
    }
  }

  selectDataset(dataset: Dataset) {
    this._store.setFocusedStep(dataset);
  }

  showAddFormulaPopup(formulaDatasetColumn?: DatasetColumn) {
    if (formulaDatasetColumn) {
      this.trasformationService.findByColumnId(formulaDatasetColumn.id ?? '').subscribe({
        next: (f: DatasetColumnFormula) => {
          this.formula = f;
          this._store.setAddFormulaPopupVisible(true);
        },
        error: (err: any) => {
          this.notify(
            this._translateService.instant('impossibile modificare la formula:' + err.message),
            'error',
            4000,
          );
        },
      });
    } else {
      this._store.setAddFormulaPopupVisible(true);
    }
  }

  showJoinWizard() {
    this._store.setJoinWizardVisible(true);
  }

  showUnionWizard() {
    this._store.setUnionWizardVisible(true);
  }

  showAggregationWizard() {
    this._store.setAggregationWizardVisible(true);
  }

  showSubsetWizard() {
    this._store.setSubsetWizardVisible(true);
  }

  /**
   * NAU-241/NAU-242: Show edit dialog for JOIN dataset (columns mode)
   */
  showEditJoinDialog(dataset: Dataset) {
    this.editingJoinDataset.set(dataset);
    this.editJoinMode.set('columns');
    this.editJoinDialogVisible.set(true);

    // Note: Dialog will need to load join details from Dataset entity which includes:
    // - dataset.datasetJoin.joinType (join type)
    // - dataset.datasetJoin.joinColumns (join column mappings)
    // - dataset.datasetColumns (output columns)
    // This data should already be available in the Dataset model from the store
  }

  /**
   * NAU-241/NAU-242: Show edit mappings for JOIN dataset (mappings mode)
   */
  showEditJoinMappings(dataset: Dataset) {
    this.editingJoinDataset.set(dataset);
    this.editJoinMode.set('mappings');
    this.editJoinDialogVisible.set(true);
  }

  showEditSourceColumnsDialog(dataset: Dataset) {
    this.editingSourceDataset.set(dataset);
    this.editSourceColumnsDialogVisible.set(true);
  }

  showEditDatasetDialog(dataset: Dataset) {
    this.editingDataset.set(dataset);
    this.editDatasetPopupVisible.set(true);
  }

  /**
   * NAU-241/NAU-242: Handle edit join saved
   */
  onEditJoinSaved(id: Id) {
    this.editJoinDialogVisible.set(false);
    this.editingJoinDataset.set(null);

    // Reload datasets and re-focus to refresh grid columns and preview
    concat(this._store.reloadDatasets(this.pipelineId, id.id), this._store.loadDatasetJoins(this.pipelineId)).subscribe(
      {
        next: () => {
          notify('Join configuration updated successfully', 'success', 3000);
        },
        error: () => {
          notify('Failed to reload datasets', 'error', 3000);
        },
      },
    );
  }

  /**
   * NAU-241/NAU-242: Handle edit join dialog closed
   */
  onEditJoinClosed() {
    this.editJoinDialogVisible.set(false);
    this.editingJoinDataset.set(null);
  }

  onEditSourceColumnsSaved() {
    const datasetId = this.editingSourceDataset()?.id ?? null;
    this.editSourceColumnsDialogVisible.set(false);
    this.editingSourceDataset.set(null);

    this._store.reloadDatasets(this.pipelineId, datasetId).subscribe({
      next: () => {
        notify(this._translateService.instant('dataset.source.edit.save.success'), 'success', 3000);
      },
      error: () => {
        notify(this._translateService.instant('dataset.source.edit.save.error'), 'error', 3000);
      },
    });
  }

  onEditSourceColumnsClosed() {
    this.editSourceColumnsDialogVisible.set(false);
    this.editingSourceDataset.set(null);
  }

  onEditDatasetSaved(update: DatasetMetadataUpdate) {
    const dataset = this.editingDataset();
    if (!dataset?.id) {
      return;
    }

    this._screenLockStore.lockScreen();
    this.datasetService
      .updateDatasetMetadata(dataset.id, update)
      .pipe(
        switchMap(() => this._store.reloadDatasets(this.pipelineId, dataset.id)),
        finalize(() => this._screenLockStore.unlockScreen()),
        catchError((err) => {
          const message =
            err?.error?.message ?? err?.error ?? err?.message ?? this._translateService.instant('error.generic');
          notify(this._translateService.instant(message), 'error', 4000);
          return EMPTY;
        }),
      )
      .subscribe(() => {
        this.editDatasetPopupVisible.set(false);
        this.editingDataset.set(null);
        notify(this._translateService.instant('dataset.metadata.updated.successfully'), 'success', 3000);
      });
  }

  onEditDatasetClosed() {
    this.editDatasetPopupVisible.set(false);
    this.editingDataset.set(null);
  }

  /**
   * NAU-241/NAU-242: Get left dataset for join
   */
  getJoinLeftDataset(joinDataset: Dataset): Dataset | null {
    const join = this._store.datasetJoins().find((j) => j.datasetId === joinDataset.id);
    if (!join) return null;
    return this._store.datasets().find((d) => d.id === join.leftDatasetId) ?? null;
  }

  /**
   * NAU-241/NAU-242: Get right dataset for join
   */
  getJoinRightDataset(joinDataset: Dataset): Dataset | null {
    const join = this._store.datasetJoins().find((j) => j.datasetId === joinDataset.id);
    if (!join) return null;
    return this._store.datasets().find((d) => d.id === join.rightDatasetId) ?? null;
  }

  /**
   * NAU-241/NAU-242: Get join type for join dataset
   */
  getJoinType(joinDataset: Dataset): string {
    const join = this._store.datasetJoins().find((j) => j.datasetId === joinDataset.id);
    return join?.joinType ?? 'INNER';
  }

  addFormulaToGrid() {
    this._store.reloadDatasets(this.pipelineId, this._store.focusedDataset()!.id).subscribe();
    this._store.setAddFormulaPopupVisible(false);
    this.formula = undefined;
  }

  deleteDatasetColumn(
    datasetColumnId: string | undefined,
    focusedDatasetId: string | null = this._store.focusedDataset()?.id ?? null,
  ) {
    if (!datasetColumnId) {
      return;
    }
    this._store
      .deleteDatasetColumn(datasetColumnId)
      .pipe(
        switchMap(() => this.refreshAfterColumnDelete(focusedDatasetId)),
        catchError((err) => {
          this.notify(this.extractErrorMessage(err), 'error', 5000);
          return EMPTY;
        }),
      )
      .subscribe(() => {
        this.notify(this._translateService.instant('dataset.column.delete.updated'), 'success', 3000);
      });
  }

  getSimpleColumnActionsButtonId(column: DatasetColumn, index: number): string {
    return `column-actions-simple-${this.toSafeDomId(this.getColumnStableKey(column, index))}`;
  }

  getFormulaColumnActionsButtonId(column: DatasetColumn, index: number): string {
    return `column-actions-formula-${this.toSafeDomId(this.getColumnStableKey(column, index))}`;
  }

  onSimpleColumnMenuItemSelected(outputName: string | undefined, actionId: number): void {
    if (actionId === PipelineComponent.COLUMN_ACTION_RENAME) {
      this.showEditColumnAliasDialogByOutputName(outputName);
      return;
    }

    if (actionId === PipelineComponent.COLUMN_ACTION_DELETE) {
      this.showDeleteColumnDialogByOutputName(outputName);
      return;
    }

    if (actionId === PipelineComponent.COLUMN_ACTION_CAST) {
      this.showEditColumnCastDialogByOutputName(outputName);
    }
  }

  onFormulaColumnMenuItemSelected(column: DatasetColumn, actionId: number): void {
    if (actionId === PipelineComponent.COLUMN_ACTION_RENAME) {
      this.showEditColumnAliasDialog(column);
      return;
    }

    if (actionId === PipelineComponent.COLUMN_ACTION_EDIT_FORMULA) {
      this.showAddFormulaPopup(column);
      return;
    }

    if (actionId === PipelineComponent.COLUMN_ACTION_DELETE) {
      this.showDeleteColumnDialog(column, 'dataset.formula.delete.confirmation');
    }
  }

  private toSafeDomId(value: string): string {
    return value.replace(/[^a-zA-Z0-9_-]/g, '-');
  }

  closeFormulaPopup() {
    this._store.setAddFormulaPopupVisible(false);
    this.formula = undefined;
  }

  closeDatasetWizard() {
    this._store.setDatasetPopupVisible(false);
  }

  getColumnOutputName(column: DatasetColumn): string {
    return column.displayName ?? resolveDatasetColumnOutputName(column.name, column.alias);
  }

  private getEffectiveColumnType(column: DatasetColumn): string {
    return column.column?.typeTargetCol ?? column.column?.typeOrigCol ?? 'Utf8';
  }

  private getColumnStableKey(column: DatasetColumn, index: number): string {
    return column.id ?? `${column.type}-${column.columnOrder}-${index}`;
  }

  trackDatasetColumn(index: number, column: DatasetColumn): string {
    return `${this.getColumnStableKey(column, index)}:${this.getColumnOutputName(column)}`;
  }

  getFormulaColumnTemplateName(column: DatasetColumn, index: number): string {
    return `formulaHeaderTemplate${this.getColumnStableKey(column, index)}`;
  }

  getSimpleColumnTemplateName(column: DatasetColumn, index: number): string {
    return `simpleHeaderTemplate${this.getColumnStableKey(column, index)}`;
  }

  toPreviewColumn(column: DatasetColumn): ConnectorMetadataPreviewColumn {
    return {
      columnName: column.name,
      alias: column.alias,
      type: column.column?.typeOrigCol ?? 'Utf8',
      length: column.column?.length,
      precision: column.column?.precision,
      cast:
        column.column?.typeTargetCol != null
          ? {
              sourceType: column.column?.typeOrigCol,
              targetType: column.column.typeTargetCol,
              params: column.column.castParams,
            }
          : null,
    };
  }

  private normalizePreviewRowsForCastValidation(column: DatasetColumn, rows: any[]): any[] {
    const outputName = this.getColumnOutputName(column);
    return rows.map((row) => ({
      ...row,
      [column.name]: row?.[column.name] ?? row?.[outputName],
    }));
  }

  getPreviewColumnDataType(column: DatasetColumn): DataGridDataType {
    return this._dataGridColumnTypeMapper.mapType(this.getEffectiveColumnType(column));
  }

  getColumnTypeMeta(column: DatasetColumn): ColumnTypeMeta {
    return resolveColumnTypeMeta(this.getEffectiveColumnType(column), (value) =>
      this._dataGridColumnTypeMapper.mapType(value),
    );
  }

  hasColumnCast(column: DatasetColumn): boolean {
    return (
      !!column.column?.typeTargetCol &&
      normalizeCastTypeOption(column.column.typeTargetCol) !== normalizeCastTypeOption(column.column?.typeOrigCol)
    );
  }

  showEditColumnAliasDialogByOutputName(outputName: string | undefined): void {
    if (!outputName) {
      return;
    }

    const column = this._store.simpleColumns().find((item) => this.getColumnOutputName(item) === outputName);
    if (column) {
      this.showEditColumnAliasDialog(column);
    }
  }

  showEditColumnCastDialogByOutputName(outputName: string | undefined): void {
    if (!outputName) {
      return;
    }

    const column = this._store.simpleColumns().find((item) => this.getColumnOutputName(item) === outputName);
    if (column) {
      this.showEditColumnCastDialog(column);
    }
  }

  showDeleteColumnDialogByOutputName(outputName: string | undefined): void {
    if (!outputName) {
      return;
    }

    const column = this._store.simpleColumns().find((item) => this.getColumnOutputName(item) === outputName);
    if (column) {
      this.showDeleteColumnDialog(column);
    }
  }

  showEditColumnAliasDialog(column: DatasetColumn): void {
    this.openColumnActionIfUsageAllowed(column, {
      blockedPopupState: {
        impacts: this.renameBlockedImpacts,
        visible: this.renameImpactPopupVisible,
      },
      openAllowedAction: () => {
        this.editingColumn.set(column);
        this.editColumnAlias = column.alias ?? '';
        this.editColumnImpacts.set([]);
        this.editColumnValidationMessage.set(null);
        this.editColumnPopupVisible.set(true);
      },
    });
  }

  showDeleteColumnDialog(column: DatasetColumn, confirmationKey: string = 'dataset.column.delete.confirmation'): void {
    this.openColumnActionIfUsageAllowed(column, {
      blockedPopupState: {
        impacts: this.deleteBlockedImpacts,
        visible: this.deleteImpactPopupVisible,
      },
      openAllowedAction: () => {
        const result = confirm(this._translateService.instant(confirmationKey), '');
        result.then((dialogResult) => {
          if (dialogResult) {
            this.deleteDatasetColumn(column.id, this._store.focusedDataset()?.id ?? null);
          }
        });
      },
    });
  }

  showEditColumnCastDialog(column: DatasetColumn): void {
    this.openColumnActionIfUsageAllowed(column, {
      blockedPopupState: {
        impacts: this.castBlockedImpacts,
        visible: this.castImpactPopupVisible,
      },
      openAllowedAction: () => {
        this.castEditingColumn.set(column);
        this.castValidationResult.set(null);
        this.castValidationLoading.set(false);
        this.castBlockedImpacts.set([]);
        this.castColumnDialogVisible.set(true);
      },
    });
  }

  closeEditColumnAliasDialog(): void {
    this.editColumnPopupVisible.set(false);
    this.editingColumn.set(null);
    this.editColumnAlias = '';
    this.editColumnImpacts.set([]);
    this.editColumnValidationMessage.set(null);
    this.isSavingColumnRename.set(false);
  }

  closeEditColumnCastDialog(): void {
    this.castColumnDialogVisible.set(false);
    this.castEditingColumn.set(null);
    this.castValidationResult.set(null);
    this.castValidationLoading.set(false);
    this.isSavingColumnCast.set(false);
  }

  saveEditedColumnAlias(): void {
    const renameContext = this.resolveColumnRenameContext();
    if (!renameContext) {
      return;
    }

    this.resetColumnRenameValidationState();
    const normalizedAlias = this.validateAndNormalizeAlias(renameContext.columnName);
    if (normalizedAlias === null) {
      return;
    }

    if (this.hasDuplicateOutputName(renameContext.columnId, renameContext.columnName, normalizedAlias)) {
      this.editColumnValidationMessage.set(this._translateService.instant('join.column.alias.validation.error'));
      return;
    }

    const payload = this.createColumnRenamePayload(renameContext.columnId, renameContext.columnName, normalizedAlias);
    this.executeColumnRename(payload, renameContext.focusedDatasetId);
  }

  requestColumnCastValidation(cast: ColumnCastConfig): void {
    const castContext = this.resolveColumnCastContext();
    if (!castContext) {
      return;
    }

    this.castValidationLoading.set(true);
    this.castValidationResult.set(null);
    this.datasetService
      .getPreview(castContext.focusedDatasetId)
      .pipe(
        take(1),
        catchError(() => of([])),
        finalize(() => this.castValidationLoading.set(false)),
      )
      .subscribe({
        next: (rows) => {
          const normalizedRows = this.normalizePreviewRowsForCastValidation(castContext.column, rows);
          this.castValidationResult.set(
            buildCastValidationResult({
              column: this.toPreviewColumn(castContext.column),
              cast,
              sourceRows: normalizedRows,
              castedRows: null,
            }),
          );
        },
        error: (error) => {
          this.castValidationResult.set({
            valid: false,
            rows: [
              {
                sourceValue: '',
                castResult: '',
                status: 'error',
                message: this.extractErrorMessage(error),
              },
            ],
            errorCount: 1,
            sampleCount: 0,
          });
        },
      });
  }

  saveEditedColumnCast(cast: ColumnCastConfig | null): void {
    const castContext = this.resolveColumnCastContext();
    if (!castContext) {
      return;
    }

    const payload = this.createColumnCastPayload(castContext.column, cast);
    this.executeColumnCast(payload, castContext.focusedDatasetId, cast);
  }

  private resolveColumnRenameContext(): {
    columnId: string;
    columnName: string;
    focusedDatasetId: string;
  } | null {
    const column = this.editingColumn();
    const focusedDataset = this._store.focusedDataset();
    if (!column?.id || !focusedDataset?.id) {
      return null;
    }

    return {
      columnId: column.id,
      columnName: column.name,
      focusedDatasetId: focusedDataset.id,
    };
  }

  private resolveColumnCastContext(): {
    column: DatasetColumn;
    focusedDatasetId: string;
  } | null {
    const column = this.castEditingColumn();
    if (!column?.id) {
      return null;
    }

    const focusedDatasetId = this._store.focusedDataset()?.id;
    if (!focusedDatasetId) {
      return null;
    }

    if (!this.hasColumnOriginalType(column)) {
      return null;
    }

    return {
      column,
      focusedDatasetId,
    };
  }

  private hasColumnOriginalType(column: DatasetColumn): boolean {
    return !!column.column?.typeOrigCol;
  }

  private resetColumnRenameValidationState(): void {
    this.editColumnValidationMessage.set(null);
    this.editColumnImpacts.set([]);
  }

  private validateAndNormalizeAlias(columnName: string): string | undefined | null {
    const normalizedAlias = normalizeDatasetColumnAlias(this.editColumnAlias, columnName);
    if (normalizedAlias && !this.aliasIdentifierPattern.test(normalizedAlias)) {
      this.notify(this._translateService.instant('error.dataset.column.alias.invalid'), 'error', 4000);
      return null;
    }

    return normalizedAlias;
  }

  private hasDuplicateOutputName(columnId: string, columnName: string, normalizedAlias: string | undefined): boolean {
    const nextOutputName = resolveDatasetColumnOutputName(columnName, normalizedAlias);
    return this._store
      .columns()
      .filter((item) => item.id !== columnId)
      .map((item) => resolveDatasetColumnOutputName(item.name, item.alias))
      .some((outputName) => outputName === nextOutputName);
  }

  private createColumnRenamePayload(
    columnId: string,
    columnName: string,
    normalizedAlias: string | undefined,
  ): DatasetColumnRenamePayload {
    return {
      id: columnId,
      name: columnName,
      alias: normalizedAlias,
    };
  }

  private previewColumnUsageImpact(column: DatasetColumn): Observable<DatasetColumnRenameImpactPreview> {
    return this.datasetColumnService.previewUsageImpact({
      id: column.id!,
      name: column.name,
    });
  }

  private openColumnActionIfUsageAllowed(column: DatasetColumn, config: ColumnActionPrecheckConfig): void {
    this.previewColumnUsageImpact(column).subscribe({
      next: (preview) => {
        if (this.isPreviewBlocked(preview)) {
          this.openImpactPopup(config.blockedPopupState, preview.impacts);
          return;
        }
        config.openAllowedAction();
      },
      error: (err) => {
        this.notify(this.extractErrorMessage(err), 'error', 5000);
      },
    });
  }

  private isPreviewBlocked(preview: DatasetColumnRenameImpactPreview | null | undefined): boolean {
    return !!preview?.blocked && !!preview.impacts?.length;
  }

  private openImpactPopup(state: ImpactPopupState, impacts: DatasetColumnRenameImpactItem[]): void {
    state.impacts.set(impacts);
    state.visible.set(true);
  }

  private executeColumnRename(payload: DatasetColumnRenamePayload, focusedDatasetId: string): void {
    this.executeColumnMutation({
      preview$: this.datasetColumnService.previewRenameImpact(payload),
      applyPayload: payload,
      focusedDatasetId,
      savingSignal: this.isSavingColumnRename,
      onBlocked: (preview) => {
        this.editColumnImpacts.set(preview.impacts);
        this.notify(this._translateService.instant('dataset.column.rename.blocked'), 'error', 4000);
      },
      applyUpdate: (currentPayload) => this.datasetColumnService.updateDatasetColumn(currentPayload),
      onSuccess: () => this.handleColumnRenameSuccess(),
    });
  }

  private handleColumnRenameError(err: unknown): Observable<never> {
    const message = this.extractErrorMessage(err);
    this.notify(message, 'error', 5000);
    return EMPTY;
  }

  private handleColumnRenameSuccess(): void {
    this.closeEditColumnAliasDialog();
    this.notify(this._translateService.instant('dataset.column.rename.updated'), 'success', 3000);
  }

  private createColumnCastPayload(column: DatasetColumn, cast: ColumnCastConfig | null): DatasetColumnCastPayload {
    return {
      id: column.id!,
      name: column.name,
      column: {
        typeOrigCol: column.column.typeOrigCol,
        typeTargetCol: cast?.targetType ?? null,
        castParams: cast?.params ?? null,
      },
    };
  }

  private executeColumnCast(
    payload: DatasetColumnCastPayload,
    focusedDatasetId: string,
    cast: ColumnCastConfig | null,
  ): void {
    this.castBlockedImpacts.set([]);
    this.executeColumnMutation({
      preview$: this.datasetColumnService.previewCastImpact(payload),
      applyPayload: payload,
      focusedDatasetId,
      savingSignal: this.isSavingColumnCast,
      blockedPopupState: {
        impacts: this.castBlockedImpacts,
        visible: this.castImpactPopupVisible,
      },
      onBlocked: () => {
        this.closeEditColumnCastDialog();
        this.notify(this._translateService.instant('dataset.column.cast.blocked'), 'error', 4000);
      },
      applyUpdate: (currentPayload) => this.datasetColumnService.updateDatasetColumnCast(currentPayload),
      onSuccess: () => this.handleColumnCastSuccess(cast),
    });
  }

  private executeColumnMutation<TPayload>(config: ColumnMutationConfig<TPayload>): void {
    config.savingSignal.set(true);
    config.preview$
      .pipe(
        switchMap((preview) => this.applyColumnMutationPreview(preview, config)),
        switchMap(() => this.refreshFocusedDatasetPreview(config.focusedDatasetId)),
        finalize(() => config.savingSignal.set(false)),
        catchError((err) => this.handleColumnRenameError(err)),
      )
      .subscribe(() => {
        config.onSuccess();
      });
  }

  private applyColumnMutationPreview<TPayload>(
    preview: DatasetColumnRenameImpactPreview,
    config: ColumnMutationConfig<TPayload>,
  ): Observable<void> {
    if (this.isPreviewBlocked(preview)) {
      if (config.blockedPopupState) {
        this.openImpactPopup(config.blockedPopupState, preview.impacts);
      }
      config.onBlocked(preview, config.applyPayload);
      return EMPTY;
    }

    return config.applyUpdate(config.applyPayload);
  }

  private refreshFocusedDatasetPreview(focusedDatasetId: string): Observable<Dataset[]> {
    this.previewGridVisible.set(false);
    return this.datasetService.preparePreviewParquetsFromDataset(focusedDatasetId).pipe(
      switchMap(() => this._store.reloadDatasets(this.pipelineId, focusedDatasetId)),
      finalize(() => this.previewGridVisible.set(true)),
    );
  }

  private refreshAfterColumnDelete(focusedDatasetId: string | null): Observable<Dataset[]> {
    if (!focusedDatasetId) {
      return this._store.reloadDatasets(this.pipelineId, null);
    }

    return this.refreshFocusedDatasetPreview(focusedDatasetId).pipe(
      catchError(() => this._store.reloadDatasets(this.pipelineId, focusedDatasetId)),
    );
  }

  private handleColumnCastSuccess(cast: ColumnCastConfig | null): void {
    this.closeEditColumnCastDialog();
    const messageKey = cast ? 'dataset.column.cast.updated' : 'dataset.column.cast.removed';
    this.notify(this._translateService.instant(messageKey), 'success', 3000);
  }

  closeCastImpactPopup(): void {
    this.castImpactPopupVisible.set(false);
    this.castBlockedImpacts.set([]);
  }

  closeRenameImpactPopup(): void {
    this.renameImpactPopupVisible.set(false);
    this.renameBlockedImpacts.set([]);
  }

  closeDeleteImpactPopup(): void {
    this.deleteImpactPopupVisible.set(false);
    this.deleteBlockedImpacts.set([]);
  }

  onSavedDataset(datasetId: Id) {
    this._screenLockStore.lockScreen();
    this._store.reloadDatasets(this.pipelineId, datasetId.id).subscribe({
      next: () => {
        this._screenLockStore.unlockScreen();
        this._store.setDatasetPopupVisible(false);
      },
      error: (err) => {
        this._screenLockStore.unlockScreen();
        this._store.setDatasetPopupVisible(false);
        this.notify(this._translateService.instant('dataset.error.createparquet'), 'error', 4000);
      },
    });
  }

  onAddExportClick() {
    this.selectedExportType = null;
    this.editingExportId = null;
    this.exportWizardDatasetId = this._store.focusedDataset()?.id ?? null;
    this._store.setExportWizardVisible(true);
  }

  addDestinationStep() {
    const datasetId = this.exportWizardDatasetId ?? this._store.focusedDataset()?.id ?? null;
    this._store.reloadDatasets(this.pipelineId, datasetId).subscribe(() => {
      this._store.setExportWizardVisible(false);
      this.selectedExportType = null;
      this.editingExportId = null;
      this.exportWizardDatasetId = null;
    });
  }

  closeExportWizard() {
    this._store.setExportWizardVisible(false);
    this.selectedExportType = null;
    this.editingExportId = null;
    this.exportWizardDatasetId = null;
  }

  executePipeline() {
    this._screenLockStore.setAutoUnlock(false);
    this.pipelineService.executePipelineAsync(this.pipelineId).subscribe({
      complete: () => {
        this._screenLockStore.unlockScreen();
        this.notify(this._translateService.instant('export.started.successfully'), 'success', 4000);
      },
    });
  }

  deleteDataset(dataset: Dataset): void {
    this._store.deleteDataset(dataset).subscribe({
      next: () => {
        this._store.reloadDatasets(this.pipelineId, null).subscribe();
      },
      error: (err) => {
        const message =
          err?.error?.message ?? err?.error ?? err?.message ?? this._translateService.instant('error.generic');
        this.notify(this._translateService.instant(message), 'error', 4000);
      },
    });
  }

  notify(message: string | undefined, type: string, displayTime: number): void {
    notify(message, type, displayTime);
  }

  onSavedJoin(datasetId: Id) {
    this._store.setJoinWizardVisible(false);
    this._store.reloadDatasets(this.pipelineId, datasetId.id).subscribe(() => {
      this._store.loadDatasetJoins(this.pipelineId).subscribe();
    });
  }

  onSavedUnion(datasetId: Id) {
    this._store.setUnionWizardVisible(false);
    this._store.reloadDatasets(this.pipelineId, datasetId.id).subscribe(() => {
      this._store.loadDatasetUnions(this.pipelineId).subscribe();
    });
  }

  onSavedAggregation(datasetId: Id) {
    this._store.setAggregationWizardVisible(false);
    this._store.reloadDatasets(this.pipelineId, datasetId.id).subscribe(() => {
      this._store.loadDatasetAggregations(this.pipelineId).subscribe();
    });
    notify(this._translateService.instant('aggregation.created.successfully'), 'success', 4000);
  }

  onSavedSubset(datasetId: Id) {
    this._store.setSubsetWizardVisible(false);
    this._store.reloadDatasets(this.pipelineId, datasetId.id).subscribe(() => {
      this._store.loadDatasetSubsets(this.pipelineId).subscribe();
    });
  }

  onClosedJoin() {
    this._store.setJoinWizardVisible(false);
  }

  onClosedUnion() {
    this._store.setUnionWizardVisible(false);
  }

  onClosedAggregation() {
    this._store.setAggregationWizardVisible(false);
  }

  private restoreViewMode(): void {
    const storedMode = sessionStorage.getItem(this.viewModeStorageKey);
    if (storedMode === 'list' || storedMode === 'flow') {
      this.viewMode = storedMode;
    }
  }

  onClosedSubset() {
    this._store.setSubsetWizardVisible(false);
  }

  editExport(connector: DatasetConnector): void {
    if (
      connector.connector.connectorType === ConnectorType.REST_API ||
      connector.connector.connectorType === ConnectorType.BUSINESS_CENTRAL
    ) {
      this.exportWizardDatasetId = this.findDatasetIdByExportConnector(connector.id);
      this.editingExportId = connector.id;
      this.selectedExportType =
        connector.connector.connectorType === ConnectorType.BUSINESS_CENTRAL
          ? ExportType.BUSINESS_CENTRAL
          : ExportType.REST_API;
      this._store.setExportWizardVisible(true);
      return;
    }
    this.editingExport.set(connector);
    this.editConnectorEntity = connector.connectorEntity;

    const isCloud =
      connector.connector.connectorType === ConnectorType.S3_BUCKET ||
      connector.connector.connectorType === ConnectorType.AZURE_BLOB;
    if (isCloud) {
      const { directoryPath, fileName } = parseCloudConnectorEntity(connector.connectorEntity);
      this.editCloudDirectoryPath.set(directoryPath);
      this.editCloudFileName.set(fileName);
      this.editCloudSelectedItemPath.set(connector.connectorEntity?.trim() || null);
      this.loadEditExportTree(connector);
    }

    this.editExportPopupVisible.set(true);
  }

  deleteExport(connector: DatasetConnector): void {
    const focusedDatasetId = this._store.focusedDataset()?.id ?? null;
    this._screenLockStore.lockScreen();
    this.datasetConnectorService
      .deleteExportDataset(connector.id)
      .pipe(
        switchMap(() => this._store.reloadDatasets(this.pipelineId, focusedDatasetId)),
        finalize(() => this._screenLockStore.unlockScreen()),
        catchError((err) => {
          const message = this.extractErrorMessage(err);
          this.notify(message, 'error', 4000);
          return EMPTY;
        }),
      )
      .subscribe(() => {
        this.notify(this._translateService.instant('dataset.export.deleted.successfully'), 'success', 4000);
      });
  }

  closeEditExport(): void {
    this.editExportPopupVisible.set(false);
    this.editingExport.set(null);
    this.editConnectorEntity = '';
    this.editCloudDirectoryPath.set('');
    this.editCloudFileName.set('');
    this.editCloudSelectedItemPath.set(null);
    this.editCloudTreeNodes.set([]);
    this.isEditCloudTreeLoading.set(false);
  }

  isEditingCloudFileExport(): boolean {
    const connectorType = this.editingExport()?.connector?.connectorType;
    return connectorType === ConnectorType.S3_BUCKET || connectorType === ConnectorType.AZURE_BLOB;
  }

  onEditExportTreeNodeSelected(event: TiaraSuiteTreeSelectionEvent | null): void {
    if (!event) {
      return;
    }
    const item = (event.node?.value ?? event.value) as FileExplorerItem;
    if (event.kind === 'group') {
      // folder selected
      this.editCloudDirectoryPath.set(item.path);
      this.editCloudFileName.set('');
      this.editCloudSelectedItemPath.set(item.path);
    } else {
      // file selected
      const dir = directoryPathFromItemPath(item.path);
      const baseName = fileNameWithoutExtension(item.path);
      this.editCloudDirectoryPath.set(dir);
      this.editCloudFileName.set(baseName);
      this.editCloudSelectedItemPath.set(item.path);
    }
  }

  private loadEditExportTree(connector: DatasetConnector): void {
    const connectorId = connector.connector.id;
    if (!connectorId) {
      return;
    }

    this.editCloudTreeNodes.set([]);
    this.isEditCloudTreeLoading.set(true);

    if (connector.connector.connectorType === ConnectorType.S3_BUCKET) {
      this._s3BucketConnectorService
        .findConnector(connectorId)
        .pipe(takeUntilDestroyed(this._destroyRef))
        .subscribe({
          next: (fullConnector) => {
            this._s3BucketConnectorService
              .connectionPreview(fullConnector)
              .pipe(takeUntilDestroyed(this._destroyRef))
              .subscribe({
                next: (items) => {
                  this.editCloudTreeNodes.set(buildExportCloudFileTreeNodes(items ?? []));
                },
                error: () => {
                  this.editCloudTreeNodes.set([]);
                },
                complete: () => {
                  this.isEditCloudTreeLoading.set(false);
                },
              });
          },
          error: () => {
            this.isEditCloudTreeLoading.set(false);
          },
        });
      return;
    }

    if (connector.connector.connectorType === ConnectorType.AZURE_BLOB) {
      this._azureBlobConnectorService
        .findConnector(connectorId)
        .pipe(takeUntilDestroyed(this._destroyRef))
        .subscribe({
          next: (fullConnector) => {
            this._azureBlobConnectorService
              .connectionPreview(fullConnector)
              .pipe(takeUntilDestroyed(this._destroyRef))
              .subscribe({
                next: (items) => {
                  this.editCloudTreeNodes.set(buildExportCloudFileTreeNodes(items ?? []));
                },
                error: () => {
                  this.editCloudTreeNodes.set([]);
                },
                complete: () => {
                  this.isEditCloudTreeLoading.set(false);
                },
              });
          },
          error: () => {
            this.isEditCloudTreeLoading.set(false);
          },
        });
    }
  }

  getEditExportTypeLabel(): string {
    const connector = this.editingExport();
    const descriptionKey = connector ? this.resolveEditExportTypeDescriptionKey(connector.exportType, connector) : null;
    return descriptionKey ? this._translateService.instant(descriptionKey) : '';
  }

  getEditExportDestinationLabelKey(): string {
    return this.isEditingCloudFileExport() ? 'dataset.export.destination.file' : 'dataset.export.destination.database';
  }

  getEditExportDestinationPlaceholderKey(): string {
    return this.isEditingCloudFileExport()
      ? 'dataset.export.destination.file.placeholder'
      : 'dataset.export.destination.database.placeholder';
  }

  getEditExportPreview(): string {
    const previewBase = this.buildEditExportPreviewBase();
    if (!previewBase) {
      return '';
    }

    return this.formatEditExportPreview(previewBase);
  }

  saveEditExport(): void {
    const connector = this.editingExport();
    if (!this.isValidExportData(connector)) {
      return;
    }

    const connectorEntityToSave = this.isEditingCloudFileExport()
      ? composeCloudConnectorEntity(this.editCloudDirectoryPath(), this.editCloudFileName())
      : this.editConnectorEntity.trim();

    this._screenLockStore.lockScreen();

    this.datasetConnectorService
      .updateExportDataset(connector!.id, connectorEntityToSave)
      .pipe(
        switchMap(() => this._store.reloadDatasets(this.pipelineId, null)),
        finalize(() => this._screenLockStore.unlockScreen()),
        catchError((err) => {
          const message = this.extractErrorMessage(err);
          this.notify(message, 'error', 4000);
          return EMPTY;
        }),
      )
      .subscribe(() => {
        this.closeEditExport();
        this.notify(this._translateService.instant('dataset.export.updated.successfully'), 'success', 4000);
      });
  }

  private isValidExportData(connector: DatasetConnector | null): boolean {
    if (!connector) {
      return false;
    }

    if (this.isEditingCloudFileExport()) {
      const fileName = this.editCloudFileName().trim();
      return !!fileName && this.fileNameNoDotsPattern.test(fileName);
    }

    const connectorEntity = this.editConnectorEntity.trim();
    return !!connectorEntity;
  }

  private buildEditExportPreviewBase(): string {
    if (this.isEditingCloudFileExport()) {
      return this.buildCloudEditExportPreviewBase();
    }

    return this.editConnectorEntity.trim();
  }

  private buildCloudEditExportPreviewBase(): string {
    const fileName = this.editCloudFileName().trim();
    if (!fileName) {
      return '';
    }

    return composeCloudConnectorEntity(this.editCloudDirectoryPath(), fileName);
  }

  private formatEditExportPreview(previewBase: string): string {
    return `${this.replaceEditExportPreviewPlaceholders(previewBase)}${this.resolveEditExportPreviewExtension()}`;
  }

  private replaceEditExportPreviewPlaceholders(preview: string): string {
    return preview.replace(/\$\{now\}/g, '<timestamp>').replace(/\$\{today\}/g, '<date>');
  }

  private resolveEditExportPreviewExtension(): string {
    if (!this.isEditingCloudFileExport()) {
      return '.csv';
    }

    const selectedPath = this.editCloudSelectedItemPath();
    if (selectedPath) {
      return resolveCloudFileType(selectedPath) === ConnectorType.EXCEL ? '.xlsx' : '.csv';
    }

    return '.csv';
  }

  private resolveEditExportTypeDescriptionKey(
    exportType: DatasetExportType | null | undefined,
    connector: DatasetConnector,
  ): string | null {
    if (!exportType) {
      return null;
    }

    const exportTypeKeyByType: Partial<Record<DatasetExportType, string>> = {
      [DatasetExportType.INSERT]: 'insert',
      [DatasetExportType.DROP]: 'drop',
      [DatasetExportType.APPEND]: 'append',
      [DatasetExportType.INSERT_UPDATE]: 'insertUpdate',
      [DatasetExportType.DELETE_INSERT]: 'deleteInsert',
    };
    const exportTypeKey = exportTypeKeyByType[exportType];
    if (!exportTypeKey) {
      return null;
    }
    const exportKindPrefix =
      connector.connector.connectorType === ConnectorType.DATABASE ? 'export.type.option.db' : 'export.type.option.s3';

    return `${exportKindPrefix}.${exportTypeKey}`;
  }

  private extractErrorMessage(err: any): string {
    return (
      err?.error?.errorMessage ??
      err?.error?.message ??
      err?.error ??
      err?.message ??
      this._translateService.instant('error.generic')
    );
  }

  getExportWizardExistingConnectors(): DatasetConnector[] {
    const datasetId = this.exportWizardDatasetId ?? this._store.focusedDataset()?.id ?? null;
    if (!datasetId) {
      return [];
    }
    return this._store.datasets().find((dataset) => dataset.id === datasetId)?.exportDatasetConnectors ?? [];
  }

  private findDatasetIdByExportConnector(exportConnectorId: string): string | null {
    return (
      this._store
        .datasets()
        .find((dataset) => dataset.exportDatasetConnectors?.some((connector) => connector.id === exportConnectorId))
        ?.id ?? null
    );
  }
}
