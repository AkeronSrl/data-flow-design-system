import { Pipeline, PipelineCloneRequest } from '@alkyra/pipeline/models/pipeline.model';
import { Component, input, OnInit, output, ViewChild } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { ValidationCallbackData } from 'devextreme-angular/common';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxPopupModule } from 'devextreme-angular/ui/popup';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxValidationGroupComponent, DxValidationGroupModule } from 'devextreme-angular/ui/validation-group';
import { DxValidatorModule } from 'devextreme-angular/ui/validator';

@Component({
  selector: 'clone-pipeline-popup',
  standalone: true,
  imports: [
    DxButtonModule,
    DxPopupModule,
    DxValidationGroupModule,
    DxTextBoxModule,
    DxTextAreaModule,
    DxValidatorModule,
    TranslateModule,
  ],
  templateUrl: './clone-pipeline-popup.component.html',
  styleUrl: './clone-pipeline-popup.component.scss',
})
export class ClonePipelinePopupComponent implements OnInit {
  @ViewChild('targetGroup', { static: false }) validationGroup: DxValidationGroupComponent | undefined;

  sourcePipeline = input<Pipeline>();
  onClonePipeline = output<PipelineCloneRequest>();
  onClosePopup = output<void>();

  clonePipeline: PipelineCloneRequest = {
    name: '',
    description: '',
  };

  ngOnInit(): void {
    const source = this.sourcePipeline();
    if (!source) {
      return;
    }
    this.clonePipeline = {
      name: `${source.name} copy`.trim(),
      description: source.description,
    };
  }

  clone() {
    if (!this.validationGroup?.instance?.validate().isValid) {
      return;
    }
    this.onClonePipeline.emit({
      name: this.clonePipeline.name.trim(),
      description: this.clonePipeline.description.trim(),
    });
  }

  closePopup() {
    this.onClosePopup.emit();
  }

  validateEmptyField = (e: ValidationCallbackData) => {
    return e.value && e.value.trim() !== '';
  };
}
