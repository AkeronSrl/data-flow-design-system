import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import {
  Pipeline,
  PipelineAuditParams,
  PipelineErrorStoreParams,
  PipelineFormModel,
  PipelineType,
} from '@alkyra/pipeline/models/pipeline.model';
import { Component, input, OnInit, output, ViewChild } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { ValidationCallbackData } from 'devextreme-angular/common';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxFormModule } from 'devextreme-angular/ui/form';
import { DxNumberBoxModule } from 'devextreme-angular/ui/number-box';
import { DxPopupModule } from 'devextreme-angular/ui/popup';
import { DxSwitchModule } from 'devextreme-angular/ui/switch';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxValidationGroupComponent, DxValidationGroupModule } from 'devextreme-angular/ui/validation-group';
import { DxValidatorModule } from 'devextreme-angular/ui/validator';

@Component({
  selector: 'edit-pipeline-popup',
  standalone: true,
  imports: [
    DxButtonModule,
    DxPopupModule,
    DxFormModule,
    TranslateModule,
    DxValidationGroupModule,
    DxTextBoxModule,
    DxTextAreaModule,
    DxValidatorModule,
    DxSwitchModule,
    DxNumberBoxModule,
    TiaraNameDescriptionLabelComponent,
  ],
  templateUrl: './edit-pipeline-popup.component.html',
  styleUrl: './edit-pipeline-popup.component.scss',
})
export class EditPipelinePopupComponent implements OnInit {
  @ViewChild('targetGroup', { static: false }) validationGroup: DxValidationGroupComponent | undefined;

  existingPipeline = input<Pipeline>();
  save = output<Pipeline>();
  close = output<void>();

  pipeline: PipelineFormModel = <PipelineFormModel>{
    description: '',
    name: '',
    dataAuditEnabled: false,
    dataAuditMaxCopies: 1,
    errorStoreEnabled: false,
    maxExecutionsStored: 3,
    retentionDays: 3,
  };

  ngOnInit(): void {
    const existingPipelineInput = this.existingPipeline();
    if (existingPipelineInput) {
      this.pipeline = {
        description: existingPipelineInput.description,
        name: existingPipelineInput.name,
        dataAuditEnabled: this.getAuditEnabled(existingPipelineInput),
        dataAuditMaxCopies: this.getAuditMaxCopies(existingPipelineInput),
        errorStoreEnabled: this.isErrorStoreEnabled(existingPipelineInput),
        maxExecutionsStored: this.getMaxExecutionsStored(existingPipelineInput),
        retentionDays: this.getRetentionDays(existingPipelineInput),
      };
    }
  }

  onAuditEnabledChanged(enabled: boolean) {
    this.pipeline.dataAuditEnabled = enabled;
    if (enabled && !this.pipeline.dataAuditMaxCopies) {
      this.pipeline.dataAuditMaxCopies = 1;
    }
  }

  onAuditCopiesChanged(value: number | null) {
    this.pipeline.dataAuditMaxCopies = this.normalizeAuditCopies(value);
  }

  onErrorStoreEnabledChanged(enabled: boolean) {
    this.pipeline.errorStoreEnabled = enabled;
    if (!enabled) {
      return;
    }

    if (this.isBatchPipeline()) {
      this.pipeline.maxExecutionsStored = this.normalizeEnabledRetentionValue(this.pipeline.maxExecutionsStored);
      return;
    }

    this.pipeline.retentionDays = this.normalizeEnabledRetentionValue(this.pipeline.retentionDays);
  }

  onMaxExecutionsStoredChanged(value: number | null) {
    this.pipeline.maxExecutionsStored = this.normalizeEnabledRetentionValue(value);
  }

  onRetentionDaysChanged(value: number | null) {
    this.pipeline.retentionDays = this.normalizeEnabledRetentionValue(value);
  }

  savePipeline() {
    if (!this.isPipelineFormValid()) {
      return;
    }

    const source = this.existingPipeline();
    const pipelineToSave = this.createPipelineToSave(source);

    this.applyAuditParams(pipelineToSave);
    this.applyErrorStoreRetentionParams(pipelineToSave);

    this.save.emit(pipelineToSave);
  }

  closePopup() {
    this.close.emit();
  }

  isExistingPipeline(): boolean {
    return !!this.existingPipeline()?.id;
  }

  isBatchPipeline(): boolean {
    return this.existingPipeline()?.pipelineType === PipelineType.BATCH;
  }

  isStreamPipeline(): boolean {
    const pipelineType = this.existingPipeline()?.pipelineType;
    return pipelineType === PipelineType.QUEUE || pipelineType === PipelineType.API;
  }

  private getAuditEnabled(pipeline: Pipeline | undefined): boolean {
    return (
      pipeline?.pipelineParams?.find((param) => param.codParametro === PipelineAuditParams.ENABLED)?.valoreBooleano ??
      false
    );
  }

  private getAuditMaxCopies(pipeline: Pipeline | undefined): number {
    const value =
      pipeline?.pipelineParams?.find((param) => param.codParametro === PipelineAuditParams.MAX_COPIES)
        ?.valoreNumerico ?? 1;
    return this.normalizeAuditCopies(value);
  }

  private normalizeAuditCopies(value: number | null | undefined): number {
    const numeric = Number.isFinite(value as number) ? Number(value) : 1;
    return Math.min(10, Math.max(1, Math.round(numeric)));
  }

  private getMaxExecutionsStored(pipeline: Pipeline | undefined): number {
    const rawValue = pipeline?.pipelineParams?.find(
      (param) => param.codParametro === PipelineErrorStoreParams.MAX_EXECUTIONS_STORED,
    )?.valoreNumerico;
    return this.resolveRetentionValue(rawValue);
  }

  private getRetentionDays(pipeline: Pipeline | undefined): number {
    const rawValue = pipeline?.pipelineParams?.find(
      (param) => param.codParametro === PipelineErrorStoreParams.RETENTION_DAYS,
    )?.valoreNumerico;
    return this.resolveRetentionValue(rawValue);
  }

  private isErrorStoreEnabled(pipeline: Pipeline | undefined): boolean {
    const explicitValue = this.getErrorStoreEnabledParam(pipeline);
    if (explicitValue !== null) {
      return explicitValue;
    }

    return !this.isDisabledLegacyRetentionValue(this.getLegacyRetentionValue(pipeline));
  }

  private resolveRetentionValue(value: number | null | undefined): number {
    return this.isDisabledLegacyRetentionValue(value) ? 3 : this.normalizeEnabledRetentionValue(value);
  }

  private getErrorStoreEnabledParam(pipeline: Pipeline | undefined): boolean | null {
    const value = pipeline?.pipelineParams?.find(
      (param) => param.codParametro === PipelineErrorStoreParams.ENABLED,
    )?.valoreBooleano;
    return value === undefined || value === null ? null : value;
  }

  private getLegacyRetentionValue(pipeline: Pipeline | undefined): number | undefined {
    const paramCode = this.isBatchPipelineType(pipeline)
      ? PipelineErrorStoreParams.MAX_EXECUTIONS_STORED
      : PipelineErrorStoreParams.RETENTION_DAYS;
    return pipeline?.pipelineParams?.find((param) => param.codParametro === paramCode)?.valoreNumerico;
  }

  private isDisabledLegacyRetentionValue(value: number | null | undefined): boolean {
    return value != null && value <= 0;
  }

  private normalizeEnabledRetentionValue(value: number | null | undefined): number {
    const numeric = Number.isFinite(value as number) ? Number(value) : 3;
    return Math.max(1, Math.round(numeric));
  }

  private applyAuditParams(pipeline: Pipeline) {
    const params = pipeline.pipelineParams ?? [];
    pipeline.pipelineParams = this.upsertPipelineParam(params, PipelineAuditParams.ENABLED, {
      valoreBooleano: this.pipeline.dataAuditEnabled,
    });
    pipeline.pipelineParams = this.upsertPipelineParam(pipeline.pipelineParams, PipelineAuditParams.MAX_COPIES, {
      valoreNumerico: this.normalizeAuditCopies(this.pipeline.dataAuditMaxCopies),
    });
  }

  private applyErrorStoreRetentionParams(pipeline: Pipeline) {
    pipeline.pipelineParams = this.upsertPipelineParam(pipeline.pipelineParams, PipelineErrorStoreParams.ENABLED, {
      valoreBooleano: this.pipeline.errorStoreEnabled,
    });

    const retentionValue = this.pipeline.errorStoreEnabled ? this.getConfiguredRetentionValue() : 0;

    if (pipeline.pipelineType === PipelineType.BATCH) {
      pipeline.pipelineParams = this.upsertPipelineParam(
        pipeline.pipelineParams,
        PipelineErrorStoreParams.MAX_EXECUTIONS_STORED,
        {
          valoreNumerico: retentionValue,
        },
      );
      return;
    }

    if (pipeline.pipelineType === PipelineType.QUEUE) {
      pipeline.pipelineParams = this.upsertPipelineParam(
        pipeline.pipelineParams,
        PipelineErrorStoreParams.RETENTION_DAYS,
        {
          valoreNumerico: retentionValue,
        },
      );
    }
  }

  private getConfiguredRetentionValue(): number {
    if (this.isBatchPipeline()) {
      return this.normalizeEnabledRetentionValue(this.pipeline.maxExecutionsStored);
    }

    return this.normalizeEnabledRetentionValue(this.pipeline.retentionDays);
  }

  private isBatchPipelineType(pipeline: Pipeline | undefined): boolean {
    return pipeline?.pipelineType === PipelineType.BATCH;
  }

  private upsertPipelineParam(
    params: Pipeline['pipelineParams'],
    codParametro: string,
    values: Partial<Pipeline['pipelineParams'][number]>,
  ) {
    const existingIndex = params.findIndex((param) => param.codParametro === codParametro);
    if (existingIndex === -1) {
      return [...params, { codParametro, ...values }];
    }
    return params.map((param, index) => (index === existingIndex ? { ...param, ...values } : param));
  }

  validateEmptyField = (e: ValidationCallbackData) => {
    return e.value && e.value.trim() !== '';
  };

  private isPipelineFormValid(): boolean {
    return !!this.validationGroup?.instance?.validate().isValid;
  }

  private createPipelineToSave(source: Pipeline | undefined): Pipeline {
    return {
      id: source?.id || undefined,
      name: this.pipeline.name,
      description: this.pipeline.description,
      workspace: source?.workspace,
      pipelineParams: [...(source?.pipelineParams || [])],
      pipelineType: source?.pipelineType || PipelineType.BATCH,
    };
  }
}
