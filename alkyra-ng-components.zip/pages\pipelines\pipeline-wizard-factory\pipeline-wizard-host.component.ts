import {
  Pipeline,
  PipelineApiUpsertRequest,
  PipelineAuditParams,
  PipelineType,
} from '@alkyra/pipeline/models/pipeline.model';
import { PipelineService } from '@alkyra/pipeline/services/pipeline.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, inject, input, output } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import notify from 'devextreme/ui/notify';

import { PipelineWizardSession } from './models/pipeline-wizard-session.model';
import { ApiCreatePipelineWizardComponent } from './wizards/api-create-pipeline-wizard.component';
import { ApiEditPipelineWizardComponent } from './wizards/api-edit-pipeline-wizard.component';
import { BatchCreatePipelineWizardComponent } from './wizards/batch-create-pipeline-wizard.component';
import { BatchEditPipelineWizardComponent } from './wizards/batch-edit-pipeline-wizard.component';
import { QueueCreatePipelineWizardComponent } from './wizards/queue-create-pipeline-wizard.component';
import { QueueEditPipelineWizardComponent } from './wizards/queue-edit-pipeline-wizard.component';

@Component({
  selector: 'alk-pipeline-wizard-host',
  standalone: true,
  imports: [
    BatchCreatePipelineWizardComponent,
    BatchEditPipelineWizardComponent,
    QueueCreatePipelineWizardComponent,
    QueueEditPipelineWizardComponent,
    ApiCreatePipelineWizardComponent,
    ApiEditPipelineWizardComponent,
  ],
  templateUrl: './pipeline-wizard-host.component.html',
})
export class PipelineWizardHostComponent {
  session = input.required<PipelineWizardSession>();
  saved = output<void>();
  closed = output<void>();

  private readonly _pipelineService = inject(PipelineService);
  private readonly _translateService = inject(TranslateService);
  private readonly saveErrorTranslationsByStatus: Record<number, string> = {
    401: 'pipeline.api.error.401',
    404: 'pipeline.api.error.404',
    409: 'pipeline.api.error.409',
    422: 'pipeline.api.error.422',
  };

  onClose() {
    this.closed.emit();
  }

  onSaveRequested(pipeline: Pipeline) {
    if (pipeline.pipelineType === PipelineType.API) {
      const request = this.mapToApiUpsertRequest(pipeline);
      if (this.session().mode === 'edit') {
        this._pipelineService.updateApiPipeline(pipeline.id!, request).subscribe({
          next: () => {
            this.saved.emit();
          },
          error: (error: HttpErrorResponse) => {
            notify(this.resolveSaveErrorMessage(error), 'error', 5000);
          },
        });
        return;
      }

      this._pipelineService.addApiPipeline(request).subscribe({
        next: () => {
          this.saved.emit();
        },
        error: (error: HttpErrorResponse) => {
          notify(this.resolveSaveErrorMessage(error), 'error', 5000);
        },
      });
      return;
    }

    const mode = this.session().mode;
    if (mode === 'edit') {
      this._pipelineService.updatePipeline(pipeline).subscribe({
        next: () => {
          this.saved.emit();
        },
        error: (error: HttpErrorResponse) => {
          notify(this.resolveSaveErrorMessage(error), 'error', 5000);
        },
      });
      return;
    }

    this._pipelineService.addPipeline(pipeline).subscribe({
      next: () => {
        this.saved.emit();
      },
      error: (error: HttpErrorResponse) => {
        notify(this.resolveSaveErrorMessage(error), 'error', 5000);
      },
    });
  }

  private mapToApiUpsertRequest(pipeline: Pipeline): PipelineApiUpsertRequest {
    const request: PipelineApiUpsertRequest = {
      name: pipeline.name,
      description: pipeline.description,
      workspaceId: pipeline.workspace?.id ?? '',
      ingestPath: pipeline.apiConfig?.ingestPath ?? '',
      isActive: !!pipeline.apiConfig?.isActive,
      errorStoreEnabled: pipeline.apiConfig?.errorStoreEnabled,
      retentionDays: pipeline.apiConfig?.retentionDays,
      jsonSchema: pipeline.apiConfig?.jsonSchema ?? '',
      jsonSample: pipeline.apiConfig?.jsonSample ?? null,
    };

    if (pipeline.id) {
      request.dataAuditEnabled = this.getBooleanParam(pipeline, PipelineAuditParams.ENABLED, false);
      request.dataAuditMaxCopies = this.getNumericParam(pipeline, PipelineAuditParams.MAX_COPIES, 1);
    }

    return request;
  }

  private getBooleanParam(pipeline: Pipeline, codParametro: string, fallback: boolean): boolean {
    return pipeline.pipelineParams?.find((param) => param.codParametro === codParametro)?.valoreBooleano ?? fallback;
  }

  private getNumericParam(pipeline: Pipeline, codParametro: string, fallback: number): number {
    return pipeline.pipelineParams?.find((param) => param.codParametro === codParametro)?.valoreNumerico ?? fallback;
  }

  private resolveSaveErrorMessage(error: HttpErrorResponse): string {
    const translationKey = this.saveErrorTranslationsByStatus[error.status];
    if (translationKey) {
      return this._translateService.instant(translationKey);
    }
    return this.resolveFallbackSaveErrorMessage(error);
  }

  private resolveFallbackSaveErrorMessage(error: HttpErrorResponse): string {
    const backendMessage = this.extractBackendErrorMessage(error);
    return backendMessage || error.message || this._translateService.instant('error.generic');
  }

  private extractBackendErrorMessage(error: HttpErrorResponse): string {
    if (typeof error?.error === 'string') {
      return error.error;
    }
    return error?.error?.errorMessage ?? error?.error?.message ?? '';
  }
}
