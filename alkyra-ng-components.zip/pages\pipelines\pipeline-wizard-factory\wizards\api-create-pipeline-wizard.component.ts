import { PipelineApiWizardComponent } from '@alkyra/pipeline/components/pipeline-api-wizard/pipeline-api-wizard.component';
import { Pipeline, PipelineApiParams, PipelineType } from '@alkyra/pipeline/models/pipeline.model';
import { Component, computed, input, output } from '@angular/core';

import { PipelineWizardSession } from '../models/pipeline-wizard-session.model';

@Component({
  selector: 'alk-api-create-pipeline-wizard',
  standalone: true,
  imports: [PipelineApiWizardComponent],
  template: `
    <alk-pipeline-api-wizard [pipeline]="pipeline()" (onSave)="save.emit($event)" (onClose)="close.emit()">
    </alk-pipeline-api-wizard>
  `,
})
export class ApiCreatePipelineWizardComponent {
  context = input.required<PipelineWizardSession>();
  save = output<Pipeline>();
  close = output<void>();

  readonly pipeline = computed<Pipeline>(() => ({
    id: undefined,
    name: '',
    description: '',
    workspace: this.context().workspace,
    pipelineType: PipelineType.API,
    pipelineParams: [{ codParametro: PipelineApiParams.IS_ACTIVE, valoreBooleano: false }],
  }));
}
