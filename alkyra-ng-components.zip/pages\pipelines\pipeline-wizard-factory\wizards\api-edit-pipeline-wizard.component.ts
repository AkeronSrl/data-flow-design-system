import { PipelineApiWizardComponent } from '@alkyra/pipeline/components/pipeline-api-wizard/pipeline-api-wizard.component';
import { Pipeline } from '@alkyra/pipeline/models/pipeline.model';
import { Component, computed, input, output } from '@angular/core';

import { PipelineWizardSession } from '../models/pipeline-wizard-session.model';

@Component({
  selector: 'alk-api-edit-pipeline-wizard',
  standalone: true,
  imports: [PipelineApiWizardComponent],
  template: `
    <alk-pipeline-api-wizard [pipeline]="pipeline()" (onSave)="save.emit($event)" (onClose)="close.emit()">
    </alk-pipeline-api-wizard>
  `,
})
export class ApiEditPipelineWizardComponent {
  context = input.required<PipelineWizardSession>();
  save = output<Pipeline>();
  close = output<void>();

  readonly pipeline = computed<Pipeline>(() => this.context().existingPipeline!);
}
