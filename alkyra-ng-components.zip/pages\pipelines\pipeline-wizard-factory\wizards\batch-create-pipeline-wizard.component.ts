import { Pipeline, PipelineType } from '@alkyra/pipeline/models/pipeline.model';
import { Component, computed, input, output } from '@angular/core';

import { EditPipelinePopupComponent } from '../../edit-pipeline-popup/edit-pipeline-popup.component';
import { PipelineWizardSession } from '../models/pipeline-wizard-session.model';

@Component({
  selector: 'alk-batch-create-pipeline-wizard',
  standalone: true,
  imports: [EditPipelinePopupComponent],
  template: `
    <edit-pipeline-popup [existingPipeline]="pipeline()" (save)="save.emit($event)" (close)="close.emit()"></edit-pipeline-popup>
  `,
})
export class BatchCreatePipelineWizardComponent {
  context = input.required<PipelineWizardSession>();
  save = output<Pipeline>();
  close = output<void>();

  readonly pipeline = computed<Pipeline>(() => ({
    id: undefined,
    name: '',
    description: '',
    workspace: this.context().workspace,
    pipelineType: PipelineType.BATCH,
    pipelineParams: [],
  }));
}
