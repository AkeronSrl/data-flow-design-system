import { PipelineQueueWizardComponent } from '@alkyra/pipeline/components/pipeline-queue-wizard/pipeline-queue-wizard.component';
import { Pipeline } from '@alkyra/pipeline/models/pipeline.model';
import { Component, input, output } from '@angular/core';

import { PipelineWizardSession } from '../models/pipeline-wizard-session.model';

@Component({
  selector: 'alk-queue-create-pipeline-wizard',
  standalone: true,
  imports: [PipelineQueueWizardComponent],
  template: `
    <alk-pipeline-queue-wizard
      [workspace]="context().workspace"
      (onSave)="save.emit($event)"
      (onClose)="close.emit()"></alk-pipeline-queue-wizard>
  `,
})
export class QueueCreatePipelineWizardComponent {
  context = input.required<PipelineWizardSession>();
  save = output<Pipeline>();
  close = output<void>();
}
