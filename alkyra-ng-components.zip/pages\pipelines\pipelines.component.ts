import {
  TiaraCircularIllustrationComponent,
  TiaraListComponent,
  TiaraListItemComponent,
  TiaraListItemSectionComponent,
} from '@akeron-ng/tiara-ng';
import { TiaraIconContainerComponent } from '@akeron-ng/tiara-ng/tiara-icon-container';
import { TiaraNavBarUiComponent } from '@akeron-ng/tiara-ng/tiara-nav-bar-ui';
import { PipelineService } from '@alkyra/pipeline/services/pipeline.service';
import { PipelineCloneService } from '@alkyra/pipeline/services/pipeline-clone.service';
import { ScreenLockStore } from '@alkyra/screen-lock/+store/screen-lock.store';
import { Workspace } from '@alkyra/workspace/models/workspace.model';
import { WorkspaceService } from '@alkyra/workspace/services/workspace.service';
import { CommonModule } from '@angular/common';
import { Component, computed, inject, OnInit, signal } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { alert, confirm } from 'devextreme/ui/dialog';
import notify from 'devextreme/ui/notify';
import { ValueChangedEvent } from 'devextreme/ui/text_box';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxDropDownButtonModule } from 'devextreme-angular/ui/drop-down-button';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxSwitchModule } from 'devextreme-angular/ui/switch';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxTooltipModule } from 'devextreme-angular/ui/tooltip';
import { finalize, Observable, switchMap } from 'rxjs';

import { PipelineAuditStatusComponent } from '../../pipeline/components/pipeline-audit-status/pipeline-audit-status.component';
import {
  Pipeline,
  PipelineAuditParams,
  PipelineCloneRequest,
  PipelineListItem,
  PipelineQueueParams,
  PipelineType,
} from '../../pipeline/models/pipeline.model';
import { PipelinesStore } from './+store/pipelines.store';
import { ClonePipelinePopupComponent } from './clone-pipeline-popup/clone-pipeline-popup.component';
import { PipelineWizardSession } from './pipeline-wizard-factory/models/pipeline-wizard-session.model';
import { PipelineWizardHostComponent } from './pipeline-wizard-factory/pipeline-wizard-host.component';

@Component({
  selector: 'alk-pipelines',
  standalone: true,
  imports: [
    CommonModule,
    DxButtonModule,
    DxTextBoxModule,
    TranslatePipe,
    TiaraListComponent,
    TiaraListItemComponent,
    TiaraListItemSectionComponent,
    ClonePipelinePopupComponent,
    TiaraCircularIllustrationComponent,
    TiaraNavBarUiComponent,
    DxScrollViewModule,
    TiaraIconContainerComponent,
    DxDropDownButtonModule,
    DxSwitchModule,
    DxTooltipModule,
    PipelineAuditStatusComponent,
    PipelineWizardHostComponent,
  ],
  templateUrl: './pipelines.component.html',
  styleUrl: './pipelines.component.scss',
})
export class PipelinesComponent implements OnInit {
  private readonly _workspaceService = inject(WorkspaceService);
  private readonly _pipelineService = inject(PipelineService);
  private readonly _pipelineCloneService = inject(PipelineCloneService);
  private readonly _translateService: TranslateService = inject(TranslateService);
  private readonly _screenLockStore = inject(ScreenLockStore);
  private readonly _router = inject(Router);

  searchValue = signal<string>('');
  hasSearch = computed(() => {
    const val = this.searchValue();
    if (val && val !== '') {
      return true;
    }
    return false;
  });
  hasPipelines = computed(() => this._store.pipelineListItems().length > 0);

  _store = inject(PipelinesStore);
  _activatedRoute: ActivatedRoute = inject(ActivatedRoute);
  _wizardSession = signal<PipelineWizardSession | null>(null);
  _pipelineToClone: Pipeline | undefined = undefined;

  workspaceId!: string;
  workspace!: Workspace;
  private readonly _confirmSaveTitle = this._translateService.instant('pipeline.queue.confirm.save');
  private readonly _connectionUsedMessage = this._translateService.instant('pipeline.queue.connection.already.used');

  showTooltip = false;
  pipelineTypes = [
    { type: PipelineType.BATCH, text: this._translateService.instant('pipeline.batch'), icon: 'fa-regular fa-server' },
    {
      type: PipelineType.QUEUE,
      text: this._translateService.instant('pipeline.queue'),
      icon: 'fa-regular fa-inbox-in',
    },
    {
      type: PipelineType.API,
      text: this._translateService.instant('pipeline.api'),
      icon: 'fa-regular fa-code',
    },
  ];
  showAddPipelineButtons = false;

  listButtons = [
    {
      icon: 'trash',
      onClick: (pipeline: Pipeline) => this.deletePipeline(pipeline),
    },
    {
      icon: 'edit',
      onClick: (pipeline: Pipeline) => {
        this._router.navigate(['workspaces', this.workspaceId, 'pipelines', pipeline.id]);
      },
    },
  ];

  ngOnInit(): void {
    this.workspaceId = this._activatedRoute.snapshot.paramMap.get('id')!;
    this._workspaceService.findWorkspaceById(this.workspaceId).subscribe((workspace) => {
      this.workspace = workspace;
    });
    this._store.reloadPipelines(this.workspaceId);
  }

  openPipeline(pipelineListItem: PipelineListItem) {
    this.showTooltip = false;
    if (this.shouldShowOpenBlockedTooltip(pipelineListItem)) {
      this.showTooltip = true;
      return;
    }
    this._router.navigate(['workspaces', this.workspaceId, 'pipelines', pipelineListItem.id]);
  }

  private shouldShowOpenBlockedTooltip(pipelineListItem: PipelineListItem): boolean {
    return pipelineListItem.isActive && this.isRealtimePipeline(pipelineListItem);
  }

  private isRealtimePipeline(pipelineListItem: PipelineListItem): boolean {
    return pipelineListItem.isQueue || !!pipelineListItem.isApi;
  }

  openDataAudit(pipelineListItem: PipelineListItem) {
    if (!pipelineListItem.id || !this.isAuditEnabled(pipelineListItem)) {
      return;
    }
    this._router.navigate(['/logs/data-audit', pipelineListItem.id], {
      queryParams: { source: 'pipeline', workspaceId: this.workspaceId },
    });
  }

  getPipelineTypeTranslated(type: PipelineType): string {
    return this.pipelineTypes.find((t) => t.type === type)?.text || '';
  }

  getPipelineTypeIcon(type: PipelineType): string {
    switch (type) {
      case PipelineType.BATCH:
        return 'fa-regular fa-server';
      case PipelineType.QUEUE:
        return 'fa-regular fa-inbox-in';
      case PipelineType.API:
        return 'fa-regular fa-code';
      default:
        return 'fa-regular fa-server';
    }
  }

  isAuditEnabled(pipelineListItem: PipelineListItem): boolean {
    return (
      pipelineListItem.pipeline.pipelineParams?.find((param) => param.codParametro === PipelineAuditParams.ENABLED)
        ?.valoreBooleano ?? false
    );
  }

  getAuditMaxCopies(pipelineListItem: PipelineListItem): number {
    return (
      pipelineListItem.pipeline.pipelineParams?.find((param) => param.codParametro === PipelineAuditParams.MAX_COPIES)
        ?.valoreNumerico ?? 1
    );
  }

  addPipeline() {
    this.showAddPipelineButtons = !this.showAddPipelineButtons;
  }

  createPipeline(pipelineType: PipelineType) {
    this.showAddPipelineButtons = false;
    const workspace = this.workspace ?? {
      id: this.workspaceId,
      name: 'Workspace',
      description: 'Workspace',
      icon: 'default-icon',
    };
    this._wizardSession.set({
      mode: 'create',
      pipelineType,
      workspace,
    });
  }

  togglePipelineActive(pipelineListItem: PipelineListItem, event: any) {
    // Evita che il reload scateni un nuovo onValueChanged
    if (event.event === undefined) {
      return;
    }

    if (event.value) {
      this._pipelineService.activatePipeline(pipelineListItem.id!).subscribe({
        next: (validationResult) => {
          if (validationResult.status == 'error') {
            pipelineListItem.isActive = false;
            const title: string = this._translateService.instant('error.generic');
            alert(validationResult.message, title).then(() => {
              this._store.reloadPipelines(this.workspaceId);
            });
          } else {
            this.notify('pipeline.activated.successfully', 'success', 4000);
            this._store.reloadPipelines(this.workspaceId);
          }
        },
        error: (_) => {
          pipelineListItem.isActive = false;
          this.notify('pipeline.activation.failed', 'error', 4000);
          this._store.reloadPipelines(this.workspaceId);
        },
      });
    } else {
      this._pipelineService.deactivatePipeline(pipelineListItem.id!).subscribe({
        next: () => {
          this.notify('pipeline.deactivated.successfully', 'success', 4000);
          this._store.reloadPipelines(this.workspaceId);
        },
        error: (_) => {
          pipelineListItem.isActive = true;
          this.notify('pipeline.deactivation.failed', 'error', 4000);
          this._store.reloadPipelines(this.workspaceId);
        },
      });
    }
  }

  onSavedPipeline() {
    this.closePipelineWizard();
    this._store.reloadPipelines(this.workspaceId);
    this.notify('pipeline.saved.successfully', 'success', 4000);
  }

  executePipeline(pipelineListItem: PipelineListItem) {
    if (!pipelineListItem.id) {
      this.notify('pipeline.id.not.available', 'error', 4000);
      return;
    }
    this._screenLockStore.setAutoUnlock(false);
    this._pipelineService.executePipelineAsync(pipelineListItem.id).subscribe({
      complete: () => {
        this._screenLockStore.unlockScreen();
        this.notify('export.started.successfully', 'success', 4000);
      },
    });
  }

  runClonePipelineWithLoading<T>(cloneRequest$: Observable<T>, onSuccess: () => void) {
    this._screenLockStore.lockScreen();
    cloneRequest$
      .pipe(
        switchMap(() => this._store.reloadPipelines$(this.workspaceId)),
        finalize(() => this._screenLockStore.unlockScreen()),
      )
      .subscribe({
        next: () => {
          onSuccess();
        },
        error: () => {
          // Error handling is managed globally by existing interceptors/dialogs.
        },
      });
  }

  clonePipeline(pipelineListItem: PipelineListItem) {
    if (!pipelineListItem.id) {
      this.notify('pipeline.id.not.available', 'error', 4000);
      return;
    }

    if (!pipelineListItem.isQueue) {
      this.openClonePipelinePopup(pipelineListItem.pipeline);
      return;
    }

    const connectionId =
      pipelineListItem.pipeline.pipelineParams?.find(
        (param) => param.codParametro === PipelineQueueParams.CONNECTION_ID,
      )?.valoreStringa || '';
    this._pipelineService.isConnectionUsedInPipelines(connectionId).subscribe({
      next: (used) => {
        if (used) {
          const result = confirm(this._connectionUsedMessage, this._confirmSaveTitle);
          result.then((dialogResult) => {
            if (dialogResult) {
              this.openClonePipelinePopup(pipelineListItem.pipeline);
            }
          });
          return;
        }
        this.openClonePipelinePopup(pipelineListItem.pipeline);
      },
      error: () => {
        this.openClonePipelinePopup(pipelineListItem.pipeline);
      },
    });
  }

  onClonePipeline(cloneRequest: PipelineCloneRequest) {
    if (!this._pipelineToClone?.id) {
      this.notify('pipeline.id.not.available', 'error', 4000);
      return;
    }
    this.runClonePipelineWithLoading(
      this._pipelineCloneService.clonePipeline({ pipelineId: this._pipelineToClone.id, cloneRequest }),
      () => {
        this.closeClonePipelinePopup();
        this.notify('pipeline.cloned.successfully', 'success', 4000);
      },
    );
  }

  deletePipeline(pipeline: Pipeline) {
    const result = confirm(
      this._translateService.instant('pipeline.delete.confirmation'),
      this._translateService.instant('pipeline.delete'),
    );
    result.then((dialogResult) => {
      if (dialogResult) {
        this._pipelineService.deletePipeline(pipeline.id!).subscribe({
          next: () => {
            this._store.reloadPipelines(pipeline.workspace?.id || '');
            this.notify('pipeline.deleted.successfully', 'success', 4000);
          },
          error: () => {
            this.notify('pipeline.deletion.failed', 'error', 4000);
          },
        });
      }
    });
  }

  copyPipelineId(pipelineListItem: PipelineListItem) {
    if (!pipelineListItem.id) {
      this.notify('pipeline.id.not.available', 'error', 4000);
      return;
    }
    navigator.clipboard
      .writeText(pipelineListItem.id)
      .then(() => {
        this.notify('pipeline.id.copied', 'success', 4000);
      })
      .catch(() => {
        this.notify('pipeline.id.copy.failed', 'error', 4000);
      });
  }

  notify(message: string, type: string, displayTime: number): void {
    notify(this._translateService.instant(message), type, displayTime);
  }

  onBackClick() {
    this._router.navigate(['/workspaces']);
  }

  openEditPipelineWizard(pipeline: Pipeline) {
    const workspace =
      this.workspace ??
      pipeline.workspace ??
      ({ id: this.workspaceId, name: 'Workspace', description: 'Workspace', icon: 'default-icon' } as Workspace);
    this._wizardSession.set({
      mode: 'edit',
      pipelineType: pipeline.pipelineType,
      workspace,
      existingPipeline: pipeline,
    });
  }

  closePipelineWizard() {
    this._wizardSession.set(null);
  }

  openClonePipelinePopup(pipeline: Pipeline) {
    this._pipelineToClone = pipeline;
    this._store.setClonePipelinePopupVisible(true);
  }

  closeClonePipelinePopup() {
    this._pipelineToClone = undefined;
    this._store.setClonePipelinePopupVisible(false);
  }

  searchValueChanged(e: ValueChangedEvent) {
    this.searchValue.set(e.value || '');
    this._store.findPipelinesByNameOrDescription(this.workspaceId, this.searchValue());
  }
}
