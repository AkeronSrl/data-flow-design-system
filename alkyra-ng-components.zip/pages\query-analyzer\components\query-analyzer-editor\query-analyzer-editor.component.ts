import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { DBMSType } from '@alkyra/connector/models/dbms-type.model';
import { ExpressionEditorConfig } from '@alkyra/ui/smart-expression-editor/models/expression-editor.model';
import { SmartExpressionEditorComponent } from '@alkyra/ui/smart-expression-editor/smart-expression-editor.component';
import { dbmsTypeToExpressionDialect } from '@alkyra/ui/smart-expression-editor/utils/expression-dialect.util';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { DxButtonModule } from 'devextreme-angular/ui/button';

import { QueryAnalyzerStore } from '../../+store/query-analyzer.store';

@Component({
  selector: 'alk-query-analyzer-editor',
  standalone: true,
  imports: [CommonModule, TranslatePipe, DxButtonModule, SmartExpressionEditorComponent],
  templateUrl: './query-analyzer-editor.component.html',
  styleUrl: './query-analyzer-editor.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class QueryAnalyzerEditorComponent {
  protected readonly _store = inject(QueryAnalyzerStore);
  private readonly _translateService = inject(TranslateService);
  protected readonly editorConfig = computed<ExpressionEditorConfig>(() => {
    const activeConnection = this._store.activeConnection();
    const dbmsType =
      activeConnection && 'dbmsType' in activeConnection
        ? (activeConnection.dbmsType as DBMSType | undefined)
        : undefined;
    return {
      dialect:
        activeConnection?.connectorType === ConnectorType.SALESFORCE ? 'soql' : dbmsTypeToExpressionDialect(dbmsType),
      warnOnUnknownFunctions: true,
      maxSuggestions: 25,
    };
  });
  protected readonly editorPlaceholder = computed(() =>
    this._store.isSalesforceContext()
      ? this._translateService.instant('query.analyzer.editor.placeholder.salesforce')
      : this._translateService.instant('query.analyzer.editor.placeholder'),
  );

  protected renameSelectedQuery(): void {
    const query = this._store.selectedQuery();
    if (!query) {
      return;
    }
    this._store.openEditPopup(query);
  }

  protected deleteSelectedQuery(): void {
    const query = this._store.selectedQuery();
    if (!query) {
      return;
    }
    this._store.deleteQuery(query);
  }
}
