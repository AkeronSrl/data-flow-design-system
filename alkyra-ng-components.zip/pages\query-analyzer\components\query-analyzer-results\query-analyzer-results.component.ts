import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';

import { QueryAnalyzerStore } from '../../+store/query-analyzer.store';

@Component({
  selector: 'alk-query-analyzer-results',
  standalone: true,
  imports: [CommonModule, TranslatePipe, DxDataGridModule, TiaraCircularIllustrationComponent],
  templateUrl: './query-analyzer-results.component.html',
  styleUrl: './query-analyzer-results.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class QueryAnalyzerResultsComponent {
  protected readonly _store = inject(QueryAnalyzerStore);
}
