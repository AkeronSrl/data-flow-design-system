import { TiaraCircularIllustrationComponent, TiaraDecoratedCardComponent } from '@akeron-ng/tiara-ng';
import { SavedQuery } from '@alkyra/query-analyzer/models/saved-query.model';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxButtonModule, DxButtonTypes } from 'devextreme-angular/ui/button';

import { QueryAnalyzerStore } from '../../+store/query-analyzer.store';

@Component({
  selector: 'alk-query-analyzer-saved-list',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    DxButtonModule,
    TiaraCircularIllustrationComponent,
    TiaraDecoratedCardComponent,
  ],
  templateUrl: './query-analyzer-saved-list.component.html',
  styleUrl: './query-analyzer-saved-list.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class QueryAnalyzerSavedListComponent {
  protected readonly _store = inject(QueryAnalyzerStore);

  protected onEditClick(event: DxButtonTypes.ClickEvent, query: SavedQuery): void {
    event.event?.stopPropagation();
    this._store.openEditPopup(query);
  }

  protected onDeleteClick(event: DxButtonTypes.ClickEvent, query: SavedQuery): void {
    event.event?.stopPropagation();
    this._store.deleteQuery(query);
  }
}
