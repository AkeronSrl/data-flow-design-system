import { ConnectorMetadataColumn } from '@alkyra/connector/models/connector-metadata-column.model';
import { DatabaseSourceMetadata } from '@alkyra/database-connector/models/database-source-metadata.model';
import { DatabaseConnectorService } from '@alkyra/database-connector/services/database-connector.service';
import { SavedQuery } from '@alkyra/query-analyzer/models/saved-query.model';
import { SalesforceObject } from '@alkyra/salesforce-connector/models/salesforce-object.model';
import { SalesforceConnectorService } from '@alkyra/salesforce-connector/services/salesforce-connector.service';
import { ScreenLockStore } from '@alkyra/screen-lock/+store/screen-lock.store';
import {
  SchemaDiscoveryExpandEvent,
  SchemaDiscoveryNode,
  SchemaDiscoverySelectionEvent,
} from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, inject, input, signal } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { catchError, map, of, Subscription } from 'rxjs';

import { QueryAnalyzerStore } from '../../+store/query-analyzer.store';
import {
  getSavedQueryNodeId,
  mapQueryAnalyzerDatabaseSchemaDiscoveryNodes,
  mapQueryAnalyzerSalesforceSchemaDiscoveryNodes,
  QueryAnalyzerDatabaseSchemaState,
  QueryAnalyzerSalesforceSchemaState,
} from './query-analyzer-schema-discovery.mapper';

@Component({
  selector: 'alk-query-analyzer-schema-browser',
  standalone: true,
  imports: [CommonModule, SchemaDiscoveryComponent],
  templateUrl: './query-analyzer-schema-browser.component.html',
  styleUrl: './query-analyzer-schema-browser.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class QueryAnalyzerSchemaBrowserComponent {
  readonly connectionId = input<string | null>(null);

  protected readonly isLoading = signal(false);
  protected readonly hasError = signal(false);
  protected readonly selectedNodeId = computed(() => this.selectedTreeNodeId());
  protected readonly schemaError = computed(() =>
    this.hasError() ? this.translateService.instant('query.analyzer.schema.error') : null,
  );
  protected readonly labels = computed(() => ({
    tables: this.translateService.instant('query.analyzer.schema.tables'),
    views: this.translateService.instant('query.analyzer.schema.views'),
    objects: this.translateService.instant('query.analyzer.schema.objects'),
    savedQueries: this.translateService.instant('query.analyzer.saved.section.title'),
    objectLoading: this.translateService.instant('query.analyzer.schema.object.loading'),
    objectError: this.translateService.instant('query.analyzer.schema.object.error'),
    objectEmpty: this.translateService.instant('query.analyzer.schema.object.empty'),
  }));
  protected readonly schemaNodes = computed<SchemaDiscoveryNode[]>(() => {
    const labels = this.labels();

    if (this.queryAnalyzerStore.isSalesforceContext()) {
      return mapQueryAnalyzerSalesforceSchemaDiscoveryNodes(
        this.getSalesforceStates(),
        this.queryAnalyzerStore.savedQueries(),
        labels,
      );
    }

    return mapQueryAnalyzerDatabaseSchemaDiscoveryNodes(
      this.databaseMetadataNodes(),
      this.queryAnalyzerStore.savedQueries(),
      labels,
    );
  });

  private readonly databaseConnectorService = inject(DatabaseConnectorService);
  private readonly salesforceConnectorService = inject(SalesforceConnectorService);
  private readonly queryAnalyzerStore = inject(QueryAnalyzerStore);
  private readonly screenLockStore = inject(ScreenLockStore);
  private readonly translateService = inject(TranslateService);
  private readonly databaseMetadataNodes = signal<QueryAnalyzerDatabaseSchemaState[]>([]);
  private readonly salesforceNodeStates = signal<Record<string, QueryAnalyzerSalesforceSchemaState>>({});
  private readonly selectedTreeNodeId = signal<string | null>(null);
  private readonly salesforceDescribeRequests = new Map<string, Subscription>();

  constructor() {
    this.syncSelectedQueryNode();
    this.loadSchemaOnConnectionChange();
  }

  protected onNodeSelected(selection: SchemaDiscoverySelectionEvent): void {
    this.selectedTreeNodeId.set(selection.nodeId);

    if (this.isSavedQuerySelection(selection)) {
      this.queryAnalyzerStore.selectSavedQuery(selection.node.data);
      return;
    }

    if (this.isSalesforceObjectSelection(selection)) {
      this.ensureSalesforceObjectLoaded(selection.node.data);
    }
  }

  protected onNodeExpanded(event: SchemaDiscoveryExpandEvent): void {
    const resource = event.node.data;
    if (this.isSalesforceObject(resource)) {
      this.setSalesforceNodeExpanded(resource, true);
      this.ensureSalesforceObjectLoaded(resource);
      return;
    }

    if (!this.isDatabaseMetadata(resource)) {
      return;
    }

    this.expandDatabaseNode(resource);
  }

  protected onNodeCollapsed(event: SchemaDiscoveryExpandEvent): void {
    const resource = event.node.data;
    if (this.isSalesforceObject(resource)) {
      this.setSalesforceNodeExpanded(resource, false);
      return;
    }

    if (!this.isDatabaseMetadata(resource)) {
      return;
    }

    this.updateDatabaseMetadataState(resource.tableName, {
      expanded: false,
    });
  }

  private setSalesforceNodeExpanded(resource: SalesforceObject, expanded: boolean): void {
    const currentState = this.salesforceNodeStates()[resource.name];
    if (!currentState) {
      return;
    }

    this.updateSalesforceNodeState({
      ...currentState,
      expanded,
    });
  }

  private expandDatabaseNode(resource: DatabaseSourceMetadata): void {
    const connectionId = this.connectionId();
    const currentState = this.getDatabaseMetadataState(resource.tableName);
    if (!connectionId || !currentState) {
      return;
    }

    this.updateDatabaseMetadataState(resource.tableName, {
      expanded: true,
    });

    if (currentState.columnsLoading || currentState.columnsLoaded) {
      return;
    }

    this.loadDatabaseColumns(connectionId, resource.tableName);
  }

  private loadDatabaseColumns(connectionId: string, tableName: string): void {
    this.updateDatabaseMetadataState(tableName, {
      expanded: true,
      columnsLoading: true,
    });

    this.databaseConnectorService
      .columns(connectionId, tableName)
      .pipe(catchError(() => of([] as ConnectorMetadataColumn[])))
      .subscribe((columns) => {
        if (!this.getDatabaseMetadataState(tableName)) {
          return;
        }

        this.updateDatabaseMetadataState(tableName, {
          columns,
          columnsLoaded: true,
          columnsLoading: false,
          expanded: true,
        });
      });
  }

  private getSalesforceStates(): QueryAnalyzerSalesforceSchemaState[] {
    return Object.values(this.salesforceNodeStates()).sort((left, right) =>
      left.resource.name.localeCompare(right.resource.name),
    );
  }

  private syncSelectedQueryNode(): void {
    effect(() => {
      const selectedQuery = this.queryAnalyzerStore.selectedQuery();
      this.selectedTreeNodeId.set(selectedQuery ? getSavedQueryNodeId(selectedQuery) : null);
    });
  }

  private loadSchemaOnConnectionChange(): void {
    effect((onCleanup) => {
      const activeConnectionId = this.connectionId();

      if (!activeConnectionId) {
        this.resetSchemaState();
        return;
      }

      if (this.queryAnalyzerStore.isSalesforceContext()) {
        const subscription = this.loadSalesforceObjects(activeConnectionId);
        onCleanup(() => {
          subscription.unsubscribe();
          this.cleanupSalesforceDescribeRequests();
          this.screenLockStore.unlockScreen();
        });
        return;
      }

      this.startSchemaLoading();

      const metadataSubscription = this.buildDatabaseMetadataRequest(activeConnectionId).subscribe((nodes) => {
        if (!nodes) {
          return;
        }

        this.completeDatabaseLoading(nodes);
      });

      onCleanup(() => {
        metadataSubscription.unsubscribe();
        this.screenLockStore.unlockScreen();
      });
    });
  }

  private loadSalesforceObjects(connectionId: string): Subscription {
    this.startSchemaLoading();
    return this.salesforceConnectorService
      .getObjects(connectionId, true)
      .pipe(
        map((objects) => [...objects].sort((left, right) => left.name.localeCompare(right.name))),
        catchError(() => {
          this.handleInitialSchemaLoadingError();
          return of([] as SalesforceObject[]);
        }),
      )
      .subscribe((objects) => {
        if (this.hasError()) {
          return;
        }

        this.salesforceNodeStates.set(
          Object.fromEntries(
            objects.map((resource) => [
              resource.name,
              {
                resource,
                status: 'idle' as const,
                columns: [],
                expanded: false,
              },
            ]),
          ),
        );
        this.completeInitialLoading();
      });
  }

  private ensureSalesforceObjectLoaded(resource: SalesforceObject): void {
    const connectionId = this.connectionId();
    if (!connectionId) {
      return;
    }

    const currentState = this.salesforceNodeStates()[resource.name];
    if (!this.canLoadSalesforceObject(currentState)) {
      return;
    }

    this.updateSalesforceNodeState({
      ...currentState,
      status: 'loading',
      expanded: true,
    });

    this.salesforceDescribeRequests.get(resource.name)?.unsubscribe();
    const request = this.salesforceConnectorService
      .columns(connectionId, resource.name, true)
      .pipe(catchError(() => of(null)))
      .subscribe((columns) => {
        const nextState = this.salesforceNodeStates()[resource.name];
        if (!nextState) {
          return;
        }

        if (columns === null) {
          this.updateSalesforceNodeState({
            ...nextState,
            status: 'error',
            columns: [],
          });
        } else {
          this.updateSalesforceNodeState({
            ...nextState,
            status: 'loaded',
            columns,
          });
        }

        this.salesforceDescribeRequests.delete(resource.name);
      });

    this.salesforceDescribeRequests.set(resource.name, request);
  }

  private canLoadSalesforceObject(
    state: QueryAnalyzerSalesforceSchemaState | undefined,
  ): state is QueryAnalyzerSalesforceSchemaState {
    return !!state && state.status !== 'loading' && state.status !== 'loaded';
  }

  private updateSalesforceNodeState(state: QueryAnalyzerSalesforceSchemaState): void {
    this.salesforceNodeStates.update((current) => ({
      ...current,
      [state.resource.name]: state,
    }));
  }

  private buildDatabaseMetadataRequest(activeConnectionId: string) {
    return this.databaseConnectorService.getMetadata(activeConnectionId).pipe(
      map((metadata) => [...metadata].sort((left, right) => left.tableName.localeCompare(right.tableName))),
      map((metadata) =>
        metadata.map((item) => ({
          resource: item,
          columnsLoaded: false,
          columnsLoading: false,
          expanded: false,
        })),
      ),
      catchError(() => {
        this.handleInitialSchemaLoadingError();
        return of(null);
      }),
    );
  }

  private startSchemaLoading(): void {
    this.isLoading.set(true);
    this.hasError.set(false);
    this.screenLockStore.lockScreen();
  }

  private completeInitialLoading(): void {
    this.isLoading.set(false);
    this.hasError.set(false);
    this.screenLockStore.unlockScreen();
  }

  private resetSchemaState(): void {
    this.isLoading.set(false);
    this.hasError.set(false);
    this.databaseMetadataNodes.set([]);
    this.salesforceNodeStates.set({});
    this.selectedTreeNodeId.set(null);
    this.cleanupSalesforceDescribeRequests();
    this.screenLockStore.unlockScreen();
  }

  private completeDatabaseLoading(nodes: QueryAnalyzerDatabaseSchemaState[]): void {
    this.databaseMetadataNodes.set(nodes);
    this.completeInitialLoading();
  }

  private getDatabaseMetadataState(tableName: string): QueryAnalyzerDatabaseSchemaState | undefined {
    return this.databaseMetadataNodes().find((state) => state.resource.tableName === tableName);
  }

  private updateDatabaseMetadataState(tableName: string, patch: Partial<QueryAnalyzerDatabaseSchemaState>): void {
    this.databaseMetadataNodes.update((states) =>
      states.map((state) =>
        state.resource.tableName === tableName
          ? {
              ...state,
              ...patch,
            }
          : state,
      ),
    );
  }

  private handleInitialSchemaLoadingError(): void {
    this.hasError.set(true);
    this.databaseMetadataNodes.set([]);
    this.salesforceNodeStates.set({});
    this.isLoading.set(false);
    this.screenLockStore.unlockScreen();
  }

  private cleanupSalesforceDescribeRequests(): void {
    for (const request of this.salesforceDescribeRequests.values()) {
      request.unsubscribe();
    }
    this.salesforceDescribeRequests.clear();
  }

  private isSavedQuerySelection(
    selection: SchemaDiscoverySelectionEvent,
  ): selection is SchemaDiscoverySelectionEvent & {
    node: SchemaDiscoveryNode & { data: SavedQuery };
  } {
    return this.isSavedQuery(selection.node.data);
  }

  private isSavedQuery(value: unknown): value is SavedQuery {
    return !!value && typeof value === 'object' && 'name' in value && 'queryValue' in value;
  }

  private isSalesforceObjectSelection(
    selection: SchemaDiscoverySelectionEvent,
  ): selection is SchemaDiscoverySelectionEvent & { node: SchemaDiscoveryNode & { data: SalesforceObject } } {
    return this.isSalesforceObject(selection.node.data);
  }

  private isSalesforceObject(value: unknown): value is SalesforceObject {
    return !!value && typeof value === 'object' && 'name' in value && !('tableName' in value);
  }

  private isDatabaseMetadata(value: unknown): value is DatabaseSourceMetadata {
    return !!value && typeof value === 'object' && 'tableName' in value;
  }
}
