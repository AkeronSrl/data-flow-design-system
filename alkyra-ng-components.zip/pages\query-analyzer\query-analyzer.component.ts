import { TiaraCollapsableContainerComponent } from '@akeron-ng/tiara-ng/tiara-collapsable-container';
import { TiaraNavBarUiComponent } from '@akeron-ng/tiara-ng/tiara-nav-bar-ui';
import { ConnectionStatus } from '@alkyra/infrastructure-services/rabbitmq-connection.service';
import { RabbitMqInitializerService } from '@alkyra/infrastructure-services/rabbitmq-initializer.service';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, DestroyRef, effect, inject, OnInit, ViewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import notify from 'devextreme/ui/notify';
import { ValidationCallbackData } from 'devextreme-angular/common';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxPopupModule } from 'devextreme-angular/ui/popup';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxValidationGroupComponent, DxValidationGroupModule } from 'devextreme-angular/ui/validation-group';
import { DxValidatorModule } from 'devextreme-angular/ui/validator';
import { distinctUntilChanged, map } from 'rxjs';

import { QueryAnalyzerStore } from './+store/query-analyzer.store';
import { QueryAnalyzerEditorComponent } from './components/query-analyzer-editor/query-analyzer-editor.component';
import { QueryAnalyzerResultsComponent } from './components/query-analyzer-results/query-analyzer-results.component';
import { QueryAnalyzerSchemaBrowserComponent } from './components/query-analyzer-schema-browser/query-analyzer-schema-browser.component';

@Component({
  selector: 'alk-query-analyzer',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    TiaraNavBarUiComponent,
    TiaraCollapsableContainerComponent,
    QueryAnalyzerSchemaBrowserComponent,
    QueryAnalyzerEditorComponent,
    QueryAnalyzerResultsComponent,
    DxPopupModule,
    DxTextBoxModule,
    DxTextAreaModule,
    DxValidationGroupModule,
    DxValidatorModule,
    DxButtonModule,
  ],
  providers: [QueryAnalyzerStore],
  templateUrl: './query-analyzer.component.html',
  styleUrl: './query-analyzer.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class QueryAnalyzerComponent implements OnInit {
  protected readonly _store = inject(QueryAnalyzerStore);
  private readonly destroyRef = inject(DestroyRef);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly rabbitmqInitializer = inject(RabbitMqInitializerService);
  private readonly translateService = inject(TranslateService);

  @ViewChild('createGroup', { static: false }) createGroup?: DxValidationGroupComponent;
  @ViewChild('editGroup', { static: false }) editGroup?: DxValidationGroupComponent;

  private errorShown = false;

  constructor() {
    effect(() => {
      const status = this.rabbitmqInitializer.getConnectionStatus()();
      this.handleConnectionStatusChange(status);
    });
  }

  ngOnInit(): void {
    this.route.paramMap
      .pipe(
        map((params) => params.get('connectionId')),
        distinctUntilChanged(),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((connectionId) => {
        if (connectionId) {
          this._store.initialize(connectionId);
        }
      });
  }

  private handleConnectionStatusChange(status: ConnectionStatus): void {
    if (this.errorShown) {
      return;
    }

    if (status === ConnectionStatus.ERROR) {
      this.showRabbitMqError();
      return;
    }

    if (status === ConnectionStatus.DISCONNECTED && !this.rabbitmqInitializer.isConnected()) {
      this.scheduleDisconnectionCheck();
    }
  }

  private scheduleDisconnectionCheck(): void {
    setTimeout(() => {
      const currentStatus = this.rabbitmqInitializer.getConnectionStatus()();
      const isStillDown = currentStatus !== ConnectionStatus.CONNECTED && currentStatus !== ConnectionStatus.CONNECTING;

      if (!this.errorShown && isStillDown) {
        this.showRabbitMqError();
      }
    }, 2000);
  }

  private showRabbitMqError(): void {
    this.errorShown = true;
    notify(this.translateService.instant('query.analyzer.rabbitmq.unavailable'), 'error', 5000);
  }

  confirmCreateQuery() {
    if (!this.createGroup?.instance?.validate().isValid) {
      return;
    }
    this._store.createQuery();
  }

  confirmEditQuery() {
    if (!this.editGroup?.instance?.validate().isValid) {
      return;
    }
    this._store.updateQueryMetadata();
  }

  onBackClick() {
    this.router.navigate(['/connections']);
  }

  validateNotEmpty = (e: ValidationCallbackData) => {
    return `${e.value ?? ''}`.trim() !== '';
  };
}
