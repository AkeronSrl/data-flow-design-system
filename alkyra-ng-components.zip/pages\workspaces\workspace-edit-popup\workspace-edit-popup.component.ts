import { TiaraSuiteIconSelectBoxComponent } from '@akeron-ng/tiara-ng-suite/tiara-icon-select-box';
import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { ValidationCallbackData } from 'devextreme-angular/common';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxPopupModule } from 'devextreme-angular/ui/popup';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxValidationGroupComponent, DxValidationGroupModule } from 'devextreme-angular/ui/validation-group';
import { DxValidatorModule } from 'devextreme-angular/ui/validator';

import { Workspace } from '../../../workspace/models/workspace.model';

@Component({
  selector: 'alk-workspace-edit-popup',
  templateUrl: './workspace-edit-popup.component.html',
  styleUrls: ['./workspace-edit-popup.component.scss'],
  standalone: true,
  imports: [
    DxTextBoxModule,
    DxTextAreaModule,
    DxButtonModule,
    DxPopupModule,
    TranslatePipe,
    TiaraSuiteIconSelectBoxComponent,
    DxValidatorModule,
    DxValidationGroupModule,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkspaceEditPopupComponent {
  @ViewChild('targetGroup', { static: false }) validationGroup: DxValidationGroupComponent | undefined;

  id: string | undefined = undefined;
  nameForm: string = '';
  descriptionForm: string = '';
  iconForm: string = '';

  @Input()
  set workspace(value: Workspace | null) {
    if (value) {
      this.id = value.id;
      this.nameForm = value.name;
      this.descriptionForm = value.description;
      this.iconForm = value.icon;
    }
  }
  @Output() onSaveWorkspace = new EventEmitter<Workspace>();
  @Output() onClosePopup = new EventEmitter<void>();

  onNameChanged(name: string) {
    this.nameForm = name;
  }

  onDescriptionChanged(description: string) {
    this.descriptionForm = description;
  }

  onIconChanged(icon: string) {
    this.iconForm = icon;
  }

  saveWorkspace() {
    if (this.validationGroup?.instance?.validate().isValid) {
      this.onSaveWorkspace.emit({
        id: this.id,
        name: this.nameForm,
        description: this.descriptionForm,
        icon: this.iconForm,
      });
    }
  }

  closePopup() {
    this.onClosePopup.emit();
  }

  validateName = (e: ValidationCallbackData) => {
    return e.value.trim() !== '';
  };
}
