import { TiaraIconContainerComponent } from '@akeron-ng/tiara-ng/tiara-icon-container';
import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';

import { Workspace } from '../../../workspace/models/workspace.model';

@Component({
  selector: 'alk-workspace-tile',
  templateUrl: './workspace-tile.component.html',
  styleUrls: ['./workspace-tile.component.scss'],
  standalone: true,
  imports: [DxScrollViewModule, TiaraIconContainerComponent, DxButtonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkspaceTileComponent {
  @Input() workspace: Workspace = {
    description: '',
    icon: 'fa-light fa-empty-set',
    name: '',
  };
  @Output() tileClick = new EventEmitter<string>();
  @Output() deleteClick = new EventEmitter<Workspace>();
  @Output() editClick = new EventEmitter<Workspace>();

  onDeleteWorkspace() {
    this.deleteClick.emit(this.workspace);
  }

  onTileClick() {
    this.tileClick.emit(this.workspace.id);
  }

  onEditWorkspace() {
    this.editClick.emit(this.workspace);
  }
}
