import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { Workspace } from '@alkyra/workspace/models/workspace.model';
import { ChangeDetectionStrategy, Component, inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { confirm } from 'devextreme/ui/dialog';
import notify from 'devextreme/ui/notify';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxPopupModule } from 'devextreme-angular/ui/popup';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';

import { WorkspaceStore } from './+store/workspace.store';
import { WorkspaceEditPopupComponent } from './workspace-edit-popup/workspace-edit-popup.component';
import { WorkspaceTileComponent } from './workspace-tile/workspace-tile.component';

@Component({
  selector: 'alk-workspaces',
  standalone: true,
  imports: [
    DxButtonModule,
    TranslatePipe,
    DxScrollViewModule,
    WorkspaceTileComponent,
    DxPopupModule,
    WorkspaceEditPopupComponent,
    TiaraCircularIllustrationComponent,
  ],
  templateUrl: './workspaces.component.html',
  styleUrl: './workspaces.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkspacesComponent implements OnInit {
  _store = inject(WorkspaceStore);
  _router = inject(Router);
  private readonly _translateService = inject(TranslateService);

  ngOnInit(): void {
    this._store.loadWorkspace();
  }

  openWorkspace(workspaceId: string) {
    this._router.navigate(['/workspaces', workspaceId, 'pipelines']);
  }

  getWorkspaceName(workspace: Workspace) {
    return workspace.description;
  }

  openEditPopup(workspace?: Workspace) {
    if (workspace) {
      this._store.setSelectedWorkspace(workspace);
    } else {
      this._store.setSelectedWorkspace(null);
    }
    this._store.toggleEditPopup();
  }

  updateWorkspace(workspace: Workspace) {
    if (this._store.selectedWorkspace()?.id) {
      this._store.updateWorkspace(workspace);
    } else {
      this._store.addWorkspace(workspace);
    }
  }

  closeEditPopup() {
    this._store.toggleEditPopup();
  }

  deleteWorkspace(workspace: Workspace) {
    const result = confirm(
      this._translateService.instant('workspace.delete.confirmation'),
      this._translateService.instant('workspace.delete.title'),
    );
    result.then((dialogResult) => {
      if (dialogResult) {
        this._store.deleteWorkspace(workspace);
      }
    });
  }

  notify(message: string | undefined, type: string, displayTime: number): void {
    notify(message, type, displayTime);
  }
}
