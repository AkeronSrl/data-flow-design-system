import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { DxDropDownBoxModule } from 'devextreme-angular/ui/drop-down-box';
import { DxTreeViewModule } from 'devextreme-angular/ui/tree-view';

@Component({
  selector: 'alk-message-path-selector',
  standalone: true,
  imports: [DxDropDownBoxModule, DxTreeViewModule],
  templateUrl: './message-path-selector.component.html',
  styleUrl: './message-path-selector.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MessagePathSelectorComponent {
  @Input() tree: Record<string, any> = {};
  @Input() basePath = '';
  @Input() value: string | string[] = '';
  @Input() placeholder: string | null = null;
  @Input() selectionMode: 'node' | 'leaf' = 'node';
  @Input() width: string | number = '100%';
  @Input() displayValueFormatter?: (value: string | any[]) => string;
  @Input() showClearButton = true;
  @Input() multiple = false;

  @Output() valueChange = new EventEmitter<string | string[]>();

  get selectedValue(): string | string[] {
    if (this.multiple) {
      return this.stripRootArray(this.value);
    }
    return this.stripRoot(typeof this.value === 'string' ? this.value : '');
  }

  get treeItems(): any[] {
    const subTree = this.getSubTree(this.tree, this.basePath);
    const selected = this.multiple ? this.stripRootArray(this.value) : [this.stripRoot(this.value as string)];
    if (this.selectionMode === 'leaf') {
      return this.markSelected(this.mapLeavesOnly(subTree, ''), selected);
    }
    return this.markSelected(this.mapTreeNodesOnly(subTree, ''), selected);
  }

  get dataSource(): any[] {
    if (this.selectionMode === 'leaf') {
      return this.collectLeafItems(this.treeItems);
    }
    return this.collectNodeItems(this.treeItems);
  }

  get displayValueFormatterFn(): (value: string | any[]) => string {
    return (
      this.displayValueFormatter ??
      ((value) => {
        let values: any[];
        if (Array.isArray(value)) {
          values = value;
        } else if (value) {
          values = [value];
        } else {
          values = [];
        }
        return values.join(', ');
      })
    );
  }

  onValueChanged(value: any): void {
    if (this.multiple) {
      const singleValueArray = value ? [value] : [];
      const valueArray = Array.isArray(value) ? value : singleValueArray;
      const normalized = this.normalizeSelection(valueArray);
      this.valueChange.emit(normalized);
      return;
    }
    const normalized = value ?? '';
    this.valueChange.emit(normalized);
  }

  onItemSelectionChanged(event: any, dropDown: any): void {
    const node = event?.node;
    if (!node) return;

    if (this.shouldIgnoreSelection(node)) {
      this.unselectNode(event, node);
      return;
    }

    if (this.multiple) {
      this.handleMultipleSelection(event, dropDown);
      return;
    }

    this.handleSingleSelection(node, dropDown);
  }

  private unselectNode(event: any, node: any): void {
    event?.component?.unselectItem?.(node.key);
  }

  private handleMultipleSelection(event: any, dropDown: any): void {
    const selectedKeys = this.normalizeSelection(event?.component?.getSelectedNodeKeys?.() ?? []);
    dropDown?.instance?.option('value', selectedKeys);
    this.onValueChanged(selectedKeys);
  }

  private handleSingleSelection(node: any, dropDown: any): void {
    const path = this.getNodePath(node);
    if (!path) return;
    this.selectNodeInDropdown(dropDown, path);
  }

  private shouldIgnoreSelection(node: any): boolean {
    return this.isInvalidLeafSelection(node) || this.isDisabledNodeSelection(node);
  }

  private isInvalidLeafSelection(node: any): boolean {
    return this.selectionMode === 'leaf' && this.isNodeWithChildren(node);
  }

  private isDisabledNodeSelection(node: any): boolean {
    return this.selectionMode === 'node' && node?.itemData?.disabled;
  }

  private getSubTree(tree: Record<string, any>, path: string): any {
    if (!path) return tree || {};
    const segments = this.normalizePath(path);
    return this.traverseTree(tree, segments);
  }

  private normalizePath(path: string): string[] {
    const normalizedPath = this.stripRoot(path);
    return normalizedPath.split('.').filter(Boolean);
  }

  private stripRoot(path: string | undefined): string {
    if (!path) return '';
    if (path.startsWith('$.')) return path.slice(2);
    if (path.startsWith('$')) return path.slice(1);
    return path;
  }

  private stripRootArray(value: string | string[] | undefined): string[] {
    if (!value) return [];
    const values = Array.isArray(value) ? value : [value];
    return values.map((v) => this.stripRoot(v)).filter(Boolean);
  }

  private traverseTree(tree: any, segments: string[]): any {
    let current: any = tree ?? {};
    for (const segment of segments) {
      if (!this.hasSegment(current, segment)) {
        return {};
      }
      current = current[segment];
    }
    return current;
  }

  private hasSegment(obj: any, segment: string): boolean {
    return obj && typeof obj === 'object' && segment in obj;
  }

  private mapTreeToItems(tree: any, prefix: string): any[] {
    if (!tree || typeof tree !== 'object') {
      return [];
    }

    return Object.keys(tree)
      .filter((key) => key !== '__leaf')
      .map((key) => {
        const fullPath = prefix ? `${prefix}.${key}` : key;
        const child = tree[key];
        const isLeaf = this.isLeafNode(child);

        const item: any = { id: fullPath, text: key };
        if (!isLeaf) {
          const children = this.mapTreeToItems(child, fullPath);
          if (children.length) {
            item.items = children;
          }
        }
        return item;
      });
  }

  private mapTreeNodesOnly(tree: any, prefix: string): any[] {
    if (!tree || typeof tree !== 'object') {
      return [];
    }

    return Object.keys(tree)
      .filter((key) => key !== '__leaf')
      .map((key) => {
        const fullPath = prefix ? `${prefix}.${key}` : key;
        const child = tree[key];
        const isLeaf = this.isLeafNode(child);
        const item: any = { id: fullPath, text: key, disabled: isLeaf };
        if (!isLeaf) {
          const children = this.mapTreeNodesOnly(child, fullPath);
          if (children.length) {
            item.items = children;
          }
        }
        return item;
      });
  }

  private mapLeavesOnly(tree: any, prefix: string): any[] {
    if (!tree || typeof tree !== 'object') {
      return [];
    }

    return Object.keys(tree)
      .filter((key) => key !== '__leaf')
      .reduce<any[]>((acc, key) => {
        const fullPath = prefix ? `${prefix}.${key}` : key;
        const child = tree[key];
        if (this.isLeafNode(child)) {
          acc.push({ id: fullPath, text: fullPath });
        }
        return acc;
      }, []);
  }

  private collectLeafItems(items: any[]): any[] {
    if (!Array.isArray(items) || !items.length) return [];
    return items.reduce<any[]>((acc, item) => {
      if (item.items?.length) {
        acc.push(...this.collectLeafItems(item.items));
      } else {
        acc.push({ id: item.id, text: item.id });
      }
      return acc;
    }, []);
  }

  private collectNodeItems(items: any[]): any[] {
    if (!Array.isArray(items) || !items.length) return [];
    return items.reduce<any[]>((acc, item) => {
      if (!item.disabled) {
        acc.push({ id: item.id, text: item.id });
      }
      if (item.items?.length) {
        acc.push(...this.collectNodeItems(item.items));
      }
      return acc;
    }, []);
  }

  private isLeafNode(node: any): boolean {
    return !node || typeof node !== 'object' || Object.keys(node).every((k) => k === '__leaf');
  }

  private isNodeWithChildren(node: any): boolean {
    return !!node?.children?.length;
  }

  private getNodePath(node: any): string {
    return node?.key ?? node?.itemData?.id;
  }

  private selectNodeInDropdown(dropDown: any, path: string): void {
    dropDown?.instance?.option('value', path);
    this.onValueChanged(path);
    dropDown?.instance?.close();
  }

  private markSelected(items: any[], targetIds: string[] | undefined): any[] {
    const targetSet = new Set(targetIds?.filter(Boolean) ?? []);
    return items.map((item) => {
      const selected = targetSet.has(item.id);
      const children = item.items ? this.markSelected(item.items, targetIds) : undefined;
      return {
        ...item,
        ...(children ? { items: children } : {}),
        ...(selected ? { selected: true } : {}),
      };
    });
  }

  private normalizeSelection(values: string[]): string[] {
    return values.map((v) => this.stripRoot(v)).filter(Boolean);
  }
}
