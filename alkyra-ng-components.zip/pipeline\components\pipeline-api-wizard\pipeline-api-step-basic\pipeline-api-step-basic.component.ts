import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { ChangeDetectionStrategy, Component, computed, inject, input, Signal, ViewChild } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { ValueChangedEvent as NumberBoxValueChangedEvent } from 'devextreme/ui/number_box';
import { ValueChangedEvent as SwitchValueChangedEvent } from 'devextreme/ui/switch';
import { ValueChangedEvent as TextAreaValueChangedEvent } from 'devextreme/ui/text_area';
import { ValueChangedEvent as TextBoxValueChangedEvent } from 'devextreme/ui/text_box';
import { ValidationCallbackData } from 'devextreme-angular/common';
import { DxNumberBoxModule } from 'devextreme-angular/ui/number-box';
import { DxSwitchModule } from 'devextreme-angular/ui/switch';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxValidationGroupComponent, DxValidationGroupModule } from 'devextreme-angular/ui/validation-group';
import { DxValidatorModule } from 'devextreme-angular/ui/validator';

import { PipelineApiWizardStore } from '../+store/pipeline-api-wizard.store';

@Component({
  selector: 'alk-pipeline-api-step-basic',
  templateUrl: './pipeline-api-step-basic.component.html',
  styleUrls: ['./pipeline-api-step-basic.component.scss'],
  standalone: true,
  imports: [
    TiaraNameDescriptionLabelComponent,
    TiaraSuiteWizardStepComponent,
    DxTextBoxModule,
    DxTextAreaModule,
    DxSwitchModule,
    DxNumberBoxModule,
    TranslatePipe,
    DxValidationGroupModule,
    DxValidatorModule,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PipelineApiStepBasicComponent extends WizardStep {
  @ViewChild('targetGroup', { static: false }) validationGroup: DxValidationGroupComponent | undefined;

  readonly showRetentionDays = input(false);
  readonly _store = inject(PipelineApiWizardStore);
  readonly ingestPathPattern = /^[A-Za-z0-9_-]+$/;
  readonly showAuditSection = computed(() => this._store.isEditMode());

  onNameChange(value: TextBoxValueChangedEvent) {
    this._store.setName(value.value ?? '');
  }

  onDescriptionChange(value: TextAreaValueChangedEvent) {
    this._store.setDescription(value.value ?? '');
  }

  onIngestPathChange(value: TextBoxValueChangedEvent) {
    this._store.setIngestPath(value.value ?? '');
  }

  onRetentionDaysChange(value: NumberBoxValueChangedEvent) {
    this._store.setRetentionDays(value.value);
  }

  onErrorStoreEnabledChange(value: SwitchValueChangedEvent) {
    this._store.setErrorStoreEnabled(!!value.value);
  }

  onDataAuditEnabledChange(value: boolean) {
    this._store.setDataAuditEnabled(value);
  }

  onDataAuditMaxCopiesChange(value: number | null | undefined) {
    this._store.setDataAuditMaxCopies(value);
  }

  validateEmptyField = (e: ValidationCallbackData) => {
    return e.value && e.value.trim() !== '';
  };

  override canGoforward: Signal<boolean> = computed(() => {
    const name = this._store.name().trim();
    const description = this._store.description().trim();
    const ingestPath = this._store.ingestPath().trim();

    return !!name && !!description && !!ingestPath && this.ingestPathPattern.test(ingestPath);
  });
}
