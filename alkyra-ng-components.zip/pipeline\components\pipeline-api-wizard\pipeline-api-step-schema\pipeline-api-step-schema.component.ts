import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { ChangeDetectionStrategy, Component, computed, inject, OnInit, Signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import notify from 'devextreme/ui/notify';
import { ValueChangedEvent as TextAreaValueChangedEvent } from 'devextreme/ui/text_area';
import { ValidationCallbackData } from 'devextreme-angular/common';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';
import { DxValidatorModule } from 'devextreme-angular/ui/validator';

import { PipelineApiWizardStore } from '../+store/pipeline-api-wizard.store';
import { beautifyJsonIfValid, isJsonParsable, isJsonSampleValid, isJsonSchemaValid } from '../pipeline-api-json.utils';

@Component({
  selector: 'alk-pipeline-api-step-schema',
  templateUrl: './pipeline-api-step-schema.component.html',
  styleUrls: ['./pipeline-api-step-schema.component.scss'],
  standalone: true,
  imports: [
    TiaraSuiteWizardStepComponent,
    TiaraNameDescriptionLabelComponent,
    TranslatePipe,
    DxButtonModule,
    DxLoadIndicatorModule,
    DxTextAreaModule,
    DxValidatorModule,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PipelineApiStepSchemaComponent extends WizardStep implements OnInit {
  readonly _store = inject(PipelineApiWizardStore);
  private readonly _translateService = inject(TranslateService);

  ngOnInit(): void {
    this._store.beautifyJsonFieldsIfValid();
  }

  get isGeneratingSchema() {
    return this._store.isGeneratingSchema();
  }

  onJsonSampleChange(value: TextAreaValueChangedEvent) {
    this._store.setJsonSample(value.value ?? '');
  }

  onJsonSchemaChange(value: TextAreaValueChangedEvent) {
    this._store.setJsonSchema(value.value ?? '');
  }

  generateSchemaFromSample() {
    const jsonSample = this._store.jsonSample().trim();
    if (!jsonSample || this._store.isGeneratingSchema()) {
      return;
    }

    this._store.generateSchemaFromSample(jsonSample).subscribe({
      next: (jsonSchema) => {
        this._store.setJsonSchema(jsonSchema);
        notify(this._translateService.instant('pipeline.api.schema.generate.success'), 'success', 3000);
      },
      error: () => {
        notify(this._translateService.instant('pipeline.api.schema.generate.failed'), 'error', 3000);
      },
    });
  }

  beautifySample() {
    this.beautifyField('sample');
  }

  beautifySchema() {
    this.beautifyField('schema');
  }

  validateJsonSchema = (e: ValidationCallbackData) => {
    return this.isSchemaValid(e.value);
  };

  validateJsonSample = (e: ValidationCallbackData) => {
    return this.isSampleValid(e.value);
  };

  override canGoforward: Signal<boolean> = computed(() => {
    return this.isSchemaValid(this._store.jsonSchema()) && this.isSampleValid(this._store.jsonSample());
  });

  private beautifyField(field: 'sample' | 'schema') {
    const source = this.getJsonFieldValue(field);
    if (!source.trim()) {
      return;
    }

    if (!isJsonParsable(source)) {
      notify(this._translateService.instant('pipeline.api.json.beautify.invalid'), 'error', 3000);
      return;
    }

    this.setJsonFieldValue(field, beautifyJsonIfValid(source));
  }

  private getJsonFieldValue(field: 'sample' | 'schema'): string {
    return field === 'sample' ? this._store.jsonSample() : this._store.jsonSchema();
  }

  private setJsonFieldValue(field: 'sample' | 'schema', value: string): void {
    if (field === 'sample') {
      this._store.setJsonSample(value);
      return;
    }

    this._store.setJsonSchema(value);
  }

  private isSchemaValid(value: unknown): boolean {
    return isJsonSchemaValid(value);
  }

  private isSampleValid(value: unknown): boolean {
    return isJsonSampleValid(value);
  }
}
