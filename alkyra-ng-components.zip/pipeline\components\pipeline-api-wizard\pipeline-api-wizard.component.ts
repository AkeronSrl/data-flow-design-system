import { TiaraSuiteWizardComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { Pipeline } from '@alkyra/pipeline/models/pipeline.model';
import { PipelineService } from '@alkyra/pipeline/services/pipeline.service';
import { Component, computed, inject, input, OnInit, output } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';

import { PipelineApiWizardStore } from './+store/pipeline-api-wizard.store';
import { PipelineApiStepBasicComponent } from './pipeline-api-step-basic/pipeline-api-step-basic.component';
import { PipelineApiStepSchemaComponent } from './pipeline-api-step-schema/pipeline-api-step-schema.component';

@Component({
  selector: 'alk-pipeline-api-wizard',
  standalone: true,
  imports: [TiaraSuiteWizardComponent, TranslatePipe, PipelineApiStepBasicComponent, PipelineApiStepSchemaComponent],
  providers: [PipelineApiWizardStore],
  templateUrl: './pipeline-api-wizard.component.html',
  styleUrl: './pipeline-api-wizard.component.scss',
})
export class PipelineApiWizardComponent implements OnInit {
  readonly pipeline = input.required<Pipeline>();
  readonly onSave = output<Pipeline>();
  readonly onClose = output<void>();
  readonly showRetentionDays = computed(() => !!this.pipeline().id);

  readonly _store = inject(PipelineApiWizardStore);
  private readonly _pipelineService = inject(PipelineService);

  ngOnInit(): void {
    const pipeline = this.pipeline();
    this._store.initializeFromPipeline(pipeline);

    if (pipeline.id) {
      this._pipelineService.getApiPipelineConfig(pipeline.id).subscribe((config) => {
        this._store.applyApiConfig(config);
      });
    }
  }

  complete() {
    this.onSave.emit(this._store.buildPipeline(this.pipeline()));
  }

  close() {
    this._store.reset();
    this.onClose.emit();
  }
}
