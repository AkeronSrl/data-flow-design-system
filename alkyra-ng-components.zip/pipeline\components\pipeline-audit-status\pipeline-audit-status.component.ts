import { CommonModule } from '@angular/common';
import { Component, input } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';

@Component({
  selector: 'alk-pipeline-audit-status',
  standalone: true,
  imports: [CommonModule, TranslatePipe],
  templateUrl: './pipeline-audit-status.component.html',
  styleUrl: './pipeline-audit-status.component.scss',
})
export class PipelineAuditStatusComponent {
  enabled = input<boolean>(false);
  maxCopies = input<number>(1);
}
