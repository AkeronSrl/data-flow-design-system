import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { TiaraCollapsableContainerComponent } from '@akeron-ng/tiara-ng/tiara-collapsable-container';
import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { AmazonSqsConnector } from '@alkyra/amazon-sqs-connector/models/amazon-sqs-connector.model';
import { AmazonSqsConnectorService } from '@alkyra/amazon-sqs-connector/services/amazon-sqs-connector.service';
import { ConnectorType } from '@alkyra/connector/models/connector.model';
import { PipelineParamDto, PipelineQueueParams } from '@alkyra/pipeline/models/pipeline.model';
import { ScreenLockStore } from '@alkyra/screen-lock/+store/screen-lock.store';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, inject, OnInit, Signal, signal } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { DxDropDownBoxModule } from 'devextreme-angular/ui/drop-down-box';
import { DxListModule } from 'devextreme-angular/ui/list';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';
import { DxTreeViewModule } from 'devextreme-angular/ui/tree-view';
import { BehaviorSubject, lastValueFrom } from 'rxjs';

import { PipelineQueueWizardStore } from '../pipeline-queue-wizard/+store/pipeline-queue-wizard.store';

@Component({
  selector: 'alk-pipeline-dlq-selector',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    DxListModule,
    DxDropDownBoxModule,
    DxTreeViewModule,
    TiaraCollapsableContainerComponent,
    TiaraCircularIllustrationComponent,
    TiaraSuiteWizardStepComponent,
    DxTextAreaModule,
    DxScrollViewModule,
  ],
  templateUrl: './pipeline-dlq-selector.component.html',
  styleUrl: './pipeline-dlq-selector.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PipelineDlqSelectorComponent extends WizardStep implements OnInit {
  private readonly _screenLockStore = inject(ScreenLockStore);
  private readonly _amazonSqsConnectorService = inject(AmazonSqsConnectorService);
  private readonly _translateService = inject(TranslateService);

  _pipelineQueueWizardStore = inject(PipelineQueueWizardStore);
  private readonly _emptyDlqConnector: AmazonSqsConnector = {
    id: '__EMPTY_DLQ__',
    description: this._translateService.instant('pipeline.dlq.selector.empty'),
    connectorType: ConnectorType.AMAZON_SQS,
    awsRegion: '',
    accessKey: '',
    secretKey: '',
    queueUrl: '',
  };
  _connectorSelected = signal<AmazonSqsConnector>(this._emptyDlqConnector);

  private _amazonSqsConnectorsSubject = new BehaviorSubject<AmazonSqsConnector[]>([this._emptyDlqConnector]);
  $amazonSqsConnectors = this._amazonSqsConnectorsSubject.asObservable();
  private _rawConnectors: AmazonSqsConnector[] = [];

  readonly emptyDlqKey = this._emptyDlqConnector.id;
  isEmptySelection = computed(() => this._connectorSelected().id === this._emptyDlqConnector.id);

  private readonly _filterEffect = effect(() => {
    const queueConnectionId = this._pipelineQueueWizardStore
      .pipelineParams()
      .find((param) => param.codParametro === PipelineQueueParams.CONNECTION_ID)?.valoreStringa;
    this._updateConnectorList(queueConnectionId);
  });

  get preview() {
    return this._pipelineQueueWizardStore.preview();
  }

  ngOnInit(): void {
    this._amazonSqsConnectorService.findAll().subscribe((connectors) => {
      this._rawConnectors = connectors;
      const queueConnectionId = this._pipelineQueueWizardStore
        .pipelineParams()
        .find((param) => param.codParametro === PipelineQueueParams.CONNECTION_ID)?.valoreStringa;
      this._updateConnectorList(queueConnectionId);

      const dlqConnectionId = this._pipelineQueueWizardStore
        .pipelineParams()
        .find((param) => param.codParametro === PipelineQueueParams.DLQ_CONNECTION_ID)?.valoreStringa;
      if (dlqConnectionId) {
        const selected = connectors.find((connector) => connector.id === dlqConnectionId);
        if (selected) {
          this._connectorSelected.set(selected);
        }
      }
    });
  }

  clearStore(): void {
    this._pipelineQueueWizardStore.removePipelineParam(PipelineQueueParams.DLQ_CONNECTION_ID);
    this._connectorSelected.set(this._emptyDlqConnector);
  }

  onConnectionSelected(event: any): void {
    const selectedItem: AmazonSqsConnector | undefined = event.addedItems?.[0];
    if (!selectedItem) {
      return;
    }

    if (selectedItem.id === this._emptyDlqConnector.id) {
      this._pipelineQueueWizardStore.removePipelineParam(PipelineQueueParams.DLQ_CONNECTION_ID);
      this._connectorSelected.set(this._emptyDlqConnector);
      return;
    }

    const selectedId = selectedItem.id;
    if (!selectedId) {
      return;
    }

    const param: PipelineParamDto = { codParametro: PipelineQueueParams.DLQ_CONNECTION_ID, valoreStringa: selectedId };
    this._pipelineQueueWizardStore.addPipelineParam(param);
    lastValueFrom(this._amazonSqsConnectorService.findConnector(selectedId)).then((connector) => {
      this._connectorSelected.set(connector);
      if (connector.payloadSample && connector.payloadSample !== '') {
        this._pipelineQueueWizardStore.setPreview(connector.payloadSample);
      } else if (connector.payloadSchema && connector.payloadSchema !== '') {
        this._pipelineQueueWizardStore.setPreview(connector.payloadSchema);
      } else {
        this._pipelineQueueWizardStore.testPreviewConnection(connector);
      }
    });
  }

  override canGoforward: Signal<boolean> = computed(() => true);

  private _updateConnectorList(queueConnectionId?: string) {
    if (this._rawConnectors.length === 0) {
      this._amazonSqsConnectorsSubject.next([this._emptyDlqConnector]);
      this._connectorSelected.set(this._emptyDlqConnector);
      return;
    }

    const filtered = this._rawConnectors.filter((connector) => connector.id !== queueConnectionId);
    this._amazonSqsConnectorsSubject.next([this._emptyDlqConnector, ...filtered]);

    const dlqConnectionId = this._pipelineQueueWizardStore
      .pipelineParams()
      .find((param) => param.codParametro === PipelineQueueParams.DLQ_CONNECTION_ID)?.valoreStringa;

    if (!dlqConnectionId) {
      this._connectorSelected.set(this._emptyDlqConnector);
      return;
    }

    const selected = filtered.find((connector) => connector.id === dlqConnectionId);
    if (selected) {
      this._connectorSelected.set(selected);
      return;
    }

    this._pipelineQueueWizardStore.removePipelineParam(PipelineQueueParams.DLQ_CONNECTION_ID);
    this._connectorSelected.set(this._emptyDlqConnector);
  }
}
