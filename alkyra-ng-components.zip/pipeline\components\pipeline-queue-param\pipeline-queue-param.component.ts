import { TiaraNameDescriptionLabelComponent } from '@akeron-ng/tiara-ng/tiara-name-description-label';
import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { ApplyIfEnum } from '@alkyra/pipeline/models/pipeline.model';
import { ChangeDetectionStrategy, Component, computed, effect, inject, Signal, signal } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxAccordionModule } from 'devextreme-angular/ui/accordion';
import { DxFormModule } from 'devextreme-angular/ui/form';
import { DxiItemModule, DxoLabelModule } from 'devextreme-angular/ui/nested';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';

import { MessagePathSelectorComponent } from '../message-path-selector/message-path-selector.component';
import { PipelineQueueWizardStore } from '../pipeline-queue-wizard/+store/pipeline-queue-wizard.store';

@Component({
  selector: 'alk-pipeline-queue-param',
  standalone: true,
  imports: [
    TranslatePipe,
    TiaraSuiteWizardStepComponent,
    DxScrollViewModule,
    DxiItemModule,
    DxoLabelModule,
    DxFormModule,
    DxAccordionModule,
    TiaraNameDescriptionLabelComponent,
    MessagePathSelectorComponent,
  ],
  templateUrl: './pipeline-queue-param.component.html',
  styleUrl: './pipeline-queue-param.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PipelineQueueParamComponent extends WizardStep {
  _pipelineQueueWizardStore = inject(PipelineQueueWizardStore);
  applyIfOptions = Object.values(ApplyIfEnum);
  onEqualOptions = [
    { value: 'IGNORE', text: 'IGNORE' },
    { value: 'UPDATE', text: 'UPDATE' },
  ];
  _pipelineQueueParamFormTemp = this._pipelineQueueWizardStore.pipelineQueueParamFormModel();
  fieldChange = signal({ field: '', value: '' });
  displayDataNodeValue = (value: string | any[]): string => {
    const path = Array.isArray(value) ? value.join(', ') : value;
    return this.formatPath(path);
  };
  displayOccurredAtValue = (value: string | any[]): string => {
    const path = Array.isArray(value) ? value.join(', ') : value;
    return this.stripRoot(path);
  };
  displayKeyValue = (value: string | any[]): string => {
    const path = Array.isArray(value) ? value.join(', ') : value;
    return path || '';
  };
  requiredFields = ['forEach', 'key'];

  constructor() {
    super();
    effect(() => {
      const model = this._pipelineQueueWizardStore.pipelineQueueParamFormModel();
      if (!this._pipelineQueueParamFormTemp.forEach && model.forEach) {
        this.updateFormField('forEach', model.forEach);
      }
    });
  }

  override canGoforward: Signal<boolean> = computed(() => {
    this.fieldChange(); // to re-evaluate when field changes
    const isValid = Object.entries(this._pipelineQueueParamFormTemp)
      .filter(([fieldKey]) => this.requiredFields.includes(fieldKey))
      .every(([, fieldValue]) => {
        return this.isValuePresent(fieldValue);
      });
    return isValid;
  });

  override onForward(): void {
    const isPartitionKeyEmpty = !this.isValuePresent(this._pipelineQueueParamFormTemp.partitionKey);
    const hasKey = this.isValuePresent(this._pipelineQueueParamFormTemp.key);

    if (isPartitionKeyEmpty && hasKey) {
      this._pipelineQueueParamFormTemp = {
        ...this._pipelineQueueParamFormTemp,
        partitionKey: this.cloneSelection(this._pipelineQueueParamFormTemp.key),
      };
    }
    this._pipelineQueueWizardStore.setPipelineQueueParamFormModel(this._pipelineQueueParamFormTemp);
  }

  onFieldDataChanged(event: any) {
    this.updateFormField(event.dataField, event.value);
  }

  onKeySelected(path: string | string[]) {
    this.updateFormField('key', path);
  }

  onForEachSelected(path: string | string[]) {
    this.updateFormField('forEach', path);
  }

  onPartitionKeySelected(path: string | string[]) {
    this.updateFormField('partitionKey', path);
  }

  onOccurredAtSelected(path: string | string[]) {
    this.updateFormField('occurredAt', path);
  }

  private updateFormField(field: string, value: any) {
    const previousForm = this._pipelineQueueParamFormTemp;
    const normalizedValue = this.normalizeSelectionValue(value);
    let updatedForm = {
      ...previousForm,
      [field]: normalizedValue,
    };

    if (field === 'key') {
      updatedForm = this.updateKeyField(updatedForm, previousForm, normalizedValue);
    }

    if (field === 'forEach' && normalizedValue !== previousForm.forEach) {
      updatedForm = this.updateForEachField(updatedForm);
    }

    this._pipelineQueueParamFormTemp = updatedForm;
    this.fieldChange.set({ field, value: normalizedValue });
  }

  private updateKeyField(updatedForm: any, previousForm: any, value: any) {
    const isReset = !this.isValuePresent(value);
    const shouldSyncPartitionKey =
      !this.isValuePresent(previousForm.partitionKey) ||
      this.areValuesEqual(previousForm.partitionKey, previousForm.key) ||
      isReset;
    return {
      ...updatedForm,
      partitionKey: shouldSyncPartitionKey ? this.cloneSelection(value) : updatedForm.partitionKey,
    };
  }

  private updateForEachField(updatedForm: any) {
    return {
      ...updatedForm,
      key: this.emptySelection(updatedForm.key),
      partitionKey: this.emptySelection(updatedForm.partitionKey),
    };
  }

  private formatPath(path: string | undefined): string {
    if (!path) return '';
    return path.startsWith('$') ? path : `$.${path}`;
  }

  private isValuePresent(value: any): boolean {
    if (Array.isArray(value)) {
      return value.length > 0;
    }
    return value !== null && value !== undefined && value !== '';
  }

  private normalizeSelectionValue(value: any): any {
    if (Array.isArray(value)) {
      return value.filter((item) => item !== undefined && item !== null && item !== '');
    }
    return value ?? '';
  }

  private cloneSelection(value: any) {
    if (Array.isArray(value)) {
      return [...value];
    }
    return value ?? '';
  }

  private emptySelection(reference: any) {
    return Array.isArray(reference) ? [] : '';
  }

  private areValuesEqual(a: any, b: any): boolean {
    const normalize = (v: any) => (Array.isArray(v) ? v.join(',') : (v ?? ''));
    return normalize(a) === normalize(b);
  }

  private stripRoot(path: string | undefined): string {
    if (!path) return '';
    if (path.startsWith('$.')) return path.slice(2);
    if (path.startsWith('$')) return path.slice(1);
    return path;
  }
}
