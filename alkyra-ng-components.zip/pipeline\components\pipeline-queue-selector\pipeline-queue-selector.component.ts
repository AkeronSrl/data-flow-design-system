import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { TiaraCollapsableContainerComponent } from '@akeron-ng/tiara-ng/tiara-collapsable-container';
import { TiaraSuiteWizardStepComponent, WizardStep } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { AmazonSqsConnector } from '@alkyra/amazon-sqs-connector/models/amazon-sqs-connector.model';
import { AmazonSqsConnectorService } from '@alkyra/amazon-sqs-connector/services/amazon-sqs-connector.service';
import { PipelineParamDto, PipelineQueueParams } from '@alkyra/pipeline/models/pipeline.model';
import { ScreenLockStore } from '@alkyra/screen-lock/+store/screen-lock.store';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject, OnInit, Signal, signal } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxDropDownBoxModule } from 'devextreme-angular/ui/drop-down-box';
import { DxListModule } from 'devextreme-angular/ui/list';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';
import { DxTreeViewModule } from 'devextreme-angular/ui/tree-view';
import { BehaviorSubject, lastValueFrom } from 'rxjs';

import { PipelineQueueWizardStore } from '../pipeline-queue-wizard/+store/pipeline-queue-wizard.store';

@Component({
  selector: 'alk-pipeline-queue-selector',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    DxListModule,
    DxDropDownBoxModule,
    DxTreeViewModule,
    TiaraCollapsableContainerComponent,
    TiaraCircularIllustrationComponent,
    TiaraSuiteWizardStepComponent,
    DxTextAreaModule,
    DxScrollViewModule,
  ],
  templateUrl: './pipeline-queue-selector.component.html',
  styleUrl: './pipeline-queue-selector.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PipelineQueueSelectorComponent extends WizardStep implements OnInit {
  private readonly _screenLockStore = inject(ScreenLockStore);
  private readonly _amazonSqsConnectorService = inject(AmazonSqsConnectorService);

  _pipelineQueueWizardStore = inject(PipelineQueueWizardStore);
  _connectorSelected = signal<AmazonSqsConnector | null>(null);

  private _amazonSqsConnectorsSubject = new BehaviorSubject<AmazonSqsConnector[]>([]);
  $amazonSqsConnectors = this._amazonSqsConnectorsSubject.asObservable();

  get preview() {
    return this._pipelineQueueWizardStore.preview();
  }

  ngOnInit(): void {
    this._amazonSqsConnectorService.findAll().subscribe((connectors) => {
      this._amazonSqsConnectorsSubject.next(connectors);
    });
  }

  clearStore(): void {
    this._pipelineQueueWizardStore.removePipelineParam(PipelineQueueParams.CONNECTION_ID);
    this._connectorSelected.set(null);
    this._pipelineQueueWizardStore.setPipelineParams([]);
    this._pipelineQueueWizardStore.clearMessageStructure();
  }

  onConnectionSelected(event: any): void {
    const selectedId = event.addedItems[0]?.id;
    const param: PipelineParamDto = { codParametro: PipelineQueueParams.CONNECTION_ID, valoreStringa: selectedId };
    this._pipelineQueueWizardStore.addPipelineParam(param);
    lastValueFrom(this._amazonSqsConnectorService.findConnector(selectedId)).then((connector) => {
      this._connectorSelected.set(connector);
      //la preview Ã¨ valorizzata con sample se presente, altrimenti con schema se presente
      //se nessuno dei due Ã¨ presente, viene eseguito il test di connessione
      if (connector.payloadSample && connector.payloadSample !== '') {
        this._pipelineQueueWizardStore.setPreview(connector.payloadSample);
      } else if (connector.payloadSchema && connector.payloadSchema !== '') {
        this._pipelineQueueWizardStore.setPreview(connector.payloadSchema);
      } else {
        this._pipelineQueueWizardStore.testPreviewConnection(connector);
      }
      this._pipelineQueueWizardStore.setMessageStructureFromConnector(connector);
    });
  }

  override canGoforward: Signal<boolean> = computed(() => {
    return this._pipelineQueueWizardStore
      .pipelineParams()
      .some((param) => param.codParametro === PipelineQueueParams.CONNECTION_ID && param.valoreStringa !== '');
  });
}
