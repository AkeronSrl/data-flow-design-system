import { TiaraSuiteWizardComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { Pipeline, PipelineQueueParams, PipelineType } from '@alkyra/pipeline/models/pipeline.model';
import { Workspace } from '@alkyra/workspace/models/workspace.model';
import { ChangeDetectionStrategy, Component, inject, input, OnInit, output } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { confirm } from 'devextreme/ui/dialog';

import { PipelineService } from '../../services/pipeline.service';
import { PipelineDlqSelectorComponent } from '../pipeline-dlq-selector/pipeline-dlq-selector.component';
import { PipelineQueueEditNameComponent } from '../pipeline-queue-edit-name/pipeline-queue-edit-name';
import { PipelineQueueParamComponent } from '../pipeline-queue-param/pipeline-queue-param.component';
import { PipelineQueueSelectorComponent } from '../pipeline-queue-selector/pipeline-queue-selector.component';
import { PipelineQueueWizardStore } from './+store/pipeline-queue-wizard.store';

@Component({
  selector: 'alk-pipeline-queue-wizard',
  templateUrl: './pipeline-queue-wizard.component.html',
  standalone: true,
  imports: [
    TiaraSuiteWizardComponent,
    TranslatePipe,
    PipelineQueueEditNameComponent,
    PipelineQueueSelectorComponent,
    PipelineQueueParamComponent,
    PipelineDlqSelectorComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [PipelineQueueWizardStore],
})
export class PipelineQueueWizardComponent implements OnInit {
  private readonly _pipelineQueueWizardStore = inject(PipelineQueueWizardStore);
  private readonly _pipelineService = inject(PipelineService);
  private readonly _translateService = inject(TranslateService);

  private readonly _confirmSaveTitle = this._translateService.instant('pipeline.queue.confirm.save');
  private readonly _connectionUsedMessage = this._translateService.instant('pipeline.queue.connection.already.used');

  onSave = output<Pipeline>();
  onClose = output<void>();

  workspace = input<Workspace | null>();

  ngOnInit(): void {
    this._pipelineQueueWizardStore.setWorkspace(this.workspace()!);
  }

  complete() {
    const pipeline = this.buildQueuePipeline();
    const connectionId =
      this._pipelineQueueWizardStore
        .pipelineParams()
        .find((param) => param.codParametro === PipelineQueueParams.CONNECTION_ID)?.valoreStringa || '';

    this._pipelineService.isConnectionUsedInPipelines(connectionId).subscribe({
      next: (used) => {
        if (used) {
          this.confirmSave(pipeline);
          return;
        }
        this.emitSave(pipeline);
      },
    });
  }

  close() {
    this._pipelineQueueWizardStore.reset();
    this.onClose.emit();
  }

  private confirmSave(pipeline: Pipeline) {
    const result = confirm(this._connectionUsedMessage, this._confirmSaveTitle);
    result.then((dialogResult) => {
      if (dialogResult) {
        this.emitSave(pipeline);
      }
    });
  }

  private emitSave(pipeline: Pipeline) {
    this.populatePipelineParams(pipeline);
    this.onSave.emit(pipeline);
  }

  private buildQueuePipeline(): Pipeline {
    return {
      id: undefined,
      name: this._pipelineQueueWizardStore.name(),
      description: this._pipelineQueueWizardStore.description(),
      pipelineType: PipelineType.QUEUE,
      workspace: this._pipelineQueueWizardStore.workspace()!,
      pipelineParams: this._pipelineQueueWizardStore.pipelineParams(),
    };
  }

  private populatePipelineParams(pipeline: Pipeline) {
    if (!pipeline.pipelineParams) {
      pipeline.pipelineParams = [];
    }
    const formModel = this._pipelineQueueWizardStore.pipelineQueueParamFormModel();
    pipeline.pipelineParams.push({
      codParametro: PipelineQueueParams.FOR_EACH,
      valoreStringa: formModel.forEach,
    });
    pipeline.pipelineParams.push({
      codParametro: PipelineQueueParams.KEY,
      valoreStringa: this.normalizeParamValue(formModel.key),
    });
    pipeline.pipelineParams.push({
      codParametro: PipelineQueueParams.IDEMPOTENCY,
      valoreBooleano: formModel.idempotency,
    });
    pipeline.pipelineParams.push({ codParametro: PipelineQueueParams.APPLY_IF, valoreStringa: formModel.applyIf });
    pipeline.pipelineParams.push({
      codParametro: PipelineQueueParams.PARTITION_KEY,
      valoreStringa: this.normalizeParamValue(formModel.partitionKey),
    });
    pipeline.pipelineParams.push({
      codParametro: PipelineQueueParams.OCCURRED_AT,
      valoreStringa: formModel.occurredAt,
    });
    pipeline.pipelineParams.push({ codParametro: PipelineQueueParams.BATCH_SIZE, valoreNumerico: formModel.batchSize });
    pipeline.pipelineParams.push({ codParametro: PipelineQueueParams.RETRY_TIME, valoreNumerico: formModel.retryTime });
    pipeline.pipelineParams.push({ codParametro: PipelineQueueParams.ON_EQUAL, valoreStringa: formModel.on_equal });
    pipeline.pipelineParams.push({ codParametro: PipelineQueueParams.IS_ACTIVE, valoreBooleano: false });
  }

  private normalizeParamValue(value: string | string[]): string {
    if (Array.isArray(value)) {
      return value.join(',');
    }
    return value ?? '';
  }
}
