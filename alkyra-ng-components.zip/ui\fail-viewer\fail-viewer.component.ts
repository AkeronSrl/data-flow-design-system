import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

import { FailLevel } from './models/fail-level.model';
import { FailMessage } from './models/fail-message.model';

@Component({
  imports: [],
  selector: 'akn-fail-viewer',
  standalone: true,
  templateUrl: './fail-viewer.component.html',
  styleUrls: ['./fail-viewer.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FailViewerComponent {
  @Input() failMessages: FailMessage[] | undefined = undefined;

  failLevel = FailLevel;
}
