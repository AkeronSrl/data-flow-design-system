import { TiaraSuiteWizardStepperComponent } from '@akeron-ng/tiara-ng-suite/tiara-wizard';
import { CommonModule } from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ComponentRef,
  computed,
  effect,
  Input,
  inject,
  OnChanges,
  OutputEmitterRef,
  output,
  SimpleChanges,
  signal,
  ViewChild,
  ViewContainerRef,
} from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { confirm } from 'devextreme/ui/dialog';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxPopupModule } from 'devextreme-angular/ui/popup';

import { FlowWizardStateStore } from './+store/flow-wizard-state.store';
import { FlowResolveResult, FlowWizardStep, FlowWizardStepClass } from './models/flow-wizard-step';

@Component({
  selector: 'akn-flow-wizard',
  templateUrl: './flow-wizard.component.html',
  styleUrls: ['./flow-wizard.component.scss'],
  standalone: true,
  imports: [CommonModule, TiaraSuiteWizardStepperComponent, DxButtonModule, DxPopupModule, TranslatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [FlowWizardStateStore],
})
export class FlowWizardComponent<TContext = unknown> implements AfterViewInit, OnChanges {
  @Input({ required: true }) startStep!: FlowWizardStepClass<TContext>;
  @Input() context!: TContext;
  @Input() title: string = '';
  @Input() completeButtonText: string = '';
  @Input() width: string = '80vw';
  @Input() height: string = '80vh';
  @Input() initialHistory?: string[];
  @Input() showStepper: boolean = true;

  closed: OutputEmitterRef<void> = output<void>();
  completed: OutputEmitterRef<void> = output<void>();

  @ViewChild('wizardHost', { read: ViewContainerRef }) wizardHost?: ViewContainerRef;

  private readonly _translateService: TranslateService = inject(TranslateService);
  private readonly _flowState = inject(FlowWizardStateStore);
  private readonly _changeDetectorRef = inject(ChangeDetectorRef);

  private readonly _startStep = signal<FlowWizardStepClass<TContext> | null>(null);
  private readonly _context = signal<TContext | null | undefined>(undefined);
  private readonly _hostReady = signal(false);
  private readonly _currentStep = signal<FlowWizardStep<TContext> | null>(null);

  private currentStepRef: ComponentRef<FlowWizardStep<TContext>> | null = null;

  readonly currentStepId = this._flowState.currentStepId;
  readonly history = this._flowState.history;

  private readonly _stepMap = computed(() => {
    const start = this._startStep();
    const context = this._context();
    if (!start || context == null) {
      return null;
    }

    return this.buildStepMap(start);
  });

  readonly currentStepClass = computed(() => {
    const stepMap = this._stepMap();
    const currentStepId = this.currentStepId();
    if (!stepMap || !currentStepId) {
      return null;
    }

    const stepClass = stepMap.get(currentStepId);
    if (!stepClass) {
      this.failFlow(
        `Step '${currentStepId}' is not reachable from start step '${this._startStep()?.stepId ?? 'unknown'}'.`,
      );
    }

    return stepClass;
  });

  readonly projectedTotalSteps = computed(() => {
    const currentStepClass = this.currentStepClass();
    if (!currentStepClass) {
      return 1;
    }

    const baseVisitedSteps = Math.max(0, this.history().length - 1);
    return Math.max(1, baseVisitedSteps + this.tailSpan(currentStepClass, new Set<string>()));
  });

  readonly projectedSelectedStep = computed(() => {
    return Math.max(1, this.history().length);
  });

  readonly canGoNext = computed(() => {
    const step = this._currentStep();
    const stepClass = this.currentStepClass();
    if (!step || !stepClass) {
      return false;
    }

    const candidates = this.getCandidates(stepClass);
    if (candidates.length === 0) {
      return step.canGoforward();
    }

    const resolveResult = this.resolveTransition(step, candidates);
    return step.canGoforward() && resolveResult.kind === 'next';
  });

  readonly nextButtonText = computed(() => {
    const stepClass = this.currentStepClass();
    if (stepClass && this.getCandidates(stepClass).length === 0) {
      return this.completeButtonText;
    }
    return this._translateService.instant('base.wizard.next');
  });

  constructor() {
    effect(() => {
      const hostReady = this._hostReady();
      const stepClass = this.currentStepClass();
      if (!hostReady || !stepClass) {
        return;
      }

      this.renderCurrentStep(stepClass);
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['context']) {
      this._context.set(this.context);
    }

    if (changes['startStep']) {
      if (this.startStep?.stepId) {
        if (this.initialHistory?.length) {
          this._flowState.initializeWithHistory(this.initialHistory);
        } else {
          this._flowState.initialize(this.startStep.stepId);
        }
      }
      this._startStep.set(this.startStep);
      this.initializeFlow();
    }
  }

  ngAfterViewInit(): void {
    this._hostReady.set(true);
    this.initializeFlow();
  }

  goToNextStep(): void {
    if (!this.canGoNext()) {
      return;
    }

    const currentStep = this._currentStep();
    const stepClass = this.currentStepClass();
    if (!currentStep || !stepClass) {
      return;
    }

    currentStep.onForward();

    const candidates = this.getCandidates(stepClass);
    if (candidates.length === 0) {
      this.completed.emit();
      return;
    }

    const resolveResult = this.resolveTransition(currentStep, candidates);
    if (resolveResult.kind === 'pending') {
      return;
    }

    const nextId = resolveResult.next.stepId;
    const history = this.history();
    if (history.includes(nextId)) {
      this.failFlow(`Loop detected in history while navigating to '${nextId}'.`);
    }

    this._flowState.push(nextId);
  }

  goToPreviousStep(): void {
    if (this.isFirstPage()) {
      return;
    }

    const currentStep = this._currentStep();
    currentStep?.onBackward();
    this._flowState.pop();
  }

  isFirstPage(): boolean {
    return this.history().length <= 1;
  }

  isNextDisabled(): boolean {
    return !this.canGoNext();
  }

  close(): void {
    const result = confirm(this._translateService.instant('base.exit.confirm'), '');
    result.then((dialogResult) => {
      if (dialogResult) {
        this.closed.emit();
      }
    });
  }

  private initializeFlow(): void {
    const startStep = this._startStep();
    if (!startStep || !this._hostReady()) {
      return;
    }

    this.getContext();
    this.buildStepMap(startStep);
    if (this.initialHistory?.length) {
      this._flowState.initializeWithHistory(this.initialHistory);
    } else {
      this._flowState.initialize(startStep.stepId);
    }
  }

  private renderCurrentStep(stepClass: FlowWizardStepClass<TContext>): void {
    const wizardHost = this.wizardHost;
    if (!wizardHost) {
      return;
    }

    this.currentStepRef?.destroy();
    wizardHost.clear();

    const componentRef = wizardHost.createComponent(stepClass);
    this.currentStepRef = componentRef;
    this._currentStep.set(componentRef.instance);
    this._changeDetectorRef.markForCheck();
  }

  private tailSpan(stepClass: FlowWizardStepClass<TContext>, visited: Set<string>): number {
    if (visited.has(stepClass.stepId)) {
      this.failFlow(`Loop detected while calculating tail span at step '${stepClass.stepId}'.`);
    }
    visited.add(stepClass.stepId);

    const candidates = this.getCandidates(stepClass);
    if (candidates.length === 0) {
      return 1;
    }

    if (candidates.length > 1) {
      return 2;
    }

    return 1 + this.tailSpan(candidates[0], visited);
  }

  private resolveTransition(
    step: FlowWizardStep<TContext>,
    candidates: readonly FlowWizardStepClass<TContext>[],
  ): FlowResolveResult<TContext> {
    const resolveResult = step.resolveNext(this.getContext(), candidates);
    if (resolveResult.kind === 'next') {
      this.validateNextTransition(candidates, resolveResult.next);
    }

    return resolveResult;
  }

  private getCandidates(stepClass: FlowWizardStepClass<TContext>): readonly FlowWizardStepClass<TContext>[] {
    const candidates = stepClass.candidates;
    if (!Array.isArray(candidates)) {
      this.failFlow(`Step '${stepClass.stepId}' returned an invalid next candidates value.`);
    }

    this.ensureUniqueCandidateIds(stepClass.stepId, candidates);
    return candidates;
  }

  private buildStepMap(startStep: FlowWizardStepClass<TContext>): Map<string, FlowWizardStepClass<TContext>> {
    const stepMap = new Map<string, FlowWizardStepClass<TContext>>();

    const visit = (stepClass: FlowWizardStepClass<TContext>): void => {
      this.assertStepClassHasId(stepClass);
      if (this.isStepAlreadyMapped(stepMap, stepClass)) {
        return;
      }

      stepMap.set(stepClass.stepId, stepClass);
      this.visitCandidates(stepClass, visit);
    };

    visit(startStep);
    return stepMap;
  }

  private assertStepClassHasId(
    stepClass: FlowWizardStepClass<TContext> | null | undefined,
  ): asserts stepClass is FlowWizardStepClass<TContext> {
    if (!stepClass || !stepClass.stepId) {
      this.failFlow('A step class is missing a valid stepId.');
    }
  }

  private isStepAlreadyMapped(
    stepMap: Map<string, FlowWizardStepClass<TContext>>,
    stepClass: FlowWizardStepClass<TContext>,
  ): boolean {
    const existing = stepMap.get(stepClass.stepId);
    if (!existing) {
      return false;
    }

    if (existing !== stepClass) {
      this.failFlow(`Duplicate step id '${stepClass.stepId}' detected with different step classes.`);
    }

    return true;
  }

  private visitCandidates(
    stepClass: FlowWizardStepClass<TContext>,
    visit: (candidate: FlowWizardStepClass<TContext>) => void,
  ): void {
    const nextCandidates = this.getCandidates(stepClass);
    for (const candidate of nextCandidates) {
      if (!candidate || !candidate.stepId) {
        this.failFlow(`Step '${stepClass.stepId}' declared an invalid next step class.`);
      }
      visit(candidate);
    }
  }

  private ensureUniqueCandidateIds(currentStepId: string, candidates: readonly FlowWizardStepClass<TContext>[]): void {
    const seen = new Set<string>();
    for (const candidate of candidates) {
      if (!candidate.stepId) {
        this.failFlow(`Step '${currentStepId}' declared an invalid next step class.`);
      }

      if (seen.has(candidate.stepId)) {
        this.failFlow(`Step '${currentStepId}' declared duplicate next candidate id '${candidate.stepId}'.`);
      }
      seen.add(candidate.stepId);
    }
  }

  private validateNextTransition(
    candidates: readonly FlowWizardStepClass<TContext>[],
    nextStepClass: FlowWizardStepClass<TContext>,
  ): void {
    if (!candidates.some((candidate) => candidate === nextStepClass)) {
      const candidateIds = candidates.map((candidate) => candidate.stepId).join(', ');
      this.failFlow(`Step resolved next '${nextStepClass.stepId}' outside current candidates [${candidateIds}].`);
    }
  }

  private getContext(): TContext {
    const context = this._context();
    if (context == null) {
      this.failFlow('Flow context is required.');
    }

    return context;
  }

  private failFlow(message: string): never {
    const fullMessage = `[FlowWizard] ${message}`;
    console.error(fullMessage);
    throw new Error(fullMessage);
  }
}
