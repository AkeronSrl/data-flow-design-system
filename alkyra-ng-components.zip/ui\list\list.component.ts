import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FocusOutEvent } from 'devextreme/ui/text_box';
import { DxButtonModule } from 'devextreme-angular/ui/button';
import { DxListModule } from 'devextreme-angular/ui/list';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';

import { ListButton } from './models/list-button.model';
import { ListItem } from './models/list-item.model';

@Component({
  selector: 'alk-list',
  standalone: true,
  imports: [CommonModule, DxListModule, DxButtonModule, DxTextBoxModule],
  templateUrl: './list.component.html',
  styleUrl: './list.component.scss',
})
export class ListComponent<T extends ListItem> {
  @Input() text: string = '';
  @Input() items: T[] = [];
  @Input() buttons: ListButton<T>[] = [];

  @Output() onAddedItem = new EventEmitter<void>();
  @Output() onDeletedItem = new EventEmitter<T>();
  @Output() onUpdatedItem = new EventEmitter<T>();

  onItemAdded() {
    this.onAddedItem.emit();
  }

  onItemUpdated(event: FocusOutEvent, item: T) {
    const newValue = event.component.option('value') || '';
    if (newValue === item.description) {
      return;
    }
    item.description = newValue;
    this.onUpdatedItem.emit(item);
  }

  onItemDeleted(item: T) {
    this.onDeletedItem.emit(item);
  }
}
