import { TiaraCircularIllustrationComponent } from '@akeron-ng/tiara-ng';
import { CommonModule } from '@angular/common';
import {
  afterNextRender,
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  Injector,
  inject,
  input,
  output,
  signal,
  viewChild,
} from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxTreeViewComponent, DxTreeViewModule } from 'devextreme-angular/ui/tree-view';

import {
  SchemaDiscoveryExpandEvent,
  SchemaDiscoveryHeaderMeta,
  SchemaDiscoveryNode,
  SchemaDiscoverySelectionEvent,
} from './models/schema-discovery.model';

@Component({
  selector: 'alk-schema-discovery',
  standalone: true,
  imports: [
    CommonModule,
    TranslatePipe,
    DxLoadIndicatorModule,
    DxTextBoxModule,
    DxTreeViewModule,
    TiaraCircularIllustrationComponent,
  ],
  templateUrl: './schema-discovery.component.html',
  styleUrl: './schema-discovery.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SchemaDiscoveryComponent {
  private readonly _injector = inject(Injector);
  private readonly pendingExpandNodeIds = signal<string[]>([]);
  private readonly restoreScrollNodeId = signal<string | null>(null);
  private readonly treeView = viewChild<DxTreeViewComponent>('treeView');
  private preservedTreeScrollTop: number | null = null;
  private isSyncingSelection = false;
  private readonly _restoreTreeScrollEffect = effect(() => {
    const nodeId = this.restoreScrollNodeId();
    if (!nodeId) {
      return;
    }

    this.visibleNodes();
    afterNextRender(() => this.restoreTreeScrollPosition(nodeId), { injector: this._injector });
  });
  private readonly _syncTreeSelectionEffect = effect(() => {
    this.visibleNodes();
    const selectedNodeId = this.selectedNodeId();
    afterNextRender(() => this.syncTreeSelection(selectedNodeId), { injector: this._injector });
  });

  readonly title = input('');
  readonly headerMeta = input<SchemaDiscoveryHeaderMeta[]>([]);
  readonly nodes = input<SchemaDiscoveryNode[]>([]);
  readonly loading = input(false);
  readonly error = input<string | null>(null);
  readonly emptyMessage = input('query.analyzer.schema.empty');
  readonly searchPlaceholder = input('query.analyzer.schema.search.placeholder');
  readonly noResultsMessage = input('query.analyzer.schema.no.results');
  readonly showHeader = input(true);
  readonly showLoadingState = input(true);
  readonly showSearch = input(true);
  readonly selectedNodeId = input<string | null>(null);

  readonly nodeSelected = output<SchemaDiscoverySelectionEvent>();
  readonly nodeClicked = output<SchemaDiscoverySelectionEvent>();
  readonly nodeExpandRequested = output<SchemaDiscoveryExpandEvent>();
  readonly nodeExpanded = output<SchemaDiscoveryExpandEvent>();
  readonly nodeCollapsed = output<SchemaDiscoveryExpandEvent>();

  protected readonly searchQuery = signal('');
  protected readonly visibleNodes = computed(() => this.filterNodes(this.nodes(), this.searchQuery()));
  protected readonly hasVisibleNodes = computed(() => this.visibleNodes().length > 0);
  protected readonly shouldShowSearch = computed(
    () => this.showSearch() && (this.nodes().length > 0 || this.searchQuery().length > 0),
  );
  protected readonly summaryText = computed(() => this.buildSummaryText(this.headerMeta()));
  protected readonly normalizedTitle = computed(() => this.title().toUpperCase());

  protected onSearchChange(value: string | null | undefined): void {
    this.searchQuery.set((value ?? '').trim());
  }

  protected onItemSelectionChanged(event: any): void {
    if (this.isSyncingSelection) {
      return;
    }

    const node = this.getEventNode(event);
    if (!node || !event?.node?.selected) {
      return;
    }

    if (!node.selectable) {
      this.clearTreeSelection(event);
      return;
    }

    this.nodeSelected.emit({ nodeId: node.id, node });
  }

  protected onItemExpanded(event: any): void {
    const node = event?.itemData as SchemaDiscoveryNode | undefined;
    if (!node) {
      return;
    }

    this.captureTreeScrollPosition();
    this.restoreScrollNodeId.set(node.id);
    this.nodeExpanded.emit({ nodeId: node.id, node });
    this.clearPendingNodeAfterRender(node.id);
  }

  protected onItemClick(event: any): void {
    const node = this.getEventNode(event);
    if (node?.selectable) {
      this.nodeClicked.emit({ nodeId: node.id, node });
    }

    if (!this.shouldEmitExpandRequest(node, event)) {
      return;
    }

    this.markNodeAsPending(node);
    this.nodeExpandRequested.emit({ nodeId: node.id, node });
  }

  protected onItemCollapsed(event: any): void {
    const node = event?.itemData as SchemaDiscoveryNode | undefined;
    if (!node) {
      return;
    }

    this.clearPendingNode(node.id);
    this.nodeCollapsed.emit({ nodeId: node.id, node });
  }

  protected isNodePending(node: SchemaDiscoveryNode): boolean {
    return this.pendingExpandNodeIds().includes(node.id);
  }

  private buildSummaryText(headerMeta: SchemaDiscoveryHeaderMeta[]): string {
    const type = this.getHeaderType(headerMeta);
    const description = this.getHeaderDescription(headerMeta);
    return [type, description].filter(Boolean).join(' - ');
  }

  private isDescriptionMeta(item: SchemaDiscoveryHeaderMeta): boolean {
    const label = item.label?.toLowerCase() ?? '';
    return label === 'description' || label.includes('description');
  }

  private getHeaderType(headerMeta: SchemaDiscoveryHeaderMeta[]): string {
    return headerMeta[0]?.value?.trim() ?? '';
  }

  private getHeaderDescription(headerMeta: SchemaDiscoveryHeaderMeta[]): string {
    return headerMeta.find((item) => this.isDescriptionMeta(item))?.value?.trim() ?? '';
  }

  private filterNodes(nodes: SchemaDiscoveryNode[], query: string): SchemaDiscoveryNode[] {
    const normalizedQuery = query.trim().toLowerCase();
    if (!normalizedQuery) {
      return nodes;
    }

    return nodes
      .map((node) => this.filterNode(node, normalizedQuery))
      .filter((node): node is SchemaDiscoveryNode => !!node);
  }

  private filterNode(node: SchemaDiscoveryNode, query: string): SchemaDiscoveryNode | null {
    const matches = this.matchesNode(node, query);
    const items = node.items ?? [];

    if (items.length === 0) {
      return matches ? node : null;
    }

    if (matches) {
      return {
        ...node,
        expanded: true,
      };
    }

    const children = items
      .map((child) => this.filterNode(child, query))
      .filter((child): child is SchemaDiscoveryNode => !!child);

    if (children.length === 0) {
      return null;
    }

    return {
      ...node,
      expanded: true,
      hasItems: true,
      items: children,
    };
  }

  private matchesNode(node: SchemaDiscoveryNode, query: string): boolean {
    const haystack = [node.label, node.description, node.searchText]
      .filter((value): value is string => !!value)
      .join(' ')
      .toLowerCase();

    return haystack.includes(query);
  }

  private getEventNode(event: any): SchemaDiscoveryNode | undefined {
    return event?.itemData as SchemaDiscoveryNode | undefined;
  }

  private shouldEmitExpandRequest(node: SchemaDiscoveryNode | undefined, event: any): node is SchemaDiscoveryNode {
    return !!node && !!node.hasItems && !event?.node?.expanded;
  }

  private markNodeAsPending(node: SchemaDiscoveryNode): void {
    if (!this.hasIdlePlaceholder(node) || this.isNodePending(node)) {
      return;
    }

    this.pendingExpandNodeIds.update((ids) => [...ids, node.id]);
  }

  private clearPendingNodeAfterRender(nodeId: string): void {
    afterNextRender(
      () => {
        this.clearPendingNode(nodeId);
      },
      { injector: this._injector },
    );
  }

  private clearPendingNode(nodeId: string): void {
    this.pendingExpandNodeIds.update((ids) => ids.filter((id) => id !== nodeId));
  }

  private hasIdlePlaceholder(node: SchemaDiscoveryNode): boolean {
    return !!node.items?.some((item) => item.kind === 'status' && !item.label);
  }

  private captureTreeScrollPosition(): void {
    const scrollable = this.treeView()?.instance?.getScrollable?.();
    this.preservedTreeScrollTop = scrollable?.scrollTop() ?? null;
  }

  private restoreTreeScrollPosition(nodeId: string): void {
    const scrollTop = this.preservedTreeScrollTop;
    const treeView = this.treeView()?.instance;
    if (scrollTop === null || !treeView) {
      this.clearScrollRestoreState();
      return;
    }

    void treeView.updateDimensions().then(() => {
      const scrollable = treeView.getScrollable();
      if (scrollable.scrollTop() !== scrollTop) {
        scrollable.scrollTo({ top: scrollTop });
      }

      if (!this.isNodeLoading(nodeId, this.visibleNodes())) {
        this.clearScrollRestoreState();
      }
    });
  }

  private isNodeLoading(nodeId: string, nodes: SchemaDiscoveryNode[]): boolean {
    for (const node of nodes) {
      if (node.id === nodeId) {
        return node.loading === true;
      }

      if (node.items && this.isNodeLoading(nodeId, node.items)) {
        return true;
      }
    }

    return false;
  }

  private clearScrollRestoreState(): void {
    this.preservedTreeScrollTop = null;
    this.restoreScrollNodeId.set(null);
  }

  private clearTreeSelection(event: any): void {
    event?.component?.unselectAll?.();
  }

  private syncTreeSelection(selectedNodeId: string | null): void {
    const treeView = this.treeView()?.instance as any;
    if (!treeView) {
      return;
    }

    const selectionState = this.buildSelectionState(treeView, selectedNodeId);
    if (this.shouldClearTreeSelection(selectionState)) {
      this.clearSyncedTreeSelection(selectionState.treeView);
      return;
    }

    if (!selectionState.selectedNodeId || this.isTreeSelectionAlreadySynced(selectionState)) {
      return;
    }

    this.selectSyncedTreeItem(selectionState);
  }

  private buildSelectionState(treeView: any, selectedNodeId: string | null): SchemaDiscoverySelectionState {
    return {
      treeView,
      selectedNodeId,
      selectedKeys: this.getSelectedNodeKeys(treeView),
    };
  }

  private getSelectedNodeKeys(treeView: any): string[] {
    const keys = treeView.getSelectedNodeKeys?.();
    return Array.isArray(keys) ? keys : [];
  }

  private runWithSyncedSelection(action: () => void): void {
    this.isSyncingSelection = true;
    try {
      action();
    } finally {
      queueMicrotask(() => {
        this.isSyncingSelection = false;
      });
    }
  }

  private shouldClearTreeSelection(selectionState: SchemaDiscoverySelectionState): boolean {
    return (
      selectionState.selectedKeys.length > 0 &&
      (!selectionState.selectedNodeId || !this.hasNode(selectionState.selectedNodeId, this.visibleNodes()))
    );
  }

  private clearSyncedTreeSelection(treeView: any): void {
    this.runWithSyncedSelection(() => treeView.unselectAll?.());
  }

  private isTreeSelectionAlreadySynced(selectionState: SchemaDiscoverySelectionState): boolean {
    return selectionState.selectedKeys.length === 1 && selectionState.selectedKeys[0] === selectionState.selectedNodeId;
  }

  private selectSyncedTreeItem(selectionState: SchemaDiscoverySelectionState): void {
    this.runWithSyncedSelection(() => {
      selectionState.treeView.unselectAll?.();
      selectionState.treeView.selectItem?.(selectionState.selectedNodeId);
    });
  }

  private hasNode(nodeId: string, nodes: SchemaDiscoveryNode[]): boolean {
    for (const node of nodes) {
      if (node.id === nodeId) {
        return true;
      }

      if (node.items && this.hasNode(nodeId, node.items)) {
        return true;
      }
    }

    return false;
  }
}

interface SchemaDiscoverySelectionState {
  treeView: any;
  selectedNodeId: string | null;
  selectedKeys: string[];
}
