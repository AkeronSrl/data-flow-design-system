import {
  CdkConnectedOverlay,
  ConnectedPosition,
  Overlay,
  OverlayContainer,
  OverlayModule,
  ScrollStrategy,
} from '@angular/cdk/overlay';
import { CommonModule } from '@angular/common';
import { Component, computed, effect, inject, input, OnDestroy, output, signal, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ValidationCallbackData } from 'devextreme-angular/common';
import { DxTextAreaComponent, DxTextAreaModule } from 'devextreme-angular/ui/text-area';
import { DxValidatorComponent, DxValidatorModule } from 'devextreme-angular/ui/validator';

import {
  ExpressionEditorConfig,
  ExpressionLintWarning,
  ExpressionSuggestionItem,
  ExpressionValidationCallback,
  ExpressionValidationState,
} from './models/expression-editor.model';
import {
  applySuggestionAtCaret,
  buildExpressionSuggestions,
  buildExpressionWarnings,
} from './services/expression-suggestion-engine.service';

const DEFAULT_EDITOR_CONFIG: ExpressionEditorConfig = {
  dialect: 'formula',
  columns: [],
  warnOnUnknownFunctions: true,
  maxSuggestions: 50,
};

@Component({
  selector: 'alk-smart-expression-editor',
  standalone: true,
  imports: [CommonModule, DxTextAreaModule, DxValidatorModule, OverlayModule],
  templateUrl: './smart-expression-editor.component.html',
  styleUrl: './smart-expression-editor.component.scss',
})
export class SmartExpressionEditorComponent implements OnDestroy {
  value = input<string>('');
  placeholder = input<string>('');
  height = input<string | number>(120);
  disabled = input<boolean>(false);
  readOnly = input<boolean>(false);
  showSuggestionsOnFocus = input<boolean>(false);
  config = input<ExpressionEditorConfig>(DEFAULT_EDITOR_CONFIG);
  validationState = input<ExpressionValidationState>('none');
  validationMessage = input<string>('');
  validationCallback = input<ExpressionValidationCallback | null>(null);

  valueChange = output<string>();
  focusOut = output<void>();
  warningsChange = output<ExpressionLintWarning[]>();

  protected readonly editorValue = signal<string>('');
  protected readonly warnings = signal<ExpressionLintWarning[]>([]);
  protected readonly suggestions = signal<ExpressionSuggestionItem[]>([]);
  protected readonly suggestionsOpen = signal<boolean>(false);
  protected readonly selectedSuggestionIndex = signal<number>(0);
  protected readonly overlayWidth = signal<number>(220);
  protected readonly resolvedPlaceholder = computed<string>(() => {
    const explicitPlaceholder = this.placeholder();
    if (explicitPlaceholder?.trim()) {
      return explicitPlaceholder;
    }
    if (this.config()?.dialect !== 'formula') {
      return '';
    }
    return this._translateService.instant('formula.value.placeholder');
  });
  protected readonly shortcutTooltip = computed(() => this._translateService.instant('expression.editor.shortcut'));
  protected readonly hasAsyncValidationCallback = computed<boolean>(() => !!this.validationCallback());
  protected readonly validationActive = computed<boolean>(
    () => this.hasAsyncValidationCallback() || this.validationState() !== 'none',
  );
  protected readonly resolvedValidatorMessage = computed<string>(() => this.validationMessage()?.trim() ?? '');
  protected readonly suggestionPositions: ConnectedPosition[] = [
    {
      originX: 'start',
      originY: 'bottom',
      overlayX: 'start',
      overlayY: 'top',
      offsetY: 2,
    },
  ];
  private readonly overlayStackBaseZIndex = 2147483643;

  private readonly _overlay = inject(Overlay);
  private readonly _overlayContainer = inject(OverlayContainer);
  private readonly _translateService = inject(TranslateService);
  protected readonly suggestionScrollStrategy: ScrollStrategy = this._overlay.scrollStrategies.reposition();
  private validationRefreshTimer: ReturnType<typeof setTimeout> | null = null;

  @ViewChild(DxTextAreaComponent) private readonly textArea?: DxTextAreaComponent;
  @ViewChild('targetValidator') private readonly targetValidator?: DxValidatorComponent;
  @ViewChild(CdkConnectedOverlay) private readonly suggestionsOverlay?: CdkConnectedOverlay;

  constructor() {
    effect(() => {
      const nextValue = this.value() ?? '';
      const configuration = this.config() ?? DEFAULT_EDITOR_CONFIG;
      if (nextValue !== this.editorValue()) {
        this.editorValue.set(nextValue);
      }
      this.updateWarnings(nextValue, configuration);
    });

    effect(() => {
      if (this.hasAsyncValidationCallback()) {
        return;
      }

      this.validationState();
      this.validationMessage();
      this.scheduleValidationRefresh();
    });
  }

  protected onValueChanged(event: { value?: string }): void {
    const nextValue = event.value ?? '';
    this.editorValue.set(nextValue);
    this.valueChange.emit(nextValue);
    this.updateWarnings(nextValue, this.config());
  }

  protected onEditorFocusOut(event: { event?: FocusEvent }): void {
    this.syncEditorValueFromDom(event.event);
    this.refreshValidationStatus();
    this.focusOut.emit();
    setTimeout(() => this.closeSuggestions(), 100);
  }

  protected onEditorFocusIn(event: { event?: FocusEvent }): void {
    if (!this.shouldOpenSuggestionsOnFocus()) {
      return;
    }

    this.refreshSuggestions(true, event.event);
  }

  protected onEditorKeyDown(event: { event?: KeyboardEvent }): void {
    const keyboardEvent = event.event;
    if (!this.canProcessKeyboardEvent(keyboardEvent)) {
      return;
    }

    if (this.tryOpenSuggestionsManually(keyboardEvent)) {
      return;
    }

    this.handleSuggestionNavigation(keyboardEvent);
  }

  protected onEditorKeyUp(event: { event?: KeyboardEvent }): void {
    const keyboardEvent = event.event;
    if (!this.canProcessKeyboardEvent(keyboardEvent) || this.isModifierCombination(keyboardEvent)) {
      return;
    }

    if (this.shouldRefreshSuggestionsForKey(keyboardEvent.key)) {
      this.refreshSuggestions(false, keyboardEvent);
    }
  }

  protected onSuggestionMouseDown(event: MouseEvent): void {
    event.preventDefault();
  }

  protected onSuggestionClick(index: number): void {
    const selected = this.suggestions()[index];
    if (!selected) {
      return;
    }
    this.applySuggestion(selected);
  }

  protected onSuggestionsOverlayAttach(): void {
    const overlayRef = this.suggestionsOverlay?.overlayRef;
    if (!overlayRef) {
      return;
    }

    const base = this.overlayStackBaseZIndex;
    const overlayContainer = this._overlayContainer.getContainerElement();
    const hostElement = overlayRef.hostElement as HTMLElement;
    const globalOverlayWrapper = hostElement.classList.contains('cdk-global-overlay-wrapper')
      ? hostElement
      : (hostElement.closest('.cdk-global-overlay-wrapper') as HTMLElement | null);

    // DevExtreme popups can sit above default CDK overlay layers: promote the entire CDK stack.
    overlayContainer.style.zIndex = String(base);
    overlayContainer.style.pointerEvents = 'none';

    if (globalOverlayWrapper) {
      globalOverlayWrapper.style.zIndex = String(base + 1);
      globalOverlayWrapper.style.pointerEvents = 'none';
    }

    hostElement.style.zIndex = String(base + 2);
    hostElement.style.pointerEvents = 'auto';
    overlayRef.overlayElement.style.zIndex = String(base + 3);
    overlayRef.overlayElement.style.pointerEvents = 'auto';
    overlayRef.updatePosition();
  }

  protected suggestionKindLabel(kind: ExpressionSuggestionItem['kind']): string {
    return this._translateService.instant(`expression.editor.kind.${kind}`);
  }

  protected warningMessage(warning: ExpressionLintWarning): string {
    if (warning.code === 'where-prefix-missing') {
      return this._translateService.instant('expression.editor.warning.wherePrefix');
    }
    if (warning.code === 'unknown-function') {
      return this._translateService.instant('expression.editor.warning.unknownFunction', { token: warning.token });
    }
    return warning.message;
  }

  protected readonly validationRuleCallback = (_params: ValidationCallbackData): boolean => {
    return this.validationState() !== 'invalid';
  };

  protected readonly asyncValidationRuleCallback = (params: ValidationCallbackData) => {
    const callback = this.validationCallback();
    if (!callback) {
      return true;
    }

    return callback(params);
  };

  private updateWarnings(value: string, config: ExpressionEditorConfig): void {
    const nextWarnings = buildExpressionWarnings(value, this.normalizeConfig(config));
    this.warnings.set(nextWarnings);
    this.warningsChange.emit(nextWarnings);
  }

  private canProcessKeyboardEvent(event: KeyboardEvent | undefined): event is KeyboardEvent {
    return !!event && !this.disabled() && !this.readOnly();
  }

  private tryOpenSuggestionsManually(keyboardEvent: KeyboardEvent): boolean {
    if (!(keyboardEvent.ctrlKey && keyboardEvent.code === 'Space')) {
      return false;
    }

    keyboardEvent.preventDefault();
    this.refreshSuggestions(true, keyboardEvent);
    return true;
  }

  private handleSuggestionNavigation(keyboardEvent: KeyboardEvent): void {
    if (!this.hasOpenSuggestions()) {
      return;
    }

    switch (keyboardEvent.key) {
      case 'ArrowDown':
        keyboardEvent.preventDefault();
        this.moveSelection(1);
        return;
      case 'ArrowUp':
        keyboardEvent.preventDefault();
        this.moveSelection(-1);
        return;
      case 'Escape':
        keyboardEvent.preventDefault();
        this.closeSuggestions();
        return;
      case 'Enter':
      case 'Tab':
        keyboardEvent.preventDefault();
        this.selectCurrentSuggestion();
        return;
      default:
        return;
    }
  }

  private hasOpenSuggestions(): boolean {
    return this.suggestionsOpen() && this.suggestions().length > 0;
  }

  private isModifierCombination(keyboardEvent: KeyboardEvent): boolean {
    return keyboardEvent.ctrlKey || keyboardEvent.altKey || keyboardEvent.metaKey;
  }

  private shouldRefreshSuggestionsForKey(key: string): boolean {
    return key === 'Backspace' || key === 'Delete' || /^[A-Za-z0-9_.]$/.test(key);
  }

  private shouldOpenSuggestionsOnFocus(): boolean {
    if (!this.showSuggestionsOnFocus()) {
      return false;
    }
    if (this.disabled()) {
      return false;
    }
    if (this.readOnly()) {
      return false;
    }
    return true;
  }

  private normalizeConfig(config: ExpressionEditorConfig | null | undefined): ExpressionEditorConfig {
    return {
      ...DEFAULT_EDITOR_CONFIG,
      ...(config ?? {}),
      columns: config?.columns ?? [],
    };
  }

  private refreshSuggestions(manualTrigger: boolean, triggerEvent?: Event): void {
    const textarea = this.getTextAreaElement(triggerEvent);
    const caret = textarea?.selectionStart ?? this.editorValue().length;
    const suggestions = buildExpressionSuggestions(
      this.editorValue(),
      caret,
      this.normalizeConfig(this.config()),
      manualTrigger,
    );

    this.suggestions.set(suggestions);
    this.selectedSuggestionIndex.set(0);
    this.suggestionsOpen.set(suggestions.length > 0);
    this.overlayWidth.set(Math.max(220, Math.round(textarea?.getBoundingClientRect().width ?? 220)));
  }

  private selectCurrentSuggestion(): void {
    const suggestions = this.suggestions();
    const selected = suggestions[this.selectedSuggestionIndex()];
    if (!selected) {
      return;
    }
    this.applySuggestion(selected);
  }

  private applySuggestion(suggestion: ExpressionSuggestionItem): void {
    const textarea = this.getTextAreaElement();
    const caret = textarea?.selectionStart ?? this.editorValue().length;
    const applied = applySuggestionAtCaret(this.editorValue(), caret, suggestion);

    this.editorValue.set(applied.value);
    this.valueChange.emit(applied.value);
    this.updateWarnings(applied.value, this.config());
    this.closeSuggestions();

    setTimeout(() => {
      const element = this.getTextAreaElement();
      if (!element) {
        return;
      }
      element.focus();
      element.setSelectionRange(applied.caret, applied.caret);
    }, 0);
  }

  private moveSelection(step: number): void {
    const currentSuggestions = this.suggestions();
    if (!currentSuggestions.length) {
      this.selectedSuggestionIndex.set(0);
      return;
    }
    const maxIndex = currentSuggestions.length - 1;
    const next = this.selectedSuggestionIndex() + step;
    if (next < 0) {
      this.selectedSuggestionIndex.set(maxIndex);
      return;
    }
    if (next > maxIndex) {
      this.selectedSuggestionIndex.set(0);
      return;
    }
    this.selectedSuggestionIndex.set(next);
  }

  private closeSuggestions(): void {
    this.suggestionsOpen.set(false);
    this.suggestions.set([]);
    this.selectedSuggestionIndex.set(0);
    this.overlayWidth.set(220);
  }

  private scheduleValidationRefresh(): void {
    if (this.validationRefreshTimer) {
      clearTimeout(this.validationRefreshTimer);
    }

    this.validationRefreshTimer = setTimeout(() => {
      this.refreshValidationStatus();
    }, 0);
  }

  private refreshValidationStatus(): void {
    const validator = this.targetValidator?.instance;
    if (!validator) {
      return;
    }

    if (!this.validationActive()) {
      return;
    }

    validator.validate();
  }

  private syncEditorValueFromDom(event?: Event): void {
    const textarea = this.getTextAreaElement(event);
    const nextValue = textarea?.value ?? this.editorValue();
    if (nextValue === this.editorValue()) {
      return;
    }
    this.editorValue.set(nextValue);
    this.valueChange.emit(nextValue);
    this.updateWarnings(nextValue, this.config());
  }

  private getTextAreaElement(event?: Event): HTMLTextAreaElement | null {
    if (event?.target instanceof HTMLTextAreaElement) {
      return event.target;
    }

    const componentElement = this.textArea?.instance.element() as HTMLElement | undefined;
    if (!componentElement) {
      return null;
    }

    return componentElement.querySelector('textarea');
  }

  ngOnDestroy(): void {
    if (this.validationRefreshTimer) {
      clearTimeout(this.validationRefreshTimer);
      this.validationRefreshTimer = null;
    }
  }
}
