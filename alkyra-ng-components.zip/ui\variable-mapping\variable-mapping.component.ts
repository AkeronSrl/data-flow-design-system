import { TiaraSectionPanelComponent } from '@akeron-ng/tiara-ng/tiara-section-panel';
import { MappedVariable, MappingVariable, VariableMappings } from '@alkyra/ui/variable-mapping/variable-mapping.model';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, input, signal } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';

const SQL_IDENTIFIER_PATTERN = /^[A-Za-z_][A-Za-z0-9_]*$/;

@Component({
  selector: 'alk-variable-mapping',
  standalone: true,
  imports: [CommonModule, DxSelectBoxModule, DxTextBoxModule, TranslatePipe, TiaraSectionPanelComponent],
  templateUrl: './variable-mapping.component.html',
  styleUrl: './variable-mapping.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class VariableMappingComponent {
  leftVariables = input<MappingVariable[]>([]);
  rightVariables = input<MappingVariable[]>([]);
  textEditEnabled = input<boolean>(false);
  requiredRightVariables = input<MappingVariable[]>([]);

  private readonly _selectedMappings = signal<Record<string, string>>({});
  private readonly _lastSignature = signal<string>('');

  readonly hasVariables = computed(() => this.leftVariables().length > 0 && this.rightVariables().length > 0);

  constructor() {
    effect(() => {
      const signature = this.buildSignature(this.leftVariables(), this.rightVariables(), this.textEditEnabled());
      if (signature === this._lastSignature()) {
        return;
      }

      this._lastSignature.set(signature);

      const next = this.buildAutoMappings(this.leftVariables(), this.rightVariables());
      this._selectedMappings.set(next);
    });
  }

  isValid(): boolean {
    const mappedVariables = this.getMappedVariables().mappedVariables;
    if (mappedVariables.length === 0) {
      return false;
    }

    const rightCandidates = this.buildRightCandidates();
    const usedRight = this.validateAndCollectUsedRightNames(mappedVariables, rightCandidates);
    if (!usedRight) {
      return false;
    }

    return this.areRequiredRightVariablesMapped(usedRight);
  }

  getMappedVariables(): VariableMappings {
    const mappedVariables = this.leftVariables()
      .map((left) => {
        const rightVariableName = this._selectedMappings()[left.name];
        if (!rightVariableName) {
          return null;
        }

        return {
          leftVariableName: left.name,
          rightVariableName,
        };
      })
      .filter((item): item is { leftVariableName: string; rightVariableName: string } => !!item);

    return { mappedVariables };
  }

  getSelectedRightName(leftVariableName: string): string {
    return this._selectedMappings()[leftVariableName] ?? '';
  }

  getAllowedRightVariables(leftVariableName: string): MappingVariable[] {
    const selectedMappings = this._selectedMappings();
    const currentSelection = selectedMappings[leftVariableName];

    const busyRightNames = new Set<string>(
      Object.entries(selectedMappings)
        .filter(([leftName, rightName]) => leftName !== leftVariableName && !!rightName)
        .map(([, rightName]) => rightName),
    );

    return this.rightVariables().filter(
      (candidate) => candidate.name === currentSelection || !busyRightNames.has(candidate.name),
    );
  }

  onMappingChanged(leftVariableName: string, rightVariableName: string | null | undefined): void {
    const normalizedRightName = rightVariableName?.trim() ?? '';

    this._selectedMappings.update((current) => {
      const next = { ...current };

      if (!normalizedRightName) {
        delete next[leftVariableName];
        return next;
      }

      for (const [key, value] of Object.entries(next)) {
        if (key !== leftVariableName && value === normalizedRightName) {
          delete next[key];
        }
      }

      next[leftVariableName] = normalizedRightName;
      return next;
    });
  }

  private buildSignature(left: MappingVariable[], right: MappingVariable[], textEditEnabled: boolean): string {
    const leftPart = left.map((item) => item.name).join('|');
    const rightPart = right.map((item) => item.name).join('|');
    return `${leftPart}::${rightPart}::${textEditEnabled ? 'text' : 'select'}`;
  }

  private buildAutoMappings(left: MappingVariable[], right: MappingVariable[]): Record<string, string> {
    const rightByName = this.indexRightNamesByName(right);
    return this.createAutoMappings(left, rightByName);
  }

  private buildRightCandidates(): Set<string> {
    return new Set(this.rightVariables().map((item) => this.trimName(item.name)));
  }

  private validateAndCollectUsedRightNames(
    mappedVariables: MappedVariable[],
    rightCandidates: Set<string>,
  ): Set<string> | null {
    const textEditEnabled = this.textEditEnabled();
    const usedRight = new Set<string>();

    for (const mappedVariable of mappedVariables) {
      const rightName = this.trimName(mappedVariable.rightVariableName);
      if (!SQL_IDENTIFIER_PATTERN.test(mappedVariable.rightVariableName)) {
        return null;
      }
      if (!textEditEnabled && !rightCandidates.has(rightName)) {
        return null;
      }
      if (usedRight.has(rightName)) {
        return null;
      }
      usedRight.add(rightName);
    }

    return usedRight;
  }

  private areRequiredRightVariablesMapped(usedRight: Set<string>): boolean {
    const requiredRight = this.requiredRightVariables().map((item) => this.trimName(item.name));
    return requiredRight.every((requiredVariable) => usedRight.has(requiredVariable));
  }

  private indexRightNamesByName(right: MappingVariable[]): Map<string, string> {
    const rightByName = new Map<string, string>();

    for (const candidate of right) {
      const candidateName = this.trimName(candidate.name);
      if (!rightByName.has(candidateName)) {
        rightByName.set(candidateName, candidate.name);
      }
    }

    return rightByName;
  }

  private createAutoMappings(left: MappingVariable[], rightByName: Map<string, string>): Record<string, string> {
    const mappedRightNames = new Set<string>();
    const autoMappings: Record<string, string> = {};

    for (const leftVariable of left) {
      const leftName = this.trimName(leftVariable.name);
      const rightMatchName = rightByName.get(leftName);
      if (!rightMatchName || mappedRightNames.has(rightMatchName)) {
        continue;
      }

      autoMappings[leftVariable.name] = rightMatchName;
      mappedRightNames.add(rightMatchName);
    }

    return autoMappings;
  }

  private trimName(value: string): string {
    return value.trim();
  }
}
