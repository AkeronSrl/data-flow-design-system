import {
  mapVulkiTagsToSchemaDiscoveryNodes,
  VulkiSchemaSelectionData,
} from '@alkyra/ui/schema-discovery/mappers/vulki-schema-discovery.mapper';
import {
  SchemaDiscoveryNode,
  SchemaDiscoverySelectionEvent,
} from '@alkyra/ui/schema-discovery/models/schema-discovery.model';
import { SchemaDiscoveryComponent } from '@alkyra/ui/schema-discovery/schema-discovery.component';
import {
  VulkiSwaggerFieldDetail,
  VulkiSwaggerOperation,
  VulkiSwaggerTagGroup,
} from '@alkyra/vulki-connector/models/vulki-connection-test-result.model';
import { VulkiField, VulkiVersionSelection } from '@alkyra/vulki-connector/models/vulki-connector.model';
import { ChangeDetectionStrategy, Component, computed, EventEmitter, Input, Output, signal } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';

@Component({
  selector: 'alk-vulki-preview-tree',
  templateUrl: './vulki-preview-tree.component.html',
  styleUrl: './vulki-preview-tree.component.scss',
  standalone: true,
  imports: [SchemaDiscoveryComponent, TranslatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class VulkiPreviewTreeComponent {
  private readonly _items = signal<VulkiSwaggerTagGroup[]>([]);
  readonly selectedTagId = signal<string | null>(null);
  readonly schemaNodes = computed<SchemaDiscoveryNode[]>(() =>
    mapVulkiTagsToSchemaDiscoveryNodes(this._items(), {
      selectableVersions: this.selectableVersions,
      showFieldNodes: this.showFieldNodes,
      showOperationDescription: this.showOperationDescription,
    }),
  );

  @Input()
  selectableVersions: boolean = false;

  @Input()
  showFieldNodes: boolean = true;

  @Input()
  showVersionCheck: boolean = true;

  @Input()
  showOperationDescription: boolean = false;

  @Input()
  showFieldsPanel: boolean = true;

  @Input()
  set items(value: VulkiSwaggerTagGroup[] | null | undefined) {
    this._items.set(value ?? []);
    this.selectedTagId.set(null);
  }

  @Output()
  versionSelected = new EventEmitter<VulkiVersionSelection | null>();

  onNodeSelected(event: SchemaDiscoverySelectionEvent): void {
    if (!this.isSelectableTagNode(event.node)) {
      return;
    }

    this.selectedTagId.set(event.nodeId);
    this.versionSelected.emit(
      this.buildSelectionFromNode(event.node.data as VulkiSchemaSelectionData, event.node.label),
    );
  }

  onNodeClicked(event: SchemaDiscoverySelectionEvent): void {
    if (!this.isSelectableTagNode(event.node)) {
      return;
    }

    if (this.selectedTagId() === event.nodeId) {
      this.selectedTagId.set(null);
      this.versionSelected.emit({ name: '', version: '', fields: [], path: '' });
      return;
    }
  }

  private buildSelectionFromNode(selectionData: VulkiSchemaSelectionData, label: string): VulkiVersionSelection {
    const { latestVersion, fields, tagGroup } = selectionData;
    return {
      name: label,
      version: latestVersion?.version ?? '',
      fields: this.toVulkiFields(fields),
      ...this.resolveVersionPaths(latestVersion?.operations),
      tagKind: tagGroup.tagKind,
      dataloaderColumns: tagGroup.dataloaderColumns,
      dataloaderSupportedStrategies: tagGroup.dataloaderSupportedStrategies,
      dataloaderDefinitionId: tagGroup.dataloaderDefinitionId,
    };
  }

  private resolveVersionPaths(
    operations: VulkiSwaggerOperation[] | undefined,
  ): Pick<VulkiVersionSelection, 'path' | 'operations'> {
    const ops = operations ?? [];
    return {
      path: ops[0]?.path ?? '',
      operations: ops.map((op) => ({ path: op.path })),
    };
  }

  isTagSelected(tagId: string): boolean {
    return this.selectedTagId() === tagId;
  }

  private toVulkiFields(fields: VulkiSwaggerFieldDetail[]): VulkiField[] {
    return fields.map((field) => ({
      name: field.name,
      tipo: field.type,
      required: field.required,
    }));
  }

  private isSelectableTagNode(node: SchemaDiscoveryNode): boolean {
    return this.selectableVersions && node.kind === 'entity' && node.selectable === true;
  }
}
